# ASCEND 18.18.0 — UX Psychology Update

## Intent
Apply the observable UX lessons in the user-supplied video *The UX Psychology Behind Apps People Can’t Stop Using* to make ASCEND easier to understand, more personal, and more comfortable to use. The implementation favours user agency and useful habit support over manipulative engagement.

## Changes
- Added four home experiences: Focus, Balanced, Progress, and Minimal. Each changes which dashboard cards appear.
- Added independent switches for the Coach, Standing, Next quest, and Daily transmission cards.
- Moved detailed operating-system and appearance controls into a collapsed “Fine-tune your workspace” section. The full hybrid OS personalisation remains available.
- Added a small live preview label showing the chosen home layout.
- Added a five-step visual progress bar and contextual step text to first-run setup.
- Reworded the optional goal step so skipping does not imply failure or shame.
- Clarified full-screen reminder wording and softened the welcome copy.
- Dashboard layout preferences are stored in the active hunter’s `prefs.ui` settings.

## Video-derived observations used
The visible examples include a “Too many options” / “Decision fatigue” screen; onboarding questions that identify a user's goal; progress indicators; profile and palette selection; a product-page critique highlighting weak hierarchy and unclear size/value choices; a section explicitly labelled “Loss Aversion”; a “status quo bias” example; and an optional protection offer that presents benefits, price, cancellation terms, and a Skip control.

ASCEND applies the user-centred implications: present a small number of useful starting choices, personalise around the user's stated goals, show progress clearly, give important information visual priority, explain settings in plain language, and keep optional controls genuinely optional. The video also shows pressure-based urgency and fear prompts; those are not copied. ASCEND does not fabricate scarcity, threaten data loss, hide skip controls, or use shame to drive return visits.

## Verification
- All JavaScript files under `system/` passed `node --check`.
- Workspace preference logic: 7 focused assertions passed (defaults, presets, persistence, individual card filtering and custom layout).
- HTML parser check: passed; 387 IDs with no duplicates; 4 layout presets; 4 card controls; advanced options collapsed by default; onboarding progressbar present.
- Offline suite: 15/15 passed (82 app assets in the service-worker cache).
- Backend integration: 18/18 passed.
- Secret scan: 4/4 passed.
- Full test runner/build checks could not complete in this environment: it runs Node 22.16.0, below the project minimum 22.22.2, and the extracted project does not include `esbuild`, `acorn`, `jsdom` and `fake-indexeddb`. The failures are environment/dependency blockers, not reported as passing tests.
