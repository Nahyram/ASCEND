# UX Psychology in ASCEND

This document records the design decisions made from the uploaded UXPeak video and how they are implemented in ASCEND. The video was reviewed visually at regular intervals, with close inspection of the examples around decision fatigue, onboarding, progress, product-page hierarchy, loss aversion, status quo bias and optional offers. This is a visual review, not a verbatim transcript of the spoken narration.

## 1. Reduce decision fatigue
**Observed:** A screen explicitly says “Too many options!” and labels the issue “Decision fatigue.”

**ASCEND:** Settings now lead with four clear home experiences—Focus, Balanced, Progress and Minimal. Detailed OS style, navigation, colour and motion controls are available in a collapsed advanced section rather than competing for attention immediately.

## 2. Personalise around a real user goal
**Observed:** The video shows onboarding asking “What’s your main goal?” and later allowing a profile and colour palette to be designed.

**ASCEND:** The existing setup already captures a first goal. The workspace now allows a user to choose the dashboard emphasis that best supports their work, and all details can be changed later.

## 3. Make progress visible
**Observed:** Onboarding and course examples use visible step counts and segmented progress indicators.

**ASCEND:** First-run setup has a five-step progress bar, accessible progress semantics and a short caption explaining the current step.

## 4. Establish visual hierarchy
**Observed:** The product-page critique calls out that title, price, description, size and purchase controls have the same visual weight, making important information hard to find.

**ASCEND:** Dashboard content is grouped into named cards, and users can keep the cards they use most. The first-level settings screen presents only the highest-value choices; details are progressively disclosed.

## 5. Explain value and preserve choice
**Observed:** An optional device-protection offer lists its benefits and full monthly price, states cancellation terms, and presents a visible Skip action.

**ASCEND:** Home card descriptions state what each module does. The goal step is explicitly optional. Reminder controls are described in plain terms.

## 6. Avoid coercive dark patterns
**Observed:** The video also displays examples labelled “Loss Aversion” and “status quo bias,” including a fear-based imminent-deletion message.

**ASCEND policy:** Do not imitate fabricated urgency, countdown pressure, threats, fake scarcity, confusing cancellation, hidden skip actions, or shame-based notifications. Encourage progress with clear feedback, meaningful goals, and user-controlled reminders—not anxiety or compulsive loops.

## Preferences and persistence
Home layout and visible dashboard cards are stored with the existing per-hunter UI preferences. Resetting workspace design restores interface defaults only; it does not delete goals, quests, records, or learning data.
