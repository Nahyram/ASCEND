# ASCEND 18.17.0 — Hybrid Workspace Design

## Design direction

The ASCEND workspace now combines three familiar desktop and tablet interaction patterns without trying to reproduce any operating system literally:

- **Windows 11:** a translucent Mica-style navigation rail, rounded surfaces and layered depth.
- **iPadOS:** a floating, touch-friendly dock and a responsive content canvas.
- **macOS:** subtle window controls, a quiet titlebar and a centred glass dock.

The default **ASCEND Hybrid** profile combines the left navigation rail with the floating dock. The shell adapts to tablet and mobile widths, where the rail is replaced by the dock.

## Personalisation

Open **System → Settings** and use **Workspace Design Studio**. The selected options preview immediately and save automatically to the active hunter's preferences.

Users can customise:

- Starting profile: ASCEND Hybrid, Windows 11, iPadOS or macOS.
- Navigation: sidebar and dock, sidebar only, or dock only.
- Dock location: bottom, left or right; dock labels on or off.
- Workspace spacing and text size.
- Dark, OLED black, light or device-matched colour mode.
- Window material: Mica, glass or solid.
- Corner radius and accent colour, including a custom colour.
- Background presets or an uploaded image.
- Reduced motion.

**Reset workspace design** restores the default interface only. It does not alter quests, goals, records, progression or study material.

## Persistence and privacy

Interface choices are stored in the active hunter's `prefs.ui` record. A custom wallpaper is resized before saving and remains in browser-local storage for that hunter; it is not included in the cloud-synced hunter record. The workspace continues to work offline.

## Files changed

- `system/index.html` — workspace controls, window chrome and stylesheet reference.
- `system/styles/08-hybrid-os.css` — hybrid OS visual system and responsive layouts.
- `system/views/core-views.js` — preference application, persistence, wallpaper handling and reset behavior.
- `system/sw.js` — offline precache entry for the new stylesheet.
- `package.json`, `package-lock.json`, `system/src/app/version.js`, `system/sw.js`, `system/manifest.json` — release identity advanced to 18.17.0 so installed clients invalidate the previous cache.

## Verification

- JavaScript syntax and page-asset checks: passed.
- Offline service-worker suite: 15 checks passed, including 82 cached page assets.
- Backend integration suite: 18 checks passed.
- Secret scan: 4 checks passed.
- Release identity: consistent at 18.17.0. The local test environment runs Node 22.16.0, below the project's declared minimum of Node 22.22.2; the release test reports that environment mismatch.
- The full suite could not complete because this extracted project does not include its declared development dependencies (`jsdom`, `acorn`, `esbuild` and `fake-indexeddb`).

## UX Psychology additions (18.18.0)

The Settings landing now starts with four home experiences (Focus, Balanced, Progress and Minimal), while detailed OS and appearance settings are collapsed under **Fine-tune your workspace**. Users can also show or hide individual home cards. Preferences are saved per hunter.

First-run setup now shows a five-step progress bar and explains the current step. Optional goal capture is described as optional, without shame language.

These changes apply the video’s visible lessons about decision fatigue, goal-led onboarding, visible progress, clear hierarchy and transparent optional offers. ASCEND deliberately avoids fear-based urgency, fake scarcity, threats, shame prompts or hidden opt-outs. See `UX-PSYCHOLOGY-DESIGN.md` for the source-derived observations and implementation map.
