/* THE SYSTEM v18 — offline service worker.
   The precache list is generated from index.html, so a new module cannot
   be added to the app and forgotten here.
   Caches everything on first visit. After that the app never needs the network.

   ## Versioning and cache invalidation

   VERSION is the release identity and must equal SYSTEM_VERSION in
   app/version.js and "version" in package.json. offline-test.js reads all
   three and fails if they disagree, because this build shipped with the cache
   still named "system-v17" while calling itself v18 — and a cache name that
   does not change is a cache that never invalidates. The old entries survive
   activate(), files dropped from the app keep being served, and a student who
   downloaded the new release runs the old one.

   Two mechanisms, both needed:

   1. The cache NAME carries the version, so activate() deletes every cache
      that is not this release's. That retires whole releases.
   2. Precaching requests each file with cache:"reload", which bypasses the
      browser's own HTTP cache. Without it, cache.add() is allowed to satisfy
      itself from a stale heuristically-cached copy, so a new service worker
      can faithfully install last week's JavaScript into a correctly-named
      new cache. That retires individual files. */
const VERSION = "18.18.0";
const CACHE = "system-v" + VERSION;
const FILES = [
  "./", "./index.html", "./bundle.js", "./manifest.json", "./icon-32.png", "./icon-192.png",
  "./icon-512.png", "./icon-maskable.png", "./apple-touch-icon.png", "./styles/01-tokens.css", "./styles/02-panel.css",
  "./styles/03-shell.css", "./styles/04-views.css", "./styles/05-modules.css",
  "./styles/06-v13.css", "./styles/07-v14.css", "./styles/08-hybrid-os.css", "./online.js", 
  "./services/progression.js", "./services/penalty.js", "./ui/boot-auth.js",
  "./ui/onboarding.js", "./app/legacy-shell.js", "./services/vacation.js", "./services/day.js", "./services/settings.js", "./views/core-views.js",
  "./views/growth.js", "./services/tutor.js", "./views/tutor.js", "./services/transfer.js", "./services/clock.js",
  "./services/audio.js", "./ui/toast.js", "./views/wealth.js",
  "./views/access.js", "./services/security.js",
  "./views/why.js",
  "./views/v9-views.js", "./app/net.js", "./content/merge.js", "./views/shelves.js",
  "./views/forge.js", "./views/arena.js", "./ui-v11.js", "./ui/dialog.js",
  "./services/coach.js", "./services/model.js", "./services/patterns.js", "./services/goals.js",
  "./services/adaptive.js", "./services/recommend.js", "./services/briefing.js",
  "./services/ai.js", "./services/records.js", "./services/world.js",
  "./services/curriculum.js", "./services/practice.js", "./services/exams.js",
  "./services/cloud.js", "./services/api.js", "./services/opportunities.js",
  "./services/projects.js", "./services/evidence.js", "./services/scholarships.js", "./services/verification.js",
  "./services/device.js", "./services/integrity.js", "./services/perf.js",
  "./services/community.js", "./services/entitlements.js", "./services/business.js", "./services/launch.js",
  "./services/journey.js", "./services/link.js", "./views/home.js", "./views/insight.js", "./views/brain.js",
  "./views/progression.js", "./views/academy.js", "./views/beyond.js", "./views/build.js",
  "./views/gate.js", "./views/apply.js", "./views/frontier.js", "./ui/palette.js",
  "./app/router.js", "./app/wiring.js", "./assets/art-hunter.jpg", "./assets/brand-logo.jpg",
  "./assets/brand-poster.jpg", "./assets/quest-window.jpg", "./assets/quote-focus.jpg",
  "./assets/quote-never-give-up.jpg", "./assets/ascend-lockup.webp"
];

/* No skipWaiting() here. A worker that skips waiting never becomes a *waiting*
   worker, so device.js's updateWaiting() stayed false for ever, the update
   prompt could never appear, and the new build took over mid-session — the
   exact takeover the message handler at the foot of this file exists to
   prevent. The user asks; then we skip. (Phase 13 §59.)

   addAll() is atomic: one 404 or one dropped request and *nothing* is cached,
   leaving the app silently online-only. Offline is this product's central
   promise, so the shell is required and the rest is best-effort — a hunter who
   loses one shelf image offline is in better shape than one who loses the app. */
const SHELL = ["./", "./index.html", "./manifest.json"];

/* cache:"reload" on every precache request. See the versioning note at the top:
   without it a new worker may install stale bytes into a fresh cache. */
const fresh = f => new Request(f, { cache: "reload" });

self.addEventListener("install", e => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    /* The shell is required. If it cannot be cached the install fails, the old
       worker stays in control, and the student keeps a working app rather than
       being handed a half-installed one. */
    await c.addAll(SHELL.map(fresh));
    const rest = FILES.filter(f => !SHELL.includes(f));
    const failed = [];
    await Promise.all(rest.map(f => c.add(fresh(f)).catch(() => failed.push(f))));
    if (failed.length) console.warn("SW: precache incomplete —", failed.length, "file(s) missing offline:", failed);
    /* Recorded so offlineAudit() can report what actually happened rather than
       assuming a clean install. A partial precache is the case where the app
       looks fine online and fails offline, which is the failure this product
       can least afford to discover in the field. */
    await c.put("__precache-report", new Response(JSON.stringify({
      version: VERSION, at: Date.now(), expected: FILES.length,
      cached: FILES.length - failed.length, failed,
    }), { headers: { "Content-Type": "application/json" } }));
  })());
});

self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
  ).then(() => self.clients.claim()));
});

self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  /* v11: the Online Gate talks to public catalogues. Those responses are
     handled by the app's own IndexedDB cache and must never enter the
     offline shell cache — otherwise a stale API answer outlives the app. */
  const url = new URL(e.request.url);
  if (url.origin !== self.location.origin) return;
  e.respondWith(
    caches.match(e.request).then(hit => hit || fetch(e.request).then(res => {
      const copy = res.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy)).catch(() => {});
      return res;
    }).catch(() => e.request.mode === "navigate" ? caches.match("./index.html") : Response.error()))
  );
});

/* Quest notifications fired from the page still work while the app is open or
   backgrounded on Android. See README for what the web platform can and cannot do. */
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil(clients.matchAll({ type: "window" }).then(list => {
    for (const c of list) if ("focus" in c) return c.focus();
    if (clients.openWindow) return clients.openWindow("./index.html");
  }));
});

/* Phase 13 §59 — a waiting worker activates only when the user asks. A silent
   takeover mid-session is how work in an open form gets lost. */
self.addEventListener("message", e => {
  if(!e.data) return;
  if(e.data.type === "SKIP_WAITING") self.skipWaiting();
  /* offlineAudit() asks the worker which release it is rather than inferring it
     from a cache name it found by guessing. */
  if(e.data.type === "VERSION" && e.ports && e.ports[0]){
    e.ports[0].postMessage({ version: VERSION, cache: CACHE, files: FILES.length });
  }
});
