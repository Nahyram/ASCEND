/* THE SYSTEM v13 — views/core-views.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- render ---------- */
/* v18.1: the body is now the private base and renderAll is a dispatcher.
   Five other files used to reassign this name to wrap it; they register with
   Hooks instead, so this binding never changes and can become an ES export. */
function renderAll(){ return Hooks.dispatch("renderAll", renderAllBase, this, arguments); }
function renderAllBase(){ renderStatus(); renderQuests(); renderTrain(); renderDead(); renderRecords(); renderSettings(); renderTutor(); renderGoals(); renderVault(); renderCodex(); renderLore(); renderQuote(); renderWealthAdvice(); renderLessons(); renderLibrary(); renderWall(); renderAccess(); }

function renderStatus(){
  const h = H();
  $("#stAvatar").src = h.avatar || DEFAULT_AVATAR;
  $("#stName").textContent = h.name;
  $("#stTitle").textContent = `${rankName(h.rank)} · ${h.title} · ${(CURRICULA[h.curriculum]||CURRICULA.igcse).label}`;
  $("#stRank").textContent = h.rank;
  $("#stLvl").textContent = h.level;
  const need = xpNeeded(h.level);
  $("#stXp").textContent = `${h.xp} / ${need} XP`;
  $("#stXpBar").style.width = Math.min(100, h.xp/need*100) + "%";
  const max = Math.max(20, ...STAT_KEYS.map(k=>h.stats[k]));
  $("#stats").innerHTML = STAT_KEYS.map(k =>
    `<div class="stat"><b>${k}</b><div class="bar"><i style="width:${h.stats[k]/max*100}%"></i></div><span>${h.stats[k]}</span></div>`
  ).join("") + `<p class="tiny muted" style="margin-top:8px">${STAT_KEYS.map(k=>`${k} = ${STAT_LABEL[k]}`).join(" · ")}</p>`;
  const qs = questsFor(), dn = qs.filter(isDone).length;
  $("#kStreak").textContent = h.streak;
  $("#kToday").textContent = qs.length ? Math.round(dn/qs.length*100)+"%" : "—";
  $("#kTotal").textContent = h.totalCleared;

  const open = h.penalties.filter(p=>!p.done);
  $("#penaltyPanel").classList.toggle("hidden", !open.length);
  $("#penaltyList").innerHTML = open.map(p =>
    `<div class="quest missed"><div class="q-body"><span class="q-name">${esc(p.text)}</span>
      <span class="q-meta">${esc(p.reason)}</span></div>
      <button class="btn sm danger" data-pen="${p.id}">Serve</button></div>`).join("");
  $$("[data-pen]").forEach(b => b.onclick = () => {
    const p = h.penalties.find(x=>x.id===b.dataset.pen); p.done = true;
    grantStat("discipline",1); save(); toast("Penalty served","The debt is cleared.","gold"); renderAll();
  });

  const now = nowMin(), nx = questsFor().find(q => toMin(q.time) > now && !isDone(q));
  $("#nextQuest").innerHTML = nx
    ? `<div class="quest now"><span class="q-time">${fmt12(nx.time)}</span>
        <div class="q-body"><span class="q-name">${esc(nx.name)}</span>
        <span class="q-meta"><span class="tag t-${nx.cat}">${nx.cat}</span> · in ${toMin(nx.time)-now} min · ${nx.xp} XP</span></div></div>`
    : `<p class="muted tiny">All quests cleared. Rest is authorised — recovery is part of the build, not a reward.</p>`;
}

function renderQuests(){
  const h = H(), qs = questsFor(), now = nowMin();
  $("#qDay").textContent = new Date().toLocaleDateString(undefined,{weekday:"long", day:"numeric", month:"short"});
  const dnq = qs.filter(isDone).length;
  $("#qCount").textContent = qs.length ? `GOALS [${dnq}/${qs.length}]` : "";
  $("#qCount").classList.toggle("clear", qs.length > 0 && dnq === qs.length);
  const box = $("#questList"); box.innerHTML = "";
  if(!qs.length){ box.innerHTML = `<p class="muted tiny">No quests scheduled for today.</p>`; }
  qs.forEach(q => {
    const done = isDone(q), start = toMin(q.time);
    const el = document.createElement("div");
    el.className = "quest" + (done?" done":"") + (!done && now>=start && now<start+60 ? " now":"") + (!done && now>start+60 ? " missed":"");
    el.innerHTML = `<span class="q-time">${fmt12(q.time)}</span>
      <div class="q-body"><span class="q-name">${q.mand?`<span class="qb">[</span>`:""}${esc(q.name)}${q.mand?`<span class="qb">]</span>`:""}</span>
        <span class="q-meta"><span class="tag t-${q.cat}">${q.cat}</span> · ${q.xp} XP${q.mand?" · mandatory":""}</span></div>
      <button class="q-check">✓</button>`;
    el.querySelector(".q-check").onclick = () => toggleQuest(q);
    box.appendChild(el);
  });
  // spotify
  const sp = $("#spotifyWrap");
  if(h.spotify && /open\.spotify\.com/.test(h.spotify)){
    const embed = h.spotify.replace("open.spotify.com/","open.spotify.com/embed/").split("?")[0];
    sp.innerHTML = navigator.onLine
      ? `<iframe style="border-radius:2px;border:1px solid rgba(56,214,255,.3)" src="${esc(embed)}" width="100%" height="152" frameborder="0" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>`
      : `<p class="tiny muted">Offline. Spotify will load when you reconnect — use the focus tone below in the meantime.</p>`;
  } else sp.innerHTML = `<p class="tiny muted">Add a Spotify playlist link in Settings to load it here when you're online.</p>`;
}

function renderTrain(){
  const h = H();
  $("#trPath").textContent = (WORKOUTS[h.workout]||WORKOUTS.mixed).label;
  $("#trDiff").textContent = ["","Novice","Standard","Brutal"][Number(h.diff)];
  $("#trDiffSel").value = h.diff;
  $("#trWorkout").innerHTML = Object.entries(WORKOUTS).map(([k,v]) =>
    `<button class="chip ${h.workout===k?"on":""}" data-tw="${k}">${v.label}</button>`).join("");
  $$("[data-tw]").forEach(b => b.onclick = () => { H().workout = b.dataset.tw; H().reroll = 0; save(); renderTrain(); });
  $("#trDiffSel").onchange = e => { H().diff = e.target.value; save(); renderTrain(); };

  const w = makeWorkout(), key = todayKey(), doneToday = h.workoutDone[key];
  const box = $("#workoutList");
  if(w.rest){ box.innerHTML = `<p class="muted">Rest day. Recovery is part of the training — the System does not reward you for breaking it.</p>`; return; }
  box.innerHTML = w.moves.map(m =>
    `<div class="quest ${doneToday?"done":""}"><div class="q-body"><span class="q-name">${esc(m.name)}</span>
      <span class="q-meta"><span class="tag t-body">body</span></span></div>
      <b style="font-family:var(--display);font-size:18px;color:var(--mana)">${m.target}</b></div>`).join("")
    + `<p class="tiny muted" style="margin-top:8px">Reward: +40 XP, +2 STR, +1 VIT. Skipping this is a mandatory-quest miss.</p>`;
  $("#btnWorkoutDone").disabled = !!doneToday;
  $("#btnWorkoutDone").textContent = doneToday ? "Training complete" : "Complete training";
}
$("#btnWorkoutDone").onclick = () => {
  const h = H(), k = todayKey();
  if(h.workoutDone[k]) return;
  h.workoutDone[k] = true;
  h.stats.STR += 2; h.stats.VIT += 1; grantXp(40, "Training quest", "body");
  toast("Training complete","+40 XP · +2 STR · +1 VIT","gold");
  save(); renderAll();
};
$("#btnWorkoutReroll").onclick = () => { H().reroll = (H().reroll||0)+1; save(); renderTrain(); toast("Rerolled","A new training quest has been issued."); };

function renderDead(){
  const h = H(), box = $("#deadList");
  const items = [...h.deadlines].sort((a,b)=>a.date.localeCompare(b.date));
  if(!items.length){ box.innerHTML = `<p class="muted tiny">No timed quests registered. Add exams, mocks and submissions below — the System will count down.</p>`; return; }
  const today = new Date(); today.setHours(0,0,0,0);
  box.innerHTML = items.map(d => {
    const dd = Math.ceil((new Date(d.date+"T00:00:00") - today)/86400000);
    const cls = dd < 0 ? "over" : dd <= 7 ? "soon" : "";
    const w = ["","Normal","Important","S-RANK"][Number(d.weight)];
    return `<div class="dl ${cls}"><div class="days-left">${dd<0?"—":dd}</div>
      <div style="flex:1"><div>${esc(d.name)}</div>
        <div class="tiny muted">${d.date} · ${w} · ${dd<0?"overdue":dd===0?"due today":dd+" days left"}</div></div>
      <button class="btn sm ghost" data-dld="${d.id}">Done</button>
      <button class="btn sm danger" data-dlx="${d.id}">✕</button></div>`;
  }).join("");
  $$("[data-dld]").forEach(b => b.onclick = () => {
    const d = h.deadlines.find(x=>x.id===b.dataset.dld);
    grantXp(50*Number(d.weight), d.name); grantStat("study", Number(d.weight));
    h.deadlines = h.deadlines.filter(x=>x.id!==d.id); save();
    toast("Timed quest cleared", `+${50*Number(d.weight)} XP`, "gold"); renderAll();
  });
  $$("[data-dlx]").forEach(b => b.onclick = () => { h.deadlines = h.deadlines.filter(x=>x.id!==b.dataset.dlx); save(); renderDead(); });
}
$("#dlAdd").onclick = () => {
  const n = $("#dlName").value.trim(), d = $("#dlDate").value;
  if(!n || !d) return toast("Incomplete","A timed quest needs a name and a due date.","blood");
  H().deadlines.push({id:uid(), name:n, date:d, weight:$("#dlWeight").value});
  $("#dlName").value = ""; save(); renderDead(); toast("Registered","The countdown has begun.");
};

function renderRecords(){
  const h = H(), heat = $("#heat"); heat.innerHTML = "";
  const rows = [];
  for(let i=89;i>=0;i--){
    const d = new Date(); d.setDate(d.getDate()-i);
    const k = todayKey(d), done = Object.keys(h.done[k]||{}).length;
    const total = h.quests.filter(q=>q.days.includes(d.getDay())).length || 1;
    const r = Math.min(1, done/total);
    const cell = document.createElement("i");
    cell.style.background = r ? `rgba(56,214,255,${0.12 + r*0.75})` : "rgba(56,214,255,.05)";
    if(r) cell.style.boxShadow = `0 0 ${Math.round(r*10)}px rgba(56,214,255,${r*.6})`;
    cell.title = `${k} — ${done}/${total}`;
    heat.appendChild(cell);
    if(done) rows.push({k, done, total, rate: Math.round(r*100)});
  }
  $("#logBody").innerHTML = rows.reverse().slice(0,30).map(r =>
    `<tr><td>${r.k}</td><td>${r.done} / ${r.total}</td><td>${r.rate}%</td><td>—</td></tr>`).join("")
    || `<tr><td colspan="4" class="muted tiny">No record yet. Clear a quest.</td></tr>`;
}

function renderSettings(){
  const h = H();
  $("#setAvatar").src = h.avatar || DEFAULT_AVATAR;
  $("#setName").value = h.name; $("#setTitle").value = h.title; $("#setSpotify").value = h.spotify || "";
  $("#setCur").value = h.curriculum || "igcse";
  $("#setAI").value = h.aiEndpoint || "";
  $("#setPenalty").value = h.penaltyMode; $("#setAlarm").value = h.alarmMode;
  $("#setAutoLock").value = String(h.autoLockMin||0);
  $("#cPayLink").value = DB.store.payLink; $("#cBlurb").value = DB.store.blurb;
  $("#cCount").value = DB.store.countEndpoint || "";
  renderSetQuests();
  if(typeof renderPersonalization === "function") renderPersonalization();
}
function renderSetQuests(){
  const h = H(), box = $("#setQuests"); box.innerHTML = "";
  h.quests.sort((a,b)=>a.time.localeCompare(b.time)).forEach(q => box.appendChild(questEditor(q, h, () => { save(); renderSetQuests(); renderQuests(); })));
}
$("#sqAdd").onclick = () => {
  const t = $("#sqTime").value, n = $("#sqName").value.trim();
  if(!t || !n) return toast("Incomplete","A quest needs a time and a name.","blood");
  H().quests.push({id:uid(), time:t, name:n, cat:$("#sqCat").value, days:WD, mand:false, xp:15});
  $("#sqName").value=""; save(); renderSetQuests(); renderQuests();
};
$("#setPhoto").onchange = e => { if(e.target.files[0]) readPhoto(e.target.files[0], d => { H().avatar = d; save(); renderStatus(); renderSettings(); toast("Photo updated",""); }); };
/* v18: the validation moved to services/settings.js. This reads the form and
   reports the outcome — including the refusals, which the previous version
   swallowed. An invalid AI endpoint used to be silently deleted and then
   announced as "Saved", which is the app telling the student the opposite of
   what it did. */
$("#setSave").onclick = () => {
  const res = applyHunterSettings({
    name:        $("#setName").value,
    title:       $("#setTitle").value,
    curriculum:  $("#setCur").value,
    aiEndpoint:  $("#setAI").value,
    spotify:     $("#setSpotify").value,
    penaltyMode: $("#setPenalty").value,
    alarmMode:   $("#setAlarm").value,
    autoLockMin: $("#setAutoLock").value,
  });
  renderAll();
  const o = settingsOutcome(res);
  toast(o.title, o.body, o.tone);
};
$("#cSave").onclick = () => {
  const res = applyStorefront({
    payLink:       $("#cPayLink").value,
    blurb:         $("#cBlurb").value,
    countEndpoint: $("#cCount").value,
  });
  renderSettings(); renderAccess(); pingCount();
  const o = settingsOutcome(res);
  toast(res.rejected.length ? o.title : "Storefront saved",
        res.rejected.length ? o.body : "Buyers will see this under \u25c6 Access.",
        res.rejected.length ? "blood" : "gold");
};
/* v8: random access keys. The key goes to the buyer; the HASH goes into KEY_HASHES before deploying. */
$("#cKeyGo").onclick = async () => {
  const n = $("#cKeyName").value.trim();
  if(!n) return toast("Name required","Enter the buyer's hunter name.","blood");
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const r = crypto.getRandomValues(new Uint8Array(12));
  const s = [...r].map(b => A[b % A.length]).join("");
  const key = `SYS-${s.slice(0,4)}-${s.slice(4,8)}-${s.slice(8,12)}`;
  const hash = await sha256hex(key);
  $("#cKeyOut").innerHTML = `<b>${esc(n)}</b> → <b>${key}</b><br>` +
    `<span class="muted">Send the key to the buyer. Then add this hash to KEY_HASHES in index.html before shipping their copy:</span><br>"${hash}"`;
};
/* v18: the redemption itself moved to services/entitlements.js. What is left
   here is the form. The takeover copy changed too, and the change matters more
   than it looks: "FULL ACCESS GRANTED / All features unlocked" claimed both a
   verification that never happened and a set of locked features that does not
   exist — every learning feature is free by rule, so there was nothing to
   unlock. Overstating a gate to a paying student is the same lie as
   overstating it to a developer, and the developer at least can read the code. */
$("#keyGo").onclick = async () => {
  const raw = $("#keyInput").value.trim().toUpperCase();
  if(!raw) return;
  if(!KEY_HASHES.length) return toast("No keys installed","The creator hasn't added access keys to this build yet.","blood");
  const hash = await sha256hex(raw);
  if(!KEY_HASHES.includes(hash)) return toast("Invalid key","That key isn't recognised.","blood");
  DeviceEntitlements.grant();
  renderSettings();
  const posture = entitlementPosture();
  takeover({
    kind:"unlock",
    title:"KEY RECORDED",
    sub:"Thank you for backing the creator. " + posture.detail,
    reward:"Recorded on this device",
  });
};
$("#setPinGo").onclick = async () => {
  const h = H(), v = $("#setPin").value.trim();
  if(v && !/^\d{4,6}$/.test(v)) return toast("PIN invalid","Use 4 to 6 digits, or leave blank to remove the lock.","blood");
  await setPinFor(h, v);
  $("#setPin").value = "";
  save();
  toast(v ? "PIN updated" : "PIN removed", v ? "Hardened and stored on this device only." : "This hunter now opens without a lock.", "gold");
};
$("#btnNotif").onclick = async () => {
  if(!("Notification" in window)) return toast("Unsupported","This device can't do notifications.","blood");
  const p = await Notification.requestPermission();
  toast(p === "granted" ? "Notifications on" : "Notifications blocked", p === "granted" ? "Quests can now reach you in the background." : "Enable them in your browser settings.", p==="granted"?"gold":"blood");
};
/* Named, and on window, because the Gate's "Export everything" button called an
   exportHunter() that had never existed — guarded by a typeof check, so it
   silently fell through to go("set") instead of exporting anything. One
   implementation, two buttons. */
window.exportHunter = async function(){
  const h = H();
  /* v18.1: the payload carries the release that wrote it.
     Until now it was {type, hunter, store} and nothing else — no version, no
     schema, no date. A file exported today and imported into a future release
     gave the importer nothing to migrate FROM: it could only guess the shape
     from the fields present, which is how silent data loss starts. The import
     side reads d.hunter and ignores unknown keys, so older files still open;
     this only adds. */
  let payload = {
    type: "system.hunter",
    app: (typeof systemBuild === "function" ? systemBuild() : { version: "unknown", schema: null }),
    exportedAt: new Date().toISOString(),
    hunter: h,
    store: DB.store,
  };
  if($("#expEncrypt").checked){
    const pass = await sysPrompt("Passphrase for this export",
      {msg:"You will need it to import the file again. There is no recovery.", inputType:"password", placeholder:"At least 6 characters", ok:"Encrypt & export"});
    if(!pass) return toast("Cancelled","No passphrase, no encrypted export.","blood");
    if(pass.length < 6) return toast("Too short","Use at least 6 characters.","blood");
    payload = await encryptExport(payload, pass);
  }
  const blob = new Blob([JSON.stringify(payload, null, 2)], {type:"application/json"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = `${h.name.replace(/\W+/g,"_")}_hunter.json`; a.click();
  toast("Exported", $("#expEncrypt").checked ? "Encrypted. Guard the passphrase — it is the only key." : "Open this file on your other device and import it.","gold");
};
$("#btnExport").onclick = () => exportHunter();


/* ---------- workspace personalisation ---------- */
/* ASCEND — workspace personalisation
   Per-hunter interface preferences. The workspace is presentation state only:
   changing it never edits quests, records, progression or study data. */
"use strict";

const UI_DEFAULTS = Object.freeze({
  profile:"hybrid", navigation:"hybrid", dockPosition:"bottom", dockLabels:true,
  density:"comfortable", fontSize:"normal", material:"mica", corners:"soft",
  wallpaper:"aurora", wallpaperData:"", accent:"#38d6ff", reduceMotion:false,
  homeLayout:"balanced", homeCards:["coach","standing","next","transmission"],
});
const UI_ALLOWED = {
  profile:["hybrid","windows","ipad","mac"],
  navigation:["hybrid","sidebar","dock"],
  dockPosition:["bottom","left","right"],
  density:["comfortable","compact","spacious"],
  fontSize:["small","normal","large"],
  material:["mica","glass","solid"],
  corners:["soft","round","square"],
  wallpaper:["aurora","midnight","frost","sunset","photo"],
  homeLayout:["focus","balanced","progress","minimal","custom"],
};

const UI_HOME_CARDS = Object.freeze(["coach","standing","next","transmission"]);
const UI_HOME_LAYOUTS = Object.freeze({
  focus:["coach","next"],
  balanced:["coach","standing","next","transmission"],
  progress:["standing","transmission"],
  minimal:["next"],
});

function uiWallpaperKey(){
  try{ return "ascend.workspace.wallpaper." + String(DB && DB.active || "local"); }
  catch(e){ return "ascend.workspace.wallpaper.local"; }
}
function readLocalWallpaper(){
  try{ return localStorage.getItem(uiWallpaperKey()) || ""; }catch(e){ return ""; }
}
function readUIPrefs(){
  const h = typeof H === "function" ? H() : null;
  const stored = h && h.prefs && h.prefs.ui && typeof h.prefs.ui === "object" ? h.prefs.ui : {};
  const out = { ...UI_DEFAULTS, ...stored };
  /* Personal photos remain local to this browser and are deliberately kept out
     of the cloud-synced hunter record. Interface choices still follow the user. */
  out.wallpaperData = readLocalWallpaper() || (typeof stored.wallpaperData === "string" ? stored.wallpaperData : "");
  for(const [k, allowed] of Object.entries(UI_ALLOWED)) if(!allowed.includes(out[k])) out[k] = UI_DEFAULTS[k];
  if(typeof out.accent !== "string" || !/^#[\da-f]{6}$/i.test(out.accent)) out.accent = UI_DEFAULTS.accent;
  if(typeof out.wallpaperData !== "string" || !out.wallpaperData.startsWith("data:image/")) out.wallpaperData = "";
  out.dockLabels = out.dockLabels !== false;
  out.reduceMotion = out.reduceMotion === true;
  if(!Array.isArray(stored.homeCards)) out.homeCards = [...(UI_HOME_LAYOUTS[out.homeLayout] || UI_HOME_LAYOUTS.balanced)];
  out.homeCards = [...new Set(out.homeCards.filter(k => UI_HOME_CARDS.includes(k)))];
  return out;
}

function applyUIPrefs(){
  const p = readUIPrefs(), root = document.documentElement;
  root.dataset.profile = p.profile;
  root.dataset.navigation = p.navigation;
  root.dataset.dockPosition = p.dockPosition;
  root.dataset.density = p.density;
  root.dataset.fontSize = p.fontSize;
  root.dataset.material = p.material;
  root.dataset.corners = p.corners;
  root.dataset.wallpaper = p.wallpaper;
  root.dataset.homeLayout = p.homeLayout;
  root.dataset.dockLabels = p.dockLabels ? "on" : "off";
  root.dataset.reduceMotion = p.reduceMotion ? "on" : "off";
  root.style.setProperty("--user-accent", p.accent);
  root.style.setProperty("--mana", p.accent);
  root.style.setProperty("--deep", p.accent);
  root.style.setProperty("--glow-m", p.reduceMotion ? "none" : `0 0 12px ${p.accent}55`);
  document.querySelectorAll("[data-home-card]").forEach(card => {
    const visible = p.homeCards.includes(card.dataset.homeCard);
    card.classList.toggle("hidden", !visible);
    card.setAttribute("aria-hidden", visible ? "false" : "true");
  });
  const body = document.body;
  if(body){
    if(p.wallpaper === "photo" && p.wallpaperData){
      body.style.backgroundImage = `linear-gradient(180deg,rgba(4,8,16,.38),rgba(4,8,16,.78)),url("${p.wallpaperData}")`;
      body.style.backgroundSize = "cover";
      body.style.backgroundPosition = "center";
      body.style.backgroundAttachment = "fixed";
    }else{
      body.style.removeProperty("background-image");
      body.style.removeProperty("background-size");
      body.style.removeProperty("background-position");
      body.style.removeProperty("background-attachment");
    }
  }
  return p;
}

function writeUIPrefs(patch, status=true){
  const h = typeof H === "function" ? H() : null;
  if(!h) return;
  if(!h.prefs || typeof h.prefs !== "object") h.prefs = {};
  if(!h.prefs.ui || typeof h.prefs.ui !== "object") h.prefs.ui = {};
  const next = { ...(patch || {}) };
  if(Object.prototype.hasOwnProperty.call(next, "wallpaperData")){
    try{
      if(next.wallpaperData) localStorage.setItem(uiWallpaperKey(), next.wallpaperData);
      else localStorage.removeItem(uiWallpaperKey());
      delete h.prefs.ui.wallpaperData;
    }catch(e){ h.prefs.ui.wallpaperData = next.wallpaperData || ""; }
    delete next.wallpaperData;
  }
  Object.assign(h.prefs.ui, next);
  applyUIPrefs();
  const ok = typeof save === "function" ? save() : false;
  const label = document.getElementById("uiSaveStatus");
  if(label && status){
    label.textContent = ok ? "Saved to this device" : "Preview only — storage unavailable";
    label.classList.toggle("saved", !!ok);
  }
  const photoStatus = document.getElementById("uiWallpaperStatus");
  if(photoStatus && h.prefs.ui.wallpaperData && h.prefs.ui.wallpaper === "photo") photoStatus.textContent = "Your background is saved on this device";
}

function syncUIPreview(p){
  const preview = document.getElementById("uiPreview");
  if(!preview) return;
  preview.dataset.profile = p.profile;
  preview.dataset.homeLayout = p.homeLayout;
  const layoutLabel = document.getElementById("uiPreviewLayout");
  if(layoutLabel) layoutLabel.textContent = p.homeLayout === "custom" ? "CUSTOM HOME" : p.homeLayout.toUpperCase() + " HOME";
  preview.style.setProperty("--preview-accent", p.accent);
  preview.classList.toggle("photo", p.wallpaper === "photo" && !!p.wallpaperData);
}

function renderPersonalization(){
  const panel = document.getElementById("workspaceCustomizer");
  if(!panel) return;
  const p = applyUIPrefs();
  const set = (id, value) => { const el = document.getElementById(id); if(el) el.value = value; };
  const check = (id, value) => { const el = document.getElementById(id); if(el) el.checked = !!value; };
  const profile = panel.querySelector(`input[name="uiProfile"][value="${p.profile}"]`);
  if(profile) profile.checked = true;
  set("uiNavigation", p.navigation); set("uiDockPosition", p.dockPosition);
  set("uiDensity", p.density); set("uiFont", p.fontSize); set("uiMaterial", p.material);
  set("uiCorners", p.corners); set("uiWallpaper", p.wallpaper); set("uiAccent", p.accent);
  check("uiDockLabels", p.dockLabels); check("uiReduceMotion", p.reduceMotion);
  check("uiHomeCoach", p.homeCards.includes("coach"));
  check("uiHomeStanding", p.homeCards.includes("standing"));
  check("uiHomeNext", p.homeCards.includes("next"));
  check("uiHomeTransmission", p.homeCards.includes("transmission"));
  panel.querySelectorAll("[data-home-layout]").forEach(button => {
    button.setAttribute("aria-pressed", String(button.dataset.homeLayout === p.homeLayout));
  });
  const status = document.getElementById("uiWallpaperStatus");
  if(status) status.textContent = p.wallpaper === "photo" && p.wallpaperData ? "Your background is saved on this device" : "Optional · image stays on this device";
  const saveLabel = document.getElementById("uiSaveStatus");
  const hasSavedPrefs = !!(H() && H().prefs && H().prefs.ui);
  if(saveLabel){
    saveLabel.textContent = hasSavedPrefs ? "Saved to this device" : "Personal workspace";
    saveLabel.classList.toggle("saved", hasSavedPrefs);
  }
  syncUIPreview(p);
}

function updateUIPrefFromControl(target){
  const id = target.id;
  const homeCardMap = {uiHomeCoach:"coach",uiHomeStanding:"standing",uiHomeNext:"next",uiHomeTransmission:"transmission"};
  if(homeCardMap[id]){
    const cards = new Set(readUIPrefs().homeCards);
    if(target.checked) cards.add(homeCardMap[id]); else cards.delete(homeCardMap[id]);
    writeUIPrefs({homeCards:[...cards],homeLayout:"custom"});
    renderPersonalization();
    return;
  }
  const map = {
    uiNavigation:"navigation", uiDockPosition:"dockPosition", uiDensity:"density",
    uiFont:"fontSize", uiMaterial:"material", uiCorners:"corners", uiWallpaper:"wallpaper",
    uiAccent:"accent", uiDockLabels:"dockLabels", uiReduceMotion:"reduceMotion",
  };
  if(id === "setTheme"){
    if(typeof setTheme === "function") setTheme(target.value);
    return;
  }
  const key = map[id];
  if(!key) return;
  const value = target.type === "checkbox" ? target.checked : target.value;
  writeUIPrefs({ [key]:value });
  syncUIPreview(readUIPrefs());
}

function resizeWallpaper(file, done){
  if(!file || !/^image\//.test(file.type || "")) return toast("Image not supported", "Choose a JPG, PNG or WebP image.", "blood");
  const reader = new FileReader();
  reader.onerror = () => toast("Could not read image", "Choose another image and try again.", "blood");
  reader.onload = () => {
    const img = new Image();
    img.onerror = () => toast("Could not open image", "This image file could not be decoded.", "blood");
    img.onload = () => {
      const max = 1600, scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext("2d");
      if(!ctx) return toast("Image unavailable", "This browser cannot process the selected image.", "blood");
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      done(canvas.toDataURL("image/jpeg", .76));
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

function bindPersonalization(){
  const panel = document.getElementById("workspaceCustomizer");
  if(!panel || panel.dataset.bound) return;
  panel.dataset.bound = "true";
  panel.addEventListener("change", e => {
    const t = e.target;
    if(t.id === "uiWallpaperFile"){
      const file = t.files && t.files[0];
      if(!file) return;
      resizeWallpaper(file, data => {
        writeUIPrefs({ wallpaper:"photo", wallpaperData:data });
        renderPersonalization();
        toast("Workspace updated", "Your background photo is stored on this device.", "gold");
      });
      t.value = "";
      return;
    }
    if(t.name === "uiProfile" && t.checked){
      const startLayout = t.value === "ipad" || t.value === "mac" ? "dock" : "hybrid";
      writeUIPrefs({ profile:t.value, navigation:startLayout, dockPosition:"bottom", dockLabels:true });
      renderPersonalization();
      return;
    }
    updateUIPrefFromControl(t);
  });
  panel.addEventListener("click", e => {
    const homeChoice = e.target.closest("[data-home-layout]");
    if(homeChoice){
      const layout = homeChoice.dataset.homeLayout;
      const cards = UI_HOME_LAYOUTS[layout];
      if(cards){
        writeUIPrefs({homeLayout:layout,homeCards:[...cards]});
        renderPersonalization();
        syncUIPreview(readUIPrefs());
      }
      return;
    }
    const swatch = e.target.closest("[data-ui-accent]");
    if(swatch){
      const accent = swatch.dataset.uiAccent;
      const input = document.getElementById("uiAccent");
      if(input) input.value = accent;
      writeUIPrefs({ accent });
      syncUIPreview(readUIPrefs());
    }
  });
  const reset = document.getElementById("uiReset");
  if(reset) reset.onclick = () => {
    const h = H();
    if(h && h.prefs) delete h.prefs.ui;
    try{ localStorage.removeItem(uiWallpaperKey()); }catch(e){}
    applyUIPrefs(); save(); renderPersonalization();
    const label = document.getElementById("uiSaveStatus");
    if(label) label.textContent = "Default workspace restored";
    toast("Workspace reset", "Your study data and quests were left untouched.", "gold");
  };
}

bindPersonalization();
applyUIPrefs();
document.addEventListener("DOMContentLoaded", () => { bindPersonalization(); applyUIPrefs(); });
