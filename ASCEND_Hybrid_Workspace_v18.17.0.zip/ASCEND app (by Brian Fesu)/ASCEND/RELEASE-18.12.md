# ASCEND 18.12 — step 5 of v19: the next action, and the time to do it in

## First, what I did not build

§6 asks for adaptive intelligence combining goals, curriculum, mastery, errors,
deadlines, history and available time.

**Six of those seven were already there.** `services/recommend.js` has ranked the
next action since v14 — deterministically, with a written reason on every item,
hard constraints outranking soft ones. It draws on recovery state, deadlines,
overdue mandatory quests, focus rating, error topics from the Academy, upcoming
exams, decayed mastery, stalled projects, opportunities, goals that are drifting,
and quests the record shows you clear least often. `services/model.js` behind it
does significance testing with a multiple-comparison correction, so it will not
announce that Tuesdays are your weak day on the strength of a coincidence.

Writing a second engine beside that one would have been the sixth duplicate-rule
collision in this project's history. So this release adds what was actually
missing.

---

## The missing input: available time

Every recommendation carried `minutes: null` or no minutes at all. The list a
student saw at 21:40 on a school night was the list a free Saturday would have
produced. That is the difference between a ranking and a plan.

`shared/domain/next-action.js` — pure, no clock, no randomness, no locale, shared
with the server like the progression reducers — now supplies an estimate for
every recommendation, and `plannedRecommendations(minutes)` fits the ranking to
the time a student actually has.

**The rule it enforces:** time may narrow the list, it may never reorder it, and
it may never drop a hard constraint. A deadline due tomorrow does not stop being
due because the evening is short. It is shown, marked as overrunning, with the
shortfall named — because hiding an obligation and letting the student find out
at rollover is the same failure as a rank that congratulates you for a promotion
the System immediately takes back.

Estimates are deliberately coarse. §22 applies to time as much as to reasons: an
honest band beats a precise-looking number the record cannot justify.

---

## "That action becomes the next quest"

`scheduleActionAsQuest()` in `services/link.js` — built on the existing
`scheduleStepAsQuest` shape rather than beside it. Same link vocabulary, same
idempotence rule, same bus event.

Two refusals it makes on purpose:

* **It will not promote something that is already a quest.** Those items appear
  precisely because the quest is on today's board and unfinished; a copy would
  double the board and pay XP twice for one piece of work.
* **It will not invent a link it cannot support.** A recommendation naming a
  topic, project or goal carries that link, so clearing the quest settles up the
  ladder. One that names nothing gets no link rather than a guessed one — a wrong
  link silently ticks off work that was never done.

---

## The check that passed while testing nothing

The promote-to-quest check originally looked for a promotable item in the live
ranking, and a freshly onboarded hunter produces exactly one recommendation —
which is already a quest. So it took an early return and reported **PASS having
never once created a quest.**

That is the same failure as 18.10's paid-not-requested rule: a check that can
pass without running is worse than no check. Two fixes:

* the creation path now uses a constructed recommendation, so it always runs;
* the fixture is seeded through the app's own APIs — a subject with topics, a
  goal, and two deadlines — until the ranking is genuinely non-trivial. It now
  produces three recommendations, two of them hard constraints, totalling 110
  minutes, so the budget checks have something real to work against.

The remaining escape hatch was replaced with an assertion that fails if the
fixture stops producing what the check needs.

---

## A finding from the ratchet

`MAX_BRIDGED_NAMES` has now been raised three releases running: 32 → 34 → 37.
Check 8 still holds — nothing is bridged without a live consumer — so each raise
was legitimate. But three in a row is itself the finding:

**The bridge grows whenever new module code is written for classic consumers, and
shrinks only when a consumer converts.** Converting more leaves cannot reduce it.
The next module tranche has to be consumers — `services/recommend.js`,
`services/link.js`, `services/progression.js` — or that number keeps climbing
while the migration looks like it is progressing.

---

## Verification

`next-action-test.js` — 13 checks: purity of the shared module; budgeting never
reordering across six budgets; a hard constraint shown rather than hidden; an
optional overrun marked but not promoted; no invented plan when no time is
stated; an estimate for every recommendation kind; identical plans across five
timezones; **no model call anywhere in the decision path**; and the live engine,
its real ranking under a 20-minute budget, and the three promote-to-quest rules.

Both new invariants are mutation-pinned: making budgeting filter instead of
annotate fails three checks; removing the idempotence guard fails the promotion
check.

**17 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra.

---

## Where v19 stands

| Step | |
|---|---|
| 1 · ES modules, leaf-first | done (18.8) |
| 2 · IndexedDB, one store | done (18.9) |
| 3 · Event log, deterministic replay | done (18.10) |
| 4 · The server replays | done (18.11) |
| 5 · Next action + available time | done (18.12) |

What remains is the long tail rather than new architecture: the remaining domains
onto the log one at a time — quests, mastery, achievements, and last of all rank,
which stays gated on quests cleared, a streak held, achievements and bosses, not
on a level. And the module conversion continues, now with consumers rather than
leaves.

Still yours, and none of it blocked by code: **password reset** (a forgotten
password is still an unrecoverable account), the **host decision** (no live
OpenAI call has ever been made), and the **data-protection position** for 13–18
year olds — which 18.11 made more pressing, since the server now holds an
event-by-event history of a student's year.
