/* THE SYSTEM v18 — offline-test.js
   Offline readiness, proved rather than assumed.

   The README's standing principle is "assert on the result, never on the
   intent". Every previous offline check in this project asserted on intent: the
   precache guard compared two lists of strings, and offlineAudit() reported
   readiness from a cache it located by guessing. Neither ever ran the service
   worker.

   This suite runs it. sw.js is loaded into a sandbox with a mock Cache API, a
   mock fetch that can be switched off, and mock event registration; the real
   install and activate handlers execute against a real file tree; then a
   navigation request is served with the network disabled and the result is
   inspected. If the app cannot boot offline, this fails.

   Deliberately hostile cases, because the friendly ones prove nothing:
     · a file listed in FILES that does not exist on disk
     · a previous release's cache sitting alongside the new one
     · a navigation to a URL that was never cached
     · a POST, which must never be served from cache
     · a cross-origin request, which must never enter the offline cache */
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = process.env.ROOT || "./system";

/* A converted module lives under src/; an unconverted one is still at the top of
   system/. Resolving instead of hard-coding means the next conversion pass does
   not silently turn this assertion into a false pass. */
function appFile(rel){
  const a = path.join(ROOT, "src", rel), b = path.join(ROOT, rel);
  return fs.existsSync(a) ? a : b;
}

let pass = 0, fail = 0;

function ok(name, cond, detail) {
  if (cond) { pass++; console.log("  PASS  " + name); }
  else { fail++; console.log("  FAIL  " + name); }
  if (detail) console.log("         " + detail);
}

/* ══════════════ a Cache API good enough to catch real bugs ══════════════ */
class MockResponse {
  constructor(body, init = {}) {
    this.body = body; this.status = init.status || 200;
    this.ok = this.status >= 200 && this.status < 300;
    this.headers = new Map(Object.entries(init.headers || {}));
    this.type = init.type || "basic";
  }
  clone() { return new MockResponse(this.body, { status: this.status }); }
  async json() { return JSON.parse(this.body); }
  async text() { return String(this.body); }
}
class MockRequest {
  constructor(url, init = {}) {
    this.url = new URL(url, "https://example.test/app/").href;
    this.method = init.method || "GET";
    this.mode = init.mode || "cors";
    this.cache = init.cache || "default";
  }
}
class MockCache {
  constructor() { this.map = new Map(); }
  _key(r) { return typeof r === "string" ? new URL(r, "https://example.test/app/").href : r.url; }
  async put(req, res) { this.map.set(this._key(req), res); }
  async match(req) { return this.map.get(this._key(req)) || undefined; }
  async keys() { return [...this.map.keys()].map(u => new MockRequest(u)); }
  async add(req) {
    const r = typeof req === "string" ? new MockRequest(req) : req;
    const res = await globalFetch(r);
    if (!res.ok) throw new Error("add failed " + r.url);
    this.map.set(r.url, res);
  }
  async addAll(list) { for (const r of list) await this.add(r); }
}
class MockCacheStorage {
  constructor() { this.stores = new Map(); }
  async open(name) { if (!this.stores.has(name)) this.stores.set(name, new MockCache()); return this.stores.get(name); }
  async keys() { return [...this.stores.keys()]; }
  async delete(name) { return this.stores.delete(name); }
  async match(req) {
    for (const c of this.stores.values()) { const h = await c.match(req); if (h) return h; }
    return undefined;
  }
}

/* The network. `online` flips it; `seen` records how each file was requested so
   the cache:"reload" contract can be asserted rather than eyeballed. */
const net = { online: true, seen: [] };
async function globalFetch(req) {
  const r = typeof req === "string" ? new MockRequest(req) : req;
  net.seen.push({ url: r.url, cache: r.cache });
  if (!net.online) throw new TypeError("Failed to fetch");
  const rel = decodeURIComponent(new URL(r.url).pathname.replace(/^\/app\//, ""));
  const disk = path.join(ROOT, rel === "" || rel.endsWith("/") ? "index.html" : rel);
  if (!fs.existsSync(disk) || fs.statSync(disk).isDirectory()) return new MockResponse("", { status: 404 });
  return new MockResponse(fs.readFileSync(disk, "utf8"), { status: 200 });
}

/* ══════════════ boot the real sw.js ══════════════ */
const handlers = {};
const sandbox = {
  self: null, caches: new MockCacheStorage(), fetch: globalFetch,
  Request: MockRequest, Response: MockResponse, URL, console,
  setTimeout, clearTimeout, clients: { matchAll: async () => [], openWindow: async () => {} },
};
sandbox.self = {
  addEventListener: (t, fn) => { (handlers[t] = handlers[t] || []).push(fn); },
  location: new URL("https://example.test/app/sw.js"),
  skipWaiting: () => { sandbox.self._skipped = true; },
  clients: { claim: async () => {} },
  _skipped: false,
};
sandbox.Response.error = () => new MockResponse("", { status: 0 });
vm.createContext(sandbox);

const swSrc = fs.readFileSync(path.join(ROOT, "sw.js"), "utf8");
try { vm.runInContext(swSrc, sandbox, { filename: "sw.js" }); }
catch (e) { console.log("  FAIL  sw.js does not execute: " + e.message); process.exit(1); }

const waits = [];
/* The first version of this helper set `responded` on its *argument* rather
   than on the event it returned, so every respondWith landed on a discarded
   object and three checks reported the app broken offline when it was not.
   A test harness gets the same rule as the app: assert on the result. */
function evt(extra = {}) {
  const e = { ...extra };
  e.waitUntil = p => waits.push(p);
  e.respondWith = p => { e.responded = p; };
  return e;
}

(async () => {
  console.log("offline-test — the service worker, actually run\n");

  /* ---------- 1. version consistency across the three places it lives ---------- */
  const pkg = JSON.parse(fs.readFileSync("./package.json", "utf8"));
  /* Absent in builds before v18, where the version lived nowhere. Reported as a
     failure rather than crashing the suite, so this file can be pointed at an
     older ROOT to confirm the checks fail without the fix. */
  const verPath = appFile("app/version.js");
  const verJs = fs.existsSync(verPath) ? fs.readFileSync(verPath, "utf8") : "";
  const verInVersionJs = (verJs.match(/SYSTEM_VERSION\s*=\s*"([^"]+)"/) || [])[1] || "(no app/version.js)";
  const verInSw = (swSrc.match(/const VERSION\s*=\s*"([^"]+)"/) || [])[1] || "(no VERSION in sw.js)";
  ok("package.json, app/version.js and sw.js all name the same release",
    pkg.version === verInVersionJs && verInVersionJs === verInSw,
    `package.json ${pkg.version} · version.js ${verInVersionJs} · sw.js ${verInSw}`);
  /* Comments are stripped first. The first version of this check searched the
     whole file for "system-v17" and failed on the comment that explains why the
     name must not be "system-v17" — the same class of mistake as the v17
     SKIP_WAITING check that passed on a string thirty lines from the handler. */
  const swCode = swSrc.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
  ok("the cache name carries the version, so a release invalidates the last one",
    /const CACHE\s*=\s*"system-v"\s*\+\s*VERSION/.test(swCode) && !/"system-v\d/.test(swCode),
    "cache name is derived from VERSION, not a literal left over from a previous release");

  /* ---------- 2. install ---------- */
  const before = evt({});
  handlers.install.forEach(h => h(before));
  await Promise.all(waits);
  const names = await sandbox.caches.keys();
  const cache = await sandbox.caches.open(names[0] || "none");
  const keys = await cache.keys();
  ok("install creates exactly one cache, named for this release",
    names.length === 1 && names[0] === "system-v" + verInSw, `caches: ${names.join(", ")}`);

  /* ---------- 3. every asset index.html needs is actually in the cache ---------- */
  const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
  const needed = [
    ...[...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]),
    ...[...html.matchAll(/<link[^>]+href="([^"]+\.css)"/g)].map(m => m[1]),
    "manifest.json", "index.html",
  ];
  const have = new Set(keys.map(k => new URL(k.url).pathname));
  const missing = needed.filter(n => !have.has("/app/" + n));
  ok("every script, stylesheet and shell file the page loads is cached",
    missing.length === 0, missing.length ? "missing: " + missing.join(", ") : `${needed.length} assets verified in the cache`);

  /* ---------- 4. cache:"reload" — the invalidation contract ---------- */
  const reloaded = net.seen.filter(s => s.cache === "reload").length;
  ok("precache requests bypass the HTTP cache (cache:\"reload\")",
    reloaded >= needed.length,
    `${reloaded} of ${net.seen.length} precache requests used cache:"reload" — without this a new worker can install stale bytes into a correctly-named new cache`);

  /* ---------- 5. install records what actually happened ---------- */
  const rep = await cache.match("__precache-report");
  const report = rep ? JSON.parse(rep.body) : null;
  ok("the worker records its own precache result instead of assuming success",
    !!report && report.version === verInSw && report.expected > 0,
    report ? `expected ${report.expected} · cached ${report.cached} · failed ${report.failed.length}` : "no report written");
  ok("nothing in the precache list is missing from disk",
    !!report && report.failed.length === 0,
    report && report.failed.length ? "failed: " + report.failed.join(", ") : "all precache entries resolved");

  /* ---------- 6. activate retires the previous release ---------- */
  await sandbox.caches.open("system-v17");          /* a leftover from the shipped build */
  await sandbox.caches.open("system-v14");
  waits.length = 0;
  handlers.activate.forEach(h => h(evt({})));
  await Promise.all(waits);
  const after = await sandbox.caches.keys();
  ok("activate deletes every cache that is not this release",
    after.length === 1 && after[0] === "system-v" + verInSw,
    `caches after activate: ${after.join(", ")}`);

  /* ---------- 7. the actual promise: boot with the network off ---------- */
  net.online = false;
  const nav = evt({ request: new MockRequest("https://example.test/app/index.html", { mode: "navigate" }) });
  handlers.fetch.forEach(h => h(nav));
  const navRes = await nav.responded;
  ok("index.html is served from cache with the network down",
    !!navRes && navRes.ok && String(navRes.body).includes("<title"), "the shell boots offline");

  /* Every module, offline. This is the check that would have caught the v15
     precache drift that broke the app offline for three releases. */
  const modResults = [];
  for (const m of needed) {
    const e = evt({ request: new MockRequest("https://example.test/app/" + m) });
    handlers.fetch.forEach(h => h(e));
    const r = await e.responded.catch(() => null);
    if (!r || !r.ok) modResults.push(m);
  }
  ok("every module and stylesheet is served offline, not just the shell",
    modResults.length === 0, modResults.length ? "failed offline: " + modResults.join(", ") : `${needed.length} assets served from cache with no network`);

  /* ---------- 8. a page that was never cached falls back to the shell ---------- */
  const deep = evt({ request: new MockRequest("https://example.test/app/never-seen", { mode: "navigate" }) });
  handlers.fetch.forEach(h => h(deep));
  const deepRes = await deep.responded.catch(() => null);
  ok("an uncached navigation falls back to the shell instead of an error page",
    !!deepRes && deepRes.ok, "deep links survive offline");

  /* ---------- 9. what must NOT be cached ---------- */
  const post = evt({ request: new MockRequest("https://example.test/app/x", { method: "POST" }) });
  handlers.fetch.forEach(h => h(post));
  ok("a POST is left alone rather than answered from cache",
    post.responded === undefined, "the worker does not respond to non-GET requests");

  const cross = evt({ request: new MockRequest("https://api.themoviedb.org/3/movie") });
  handlers.fetch.forEach(h => h(cross));
  ok("a cross-origin request never enters the offline cache",
    cross.responded === undefined, "external API answers stay out of the shell cache");

  /* ---------- 10. the update flow ---------- */
  ok("the install handler does not call skipWaiting()",
    sandbox.self._skipped === false,
    "a worker that skips waiting never becomes a waiting worker, so the update prompt can never appear");
  const swInstall = swSrc.slice(swSrc.indexOf('addEventListener("install"'), swSrc.indexOf('addEventListener("activate"'));
  ok("skipWaiting is reachable, but only from the message handler",
    !/skipWaiting/.test(swInstall) && /SKIP_WAITING/.test(swSrc),
    "checked against the install handler specifically, not by searching the whole file");

  console.log(`\n  ${pass} passed · ${fail} failed`);
  if (fail) { console.log("\noffline-test FAILED"); process.exit(1); }
  console.log("\noffline verified");
})().catch(e => { console.log("offline-test crashed: " + e.stack); process.exit(1); });
