#!/usr/bin/env node
/* sync-version.js — the one authoritative version source.

   P0-01 in the v19 register: this build calls itself v18.1 and identifies as
   18.0.0 in package.json, app/version.js and sw.js. Three places agreed with
   each other and all three disagreed with the release.

   The previous design held the three in sync with a CHECK in offline-test.js.
   A check catches drift; it does not prevent it, and it cannot tell you which
   of the three is right — it only says they differ. So a developer bumping a
   release still had to edit three files correctly and hope.

   This inverts it. package.json is the source (it is the one npm itself can
   bump with `npm version`). This script WRITES the other two from it. The
   check in offline-test.js stays, and now guards against someone hand-editing
   app/version.js or sw.js instead of running this.

   Why sw.js still holds a literal rather than importScripts()-ing version.js:
   importScripts() makes the worker fail to INSTALL if that file ever moves,
   and a worker that fails to install takes offline with it — the one thing
   this product cannot lose. The duplication is deliberate; what changes here
   is that a machine maintains it, not a person.

     node sync-version.js          write the version through
     node sync-version.js --check  exit 1 if anything is out of sync
*/
"use strict";
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const APP = path.join(ROOT, "system");
const check = process.argv.includes("--check");

const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
const version = pkg.version;

if (!/^\d+\.\d+\.\d+$/.test(version)) {
  console.error("package.json version is not a plain semver: " + version);
  process.exit(1);
}

/* Each target: the file, the pattern that holds the version, and how to
   rewrite it. Adding a fourth place the version appears means adding one entry
   here, not remembering a fourth file at release time. */
const targets = [
  {
    /* The fifth place the version lives, and the one that caught a 18.7 release
       out of sync: release-test.js compares the lockfile against package.json,
       and `npm version` does update it — but a hand-edit of package.json does
       not. It is listed here for the reason stated above: a fourth (and fifth)
       file is one entry in this table, not one more thing to remember. */
    file: "package-lock.json",
    root: ROOT,
    read: s => { try { return JSON.parse(s).version; } catch { return undefined; } },
    write: s => {
      const m = JSON.parse(s);
      m.version = version;
      if (m.packages && m.packages[""]) m.packages[""].version = version;
      return JSON.stringify(m, null, 2) + "\n";
    },
  },
  {
    file: "app/version.js",
    read: s => (s.match(/const SYSTEM_VERSION\s*=\s*"([^"]+)"/) || [])[1],
    write: s => s.replace(/(const SYSTEM_VERSION\s*=\s*")[^"]+(")/, "$1" + version + "$2"),
  },
  {
    file: "sw.js",
    read: s => (s.match(/const VERSION\s*=\s*"([^"]+)"/) || [])[1],
    write: s => s.replace(/(const VERSION\s*=\s*")[^"]+(")/, "$1" + version + "$2"),
  },
  {
    file: "manifest.json",
    read: s => { try { return JSON.parse(s).version; } catch { return undefined; } },
    write: s => {
      const m = JSON.parse(s);
      m.version = version;
      return JSON.stringify(m, null, 2) + "\n";
    },
  },
];

let drift = 0, wrote = 0;

for (const t of targets) {
  /* A file that has been converted to an ES module lives under system/src/.
     Resolving rather than hard-coding keeps this table correct through the
     migration instead of failing the release the day a file moves. */
  const base = t.root || APP;
  const abs = fs.existsSync(path.join(base, "src", t.file))
    ? path.join(base, "src", t.file)
    : path.join(base, t.file);
  if (!fs.existsSync(abs)) { console.error("missing: " + t.file); process.exit(1); }
  const src = fs.readFileSync(abs, "utf8");
  const found = t.read(src);

  if (found === version) { console.log("  ok      " + t.file.padEnd(19) + version); continue; }

  drift++;
  if (check) {
    console.error("  DRIFT   " + t.file.padEnd(19) + (found || "(none)") + "  ≠  package.json " + version);
    continue;
  }
  const next = t.write(src);
  if (next === src) { console.error("  FAILED to rewrite " + t.file + " — pattern did not match"); process.exit(1); }
  fs.writeFileSync(abs, next);
  wrote++;
  console.log("  written " + t.file.padEnd(19) + (found || "(none)") + "  ->  " + version);
}

if (check && drift) {
  console.error("\n" + drift + " file(s) disagree with package.json. Run: npm run version:sync");
  process.exit(1);
}
console.log(check
  ? "\nversion is consistent: " + version
  : "\n" + (wrote ? wrote + " file(s) updated to " : "already at ") + version);
