# ASCEND 18.13 — account recovery

Until this release a forgotten password meant an unrecoverable account. The Gate
said so before a student set one, which was the minimum honest handling and not a
solution: the first student who forgets is an account lost, and with it their
cross-device backup and their event history.

---

## What landed

**Password reset** — `POST /auth/reset/request` and `/auth/reset/confirm`.
**Email verification** — `/auth/verify/request` and `/auth/verify/confirm`, plus
an `email_verified_at` column so the state is recorded from here forward rather
than inferred later.

Tokens are stored **hashed**, expire in an hour, work **once**, and issuing a new
one kills the outstanding one — otherwise a student who clicks "forgot password"
three times has three live keys and nobody is watching the two they abandoned.

A completed reset **revokes every session on the account**. If the reset happened
because somebody else had the account, leaving their phone signed in would make
the whole exercise decorative.

**A reset touches nothing local.** I checked this before writing any of it,
because it was the one thing that could have made recovery destructive: the
device PIN is separate from the account password, and AES only encrypts export
files with a passphrase chosen at export time. So the record, the quests and the
event log all survive — which is asserted rather than assumed.

---

## Why delivery is a choice you still have to make

Sending email needs an account with a provider, a sending domain, and a
deliverability reputation. Those belong to whoever runs the server, so hardcoding
a vendor would both make that decision for you and make the whole flow
untestable.

`MAIL_TRANSPORT` is `none` by default, and **recovery is genuinely off** in that
state — the endpoint returns 503 and says so. A cheerful 200 that sends nothing
would leave a student refreshing an inbox forever, which is worse than being told
recovery is unavailable. Set `webhook` with `MAIL_WEBHOOK_URL` to turn it on;
`log` exists for development and prints the token, which is why `/health` reports
the transport and why it must never be the production one.

**So this release does not close the gap on its own.** It builds the half that
can be verified and leaves the half that is your decision clearly marked.

---

## Enumeration, and why so much of the suite is about it

The users here are 13 to 18 years old. An unauthenticated endpoint that answers
differently for a known address turns "who has an ASCEND account" into a list
anyone can assemble.

So `/auth/reset/request` answers **identically** whether the address exists,
whether a token was issued, whether the send succeeded, and whether the account is
being throttled. Everything an operator needs in order to debug it goes to the
audit trail, where they can see it and the internet cannot.

Throttling follows the **address**, not just the IP. IP limits stop a scan; they
do nothing about pointing the endpoint at one student's mailbox from a different
address each time, and the person harmed there is the student whose inbox fills
up.

One deliberate exception: a rejected weak password does **not** consume the reset
link. A typo must not burn the student's one chance.

---

## Verification

`recovery-test.js` — 15 checks over a real socket, with the webhook transport
pointed at a mailbox this suite owns, so the token is pulled **out of the
delivered message** rather than read from the database. A test that read the
token from the table would pass against a server that never sent anything.

Covered: the full happy path; the old password ceasing to work; every device
signed out; the record and event log untouched; tokens hashed and absent from
their own row; single use; reissue invalidating the previous link; expiry;
malformed and guessed tokens; weak passwords refused without burning the link;
identical answers for real and unknown addresses; throttling indistinguishable
from success; verification recorded; and the `none` transport refusing honestly
in a separate process, because the default is what a first deployment runs.

`sync-test.js` gains an end-to-end check: the real client through the Gate flow,
confirming the app surfaces the 503 rather than inventing an inbox, drops the
revoked session, keeps local progress, and signs back in.

Three mutations pinned: leaking existence on an unknown address, allowing token
reuse, and skipping session revocation each fail exactly the checks that name
them.

**18 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra.

---

## One thing I found and did not fix

The **device PIN has no recovery path at all.** It is PBKDF2-hashed on the device
with lockout on repeated failures, and there is no reset, no backup code, no
escape. A student who forgets their PIN is locked out of the local app entirely —
which, for an offline-first product, is a worse outcome than forgetting the
account password, and it is now the only unrecoverable state left.

I have not touched it, because every fix is a trade-off that is yours to make: a
backup code weakens the lock, recovery-by-account makes the PIN depend on a
server the app is designed to work without, and a wipe-and-restore-from-cloud
path only helps a student who was already syncing. Worth deciding before the PIN
is offered to real students rather than after.

---

## Still yours

* **The host decision.** No live OpenAI call has ever been made from this code.
* **`MAIL_TRANSPORT`.** Recovery is built and off until you choose a sender.
* **The data-protection position** for 13–18 year olds. Since 18.11 the server
  holds an event-by-event history of a student's year, and as of this release it
  also holds recovery tokens and verification state.
