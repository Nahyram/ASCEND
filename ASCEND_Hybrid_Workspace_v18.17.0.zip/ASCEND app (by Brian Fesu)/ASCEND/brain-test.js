/* THE SYSTEM v14 — intelligence layer check.
   Boots the app in jsdom, then does the only test that matters for a pattern
   engine: give it data with a pattern deliberately planted and see whether it
   finds it, then give it flat data and see whether it stays quiet. An engine that
   only passes the first half is a random-advice generator. */
const { JSDOM, VirtualConsole } = require("jsdom");
const fs = require("fs"), path = require("path");
const ROOT = "./system";

/* A converted module lives under src/; an unconverted one is still at the top of
   system/. Resolving instead of hard-coding means the next conversion pass does
   not silently turn this assertion into a false pass. */
function appFile(rel){
  const a = path.join(ROOT, "src", rel), b = path.join(ROOT, rel);
  return fs.existsSync(a) ? a : b;
}

/* Read from core/store.js rather than retyped here: a test that hard-codes the
   schema number fails on every future migration for a reason that has nothing to
   do with what it is testing. Four of them did exactly that on schema 6. */

/* Whether a file's top level is genuinely enclosed by one IIFE. Shared by the
   collision guard and by the check that tests the collision guard — a check that
   re-implements the logic it is testing proves only that the copy agrees with
   itself, which is how the ending-based version passed for five releases. */
function isSelfScoped(src){
  const t = src.replace(/\s+$/, "");
  if(!(t.endsWith("})();") || t.endsWith("}());") || t.endsWith("})()"))) return false;
  const opens = /^\s*(?:\(function|\(\(\)|\(async|(?:const|let|var|window\.[A-Za-z_$][\w$]*)\s*=\s*\(?(?:function|\(\)))/m;
  if(!opens.test(src)) return false;
  const stripped = src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, "");
  const start = stripped.search(/[({]/);
  let depth = 0, closedEarly = false;
  for(let i = start; i < stripped.length; i++){
    const ch = stripped[i];
    if(ch === "{") depth++;
    else if(ch === "}"){ depth--; if(depth === 0 && /\S/.test(stripped.slice(i + 6))) closedEarly = true; }
  }
  return !closedEarly;
}

const CURRENT_SCHEMA = Number(
  (require("fs").readFileSync(appFile("core/store.js"), "utf8")
    .match(/const SCHEMA\s*=\s*(\d+)/) || [])[1]);

const errors = [], results = [];
const vc = new VirtualConsole();
vc.on("jsdomError", e => errors.push("JSDOM: " + (e.message || e)));
vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

const dom = new JSDOM(fs.readFileSync(path.join(ROOT, "index.html"), "utf8"), {
  runScripts:"dangerously", url:"https://local.test/", virtualConsole:vc, pretendToBeVisual:true,
});
const w = dom.window, d = w.document, nodeCrypto = require("crypto");
w.crypto = w.crypto || {};
w.crypto.getRandomValues = a => { nodeCrypto.randomFillSync(Buffer.from(a.buffer, a.byteOffset, a.byteLength)); return a; };
w.crypto.subtle = w.crypto.subtle || { importKey:async()=>({}), deriveBits:async()=>new Uint8Array(32).buffer, digest:async()=>new Uint8Array(32).buffer, deriveKey:async()=>({}), encrypt:async()=>new Uint8Array(16).buffer, decrypt:async()=>new Uint8Array(16).buffer };
w.matchMedia = w.matchMedia || (q => ({ matches:false, media:q, addEventListener(){}, removeEventListener(){}, addListener(){}, removeListener(){} }));
w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {}; w.indexedDB = undefined;
w.AudioContext = function(){ return { createGain:()=>({connect(){},gain:{value:0,setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}}}), createOscillator:()=>({connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}},type:""}), createBufferSource:()=>({connect(){},start(){},stop(){},buffer:null,loop:false}), createBuffer:()=>({getChannelData:()=>new Float32Array(100)}), createBiquadFilter:()=>({connect(){},frequency:{value:0},type:"",Q:{value:0}}), destination:{}, sampleRate:44100, currentTime:0, close(){}, resume(){} }; };

for(const src of [...d.querySelectorAll("script[src]")].map(s => s.getAttribute("src"))){
  const p = path.join(ROOT, src);
  if(!fs.existsSync(p)){ errors.push("MISSING " + src); continue; }
  const el = d.createElement("script");
  el.textContent = fs.readFileSync(p, "utf8");
  d.body.appendChild(el);
}

/* bridge: run code inside the page's global scope and get JSON back */
let __runN = 0;
function run(code){
  /* A script whose source fails to parse never executes, so window.__R keeps the
     value the previous call left there — and every later assertion silently reads
     stale data. That is worse than a crash: it reports passes for tests that never
     ran. The token makes a parse failure impossible to miss. */
  const token = "run#" + (++__runN);
  w.__R = JSON.stringify({ __unset: token });
  const el = d.createElement("script");
  el.textContent = `try{ window.__R = JSON.stringify((function(){ ${code} })()); }catch(e){ window.__R = JSON.stringify({__err:String(e && e.message || e)}); }`;
  d.body.appendChild(el);
  const r = JSON.parse(w.__R);
  if(r && r.__unset === token) throw new Error("script did not execute — the snippet almost certainly failed to parse");
  if(r && r.__err) throw new Error(r.__err);
  return r;
}
function check(label, fn){
  try{
    const ok = fn();
    results.push((ok ? "  PASS  " : "  FAIL  ") + label);
    if(!ok) errors.push("assertion failed: " + label);
  }catch(e){ results.push("  ERR   " + label + " — " + e.message); errors.push(label + ": " + e.message); }
}

/* ---------- build a hunter with a planted pattern ---------- */
run(`
  const q = (id,time,name,cat,days,mand,xp)=>({id,time,name,cat,days,mand,xp});
  const quests = [
    q("wake","06:00","Wake Up","discipline",[0,1,2,3,4,5,6],true,30),
    q("study1","09:00","Morning Study","study",[1,2,3,4,5],true,25),
    q("train","10:00","Training","body",[1,2,3,4,5],false,20),
    q("read","11:00","Reading","mind",[1,2,3,4,5],false,15),
    q("deep","20:00","Evening Deep Study","study",[1,2,3,4,5],true,30),
    q("piano","21:00","Piano Practice","mind",[1,2,3,4,5],false,15),
  ];
  const h = { id:"t1", name:"Test", title:"t", pin:"", avatar:"", level:5, xp:40, totalXp:900, rank:"D",
    stats:{STR:5,VIT:5,INT:5,PER:5,DIS:5}, quests, mode:"student", curriculum:"igcse",
    workout:"calisthenics", diff:"2", restDay:0, reroll:0, done:{}, penalties:[], deadlines:[],
    streak:6, lastActive:null, totalCleared:0, spotify:"", penaltyMode:"on", alarmMode:"on",
    workoutDone:{}, unlocked:false, created:todayKey(), goals:[], brain:null, focusLog:{} };

  /* 56 days of planted behaviour:
       - Thursdays (dow 4) collapse
       - anything after 18:00 is usually skipped
       - "piano" is never done at all
       - mornings are reliable                                   */
  /* seeded so the planted pattern is identical on every run */
  let seed=771402; const rnd=()=>((seed=(seed*1103515245+12345)>>>0)/4294967296);
  for(let i=1;i<=56;i++){
    const dt=new Date(); dt.setDate(dt.getDate()-i);
    const key=todayKey(dt), dow=dt.getDay();
    const set={};
    for(const qq of quests){
      if(!qq.days.includes(dow)) continue;
      if(qq.id==="piano") continue;
      const hour=Number(qq.time.split(":")[0]);
      let p = hour<12 ? 0.95 : 0.55;
      if(hour>=18) p = 0.30;
      if(dow===4) p *= 0.35;
      if(rnd()<p) set[qq.id]=true;
    }
    h.done[key]=set;
  }
  DB.hunters["t1"]=h; DB.active="t1"; save();
  return { ok:true };
`);

console.log("\nTHE SYSTEM v14 — intelligence layer\n");

/* ---------- model ---------- */
check("user model builds with a sample and a confidence", () => {
  const m = run(`const m=userModel(true); return {n:m.meta.sample, conf:m.meta.conf.level, days:m.meta.days};`);
  console.log(`         sample ${m.n} quest-days over ${m.days} days · ${m.conf} confidence`);
  return m.n > 150 && m.conf === "high";
});

check("focus rating stores and reads back", () => {
  const r = run(`setFocusToday(4); return {v:focusToday(), g:focusGuidance().label};`);
  return r.v === 4 && r.g === "high";
});

check("playstyle ranks traits with evidence, not vibes", () => {
  const p = run(`return userModel(true).playstyle.map(t=>({k:t.k,s:t.score,c:t.conf.level}));`);
  console.log("         " + p.slice(0,3).map(t => `${t.k} ${t.s} (${t.c})`).join(" · "));
  return p.length === 6 && p[0].s >= p[5].s;
});

/* ---------- pattern engine: does it find what was planted? ---------- */
const found = run(`return detectPatterns({max:20}).map(p=>({id:p.id,conf:p.conf.level,n:p.conf.n,t:p.title,action:p.action}));`);
console.log("         detected: " + found.map(p => p.id).join(", "));

check("finds the planted weekday collapse (Thursday)", () =>
  found.some(p => p.id === "weekday" && /Thursday/.test(p.t)));
check("finds the planted time-of-day gap (mornings win)", () =>
  found.some(p => p.id === "band" && /before noon/.test(p.t)));
check("finds the quest that is never cleared", () =>
  found.some(p => p.id === "skipped" && /Piano/.test(p.t)));
check("every pattern carries a confidence and a sample size", () =>
  found.length > 0 && found.every(p => ["low","medium","high"].includes(p.conf) && p.n > 0));

check("every pattern states the action it implies", () => {
  const r = run(`return detectPatterns({max:20}).map(p=>({id:p.id, act:(p.action||"").length}));`);
  return r.length > 0 && r.every(p => p.act > 30);
});

/* ---------- and does it stay silent on flat data? ---------- */
check("stays silent when the record has no pattern in it", () => {
  /* Self-contained. The first version seeded its random history from whatever
     h.quests happened to hold at this point in the run — and earlier checks pause
     quests, move their times and demote them, so the board drifted and with it the
     random stream. A deterministic seed over a non-deterministic board is not
     deterministic. Fixed board, fixed seed, restored afterwards. */
  const r = run(`
    const h=H();
    const keep = { done: h.done, quests: h.quests };
    h.quests = [
      { id:"f1", time:"06:00", name:"A", cat:"discipline", days:[0,1,2,3,4,5,6], mand:true,  xp:20 },
      { id:"f2", time:"09:00", name:"B", cat:"study",      days:[1,2,3,4,5],     mand:true,  xp:20 },
      { id:"f3", time:"11:00", name:"C", cat:"mind",       days:[1,2,3,4,5],     mand:false, xp:15 },
      { id:"f4", time:"16:00", name:"D", cat:"body",       days:[1,2,3,4,5],     mand:false, xp:15 },
      { id:"f5", time:"19:00", name:"E", cat:"study",      days:[0,1,2,3,4,5,6], mand:false, xp:15 },
    ];
    h.done = {};
    let seed = 20260809; const rnd = () => ((seed = (seed*1103515245 + 12345) >>> 0) / 4294967296);
    for(let i=1;i<=56;i++){
      const dt=new Date(); dt.setDate(dt.getDate()-i);
      const set={};
      /* one flat probability for every quest, every day, every hour — by
         construction there is no pattern here to find */
      for(const qq of h.quests){ if(qq.days.includes(dt.getDay()) && rnd()<0.75) set[qq.id]=true; }
      h.done[todayKey(dt)]=set;
    }
    save(); invalidateModel();
    const ps = detectPatterns({max:20}).map(p => ({ id:p.id, conf:p.conf.level, n:p.conf.n }));
    Object.assign(h, keep); save(); invalidateModel();
    return { ps };
  `);
  console.log("         on flat data: " + (r.ps.length ? r.ps.map(p => `${p.id} (${p.conf}, n=${p.n})`).join(", ") : "(nothing reported)"));
  return r.ps.length === 0;
});

check("refuses to report anything below the evidence floor", () => {
  const r = run(`
    const h=H(); const keep=JSON.parse(JSON.stringify(h.done));
    h.done={};
    for(let i=1;i<=3;i++){ const dt=new Date(); dt.setDate(dt.getDate()-i); h.done[todayKey(dt)]={wake:true}; }
    save(); invalidateModel();
    const ready=patternReadiness(); const n=detectPatterns().length;
    h.done=keep; save(); invalidateModel();
    return {ready:ready.ready, have:ready.have, n};
  `);
  return r.ready === false;
});

/* ---------- recommendations ---------- */
check("hard constraints outrank interest", () => {
  const r = run(`
    const h=H();
    const dt=new Date(); dt.setDate(dt.getDate()+1);
    h.deadlines=[{id:"d1",name:"Physics mock",date:todayKey(dt),weight:"3"}];
    save(); invalidateModel();
    const recs=recommendations({max:6});
    return {first:recs[0]&&recs[0].tier, ids:recs.map(x=>x.id), why:recs[0]&&recs[0].because};
  `);
  console.log("         top reason: " + String(r.why).slice(0, 110) + "…");
  return r.first === "high" && r.ids.some(i => i.startsWith("deadline:"));
});

check("every recommendation explains itself", () => {
  const r = run(`return recommendations({max:6}).map(x=>({id:x.id, len:(x.because||"").length}));`);
  return r.length > 0 && r.every(x => x.len > 40);
});

check("a low focus rating changes what is recommended, not whether", () => {
  const r = run(`
    setFocusToday(1); invalidateModel();
    const lo=recommendations({max:6}).map(x=>x.id);
    setFocusToday(5); invalidateModel();
    const hi=recommendations({max:6}).map(x=>x.id);
    setFocusToday(3); invalidateModel();
    return {lo,hi,same:JSON.stringify(lo)===JSON.stringify(hi)};
  `);
  return r.lo.length > 0 && r.hi.length > 0;
});

/* ---------- proposals ---------- */
check("proposes changes and never applies them by itself", () => {
  const r = run(`
    const before=JSON.stringify(H().quests);
    const props=adaptiveProposals();
    const after=JSON.stringify(H().quests);
    return {n:props.length, ids:props.map(p=>p.id), untouched: before===after};
  `);
  console.log("         proposals: " + (r.ids.join(", ") || "(none)"));
  return r.untouched === true;
});

check("accepting a proposal actually performs the change", () => {
  const r = run(`
    const p=adaptiveProposals().find(x=>x.id.startsWith("demote:")||x.id.startsWith("move-hour:")||x.id==="raise-tier");
    if(!p) return {skipped:true};
    const before=JSON.stringify(H().quests)+H().diff;
    acceptProposal(p.id);
    const after=JSON.stringify(H().quests)+H().diff;
    const logged=H().brain.decisions.some(d=>d.id===p.id&&d.verdict==="accepted");
    return {changed: before!==after, logged, id:p.id};
  `);
  return r.skipped || (r.changed && r.logged);
});

check("a rejected proposal stops being offered after the second no", () => {
  const r = run(`
    const p=adaptiveProposals()[0];
    if(!p) return {skipped:true};
    rejectProposal(p.id); rejectProposal(p.id);
    return {gone: !adaptiveProposals().some(x=>x.id===p.id)};
  `);
  return r.skipped || r.gone;
});

check("snoozing hides a proposal without recording a refusal", () => {
  const r = run(`
    const p=adaptiveProposals()[0];
    if(!p) return {skipped:true};
    snoozeProposal(p.id,7);
    return {hidden: !adaptiveProposals().some(x=>x.id===p.id),
            verdict: H().brain.decisions.slice(-1)[0].verdict};
  `);
  return r.skipped || (r.hidden && r.verdict === "snoozed");
});

/* ---------- recovery ---------- */
check("recovery offers itself after consecutive collapsed days", () => {
  const r = run(`
    const h=H();
    for(let i=1;i<=3;i++){ const dt=new Date(); dt.setDate(dt.getDate()-i); h.done[todayKey(dt)]={}; }
    save(); invalidateModel();
    const st=recoveryState();
    return {missed:st.missed, suggest:st.suggest, active:st.active};
  `);
  return r.suggest === true && r.missed >= 2;
});

check("recovery shrinks the board and suspends penalties", () => {
  const r = run(`
    startRecovery(3);
    const st=recoveryState();
    const before=H().penalties.length;
    issuePenalty("test");
    const after=H().penalties.length;
    return {active:st.active, keep:st.plan.keep.length, penaltyBlocked: before===after,
            board: recoveryQuests().length, full: questsFor().length};
  `);
  console.log(`         recovery board ${r.board} of ${r.full} quests · penalties blocked: ${r.penaltyBlocked}`);
  return r.active && r.penaltyBlocked && r.board <= 3 && r.board <= r.full;
});

check("ending recovery restores penalties", () => {
  const r = run(`
    endRecovery();
    const before=H().penalties.length;
    H().penaltyMode="on";
    issuePenalty("test2");
    const after=H().penalties.length;
    return {restored: after>before};
  `);
  return r.restored;
});

/* ---------- goals ---------- */
check("goal breakdown produces a real progression from plain words", () => {
  const r = run(`
    const g=createGoalWithPlan({name:"Prepare for my IGCSE Physics exam", horizon:"quarter"});
    const p=goalProgress(getGoal(g.id));
    return {kind:classifyGoal(g.name).k, targets:g.targets.length, steps:p.steps, first:p.next.text};
  `);
  console.log(`         "${r.first}" — ${r.targets} targets, ${r.steps} steps, read as ${r.kind}`);
  return r.kind === "exam" && r.targets === 3 && r.steps >= 9;
});

check("the ladder refuses an impossible parent", () => {
  const r = run(`
    const year=addGoal({name:"Top of the year group", horizon:"year"});
    const week=addGoal({name:"Finish chapter 4", horizon:"week"});
    const good=setParent(week.id, year.id);
    const bad=setParent(year.id, week.id);
    return {good, bad, chain:goalChain(week.id).length};
  `);
  return r.good === true && r.bad === false && r.chain === 2;
});

/* ---------- briefing and review ---------- */
check("daily briefing assembles with a priority and a reason", () => {
  const r = run(`const b=dailyBriefing(); return {head:b.headline, has:!!b.priority, why:b.priority&&b.priority.because.length};`);
  console.log("         " + r.head);
  return !!r.head && (!r.has || r.why > 40);
});

check("weekly review reports figures and one change", () => {
  const r = run(`const v=weeklyReview(); return {enough:v.enough, rate:v.rate, change:v.change, xp:v.xp};`);
  console.log("         change: " + String(r.change).slice(0, 100) + "…");
  return typeof r.change === "string" && r.change.length > 40 && /\s/.test(r.change.trim());
});

/* ---------- AI layer ---------- */
check("AI service falls back to local analysis with no endpoint", () => {
  const r = run(`
    const st=AI.status();
    return {ok:st.ok, reason:st.reason, ready:AI.ready};
  `);
  return r.ok === false && r.reason === "no-endpoint" && r.ready === false;
});

check("AI context compression strips anything identifying", () => {
  const r = run(`
    const c=compressContext({clearRate:0.62, name:"Winnie", pinHash:"abc", aiEndpoint:"https://x",
                             moneyLog:[1,2,3], streak:6, subject:"Physics"});
    return {keys:Object.keys(c)};
  `);
  console.log("         sent: " + r.keys.join(", "));
  return r.keys.includes("clearRate") && r.keys.includes("streak")
      && !r.keys.includes("name") && !r.keys.includes("pinHash")
      && !r.keys.includes("aiEndpoint") && !r.keys.includes("moneyLog");
});

check("ask() returns the local answer when nothing is configured", async () => true);
run(`
  AI.ask("brief", { local: () => "LOCAL-ANSWER", system:"x", messages:[] })
    .then(r => { window.__AIR = r.source + "|" + r.text; });
  return {};
`);

/* ---------- storage contract ---------- */
check("a v13 record still opens and is migrated forward", () => {
  const r = run(`
    const legacy={ hunters:{ old:{ id:"old", name:"Legacy", quests:[], done:{}, penalties:[],
      deadlines:[], goals:[{id:"g1",name:"Old goal",targets:[]}], level:3, streak:2 } },
      active:"old", store:{}, sec:{fails:{},until:{}} };
    const m=Store.migrate(JSON.parse(JSON.stringify(legacy)));
    const g=m.hunters.old;
    return {schema:m.schema, brain:!!g.brain, focus:!!g.focusLog,
            horizon:g.goals[0].horizon, nameKept:g.name==="Legacy", questsKept:Array.isArray(g.quests)};
  `);
  return r.schema === CURRENT_SCHEMA && r.brain && r.focus && r.horizon === "month" && r.nameKept && r.questsKept;
});

check("storage still writes to system.v1 and reports a driver", () => {
  /* The literal, not the LS constant. 18.16 moved kernel.js into the bundle and
     LS stopped being a global because no classic script reads it — correctly, by
     module-check's rule. This assertion is about the storage key never changing,
     and a test that reads the key from the app can only ever agree with the app.
     "system.v1" is the thing that must not move: every existing install is
     behind it. */
  const r = run(`return {key: "system.v1", driver: Store.driver, durable: Store.durable, bytes: Store.bytes()>0, readable: Store.readJSON("system.v1") !== null};`);
  console.log(`         driver ${r.driver} · key ${r.key}`);
  return r.key === "system.v1" && !!r.driver;
});

/* ---------- the views ---------- */
check("every intelligence surface renders without throwing", () => {
  const r = run(`
    go("insight");
    renderBrief(); renderPatterns(); renderPlan(); renderReview(); renderBrain();
    go("quests","q-goals"); renderGoals();
    go("insight");
    const ids=["brBody","brRecs","brStyle","anaPatterns","plProposals","plLedger","rvBody","rvChange","homeFocus","goalLadder"];
    return { empty: ids.filter(i => !document.getElementById(i) || !document.getElementById(i).innerHTML.trim()) };
  `);
  if(r.empty.length) console.log("         empty: " + r.empty.join(", "));
  return r.empty.length === 0;
});

check("the whole app still walks every section", () => {
  const r = run(`
    const bad=[];
    for(const v of VIEWS){ try{ go(v.k); }catch(e){ bad.push(v.k+": "+e.message); } }
    go("home");
    return {bad};
  `);
  return r.bad.length === 0;
});

/* ══════════════ Phase 4 — gamification & progression ══════════════ */
console.log("\n  — Phase 4 —");

check("balance config exposes every tunable number in one place", () => {
  const r = run(`return { xp:Object.keys(BALANCE.xp).length, ranks:BALANCE.ranks.length,
    diff:BALANCE.difficulty.length, ach:BALANCE.achievements.length, world:BALANCE.world.length,
    titles:BALANCE.titles.length, types:BALANCE.questTypes.length };`);
  console.log(`         ${r.ach} achievements · ${r.world} world areas · ${r.titles} titles · ${r.ranks} ranks`);
  return r.xp >= 10 && r.ranks === 7 && r.diff === 6 && r.ach > 20 && r.world >= 8;
});

check("rank needs evidence, not just level", () => {
  const r = run(`
    const h=H(); h.level=50; h.xp=0; h.streak=1; h.totalCleared=5;
    const b=brain(); b.achievements=[]; b.bosses=[];
    save(); invalidateStats();
    const low=rankProgress();
    return { rank:low.rank, next:low.next && low.next.rank, missing:low.next && low.next.missing.map(m=>m.what) };
  `);
  console.log(`         level 50 with no record → rank ${r.rank}, blocked on: ${r.missing.join(", ")}`);
  return r.rank === "E" && r.missing.length > 0;
});

check("rank rises once the evidence exists", () => {
  /* Self-contained on purpose. An earlier version leaned on the clear-count left
     behind by thirty preceding tests, and drifted to three quests below the D-Rank
     threshold as soon as an unrelated test changed the seeded history. A check
     that fails because of what ran before it is not testing the thing it names. */
  const r = run(`
    const h=H();
    const keep = { done:h.done, level:h.level, streak:h.streak, rank:h.rank };
    const tier = BALANCE.ranks.find(x => x.r === "C");
    h.level = tier.level; h.streak = tier.need.streak; h.rank = "E";
    /* synthesise exactly the evidence C-Rank asks for, and no more */
    h.done = {};
    let placed = 0;
    for(let i = 1; placed < tier.need.cleared; i++){
      const d = new Date(); d.setDate(d.getDate() - i);
      const set = {};
      for(const q of h.quests){ if(placed >= tier.need.cleared) break; set[q.id] = true; placed++; }
      h.done[todayKey(d)] = set;
      if(i > 400) break;
    }
    const b = brain();
    b.achievements = BALANCE.achievements.slice(0, tier.need.achievements).map(a => ({ id:a.id, at:todayKey() }));
    b.bosses = Array.from({length: tier.need.bosses}, (_,i) => ({ id:"b"+i, name:"x", stages:[], done:true }));
    b.records = { bestStreak: tier.need.streak };
    save(); invalidateStats();

    const rp = rankProgress(); applyRank();
    const got = { rank:rp.rank, applied:H().rank, cleared:progressStats(true).cleared };

    /* and now prove the gate is real: strip one requirement, rank must fall back */
    b.bosses = [];
    save(); invalidateStats();
    got.withoutBosses = rankProgress().rank;

    Object.assign(h, keep); save(); invalidateStats();
    return got;
  `);
  console.log(`         C-Rank met with ${r.cleared} cleared → ${r.rank}; bosses removed → ${r.withoutBosses}`);
  return r.rank === "C" && r.applied === "C" && r.withoutBosses !== "C";
});

check("achievements unlock from real activity only", () => {
  const r = run(`
    const b=brain(); b.achievements=[]; save(); invalidateStats();
    const fresh=checkAchievements();
    return { ids:fresh.map(a=>a.id), n:fresh.length };
  `);
  console.log("         earned from seeded history: " + r.ids.slice(0,6).join(", "));
  return r.n > 0 && r.ids.includes("streak7");
});

check("secret achievements stay hidden until earned", () => {
  const r = run(`
    const shown=achievementList().map(a=>a.id);
    const secretIds=BALANCE.achievements.filter(a=>a.secret).map(a=>a.id);
    const earned=new Set((brain().achievements||[]).map(x=>x.id));
    const leaked=secretIds.filter(id=>shown.includes(id) && !earned.has(id));
    return { leaked, hidden:secretsRemaining() };
  `);
  return r.leaked.length === 0;
});

check("titles cannot be equipped before they are earned", () => {
  const r = run(`
    const b=brain(); b.achievements=[]; b.title=null; save(); invalidateStats();
    const bad=equipTitle("t_scholar");
    b.achievements=[{id:"book10",at:todayKey()}]; save(); invalidateStats();
    const good=equipTitle("t_scholar");
    return { bad, good, cur:equippedTitle() && equippedTitle().id };
  `);
  return r.bad === false && r.good === true && r.cur === "t_scholar";
});

check("a boss is a chain, and finishing it pays properly", () => {
  const r = run(`
    const before=H().totalXp;
    const boss=createBoss({name:"Master quadratics", template:"topic"});
    let mid=0;
    boss.stages.forEach((s,i)=>{ clearBossStage(boss.id,s.id); if(i===0) mid=H().totalXp; });
    const done=getBoss(boss.id);
    return { stages:boss.stages.length, done:done.done, stageXp:mid-before,
             totalXp:H().totalXp-before, bosses:progressStats(true).bosses };
  `);
  console.log(`         ${r.stages} stages · first stage +${r.stageXp} XP · whole boss +${r.totalXp} XP`);
  return r.done === true && r.stages === 5 && r.totalXp > r.stageXp * r.stages;
});

check("clearing a quest twice in a day pays once", () => {
  const r = run(`
    const h=H(); const q=questsFor()[0];
    if(!q) return {skipped:true};
    brain().xpLedger={day:todayKey(), total:0, paid:{}};
    delete (h.done[todayKey()]||{})[q.id]; save();
    const a=h.totalXp; toggleQuest(q);
    const b=h.totalXp; toggleQuest(q); toggleQuest(q);
    const c=h.totalXp;
    return { first:b-a, second:c-b, cleared:!!(h.done[todayKey()]||{})[q.id] };
  `);
  if(r.skipped) return true;
  console.log(`         first clear +${r.first} XP · re-clear +${r.second} XP`);
  return r.first > 0 && r.second === 0 && r.cleared === true;
});

check("the daily XP ceiling holds", () => {
  const r = run(`
    const b=brain(); b.xpLedger={day:todayKey(), total:0, paid:{}}; save();
    const before=H().totalXp;
    for(let i=0;i<200;i++) grantXp(100,"farm test");   /* untagged — the loop the cap exists for */
    return { gained:H().totalXp-before, cap:BALANCE.antiFarm.dailyXpCap };
  `);
  console.log(`         200 x 100 XP requested → ${r.gained} granted (cap ${r.cap})`);
  return r.gained === r.cap;
});

check("world areas open on progression and nothing functional is gated", () => {
  const r = run(`
    const b=brain(); b.areas=[]; save(); invalidateStats();
    const opened=checkWorld().map(a=>a.k);
    const map=worldMap();
    /* every area must map onto a view that is already reachable from the rail */
    const keys=VIEWS.map(v=>v.k);
    return { opened, total:map.length, locked:map.filter(a=>!a.unlocked).length, views:keys.length };
  `);
  console.log(`         opened: ${r.opened.join(", ") || "(none)"} · ${r.locked} still closed of ${r.total}`);
  return r.opened.includes("gate") && r.total >= 8;
});

check("next milestone is the nearest one, not always the level", () => {
  const r = run(`
    const m=nextMilestone();
    return { kind:m.primary.kind, pct:m.primary.pct, n:m.all.length,
             sorted:m.all.every((x,i,a)=>i===0||a[i-1].pct>=x.pct) };
  `);
  console.log(`         next: ${r.kind} at ${Math.round(r.pct*100)}% (${r.n} tracked)`);
  return r.sorted === true && r.n >= 2;
});

check("personal bests survive a later bad run", () => {
  const r = run(`
    const h=H(); h.streak=40; updateRecords();
    h.streak=0; updateRecords();
    const best=personalBests().find(x=>x.k==="bestStreak");
    return { best:best.v, streak:h.streak };
  `);
  return r.best === 40 && r.streak === 0;
});

check("the Path renders every panel", () => {
  const r = run(`
    go("path"); renderPath();
    const ids=["pgNext","pgStanding","pgTitles","pgBosses","pgAch","pgWorld","pgRecords"];
    return { empty: ids.filter(i=>!document.getElementById(i) || !document.getElementById(i).innerHTML.trim()) };
  `);
  if(r.empty.length) console.log("         empty: " + r.empty.join(", "));
  return r.empty.length === 0;
});

/* ══════════════ Phase 5 — the Academy ══════════════ */
console.log("\n  — Phase 5 —");

check("a syllabus outline builds the tree", () => {
  const r = run(`
    const s=addSubject({name:"Physics", target:"A"});
    const res=importOutline(s.id, ["Mechanics"," - Forces"," - Moments"," - Momentum","Waves"," - Refraction"," - Diffraction"].join(String.fromCharCode(10)));
    return { units:res.units, topics:res.topics, tree:getSubject(s.id).units.length,
             first:allTopics(s.id)[0].name, sid:s.id };
  `);
  console.log(`         ${r.units} units, ${r.topics} topics from pasted text`);
  return r.units === 2 && r.topics === 5 && r.tree === 2;
});

check("reading a topic does NOT make it mastered", () => {
  const r = run(`
    const t=allTopics()[0];
    for(let i=0;i<20;i++) markStudied(t.id);
    const m=masteryOf(t.id);
    return { state:m.state, pct:m.pct, applied:m.states.applied, why:m.why };
  `);
  console.log(`         20x "studied" → ${r.state} at ${Math.round(r.pct*100)}%`);
  return r.state === "learning" && r.pct <= 0.3 && r.applied === false;
});

check("answering questions correctly is what moves mastery", () => {
  const r = run(`
    const t=allTopics()[0];
    const easy=[], hard=[];
    for(let i=0;i<6;i++) easy.push(addQuestion({topicId:t.id, text:"q"+i, answer:"a", difficulty:"moderate"}));
    hard.push(addQuestion({topicId:t.id, text:"hard1", answer:"a", difficulty:"hard"}));
    easy.forEach(q=>recordAnswer({questionId:q.id, correct:true}));
    recordAnswer({questionId:hard[0].id, correct:true});
    const m=masteryOf(t.id);
    return { state:m.state, pct:m.pct, applied:m.states.applied, acc:m.accuracy };
  `);
  console.log(`         7 correct incl. 1 hard → ${r.state} at ${Math.round(r.pct*100)}%`);
  return r.applied === true && r.state === "review" && r.pct >= 0.7;
});

check("mastered needs recall after a real gap, not just accuracy", () => {
  const r = run(`
    const t=allTopics()[0];
    const before=masteryOf(t.id).state;
    const c=addCard({topicId:t.id, front:"f", back:"b"});
    /* three successful recalls, intervals widening */
    reviewCard(c.id,"good"); reviewCard(c.id,"good"); reviewCard(c.id,"easy");
    const m=masteryOf(t.id);
    return { before, after:m.state, recalled:m.states.recalled, gap:getTopic(t.id).ev.reviewGap };
  `);
  console.log(`         ${r.before} → ${r.after} after recall gap of ${r.gap} days`);
  return r.before === "review" && r.after === "mastered" && r.recalled === true;
});

check("a wrong answer lands in the error log with a cause", () => {
  const r = run(`
    const t=allTopics()[1];
    const q=addQuestion({topicId:t.id, text:"wrongone", answer:"a"});
    recordAnswer({questionId:q.id, correct:false, mistakeKind:"calc", given:"42"});
    const log=errorLog();
    const e=log.find(x=>x.questionId===q.id);
    return { n:log.length, kind:e&&e.kind, fix:e&&e.kindInfo.fix.length };
  `);
  return r.kind === "calc" && r.fix > 20;
});

check("getting it right later closes the error", () => {
  const r = run(`
    const t=allTopics()[1];
    const q=addQuestion({topicId:t.id, text:"loopq", answer:"a"});
    recordAnswer({questionId:q.id, correct:false, mistakeKind:"gap"});
    const open1=errorLog().filter(e=>e.questionId===q.id).length;
    recordAnswer({questionId:q.id, correct:true});
    const open2=errorLog().filter(e=>e.questionId===q.id).length;
    return { open1, open2 };
  `);
  return r.open1 === 1 && r.open2 === 0;
});

check("repeated errors on one topic become a boss chain", () => {
  const r = run(`
    const t=allTopics()[2];
    for(let i=0;i<4;i++){
      const q=addQuestion({topicId:t.id, text:"bad"+i, answer:"a"});
      recordAnswer({questionId:q.id, correct:false, mistakeKind:"misunder"});
    }
    const cands=recoveryCandidates();
    const boss=bossFromTopic(t.id);
    return { cands:cands.length, top:cands[0]&&cands[0].errors, stages:boss&&boss.stages.length, name:boss&&boss.name };
  `);
  console.log(`         "${r.name}" — ${r.stages} stages from ${r.top} errors`);
  return r.cands >= 1 && r.stages === 5;
});

check("practice draws weak topics first", () => {
  const r = run(`
    const set=buildPracticeSet(null, 10);
    const first=set[0];
    const m0=masteryOf(first.topic.id);
    const avg=allTopics().map(t=>masteryOf(t.id).pct).reduce((a,b)=>a+b,0)/allTopics().length;
    return { n:set.length, firstPct:m0.pct, avg };
  `);
  return r.n > 0 && r.firstPct <= r.avg + 0.01;
});

check("failing a card resets its interval", () => {
  const r = run(`
    const t=allTopics()[0];
    const c=addCard({topicId:t.id, front:"x", back:"y"});
    reviewCard(c.id,"good"); reviewCard(c.id,"good");
    const grown=(academy().cards.find(x=>x.id===c.id)||{}).interval;
    reviewCard(c.id,"again");
    const reset=(academy().cards.find(x=>x.id===c.id)||{}).interval;
    return { grown, reset };
  `);
  console.log(`         interval ${r.grown}d → ${r.reset}d after "again"`);
  return r.grown >= 1 && r.reset === 0;
});

check("the revision plan recalculates instead of storing a schedule", () => {
  const r = run(`
    const s=subjects()[0];
    const far=new Date(); far.setDate(far.getDate()+60);
    const e=addExam({subjectId:s.id, name:"Mock", date:todayKey(far)});
    const p1=revisionPlan(e.id);
    const near=new Date(); near.setDate(near.getDate()+5);
    const ex=academy().exams.find(x=>x.id===e.id); ex.date=todayKey(near); save(); invalidateAcademy();
    const p2=revisionPlan(e.id);
    return { farPhases:p1.phases.filter(x=>!x.skipped).map(x=>x.k),
             nearPhases:p2.phases.filter(x=>!x.skipped).map(x=>x.k),
             farDays:p1.days, nearDays:p2.days };
  `);
  console.log(`         60 days → ${r.farPhases.join(",")} · 5 days → ${r.nearPhases.join(",")}`);
  return r.farPhases.includes("foundation") && !r.nearPhases.includes("foundation");
});

check("the plan says so when the hours do not add up", () => {
  const r = run(`
    const s=subjects()[0];
    const soon=new Date(); soon.setDate(soon.getDate()+4);
    const e=addExam({subjectId:s.id, name:"Crunch", date:todayKey(soon)});
    setExamHours(e.id, 1);
    const p=revisionPlan(e.id);
    return { feasible:p.feasible, warn:(p.warning||"").length, need:p.hoursNeeded, have:p.hoursTotal };
  `);
  console.log(`         ~${r.have}h available vs ~${r.need}h needed → warning: ${r.warn>0}`);
  return r.feasible === false && r.warn > 80;
});

check("readiness reports coverage and never predicts a grade", () => {
  const r = run(`
    const e=academy().exams[0];
    const rd=examReadiness(e.id);
    const t=(rd.verdict||"").toLowerCase();
    return { verdict:rd.verdict, claims:/will (get|score|achieve)|predicted grade|guarantee/.test(t) };
  `);
  return r.claims === false && r.verdict.length > 20;
});

check("grades record a transparent gap, not a prediction", () => {
  const r = run(`
    const s=subjects()[0];
    addGrade({subjectId:s.id, name:"Paper 1", score:44, max:80});
    addGrade({subjectId:s.id, name:"Paper 2", score:60, max:80});
    const t=gradeTrend(s.id);
    return { n:t.n, delta:t.delta, gap:t.gap||"", claims:/you will|predicted|guarantee/i.test(t.gap||"") };
  `);
  return r.n === 2 && r.delta > 0 && r.claims === false;
});

check("a study session turns time into recorded evidence", () => {
  const r = run(`
    const t=allTopics()[3];
    const before=getTopic(t.id).ev.studied;
    const s=startSession({subjectId:t.subject.id, topicId:t.id, minutes:25, objective:"o"});
    finishSession(s.id, {accomplished:"did the examples", confidence:4});
    const after=getTopic(t.id).ev;
    return { before, after:after.studied, conf:after.confidence, mins:studyMinutes(7) };
  `);
  return r.after > r.before && r.conf === 4 && r.mins >= 25;
});

check("mastery fades when a topic is left alone", () => {
  const r = run(`
    const t=findTopicRef(allTopics()[0].id);
    const fresh=masteryOf(t.id).pct;
    const old=new Date(); old.setDate(old.getDate()-120);
    t.ev.lastReview=todayKey(old); save(); invalidateAcademy();
    const stale=masteryOf(t.id);
    return { fresh, stale:stale.pct, decayed:stale.decayed, floor:stale.pct>=0.5 };
  `);
  console.log(`         ${Math.round(r.fresh*100)}% → ${Math.round(r.stale*100)}% after 120 days untouched`);
  return r.decayed === true && r.stale < r.fresh && r.floor === true;
});

check("the Academy renders every panel, including from empty", () => {
  const r = run(`
    go("academy"); renderAcademy();
    const ids=["acToday","acStand","acSubjects","acStudy","acPractice","acCards","acErrors","acExams","acPlan","acGrades"];
    const filled=ids.filter(i=>!document.getElementById(i) || !document.getElementById(i).innerHTML.trim());
    /* and again with nothing set up at all */
    const keep=JSON.stringify(H().academy);
    H().academy=null; save(); invalidateAcademy(); renderAcademy();
    const emptyOk=(document.getElementById("acToday").innerHTML||"").length>50;
    H().academy=JSON.parse(keep); save(); invalidateAcademy(); renderAcademy();
    return { filled, emptyOk };
  `);
  if(r.filled.length) console.log("         empty: " + r.filled.join(", "));
  return r.filled.length === 0 && r.emptyOk === true;
});

check("a v13 record migrates all the way to the Academy schema", () => {
  const r = run(`
    const legacy={ hunters:{ old:{ id:"old", name:"Legacy", quests:[], done:{}, penalties:[],
      deadlines:[], goals:[], level:3, streak:2 } }, active:"old", store:{}, sec:{fails:{},until:{}} };
    const m=Store.migrate(JSON.parse(JSON.stringify(legacy)));
    const g=m.hunters.old;
    return { schema:m.schema, brain:!!g.brain, academy:!!g.academy,
             subjects:Array.isArray(g.academy.subjects), name:g.name };
  `);
  return r.schema === CURRENT_SCHEMA && r.brain && r.academy && r.subjects && r.name === "Legacy";
});

/* ══════════════ Phases 6–9 ══════════════ */
console.log("\n  — Phase 6: the Online Gate —");

check("the app is fully usable with no account and no server", () => {
  const r = run(`
    const st=gateStatus();
    return { mode:st.mode, text:st.text, pending:st.pending, driver:Store.driver };
  `);
  return r.mode === "local" && /without an account|fully functional/i.test(r.text);
});

check("changes are tracked incrementally, not as a whole-database dump", () => {
  const r = run(`
    const c=cloud(); c.queue=[]; c.rev=0; save();
    markChanged("progress","a"); markChanged("progress","b"); markChanged("progress","c");
    markChanged("academy","x");
    const q=pendingChanges();
    return { entries:q.length, collapsed:q[0].n, scopes:q.map(x=>x.scope) };
  `);
  console.log(`         4 edits across 2 scopes → ${r.entries} queue entries (${r.collapsed} collapsed)`);
  return r.entries === 2 && r.collapsed === 3;
});

/* The sync tests have to run as one ordered chain. An earlier version ran them as
   three separate checks, and every one of them "passed" — because the synchronous
   test body finished before signIn's promise ever resolved, so the later checks
   were asserting against a client that had never signed in. The failure only
   surfaced because the round-trip assertion looked at the server rather than at a
   return value. Async work gets one chain and one set of assertions at the end. */
run(`
  (async () => {
    const out = {};
    try{
      CloudDrivers.loopback._reset();
      setCloudDriver("loopback");
      const acct = await signIn({ displayName:"Tester" });
      out.signedIn = !!acct && cloud().mode === "account";

      H().totalXp = 4242; markChanged("progress","xp");
      const r1 = await syncNow({ force:true });
      const server = CloudDrivers.loopback._peek(cloud().account.id);
      out.pushOk    = r1.ok;
      out.serverXp  = server && server.payload.progress.totalXp;
      out.drained   = pendingChanges().length === 0;

      /* a second device pushes first — our next push must merge, not clobber */
      const mine = cloud().account.id;
      const theirs = JSON.parse(JSON.stringify(server.payload));
      theirs.progress.totalXp = 9000;
      theirs.progress.done["1999-01-01"] = { ghost:true };
      await CloudDrivers.loopback.push(mine, theirs, server.rev);
      H().totalXp = 5000; markChanged("progress","local edit");
      const r2 = await syncNow({ force:true });
      const after = CloudDrivers.loopback._peek(mine);
      out.concurrentOk   = r2.ok;
      out.keptTheirDay   = !!after.payload.progress.done["1999-01-01"];
      out.keptHigherXp   = after.payload.progress.totalXp === 9000;

      /* forced network failure */
      CloudDrivers.loopback._failNext(1);
      markChanged("progress","will fail");
      const r3 = await syncNow({ force:true });
      out.failOk       = r3.ok === false;
      out.retry        = r3.retryInMs;
      out.queueKept    = pendingChanges().length > 0;
      out.errorShown   = !!cloud().lastError;

      /* signing out keeps everything local */
      const xp = H().totalXp, quests = (H().quests||[]).length;
      signOut();
      out.localIntact = cloud().mode === "local" && H().totalXp === xp && (H().quests||[]).length === quests;
    }catch(e){ out.threw = String(e && e.message || e); }
    window.__SYNC = JSON.stringify(out);
  })();
  return {};
`);

check("external services fail alone and never throw", () => {
  const r = run(`
    const st=Api.status();
    const media=st.find(x=>x.key==="media");
    return { n:st.length, mediaMode:media.mode, states:st.map(x=>x.state) };
  `);
  console.log(`         ${r.n} services · media is ${r.mediaMode}`);
  return r.n >= 4 && ["unconfigured","direct","proxy"].includes(r.mediaMode);
});

check("a browser-held key is labelled public, and a proxy is offered", () => {
  const r = run(`
    apiConfig({ keys:{ media:"fake-key" } });
    const direct=apiKeyAdvice("media");
    apiConfig({ proxyBase:"https://proxy.example" });
    const proxied=apiKeyAdvice("media");
    apiConfig({ proxyBase:"" });
    return { directWarn:direct.warn===true, directText:direct.text,
             proxyMode:apiMode("media")==="direct", proxyText:proxied.text };
  `);
  return r.directWarn === true && /public/i.test(r.directText) && /server/i.test(r.proxyText);
});

check("entitlements never let the browser be the authority", () => {
  const r = run(`
    const e=entitlement("CLOUD_SYNC");
    return { allowed:e.allowed, source:e.source, note:e.note||"" };
  `);
  return r.allowed === true && r.source === "local" && /never from the browser/i.test(r.note);
});

console.log("\n  — Phases 7 & 8: opportunities and competitions —");

check("competitions are an opportunity subtype, not a second database", () => {
  const r = run(`
    const o=opps(); o.items=[]; save();
    addOpportunity({kind:"competition", name:"Maths Olympiad", organiser:"Org", url:"https://x.test"});
    addOpportunity({kind:"scholarship", name:"STEM Bursary", organiser:"Org2", url:"https://y.test"});
    return { stores:Object.keys(opps()), n:oppList().length, kinds:oppList().map(x=>x.kind) };
  `);
  return r.n === 2 && r.kinds.includes("competition") && r.kinds.includes("scholarship");
});

check("a passed deadline blocks the match outright", () => {
  const r = run(`
    const past=new Date(); past.setDate(past.getDate()-3);
    const rec=addOpportunity({kind:"competition", name:"Closed thing", deadline:todayKey(past)});
    const m=matchOpportunity(rec);
    return { blocked:m.blocked, score:m.score, reason:m.factors[0].text };
  `);
  console.log(`         "${r.reason}"`);
  return r.blocked === true && r.score === 0;
});

check("every match shows its factors, never a bare percentage", () => {
  const r = run(`
    const soon=new Date(); soon.setDate(soon.getDate()+30);
    const rec=addOpportunity({kind:"competition", name:"Physics Challenge", deadline:todayKey(soon), online:true});
    const m=matchOpportunity(rec);
    return { n:m.factors.length, hasElig:m.factors.some(f=>f.k==="Eligibility"),
             eligState:(m.factors.find(f=>f.k==="Eligibility")||{}).state,
             allText:m.factors.every(f=>f.text.length>10) };
  `);
  return r.n >= 4 && r.hasElig && r.eligState === "unknown" && r.allText;
});

check("nothing is ever shown as verified by THE SYSTEM", () => {
  const r = run(`
    const rec=oppList().find(x=>x.name==="Physics Challenge");
    const before=verifyState(rec).k;
    markChecked(rec.id);
    const after=verifyState(rec).k;
    const labels=VERIFY.map(v=>v.label);
    return { before, after, labels };
  `);
  return r.before === "unverified" && r.after === "selfcheck";
});

check("stale records are flagged for re-checking, not silently trusted", () => {
  const r = run(`
    const rec=oppList().find(x=>x.name==="Physics Challenge");
    const old=new Date(); old.setDate(old.getDate()-45);
    rec.lastChecked=todayKey(old); save();
    return { state:verifyState(rec).k, blurb:verifyState(rec).blurb };
  `);
  return r.state === "needsreview";
});

check("scam signals are raised as questions, never as accusations", () => {
  const r = run(`
    const bad=addOpportunity({kind:"scholarship", name:"Guaranteed 100% funding",
      cost:"processing fee", url:"http://bit.ly/x", notes:"apply via whatsapp"});
    const s=scamCheck(bad);
    return { flagged:s.flagged, n:s.signals.length, advice:s.advice,
             accuses:/scam|fraud|fake/i.test(s.signals.join(" ")) };
  `);
  console.log(`         ${r.n} signals raised`);
  return r.flagged === true && r.n >= 3 && r.accuses === false && /never send money/i.test(r.advice) && /prove/i.test(r.advice);
});

check("an application becomes a boss chain rather than a second task system", () => {
  const r = run(`
    const rec=oppList().find(x=>x.name==="Physics Challenge");
    buildChecklist(rec.id);
    const boss=bossFromOpportunity(rec.id);
    return { items:rec.checklist.length, stages:boss&&boss.stages.length, name:boss&&boss.name };
  `);
  return r.items >= 5 && r.stages >= 5;
});

check("a result is recorded as self-reported unless evidence is attached", () => {
  const r = run(`
    const rec=oppList().find(x=>x.name==="Physics Challenge");
    recordResult(rec.id,{kind:"Finalist"});
    const a=getOpp(rec.id).result.verification;
    recordResult(rec.id,{kind:"Finalist", evidenceUrl:"https://results.test", verified:true});
    const b=getOpp(rec.id).result.verification;
    return { a, b };
  `);
  return r.a === "selfreported" && r.b === "evidence";
});

check("activity depth rewards duration and responsibility, not count", () => {
  const r = run(`
    const o=opps(); o.activities=[];
    const old=new Date(); old.setDate(old.getDate()-300);
    const deep=addActivity({name:"Robotics", role:"Team lead", start:todayKey(old)});
    for(let i=0;i<12;i++) logActivity(deep.id,{hours:2});
    const shallow=addActivity({name:"Chess", role:"Member"});
    return { deep:activityDepth(deep).depth, shallow:activityDepth(shallow).depth,
             note:activityDepth(deep).note };
  `);
  console.log(`         12 months as team lead ${Math.round(r.deep*100)}% vs new member ${Math.round(r.shallow*100)}%`);
  return r.deep > r.shallow + 0.4;
});

check("internal challenges cannot be re-rolled until they are easy", () => {
  const r = run(`
    const o=opps(); o.challenges=[]; save();
    const a=drawChallenge("daily");
    const b=drawChallenge("daily");
    return { first:a&&a.name, second:b, internal:a&&a.internal };
  `);
  return r.first && r.second === null && r.internal === true;
});

console.log("\n  — Phase 9: projects and portfolio —");

check("a project starts from a template with real milestones", () => {
  const r = run(`
    const st=projectStore(); st.items=[]; save();
    const p=createProject({title:"Line-following robot", template:"robotics", category:"STEM"});
    return { ms:p.milestones.length, stage:p.stage, vis:p.visibility, first:p.milestones[0].name };
  `);
  console.log(`         "${r.first}" — ${r.ms} milestones, starts ${r.stage} and ${r.vis}`);
  return r.ms >= 6 && r.stage === "idea" && r.vis === "private";
});

check("progress is weighted, not a task count", () => {
  const r = run(`
    const p=projects()[0];
    setMilestoneWeight(p.id, p.milestones[0].id, 1);
    setMilestoneWeight(p.id, p.milestones[1].id, 5);
    toggleMilestone(p.id, p.milestones[0].id);
    const light=projectProgress(getProject(p.id)).pct;
    toggleMilestone(p.id, p.milestones[0].id);
    toggleMilestone(p.id, p.milestones[1].id);
    const heavy=projectProgress(getProject(p.id)).pct;
    return { light, heavy };
  `);
  console.log(`         weight-1 milestone ${Math.round(r.light*100)}% vs weight-5 ${Math.round(r.heavy*100)}%`);
  return r.heavy > r.light * 2;
});

check("a project cannot reach the portfolio without evidence and reflection", () => {
  const r = run(`
    const p=projects()[0];
    setProjectStage(p.id,"completed");
    const blocked=featureProject(p.id,true);
    addEvidence(p.id,{name:"GitHub repository", url:"https://github.test/x"});
    const stillBlocked=featureProject(p.id,true);
    saveReflection(p.id,{problem:"navigation",learning:"PID tuning"});
    const ok=featureProject(p.id,true);
    return { blocked:blocked.ok, blockers:blocked.blockers,
             stillBlocked:stillBlocked.ok, ok:ok.ok, featured:getProject(p.id).featured };
  `);
  console.log(`         refused with: ${(r.blockers||[]).length} blockers`);
  return r.blocked === false && r.stillBlocked === false && r.ok === true && r.featured === true;
});

check("a skill claim without evidence is refused", () => {
  const r = run(`
    const p=projects()[0];
    const bad=attachSkill(p.id,{name:"Programming", evidence:""});
    const good=attachSkill(p.id,{name:"Programming", evidence:"wrote the control software"});
    return { bad, good:!!good, n:getProject(p.id).skills.length };
  `);
  return r.bad === null && r.good === true && r.n === 1;
});

check("identity documents are refused as evidence", () => {
  const r = run(`
    return { warn: evidenceWarning("Scan of my passport"),
             clean: evidenceWarning("Photo of the finished robot") };
  `);
  return typeof r.warn === "string" && r.warn.length > 40 && r.clean === null;
});

check("the portfolio preview never leaks private evidence", () => {
  const r = run(`
    const p=projects()[0];
    const ev=getProject(p.id).evidence[0];
    const priv=addEvidence(p.id,{name:"Private notes", url:"https://x.test/private"});
    setEvidenceVisibility(p.id, ev.id, "portfolio");
    const view=portfolioPreview();
    const shown=view.projects[0].evidence.map(e=>e.name);
    return { shown, hasPrivate:shown.includes("Private notes"), vis:view.visibility };
  `);
  console.log(`         shown on portfolio: ${r.shown.join(", ")}`);
  return r.hasPrivate === false && r.vis === "private";
});

check("quality is dimensions, never one score", () => {
  const r = run(`
    const d=projectDimensions(projects()[0]);
    return { n:d.dims.length, met:d.met, keys:d.dims.map(x=>x.k), hasScore:"score" in d };
  `);
  return r.n === 6 && r.hasScore === false;
});

check("the growth journey assembles itself from real records", () => {
  const r = run(`
    const t=growthTimeline();
    return { n:t.length, kinds:[...new Set(t.map(x=>x.kind))] };
  `);
  console.log(`         ${r.n} events · ${r.kinds.join(", ")}`);
  return r.n > 0 && r.kinds.length >= 2;
});

check("archiving keeps a project; nothing is deleted by accident", () => {
  const r = run(`
    const p=projects()[0];
    archiveProject(p.id,true);
    return { stillThere:!!getProject(p.id), archived:getProject(p.id).archived,
             visible:projects().filter(x=>!x.archived).length };
  `);
  run(`archiveProject(projects()[0].id,false); return {};`);
  return r.stillThere === true && r.archived === true;
});

check("all three new sections render, including from empty", () => {
  const r = run(`
    go("beyond"); renderBeyond();
    go("build"); renderBuild();
    go("gate"); renderOnlineGate();
    const ids=["boSoon","boRanked","boGaps","boAll","boActs","boChal",
               "bProjects","bSuggest","bPortfolio","bPreview","bJourney",
               "gStatus","gSync","gServices","gData"];
    const empty=ids.filter(i=>!document.getElementById(i)||!document.getElementById(i).innerHTML.trim());
    const h=H(); const keep=[JSON.stringify(h.opportunities), JSON.stringify(h.projects)];
    h.opportunities=null; h.projects=null; save();
    renderBeyond(); renderBuild();
    const emptyOk=(document.getElementById("boRanked").innerHTML||"").length>50
               && (document.getElementById("bProjects").innerHTML||"").length>50;
    h.opportunities=JSON.parse(keep[0]); h.projects=JSON.parse(keep[1]); save();
    return { empty, emptyOk };
  `);
  if(r.empty.length) console.log("         empty: " + r.empty.join(", "));
  return r.empty.length === 0 && r.emptyOk === true;
});

check("a v13 record migrates all the way to schema 4", () => {
  const r = run(`
    const legacy={ hunters:{ old:{ id:"old", name:"Legacy", quests:[], done:{}, penalties:[],
      deadlines:[], goals:[], level:3, streak:2 } }, active:"old", store:{}, sec:{fails:{},until:{}} };
    const m=Store.migrate(JSON.parse(JSON.stringify(legacy)));
    const g=m.hunters.old;
    return { schema:m.schema, brain:!!g.brain, academy:!!g.academy, cloud:!!g.cloud,
             opps:!!g.opportunities, projects:!!g.projects, name:g.name, quests:Array.isArray(g.quests) };
  `);
  return r.schema === CURRENT_SCHEMA && r.brain && r.academy && r.cloud && r.opps && r.projects && r.name === "Legacy";
});

/* ══════════════ Phases 10–14 ══════════════ */
console.log("\n  — Phase 10: scholarships and applications —");

check("funding is itemised, and unstated never means free", () => {
  const r = run(`
    const soon=new Date(); soon.setDate(soon.getDate()+40);
    const o=addOpportunity({kind:"scholarship", name:"Funded Programme", deadline:todayKey(soon),
      eligibility:"Open to physics students. Requires a recommendation letter and proof of age."});
    window.__OPP=o.id;
    const blank=fundingBreakdown(o);
    setFunding(o.id,{tuition:"covered", accommodation:"covered", meals:"covered"});
    const partial=fundingBreakdown(getOpp(o.id));
    return { blankHead:blank.headline, blankCaution:blank.caution,
             head:partial.headline, caution:partial.caution,
             unspecified:partial.unspecified, covered:partial.covered };
  `);
  console.log(`         nothing recorded → "${r.blankHead}"`);
  console.log(`         3 covered, 5 unstated → "${r.head}"`);
  return /not recorded/i.test(r.blankHead) && /free/i.test(r.blankCaution)
      && r.unspecified === 5 && /not stated/i.test(r.head) && /travel|accommodation/i.test(r.caution);
});

check("eligibility never claims more than 'nothing contradicts it'", () => {
  const r = run(`
    const o=getOpp(window.__OPP);
    const e=checkEligibility(o);
    const labels=Object.values(ELIG_STATES).map(x=>x.label);
    return { state:e.state.k, label:e.state.label, factors:e.factors.map(f=>f.k),
             claims: labels.some(l=>/^you are eligible/i.test(l)) };
  `);
  console.log(`         → "${r.label}" · checked: ${r.factors.join(", ")}`);
  return r.claims === false && r.factors.includes("Age") && r.factors.includes("Recommendation");
});

check("things the app cannot see are named, not assumed", () => {
  const r = run(`
    const e=checkEligibility(getOpp(window.__OPP));
    const age=e.factors.find(f=>f.k==="Age");
    const p=studentProfile();
    return { ageState:age&&age.state, ageWhy:age&&age.text,
             holdsDob:"dob" in p || "age" in p, holdsCitizenship:"citizenship" in p };
  `);
  return r.ageState === "unknown" && /does not hold/i.test(r.ageWhy)
      && r.holdsDob === false && r.holdsCitizenship === false;
});

check("a package references existing work rather than copying it", () => {
  const r = run(`
    const st=projectStore(); st.items=[];
    const proj=createProject({title:"Robot", template:"robotics"});
    const pk=createPackage(window.__OPP);
    togglePackageItem(pk.id,"project",proj.id);
    /* editing the project must be visible through the package */
    getProject(proj.id).title="Robot v2"; save();
    const r2=packageReadiness(pk.id);
    const linked=getPackage(pk.id).projectIds[0];
    return { linked: linked===proj.id, title:getProject(linked).title,
             copied: JSON.stringify(getPackage(pk.id)).includes("Robot v2"),
             docs:r2.docs.length, evidence:r2.evidence };
  `);
  console.log(`         package holds an id, not a copy: ${!r.copied}`);
  return r.linked === true && r.title === "Robot v2" && r.copied === false && r.evidence === 1;
});

check("deadline intelligence names the constraint that depends on someone else", () => {
  const r = run(`
    const pk=packages()[0];
    const soon=new Date(); soon.setDate(soon.getDate()+14);
    getOpp(pk.oppId).deadline=todayKey(soon); save();
    setDocState(pk.id,"reference","required");
    const rd=packageReadiness(pk.id);
    return { alert:rd.alert||"", days:rd.days };
  `);
  console.log(`         "${String(r.alert).slice(0,90)}…"`);
  return /recommendation/i.test(r.alert) && /somebody else|someone else/i.test(r.alert);
});

check("the app warns against applying to everything", () => {
  const r = run(`
    for(let i=0;i<6;i++){
      const soon=new Date(); soon.setDate(soon.getDate()+50);
      const o=addOpportunity({kind:"scholarship", name:"Bulk "+i, deadline:todayKey(soon)});
      createPackage(o.id);
    }
    const d=applicationDashboard();
    return { load:d.load||"", open:d.inProgress.length+d.urgent.length };
  `);
  return /applications open/i.test(r.load) && r.open >= 6;
});

console.log("\n  — Phase 11: verification and records —");

check("a user cannot mark their own achievement verified", () => {
  const r = run(`
    const o=oppList().find(x=>x.kind==="competition") || addOpportunity({kind:"competition",name:"Comp"});
    recordResult(o.id,{kind:"Finalist"});
    const bad=setVerification("opportunity",o.id,"verified");
    const alsoBad=setVerification("opportunity",o.id,"official");
    const ok=setVerification("opportunity",o.id,"evidence");
    return { bad:bad.ok, reason:bad.reason, alsoBad:alsoBad.ok, ok:ok.ok,
             state:getOpp(o.id).result.verification };
  `);
  console.log(`         refused with: "${String(r.reason).slice(0,80)}…"`);
  return r.bad === false && r.alsoBad === false && r.ok === true && r.state === "evidence";
});

check("system achievements are separated from real-world ones", () => {
  const r = run(`
    const led=achievementLedger();
    const internal=led.filter(x=>x.internal).length;
    const external=led.filter(x=>!x.internal).length;
    const noted=led.filter(x=>x.internal).every(x=>/not an outside accomplishment/i.test(x.note||""));
    return { internal, external, noted };
  `);
  console.log(`         ${r.internal} internal · ${r.external} external`);
  return r.internal > 0 && r.external > 0 && r.noted === true;
});

check("ranking refuses to rank a population of one", () => {
  const r = run(`
    const c1=rankingConfidence(1), c2=rankingConfidence(8), c3=rankingConfidence(200);
    return { one:c1.ok, oneText:c1.text, few:c2.label, many:c3.label,
             pctSmall: percentile(3, 8), pctBig: percentile(30, 200) };
  `);
  console.log(`         n=1 → "${String(r.oneText).slice(0,70)}…"`);
  return r.one === false && /no user network|nobody to rank/i.test(r.oneText)
      && r.few === "Limited data" && r.pctSmall === null && r.pctBig === 15;
});

check("ties share a rank rather than being broken arbitrarily", () => {
  const r = run(`
    const ranked=rankAgainst([{id:"a",v:10},{id:"b",v:10},{id:"c",v:5}], "v");
    return { ranks:ranked.map(x=>x.rank) };
  `);
  return JSON.stringify(r.ranks) === JSON.stringify([1,1,3]);
});

check("personal boards each state their own metric", () => {
  const r = run(`
    const b=personalBoards();
    return { n:b.length, allMetrics:b.every(x=>x.metric && x.metric.length>20),
             keys:b.map(x=>x.k) };
  `);
  return r.n === 4 && r.allMetrics === true;
});

console.log("\n  — Phase 12: information architecture —");

check("the navigation actually builds — every area and every section", () => {
  const r = run(`
    buildNav();
    const areas=[...document.querySelectorAll(".rail-area")].map(e=>e.dataset.area);
    const subs=[...document.querySelectorAll(".sys-subbtn")].map(e=>e.dataset.view);
    const dock=[...document.querySelectorAll("[data-dock]")].map(e=>e.dataset.dock);
    const reachable=new Set([...document.querySelectorAll("[data-view]")].map(e=>e.dataset.view));
    const unreachable=VIEWS.map(v=>v.k).filter(k=>!reachable.has(k));
    return { areas, subs:subs.length, dock, unreachable };
  `);
  console.log(`         rail: ${r.areas.join(", ")} · dock: ${r.dock.join(", ")}`);
  return r.areas.length === 6 && r.dock.length === 5 && r.unreachable.length === 0;
});

check("thirteen sections became six areas, losing nothing", () => {
  const r = run(`
    const filed=Object.values(AREA_SECTIONS).flat();
    const missing=VIEWS.map(v=>v.k).filter(k=>!filed.includes(k));
    const orphan=filed.filter(k=>!VIEW[k]);
    return { areas:AREAS.length, sections:VIEWS.length, missing, orphan, dock:DOCK.length };
  `);
  console.log(`         ${r.sections} sections filed into ${r.areas} areas · dock shows ${r.dock}`);
  return r.areas === 6 && r.missing.length === 0 && r.orphan.length === 0 && r.dock <= 5;
});

check("every old deep link still resolves", () => {
  const r = run(`
    const bad=[];
    for(const k of ["home","quests","grow","learn","wealth","armory","insight","path",
                    "academy","beyond","build","gate","set"]){
      try{ go(k); if(currentView!==k) bad.push(k+" → "+currentView); }
      catch(e){ bad.push(k+": "+e.message); }
    }
    go("home");
    return { bad };
  `);
  return r.bad.length === 0;
});

check("the interface says which area you are in", () => {
  const r = run(`
    /* buildNav() runs inside enterSystem(), which the harness bypasses when it
       injects a hunter directly — so the whole navigation subsystem had never once
       been exercised by a test. Building it explicitly here is the fix; the gap it
       exposed is the more interesting half. */
    buildNav();
    go("beyond");
    const crumb=document.getElementById("crumb").textContent;
    const areaLit=[...document.querySelectorAll(".rail-area.open")].map(e=>e.dataset.area);
    const dockLit=[...document.querySelectorAll("[data-dock].on")].map(e=>e.dataset.dock);
    const title=document.title;
    go("home");
    return { crumb, areaLit, dockLit, title };
  `);
  console.log(`         Beyond → crumb "${r.crumb.split("\n")[0].slice(0,40)}" · area ${r.areaLit} · title "${r.title}"`);
  return r.areaLit.includes("grow") && r.dockLit.includes("grow") && /Beyond/.test(r.title);
});

console.log("\n  — Phase 13: device and network —");

check("a slow connection skips external calls instead of timing out", () => {
  const r = run(`
    const h=H(); h.prefs=h.prefs||{}; h.prefs.dataSaver=true; save();
    window.__P = Api.call("media","/discover/movie",{});
    return { saver:dataSaver(), slow:isSlowNetwork(), notice:networkNotice() };
  `);
  return r.saver === true && r.slow === true && r.notice.tone === "saver";
});

check("data saver explains exactly what it changed", () => {
  const r = run(`
    const e=dataSaverEffects();
    return { n:e.length, mentionsSafety: e.some(x=>/nothing you have written|not affected|unaffected/i.test(x)) };
  `);
  return r.n >= 3 && r.mentionsSafety === true;
});

check("the install prompt is withheld until the app has earned it", () => {
  const r = run(`
    const h=H(); const keep=h.done; const keepP=h.prefs;
    h.prefs={}; h.done={}; h.totalCleared=0; save();
    const cold=installOffer();
    h.done=keep; h.totalCleared=50; save();
    const warm=installOffer();
    h.prefs=keepP; h.prefs.dataSaver=false; save(); applyDataSaver();
    return { coldEarned:cold.earned, warmEarned:warm.earned, text:warm.text };
  `);
  return r.coldEarned === false && r.warmEarned === true;
});

/* The old version of this check was /SKIP_WAITING/.test(sw) — it asked whether
   the string appeared anywhere in the file. It did, in the message handler, so
   the check passed while the install handler called self.skipWaiting()
   unconditionally thirty lines above it. A worker that skips waiting never
   becomes a *waiting* worker, so the prompt device.js exists to show could never
   fire. That is asserting on intent, which the README of this very suite says
   not to do. The install handler specifically must not skip. */
check("an update never takes over a running session", () => {
  const sw = require("fs").readFileSync("./system/sw.js", "utf8");
  const install = sw.match(/addEventListener\(\s*["']install["'][\s\S]*?\n\}\);/);
  if(!install) return false;
  const skipsAtInstall = /skipWaiting\s*\(/.test(install[0]);
  const asksFirst = /["']SKIP_WAITING["'][\s\S]{0,160}?skipWaiting\s*\(/.test(sw);
  return asksFirst === true && skipsAtInstall === false;
});

console.log("\n  — Phase 14: integrity and honesty —");

check("no user-entered string is ever rendered as markup", () => {
  const r = run(`
    const probes=XSS_PROBES;
    const st=projectStore(); st.items=[];
    for(const p of probes) createProject({title:p, description:p, template:"blank"});
    go("build"); renderBuild();
    const host=document.getElementById("bProjects");
    return { injectedScripts: host.querySelectorAll("script").length,
             injectedImgs: host.querySelectorAll("img").length,
             injectedSvg: host.querySelectorAll("svg").length,
             iframes: host.querySelectorAll("iframe").length,
             titlesShown: host.textContent.includes("<img src=x") };
  `);
  console.log(`         5 XSS probes rendered · elements injected: ${r.injectedScripts + r.injectedImgs + r.injectedSvg + r.iframes}`);
  return r.injectedScripts === 0 && r.injectedImgs === 0 && r.injectedSvg === 0
      && r.iframes === 0 && r.titlesShown === true;
});

check("dangerous link schemes are refused", () => {
  const r = run(`
    return {
      js: safeUrl("javascript:alert(1)").ok,
      data: safeUrl("data:text/html,<script>x</script>").ok,
      rel: safeUrl("//evil.test").ok,
      good: safeUrl("https://example.org/x").ok,
      insecure: safeUrl("http://example.org").secure,
    };
  `);
  return r.js === false && r.data === false && r.rel === false && r.good === true && r.insecure === false;
});

check("integrity check finds broken data and repairs only what is safe", () => {
  const r = run(`
    const h=H();
    h.done[todayKey()] = { ...(h.done[todayKey()]||{}), ghostQuest:true };
    h.xp = -50;
    const sub = subjects()[0];
    if(sub){ const t=allTopics(sub.id)[0]; if(t){ const ref=findTopicRef(t.id); ref.ev.correct=999; ref.ev.attempts=3; } }
    save();
    const before=integrityCheck();
    const fixed=repairIntegrity();
    const after=integrityCheck();
    return { beforeHigh:before.counts.high, issues:before.issues.map(i=>i.what),
             fixed:fixed.fixed, afterHigh:after.counts.high, xp:H().xp };
  `);
  console.log(`         found ${r.issues.length} issues, repaired ${r.fixed}`);
  return r.beforeHigh > 0 && r.fixed > 0 && r.afterHigh === 0 && r.xp === 0;
});

check("the security posture states what it cannot protect", () => {
  const r = run(`
    const s=securityPosture();
    return { protects:s.protects.length, gaps:s.doesNotProtect.map(x=>x.k),
             authHonest: s.doesNotProtect.some(x=>/authoris/i.test(x.k) && /no server/i.test(x.why)) };
  `);
  console.log(`         does not protect: ${r.gaps.join(", ")}`);
  return r.protects >= 4 && r.gaps.length >= 3 && r.authHonest === true;
});

check("the QA register admits what is untested and why", () => {
  const r = run(`
    const q=qaRegister();
    const uncovered=q.areas.filter(a=>!a.covered);
    return { covered:q.covered, total:q.total,
             allExplained: uncovered.every(a=>a.why && a.why.length>15),
             uncovered: uncovered.map(a=>a.k) };
  `);
  console.log(`         ${r.covered}/${r.total} covered · untested: ${r.uncovered.join(", ")}`);
  return r.allExplained === true && r.uncovered.length > 0;
});

check("a failed save keeps the work in hand", () => {
  const r = run(`
    const orig=Store.writeJSON;
    Store.writeJSON=()=>({ok:false,error:new Error("quota")});
    const res=guardedSave({ draft:"an essay I just wrote" });
    Store.writeJSON=orig;
    const held=recoverUnsaved();
    return { ok:res.ok, message:res.message||"", held: held && held.work.draft };
  `);
  return r.ok === false && /still on screen/i.test(r.message) && r.held === "an essay I just wrote";
});

check("every new surface renders, including from empty", () => {
  const r = run(`
    go("beyond"); renderBeyond();
    go("path"); renderPath();
    go("gate"); renderOnlineGate();
    renderApply();
    const ids=["apDash","apDetail","pgVerify","pgBoards","gDevice","gIntegrity","gPosture"];
    const empty=ids.filter(i=>!document.getElementById(i)||!document.getElementById(i).innerHTML.trim());
    const h=H(); const keep=JSON.stringify(h.opportunities);
    h.opportunities=null; save();
    renderBeyond(); renderApply();
    const emptyOk=(document.getElementById("apDash").innerHTML||"").length>50;
    h.opportunities=JSON.parse(keep); save();
    go("home");
    return { empty, emptyOk };
  `);
  if(r.empty.length) console.log("         empty: " + r.empty.join(", "));
  return r.empty.length === 0 && r.emptyOk === true;
});

/* ══════════════ Phases 15–18 ══════════════ */
console.log("\n  — Phases 15-18 —");

check("performance reports what it measured and admits what it did not", () => {
  const r = run(`
    go("home"); go("academy"); go("quests"); go("home");
    const p=perfReport();
    return { views:p.views.length, untested:p.untested.map(u=>u.k),
             allExplained:p.untested.every(u=>u.why&&u.why.length>25),
             splitting:p.bundle.splitting, storage:p.storage.bytes>0, verdict:p.verdict };
  `);
  console.log(`         ${r.views} views timed · not measured: ${r.untested.length} areas`);
  return r.views >= 3 && r.untested.length >= 5 && r.allExplained === true && r.splitting === false;
});

check("storage names prune candidates instead of pruning", () => {
  const r = run(`
    const before=JSON.stringify(H().done).length;
    const s=storageReport();
    const after=JSON.stringify(H().done).length;
    return { unchanged: before===after, parts:s.parts.length, budget:s.budget };
  `);
  return r.unchanged === true && r.parts > 0;
});

check("the paywall rule is enforced in code, not in a comment", () => {
  const r = run(`
    const bad=registerPaidFeature("academy",{label:"Academy",why:"x",cost:"real"});
    const bad2=registerPaidFeature("practice",{label:"Practice",why:"x",cost:"real"});
    const bad3=registerPaidFeature("errorlog",{label:"Error log",why:"x",cost:"real"});
    const ok=registerPaidFeature("extrastorage",{label:"Extra storage",why:"costs money",cost:"real"});
    return { bad:bad.ok, reason:bad.reason, bad2:bad2.ok, bad3:bad3.ok, ok:ok.ok,
             academyFree: licenceCheck("academy").allowed,
             authority: licenceCheck("academy").authority };
  `);
  console.log(`         refused: "${String(r.reason).slice(0,72)}…"`);
  return r.bad === false && r.bad2 === false && r.bad3 === false && r.ok === true
      && r.academyFree === true && r.authority === "policy";
});

check("a licence check never claims the browser is the authority", () => {
  const r = run(`
    const l=licenceCheck("cloudsync");
    return { allowed:l.allowed, authority:l.authority, verified:l.verified, note:l.note };
  `);
  /* v18: this used to assert on one phrase in the note — /not a licence check/.
     Prose is the wrong place to hold a guarantee: rewording the sentence broke
     the check while the property it protects was strictly better than before.
     `verified` is a structured field, so it cannot be satisfied by wording, and
     the note is still required to disclaim rather than merely differ. */
  return r.authority === "device" && r.verified === false
      && /not enforceable|not a licence check/i.test(r.note);
});

check("money is integer minor units and regional", () => {
  const r = run(`
    region("gh"); const gh=pricing();
    region("intl"); const intl=pricing();
    region("gh");
    return { ghCur:gh.currency, intlCur:intl.currency,
             ints: Number.isInteger(gh.month) && Number.isInteger(gh.year),
             differs: gh.month !== intl.month };
  `);
  console.log(`         GHS ${r.ghCur} vs ${r.intlCur} · integer minor units: ${r.ints}`);
  return r.ints === true && r.ghCur === "GHS" && r.intlCur === "USD" && r.differs === true;
});

check("a region changes behaviour, not just a label", () => {
  const r = run(`
    const h=H(); h.prefs=h.prefs||{}; delete h.prefs.dataSaver; save();
    region("gh");
    const ghSaver=dataSaver();
    h.prefs.dataSaver=false; save();
    return { ghSaver, exams:region().exams, sensitive:region().dataCostSensitive };
  `);
  return r.ghSaver === true && r.exams.includes("WASSCE") && r.sensitive === true;
});

check("the launch gate has no override and is honest about why", () => {
  const r = run(`
    const L=launchChecklist();
    return { ready:L.ready, blocking:L.blocking.map(b=>b.k), verdict:L.verdict, stage:L.stage,
             hasOverride: typeof window.overrideLaunch === "function",
             allDetailed: L.items.every(i=>i.detail&&i.detail.length>20) };
  `);
  console.log(`         blocked on: ${r.blocking.join(", ")}`);
  return r.ready === false && r.blocking.length >= 3 && r.hasOverride === false
      && r.allDetailed === true && /personal use|closed testing/i.test(r.stage);
});

check("growth levers aimed at teenagers are refused by name", () => {
  const r = run(`
    const g=growthPlan();
    return { refused:g.refused.map(x=>x.k), channels:g.channels.length,
             hasReferral: g.refused.some(x=>/referral/i.test(x.k)),
             hasStreakGuilt: g.refused.some(x=>/streak/i.test(x.k)) };
  `);
  return r.hasReferral === true && r.hasStreakGuilt === true && r.channels >= 3;
});

check("Circle ships no messaging, directory or public profile", () => {
  const r = run(`
    const refused=COMMUNITY_REFUSED.map(x=>x.k.toLowerCase());
    const fns=["sendMessage","messageStudent","searchStudents","studentDirectory","publishProfile"];
    return { refused, missing: fns.filter(f=>typeof window[f]==="function"),
             allExplained: COMMUNITY_REFUSED.every(x=>x.why&&x.why.length>40) };
  `);
  console.log(`         refused: ${r.refused.length} features, none implemented`);
  return r.missing.length === 0 && r.refused.length >= 4 && r.allExplained === true;
});

check("a study group is local, and its health is judged honestly", () => {
  const r = run(`
    const c=community(); c.groups=[];
    const g=createGroup({name:"Physics revision", members:["Ama","Kwesi"]});
    const cold=groupHealth(community().groups.find(x=>x.id===g.id));
    for(let i=0;i<4;i++) logGroupSession(g.id,{minutes:45});
    const warm=groupHealth(community().groups[0]);
    return { cold:cold.verdict, warm:warm.verdict, sessions:warm.sessions,
             members:g.members.length };
  `);
  console.log(`         ${r.sessions} sessions → "${String(r.warm).slice(0,60)}…"`);
  return /stops meeting|group chat/i.test(r.cold) && r.sessions === 4 && /real/i.test(r.warm);
});

check("the teacher report excludes what the student did not choose to share", () => {
  const r = run(`
    const rep=buildReport();
    const txt=reportText(rep);
    return { sections:rep.sections.length, excluded:rep.excluded,
             hasReflections: /reflection/i.test(txt) && !/Not included/.test(txt.split("Not included")[0]||""),
             saysGenerated: /Generated by the student/i.test(txt),
             saysUnverified: /not independently verified/i.test(txt) };
  `);
  console.log(`         ${r.sections} sections · excludes ${r.excluded.length} kinds of content`);
  return r.sections >= 3 && r.excluded.length >= 4 && r.saysGenerated && r.saysUnverified;
});

check("class work pasted in becomes real deadlines", () => {
  const r = run(`
    const before=(H().deadlines||[]).length;
    const res=importClassWork(["Exercise 4A questions 1-10","Read chapter 7","Lab report draft"].join(String.fromCharCode(10)), {subject:"Physics"});
    const after=(H().deadlines||[]).length;
    return { added:res.added, delta:after-before, named:(H().deadlines||[]).slice(-1)[0].name };
  `);
  return r.added === 3 && r.delta === 3 && /Physics/.test(r.named);
});

check("the journey map names the earliest gap, not the furthest reach", () => {
  const r = run(`
    const j=journeyState();
    const firstUnreached=j.stages.find(s=>!s.reached);
    return { stages:j.stages.length, gap:j.gap&&j.gap.k,
             matchesEarliest: (!j.gap&&!firstUnreached) || (j.gap&&firstUnreached&&j.gap.k===firstUnreached.k),
             verdict:j.verdict };
  `);
  console.log(`         earliest gap: ${r.gap || "(none)"}`);
  return r.stages === 8 && r.matchesEarliest === true && r.verdict.length > 30;
});

check("Circle and Studio render, and stay inside the six areas", () => {
  const r = run(`
    go("circle"); renderCircle();
    go("studio"); renderStudio();
    go("home"); renderLoopMap();
    const ids=["ciGroups","ciPacts","ciReport","ciClass","ciRefused","stPerf","stBiz","stLaunch","homeJourney"];
    const empty=ids.filter(i=>!document.getElementById(i)||!document.getElementById(i).innerHTML.trim());
    return { empty, areas:AREAS.length, circleArea:areaOf("circle"), studioArea:areaOf("studio") };
  `);
  if(r.empty.length) console.log("         empty: " + r.empty.join(", "));
  return r.empty.length === 0 && r.areas === 6 && r.circleArea === "grow" && r.studioArea === "system";
});

check("a v13 record migrates all the way to schema 5", () => {
  const r = run(`
    const legacy={ hunters:{ old:{ id:"old", name:"Legacy", quests:[], done:{}, penalties:[],
      deadlines:[], goals:[], level:3, streak:2 } }, active:"old", store:{}, sec:{fails:{},until:{}} };
    const m=Store.migrate(JSON.parse(JSON.stringify(legacy)));
    const g=m.hunters.old;
    return { schema:m.schema, brain:!!g.brain, academy:!!g.academy, cloud:!!g.cloud,
             circle:!!g.circle, projects:!!g.projects, name:g.name };
  `);
  return r.schema === CURRENT_SCHEMA && r.brain && r.academy && r.cloud && r.circle && r.name === "Legacy";
});

/* ══════════════ v18 — the student graph ══════════════
   Every check below was confirmed to FAIL against the v17 source before it was
   confirmed to pass here. The audit measured the v17 behaviour precisely: a goal
   broken down produced 8 steps and 0 quests; clearing a quest left goal progress
   at 0%; six wrong answers on one topic moved mastery to 25% and never reached a
   recommendation. These assert the consequence, not the presence of a function. */
console.log("\n  — the student graph (v18) —");

check("the bus delivers to a listener, and a throwing listener is contained", () => {
  const r = run(`
    let got = null, second = 0;
    const off1 = Bus.on("TEST_PING", p => { throw new Error("listener exploded"); });
    const off2 = Bus.on("TEST_PING", p => { got = p.v; second++; });
    const ev = Bus.emit("TEST_PING", { v: 42 });
    off1(); off2();
    return { got, second, handled: ev.handled, errors: ev.errors.length };
  `);
  console.log(`         second listener still ran after the first threw: ${r.second === 1}`);
  /* A broken consumer must never stop a quest being ticked off. */
  return r.got === 42 && r.second === 1 && r.errors === 1;
});

check("an event cycle is refused instead of hanging the tab", () => {
  const r = run(`
    let n = 0;
    const off = Bus.on("TEST_LOOP", () => { n++; Bus.emit("TEST_LOOP", {}); });
    Bus.emit("TEST_LOOP", {});
    off();
    return { n };
  `);
  console.log(`         cycle stopped after ${r.n} hops`);
  return r.n > 0 && r.n <= 8;
});

check("a goal step becomes a real quest on the real board", () => {
  const r = run(`
    const before = H().quests.length;
    const g = addGoal({ name:"Finish the physics coursework", horizon:"month" });
    applyBreakdown(g.id, proposeBreakdown(g.name));
    const t = g.targets[0];
    const res = scheduleStepAsQuest(g.id, t.id, 0, { time:"18:30" });
    const q = res && res.quest;
    const again = scheduleStepAsQuest(g.id, t.id, 0, { time:"18:30" });
    return { before, after: H().quests.length, created: !!(res && res.created),
             onBoard: !!H().quests.find(x => x.id === q.id),
             link: q && q.link ? q.link.goal === g.id && q.link.step === 0 : false,
             time: q && q.time, duplicated: again && again.created, goalId:g.id, questId:q.id };
  `);
  console.log(`         board ${r.before} → ${r.after} quests · duplicate refused: ${!r.duplicated}`);
  /* v17: 8 steps, 0 quests. The ladder ended in text. */
  return r.after === r.before + 1 && r.created && r.onBoard && r.link
      && r.time === "18:30" && r.duplicated === false;
});

check("clearing that quest ticks the goal step off", () => {
  const r = run(`
    const g = allGoals().find(x => x.name === "Finish the physics coursework");
    const t = g.targets[0];
    const q = H().quests.find(x => x.link && x.link.goal === g.id && x.link.step === 0);
    const before = goalProgress(g).done;
    const stepBefore = !!t.steps[0].done;
    toggleQuest(q);
    const mid = goalProgress(getGoal(g.id)).done;
    const stepAfter = !!getGoal(g.id).targets[0].steps[0].done;
    toggleQuest(q);                       /* un-clear it again */
    const back = !!getGoal(g.id).targets[0].steps[0].done;
    return { before, mid, stepBefore, stepAfter, back };
  `);
  console.log(`         goal steps done ${r.before} → ${r.mid} · reversing un-ticks it: ${r.back === false}`);
  /* v17: goalPctBefore 0, goalPctAfter 0 — XP moved, the goal did not. */
  return r.stepBefore === false && r.stepAfter === true && r.mid === r.before + 1 && r.back === false;
});

check("a quest with no link is completely unaffected", () => {
  const r = run(`
    const plain = H().quests.find(x => !x.link && !isDone(x));
    const goalsBefore = JSON.stringify(H().goals);
    const xpBefore = H().xp;
    toggleQuest(plain);
    const same = JSON.stringify(H().goals) === goalsBefore;
    toggleQuest(plain);
    return { same, moved: H().xp !== xpBefore || true };
  `);
  /* The v17 path must survive untouched for every hunter who links nothing. */
  return r.same === true;
});

check("repeated mistakes on a topic reach the recommendation engine", () => {
  const r = run(`
    const s = addSubject({ name:"Chemistry" });
    const u = addUnit(s.id, "Bonding");
    const t = addTopic(s.id, u.id, "Ionic bonding");
    const q = addQuestion({ topicId:t.id, text:"Define an ionic bond", answer:"transfer of electrons" });
    for(let i = 0; i < 5; i++) recordAnswer({ questionId:q.id, correct:false, mistakeKind:"concept" });
    const recs = recommendations();
    const hit = recs.find(x => x.id === "errors:" + t.id);
    return { mastery: Math.round(masteryOf(getTopic(t.id)).pct * 100),
             found: !!hit, because: hit ? hit.because : "",
             tier: hit ? hit.tier : null, topicId:t.id };
  `);
  console.log(`         mastery ${r.mastery}% · surfaced as "${String(r.because).slice(0, 64)}…"`);
  /* v17: recommend.js contained no reference to mastery, errors or the Academy —
     recIds came back as [overdue, goal] no matter how badly a topic was going. */
  return r.found && r.tier === "high" && /unresolved mistakes/.test(r.because);
});

check("the recommendation names the numbers it used", () => {
  const r = run(`
    const recs = recommendations();
    const withReason = recs.filter(x => x.because && x.because.length > 40);
    const numeric = recs.filter(x => /\\d/.test(x.because || ""));
    return { total: recs.length, withReason: withReason.length, numeric: numeric.length };
  `);
  console.log(`         ${r.withReason}/${r.total} recommendations explain themselves in numbers`);
  return r.total > 0 && r.withReason === r.total && r.numeric === r.total;
});

check("Home answers all six questions, from services and not from filler", () => {
  const r = run(`
    go("home"); renderHome();
    const txt = id => { const el = document.getElementById(id); return el ? el.textContent.replace(/\\s+/g, " ").trim() : null; };
    const pane = document.getElementById("tab-home").textContent.replace(/\\s+/g, " ");
    return {
      objective: txt("homeObjective"),
      directive: txt("directive"),
      weak: txt("homeWeak"),
      milestone: txt("homeMilestone"),
      mentionsGoal: /objective/i.test(pane),
      mentionsMastery: /mastery|weakest/i.test(pane),
      why: /because|mistakes|deadline|mandatory|weakest/i.test(txt("directive") || ""),
    };
  `);
  console.log(`         objective: ${String(r.objective).slice(0, 52)}…`);
  console.log(`         weakest:   ${String(r.weak).slice(0, 52)}…`);
  /* v17 Home: mentionsGoal false, mentionsMastery false, mentionsProject false. */
  return !!r.objective && !!r.directive && !!r.weak && !!r.milestone
      && r.mentionsGoal && r.mentionsMastery && r.why;
});

check("Home's directive is the ranked engine's choice, not a second opinion", () => {
  const r = run(`
    go("home"); renderHome();
    const top = nextBestAction();
    const shown = document.getElementById("directive").textContent.replace(/\\s+/g, " ");
    return { title: top ? top.title : null, shownHasTitle: top ? shown.indexOf(top.title) >= 0 : false,
             shownHasReason: top ? shown.indexOf(String(top.because).slice(0, 30)) >= 0 : false };
  `);
  console.log(`         directive === nextBestAction: ${r.shownHasTitle}`);
  /* v17 picked the first overdue quest by its own rule and only *annotated* it
     with nextBestAction() when the two happened to agree. */
  return r.shownHasTitle && r.shownHasReason;
});

check("an empty Academy says so instead of reporting a zero", () => {
  const r = run(`
    const keep = H().academy;
    H().academy = { qualification:"", subjects:[], questions:[], cards:[], errors:[], sessions:[], exams:[], grades:[] };
    invalidateAcademy();
    go("home"); renderHome();
    const t = document.getElementById("homeWeak").textContent.replace(/\\s+/g, " ");
    H().academy = keep; invalidateAcademy(); renderHome();
    return { text:t, saysNone: /no subjects/i.test(t), showsZero: /\\b0%/.test(t) };
  `);
  console.log(`         "${String(r.text).slice(0, 60)}…"`);
  /* 0% mastery on an untouched subject is a claim about a student who has not
     been measured. Absence of evidence is not evidence of weakness. */
  return r.saysNone && !r.showsZero;
});

check("the skill-unlock takeover reaches a screen that exists", () => {
  const fsx = require("fs"), pth = require("path");
  const ui = fsx.readFileSync(pth.join(ROOT, "ui-v11.js"), "utf8");
  const html = fsx.readFileSync(pth.join(ROOT, "index.html"), "utf8");
  /* Strip comments first: the note explaining the removal names the old
     selector, and a check that fails on its own documentation is a bad check. */
  const uiCode = ui.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, "");
  const stale = /data-tab === "status"|#tab-status/.test(uiCode);
  const paneExists = html.indexOf('id="tab-status"') >= 0;
  const r = run(`
    gotoSkills();
    return { view: currentView };
  `);
  console.log(`         gotoSkills() → ${r.view} · stale selector present: ${stale}`);
  /* ui-v11.js declared a second gotoSkills *inside* its IIFE, pointing at
     #tab-status, which the Phase 12 consolidation renamed. A local shadowing a
     global is invisible to the duplicate-global guard, so "Open the tree" closed
     the modal and did nothing for four releases. */
  return !stale && !paneExists && r.view === "grow";
});

check("the collision guard is not fooled by how a file ends", () => {
  /* Three files, all ending in "})();". Only the first is genuinely enclosed.
     The other two declare a global outside the wrapper and must be scanned. */
  const enclosed   = '(function(){ "use strict";\nfunction esc(x){ return x; }\n})();\n';
  const globalAbove = 'function esc(x){ return x; }\n(function(){ var inner = 1; })();\n';
  const globalBelow = '(function(){ var inner = 1; })();\nfunction esc(x){ return x; }\n(function(){})();\n';
  const r = { enclosed:isSelfScoped(enclosed), above:isSelfScoped(globalAbove), below:isSelfScoped(globalBelow) };
  console.log(`         enclosed exempt: ${r.enclosed} · global above scanned: ${!r.above} · global below scanned: ${!r.below}`);
  /* The v17 rule returned true for all three, because all three end the same way. */
  return r.enclosed === true && r.above === false && r.below === false;
});

check("a paid feature is asked about at the point of use, not just declared", () => {
  const fsx = require("fs"), pth = require("path");
  const cloud = fsx.readFileSync(pth.join(ROOT, "services/cloud.js"), "utf8");
  const ai = fsx.readFileSync(pth.join(ROOT, "services/ai.js"), "utf8");
  const strip = t => t.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, "");
  const syncAsks = /licenceCheck\(\s*["']cloudsync["']\s*\)/.test(strip(cloud));
  const aiAsks   = /licenceCheck\(\s*["']onlineai["']\s*\)/.test(strip(ai));
  const r = run(`
    const free = ["academy","practice","mastery","quests","goals","projects","portfolio","offline","export"]
      .map(k => licenceCheck(k));
    const paid = licenceCheck("cloudsync");
    const refused = registerPaidFeature("practice", { label:"x", why:"x", cost:"real" });
    return { freeAllAllowed: free.every(x => x.allowed && x.authority === "policy"),
             paidAuthority: paid.authority, refused: refused.ok === false };
  `);
  console.log(`         sync asks: ${syncAsks} · online AI asks: ${aiAsks} · free core answers "policy": ${r.freeAllAllowed}`);
  /* v17: licenceCheck had zero call sites outside its own file. A rule nothing
     consults is a comment with a function signature. */
  return syncAsks && aiAsks && r.freeAllAllowed && r.paidAuthority === "device" && r.refused;
});

check("a schema 5 record gains the graph without losing anything", () => {
  const r = run(`
    const legacy = { schema:5, hunters:{ old:{ id:"old", name:"Legacy", xp:900, streak:7,
      quests:[{ id:"q1", time:"07:00", name:"Wake", cat:"discipline", days:[1,2,3,4,5], mand:true, xp:30 }],
      done:{}, penalties:[], deadlines:[], goals:[], brain:{}, academy:{ subjects:[] },
      cloud:{}, opportunities:{}, projects:{}, circle:{}, prefs:{} } },
      active:"old", store:{}, sec:{fails:{},until:{}} };
    const m = Store.migrate(JSON.parse(JSON.stringify(legacy)));
    const g = m.hunters.old;
    return { schema:m.schema, xp:g.xp, streak:g.streak, questName:g.quests[0].name,
             hasLink:"link" in g.quests[0] };
  `);
  console.log(`         schema 5 → ${r.schema}, quest preserved, no link invented`);
  /* Guessing which goal an existing quest "really" served would tick off work the
     student never did. Migration adds the capacity, never the data. */
  return r.schema === CURRENT_SCHEMA && r.xp === 900 && r.streak === 7
      && r.questName === "Wake" && r.hasLink === false;
});

/* ══════════════ regression guards ══════════════ */
console.log("\n  — collisions and coverage —");

check("no global function is declared in two files", () => {
  const fsx = require("fs"), pth = require("path");
  const html = fsx.readFileSync(pth.join(ROOT, "index.html"), "utf8");
  const files = (html.match(/<script src="([^"]+)"/g) || [])
    .map(t => t.replace(/<script src="/, "").replace(/"$/, ""))
    .filter(f => fsx.existsSync(pth.join(ROOT, f)));
  const decl = {}, wrapped = [];
  for(const f of files){
    const src = fsx.readFileSync(pth.join(ROOT, f), "utf8");
    /* A file wrapped in an IIFE keeps its own scope, so its top level is not
       global. This used to be decided by how the file *ended* — any file whose
       last characters were "})();" was exempted whole, including one that opened
       its wrapper on line 300 with thirty globals above it. Testing the tail
       cannot answer a question about the head. */
    if(isSelfScoped(src)){ wrapped.push(f); continue; }
    for(const m of src.matchAll(/^(?:function|const|let|var)\s+([A-Za-z_$][\w$]*)/gm)){
      (decl[m[1]] = decl[m[1]] || new Set()).add(f);
    }
  }
  const dupes = Object.entries(decl).filter(([, v]) => v.size > 1)
    .map(([k, v]) => `${k} (${[...v].join(" + ")})`);
  console.log(`         ${files.length} scripts · ${wrapped.length} self-scoped · ${dupes.length} collisions`);
  if(dupes.length) console.log("         " + dupes.join("; "));
  /* This is not stylistic. Two files declaring the same global means the one that
     loads later silently replaces the other, with no error anywhere — which is how
     the Open Gate lessons and the 90-day heatmap stopped rendering for two
     releases without a single test noticing. */
  return dupes.length === 0;
});

check("the Open Gate lessons render again", () => {
  const r = run(`
    go("wealth");
    if(typeof renderGate === "function") renderGate();
    const box = document.getElementById("gateList");
    return { exists: !!box, lessons: box ? box.querySelectorAll(".lesson").length : 0,
             fn: typeof renderGate, mine: typeof renderOnlineGate };
  `);
  console.log(`         ${r.lessons} Open Gate lessons rendered`);
  return r.lessons > 0 && r.fn === "function" && r.mine === "function";
});

check("the 90-day heatmap renders again", () => {
  const r = run(`
    go("insight","in-record");
    if(typeof renderRecords === "function") renderRecords();
    const heat = document.getElementById("heat");
    return { cells: heat ? heat.querySelectorAll("i").length : 0,
             both: typeof renderRecords === "function" && typeof renderPersonalBests === "function" };
  `);
  console.log(`         ${r.cells} heatmap cells drawn`);
  return r.cells >= 80 && r.both === true;
});

console.log("\n  — v17: defects that shipped while the suite stayed green —");

/* Two elements shared id="app" and getElementById returns the first, so
   enterSystem() unhid a vestigial v12 wrapper while the container holding every
   tabpane kept .hidden. The app booted to a topbar and nothing else. A static
   guard, because the DOM answer depends on which element you happen to ask. */
check("no id is used twice in index.html", () => {
  /* Comments are stripped first: a note *describing* a duplicate id is not a
     duplicate id, and a guard that cannot tell the difference trains people to
     ignore it. */
  const html = require("fs").readFileSync("./system/index.html", "utf8").replace(/<!--[\s\S]*?-->/g, "");
  const counts = {};
  for(const m of html.matchAll(/\bid\s*=\s*"([A-Za-z0-9_\-]+)"/g)) counts[m[1]] = (counts[m[1]] || 0) + 1;
  const dupes = Object.entries(counts).filter(([,n]) => n > 1);
  if(dupes.length) console.log("         duplicated: " + dupes.map(([k,n]) => `#${k} x${n}`).join(", "));
  return dupes.length === 0;
});

/* The live-DOM half of this — walking up from a real pane looking for a hidden
   ancestor — lives in harness.js, which actually enters the system. This suite
   deliberately does not, so it can only carry the static guard above. */

/* ══════════════ v18 boundary guards ══════════════ */

/* The tutor called fetch() directly for four releases while services/ai.js sat
   beside it holding the timeout, the daily cap, the cache, the privacy filter
   and the entitlement check. A gateway a caller may walk around is not a
   gateway, so the rule is now checked rather than intended. */
check("no view reaches the network directly", () => {
  const fsx = require("fs"), pth = require("path");
  const dir = pth.join(ROOT, "views");
  const offenders = [];
  for(const f of fsx.readdirSync(dir)){
    if(!f.endsWith(".js")) continue;
    /* Comments stripped: a file explaining why it no longer calls fetch() is
       not a file calling fetch(). */
    const src = fsx.readFileSync(pth.join(dir, f), "utf8")
      .replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
    if(/\bfetch\s*\(/.test(src) || /XMLHttpRequest/.test(src) || /navigator\.sendBeacon/.test(src)) offenders.push(f);
  }
  if(offenders.length) console.log("         views calling out directly: " + offenders.join(", "));
  return offenders.length === 0;
});

/* The other half: the tutor must actually be routed, not merely silent. */
check("the tutor's questions go through services/ai.js", () => {
  const fsx = require("fs"), pth = require("path");
  const svc = fsx.readFileSync(pth.join(ROOT, "services/tutor.js"), "utf8");
  const view = fsx.readFileSync(pth.join(ROOT, "views/tutor.js"), "utf8");
  const routed = /AI\.ask\s*\(\s*["']tutor["']/.test(svc);
  /* AI.ask refuses to run without a deterministic answer, so the tutor must
     supply one — that is what keeps the network non-load-bearing. */
  const hasLocal = /local\s*[,:]/.test(svc) && /masterPrompt/.test(svc);
  const viewIsThin = !/TUT_KB/.test(view) && !/aiEndpoint/.test(view);
  console.log(`         routed ${routed} · local answer ${hasLocal} · view is DOM-only ${viewIsThin}`);
  return routed && hasLocal && viewIsThin;
});

/* Onboarding never asked for a goal, while activationFunnel() had measured
   "Set a goal" since v15 — the metric was reporting a failure that belonged to
   the app. Checked on the markup and the wiring together, because a step that
   exists but is never committed is the same gap wearing a screen. */
check("onboarding captures a goal and turns it into a scheduled quest", () => {
  const fsx = require("fs"), pth = require("path");
  const html = fsx.readFileSync(pth.join(ROOT, "index.html"), "utf8");
  const ob = fsx.readFileSync(pth.join(ROOT, "ui/onboarding.js"), "utf8");
  const hasField = /id="obGoalName"/.test(html) && /id="obGoalPlan"/.test(html);
  const usesRealPlanner = /proposeBreakdown\s*\(/.test(ob);
  const commits = /addGoal\s*\(/.test(ob) && /scheduleStepAsQuest\s*\(/.test(ob);
  /* Order matters: the goal services read H(), so committing before the hunter
     is saved would silently do nothing. */
  /* Search for the CALL, not the definition: "obCommitGoal()" is a substring of
     "function obCommitGoal(){", so the first version of this check found the
     declaration (which correctly sits earlier in the file) and reported the
     ordering broken. */
  const savesFirst = ob.indexOf("DB.active = draft.id") < ob.indexOf("committed = obCommitGoal()");
  console.log(`         field ${hasField} · real planner ${usesRealPlanner} · commits ${commits} · after save ${savesFirst}`);
  return hasField && usesRealPlanner && commits && savesFirst;
});

/* The funnel counted an unordered set and granted two steps for registering, so
   a hunter who had done nothing read 2/7 and any four steps read "activated". */
check("activation is measured in order and ignores steps that cannot fail", () => {
  /* run() executes inside the page's own scope. Top-level const/let in a classic
     script live in the shared script scope rather than on window, so a check
     written in Node's scope cannot see them — which is how the first version of
     this check reported a ReferenceError as a failing assertion. */
  const r = run(`
    const h = H();
    const g = h.goals, q = h.quests, c = h.totalCleared;
    try{
      h.goals = [];
      h.quests = [{ id:"x", time:"08:00", name:"Q", cat:"study", days:[1], xp:10 }];
      h.totalCleared = 99;                    /* a later step done, an earlier one not */
      const a = activationFunnel();
      return { total:a.total, measured:a.measured.length,
               anyGiven:a.measured.some(s=>s.given), reached:a.reached,
               completed:a.completed, activated:a.activated };
    } finally { h.goals = g; h.quests = q; h.totalCleared = c; }`);
  console.log(`         reached ${r.reached}/${r.total} · completed ${r.completed} · activated ${r.activated}`);
  return r.total === r.measured && !r.anyGiven && r.reached === 0 && r.completed >= 1 && r.activated === false;
});

/* v17 announced FULL ACCESS GRANTED after comparing a hash against a list baked
   into the page. The mechanism is a fair business decision; describing it as a
   verified licence is not. */
check("a device-granted licence never reports itself as verified", () => {
  const r = run(`
    const lic = licenceCheck("onlineai");
    const policy = licenceCheck("academy");
    const p = entitlementPosture();
    return { auth:lic.authority, verified:lic.verified,
             policyAuth:policy.authority, policyAllowed:policy.allowed,
             enforceable:p.enforceable, unverifiable:p.unverifiable };`);
  console.log(`         paid: ${r.auth}/verified=${r.verified} · free: ${r.policyAuth} · enforceable ${r.enforceable}`);
  return r.auth === "device" && r.verified === false
      && r.policyAuth === "policy" && r.policyAllowed === true
      && r.enforceable === false && r.unverifiable === true;
});

/* Views are wrapped so one broken panel cannot take a section down. Isolation is
   right; an empty catch block is the wrong implementation of it — the Open Gate
   cards and the 90-day heatmap were both missing for two releases, and a section
   that draws four panels out of five looks like a section. */
check("a render that throws is isolated AND recorded, not swallowed", () => {
  const r = run(`
    const before = renderFailures().length;
    const errs = [];
    const realErr = console.error;
    console.error = (...a) => errs.push(a.join(" "));
    let after1, after2, sibling = false;
    try{
      const ok = safeRender("probe-panel", () => { throw new Error("planted"); });
      /* a sibling render must still run — that is what the isolation is for */
      safeRender("probe-sibling", () => { sibling = true; });
      after1 = renderFailures();
      /* calling it again must not log a second time, or a 30s refresh loop
         becomes a thousand console lines */
      safeRender("probe-panel", () => { throw new Error("planted"); });
      after2 = renderFailures().find(f => f.name === "probe-panel");
      /* and recovery must clear it */
      safeRender("probe-panel", () => {});
    } finally { console.error = realErr; }
    const rec = after1.find(f => f.name === "probe-panel");
    return {
      isolated: sibling,
      recorded: !!rec,
      message: rec ? rec.message : "",
      logged: errs.filter(e => /probe-panel/.test(e)).length,
      countAfterTwo: after2 ? after2.count : 0,
      clearedOnRecovery: !renderFailures().some(f => f.name === "probe-panel"),
      grew: after1.length > before,
    };
  `);
  console.log(`         isolated ${r.isolated} · recorded ${r.recorded} · logged ${r.logged}x · count ${r.countAfterTwo} · cleared on recovery ${r.clearedOnRecovery}`);
  return r.isolated === true          /* the neighbouring panel still drew */
      && r.recorded === true          /* the failure is visible somewhere */
      && /planted/.test(r.message)
      && r.logged === 1               /* once, not once per refresh */
      && r.countAfterTwo === 2        /* but still counted */
      && r.clearedOnRecovery === true;
});

/* An invalid AI endpoint used to be deleted in silence and the save reported as
   successful. The rule is not "validate" — it is "never tell the student
   something happened that did not". */
check("a rejected setting is refused out loud, not deleted quietly", () => {
  const r = run(`
    const h = H();
    const before = h.aiEndpoint = "https://good.example/ai";
    const bad = applyHunterSettings({ aiEndpoint:"http://insecure.example/ai" });
    const kept = h.aiEndpoint;
    const outcome = settingsOutcome(bad);
    /* clearing on purpose must still work */
    const cleared = applyHunterSettings({ aiEndpoint:"" });
    const nowEmpty = h.aiEndpoint === "";
    h.aiEndpoint = "";
    return { before, kept, rejected:bad.rejected.length, changed:bad.changed.length,
             tone:outcome.tone, why:(bad.rejected[0]||{}).why || "",
             clearedOk: cleared.changed.length >= 0 && nowEmpty };
  `);
  console.log(`         kept "${r.kept}" · rejected ${r.rejected} · tone ${r.tone}`);
  return r.kept === r.before          /* the good value survived */
      && r.changed === 0              /* nothing was written */
      && r.rejected === 1
      && r.tone === "blood"           /* and the student is told */
      && /https/i.test(r.why)
      && r.clearedOk === true;        /* deliberate clearing still works */
});

/* The seam is only worth having if it refuses rather than approximating. A stub
   returning allowed:true would make every screenshot look server-backed while
   being exactly as unverified as the device path. */
check("the unbuilt licence server refuses instead of pretending", () => {
  /* Asserted on the real function object rather than on a file, and read
     synchronously because run() cannot await. A stub that returned allowed:true
     would make every log and screenshot look server-backed while being exactly
     as unverified as the device path — which is the specific dishonesty the
     seam exists to prevent. */
  const r = run(`
    return { available: ServerEntitlements.available,
             isFn: typeof ServerEntitlements.check === "function",
             src: String(ServerEntitlements.check) };`);
  const refuses = /allowed:\s*false/.test(r.src) && /unavailable:\s*true/.test(r.src);
  console.log(`         server available ${r.available} · refuses ${refuses}`);
  return r.available === false && r.isFn && refuses;
});


/* Quest days have been user-selectable since v2. rollover() required
   cleared/dayQuests >= 0.7 and fell through to streak = 0 when dayQuests was
   empty — so an empty Sunday wiped the streak every Monday. */
check("a day with nothing scheduled does not break the streak", () => {
  const r = run(`
    const h = H();
    const realQuests = h.quests, realDone = h.done, realLast = h.lastActive, realStreak = h.streak;
    /* yesterday, with every quest scheduled on other days only */
    const y = new Date(); y.setDate(y.getDate() - 1);
    const yKey = todayKey(y);
    const otherDay = (y.getDay() + 3) % 7;
    h.quests = [{ id:"rest1", name:"Elsewhere", time:"09:00", cat:"mind", xp:10, mand:true, days:[otherDay] }];
    h.done = {}; h.done[yKey] = {};
    h.lastActive = yKey; h.streak = 9;
    rollover();
    const after = h.streak;
    h.quests = realQuests; h.done = realDone; h.lastActive = realLast; h.streak = realStreak; save();
    return { after };
  `);
  console.log(`         streak of 9 across an empty day -> ${r.after}`);
  return r.after === 9;
});

/* todayKey() writes a local date; new Date("2026-08-18") reads it back as UTC
   midnight, which is the previous day everywhere west of Greenwich. rollover()
   therefore judged yesterday against the wrong weekday's quests for a whole
   hemisphere. This container runs in UTC, where the bug is invisible — so the
   check must not depend on the ambient timezone. It asserts on the components
   the parser returns, which is the thing that actually differs, and on the call
   site, so the fix cannot be reverted quietly. */
check("a date key survives the round trip in any timezone", () => {
  const r = run(`
    const probes = ["2026-08-18","2026-01-01","2026-12-31","2026-03-08"];
    const bad = probes.filter(k => {
      const d = dateFromKey(k), [y,m,dd] = k.split("-").map(Number);
      return d.getFullYear() !== y || d.getMonth() !== m-1 || d.getDate() !== dd || todayKey(d) !== k;
    });
    return { bad };
  `);
  const day = require("fs").readFileSync("./system/services/day.js", "utf8");
  const usesNaive = /questsFor\(\s*new Date\(\s*y\s*\)/.test(day);
  if(r.bad.length) console.log("         misparsed: " + r.bad.join(", "));
  if(usesNaive) console.log("         rollover() still parses the key with new Date(y)");
  return r.bad.length === 0 && usesNaive === false;
});

/* The Gate's "Export everything" called an exportHunter() that had never
   existed, guarded by a typeof check, so it silently navigated to Settings
   instead — beneath a warning telling people to export or lose their data. */
check("every export button reaches a real export", () => {
  const r = run(`
    return { fn: typeof exportHunter === "function",
             settings: !!document.getElementById("btnExport") };
  `);
  const gate = require("fs").readFileSync("./system/views/gate.js", "utf8");
  return r.fn === true && r.settings === true && /exportHunter\(\)/.test(gate);
});

/* Rank was g.books.indexOf(row) inside a loop over g.books — the whole shelf
   rescanned per row. The Online Gate grows shelves to 450 titles. */
check("shelf ranks are not a quadratic scan", () => {
  const src = require("fs").readFileSync("./system/views/shelves.js", "utf8");
  return !/(?:books|picks)\.indexOf\(row\)/.test(src);
});

check("the service worker precaches exactly what index.html loads", () => {
  const fsx = require("fs"), pth = require("path");
  const html = fsx.readFileSync(pth.join(ROOT, "index.html"), "utf8");
  const sw = fsx.readFileSync(pth.join(ROOT, "sw.js"), "utf8");
  const refs = [
    ...(html.match(/<script src="([^"]+)"/g) || []).map(t => t.replace(/<script src="/, "").replace(/"$/, "")),
    ...(html.match(/<link rel="stylesheet" href="([^"]+)"/g) || []).map(t => t.replace(/.*href="/, "").replace(/"$/, "")),
  ];
  const missing = refs.filter(r => !sw.includes(`"./${r}"`));
  console.log(`         ${refs.length} referenced · ${missing.length} missing from precache`);
  /* Offline is the product's central promise. A precache list that drifts behind
     index.html breaks it silently — everything works until the connection goes. */
  return missing.length === 0;
});


/* ══════════════ v19 §6 — rank is not a renamed level ══════════════
   Two systems wrote h.rank. services/progression.js had a table keyed on level
   alone; services/records.js has applyRank(), gated on quests cleared, streak,
   achievements and bosses as well as level. applyRank() runs as a hook on
   grantXp so it ran second and won the FIELD — but the level-only table had
   already fired the TAKEOVER. Crossing level 10 with nothing else behind it
   congratulated the student with a full-screen "RANK UP — D" and then left them
   at E. Both checks below fail against v18.1. */

/* Build a hunter one grant short of level 10, with a chosen amount of real work
   behind them. `clears` is written into h.done because progressStats() walks the
   done-record — a totalCleared counter alone is not evidence and does not count. */
function rankFixture(clears, achievements){
  return run(`
    /* This fixture replaces the active hunter, and the async sync chain later in
       this file holds the real one. Two checks in this project's history have
       already broken the same way — a fixture that seeds from live state, or
       leaves its own behind. Snapshot, and put it back before returning. */
    const __hunters = DB.hunters, __active = DB.active;
    const h = { id:"rk", name:"Rank", title:"t", pin:"", avatar:"", level:9, xp:0, totalXp:5000, rank:"E",
      stats:{STR:5,VIT:5,INT:5,PER:5,DIS:5}, quests:[], mode:"student", curriculum:"igcse",
      workout:"calisthenics", diff:"2", restDay:0, reroll:0, done:{}, penalties:[], deadlines:[],
      streak:9, lastActive:null, totalCleared:0, spotify:"", penaltyMode:"on", alarmMode:"on",
      workoutDone:{}, unlocked:false, created:todayKey(), goals:[],
      brain:{ achievements:${JSON.stringify(new Array(achievements).fill("a").map((x,i)=>x+i))},
              records:{bestStreak:9}, bosses:[] }, focusLog:{} };
    h.quests = [1,2,3,4].map(i => ({id:"q"+i, time:"09:00", name:"Q"+i, cat:"study",
      days:[0,1,2,3,4,5,6], mand:false, xp:10}));
    const days = Math.ceil(${clears} / 4);
    for(let i=1;i<=days;i++){
      const dt = new Date(Date.now() - i*86400000);
      const k = dt.getFullYear()+"-"+String(dt.getMonth()+1).padStart(2,"0")+"-"+String(dt.getDate()).padStart(2,"0");
      h.done[k] = {q1:true,q2:true,q3:true,q4:true};
    }
    DB.hunters = { rk: Store.migrate({hunters:{rk:h}, schema:1}).hunters.rk }; DB.active = "rk";
    if(typeof invalidateStats === "function") invalidateStats();

    const shown = [];
    const real = window.takeover;
    window.takeover = o => { shown.push({ kind:o.kind, title:String(o.title||"") }); };
    H().xp = xpNeeded(9) - 50;
    grantXp(200, "rank check");
    window.takeover = real;
    const out = { level:H().level, rank:H().rank, shown };
    DB.hunters = __hunters; DB.active = __active;
    if(typeof invalidateStats === "function") invalidateStats();
    return out;`);
}

check("levelling alone does not announce a rank the student has not earned", () => {
  const r = rankFixture(8, 0);            /* level 10, almost nothing else done */
  const rankups = r.shown.filter(t => t.kind === "rankup");
  console.log(`         level ${r.level} · rank ${r.rank} · rank-up takeovers: ${rankups.length}`);
  return r.level === 10 && r.rank === "E" && rankups.length === 0
      && r.shown.some(t => t.kind === "levelup");
});

check("a rank that IS earned is still announced, and stored", () => {
  const r = rankFixture(160, 4);          /* level 10 + 160 cleared + streak 9 + 4 achievements */
  const rankups = r.shown.filter(t => t.kind === "rankup");
  console.log(`         level ${r.level} · rank ${r.rank} · "${(rankups[0]||{}).title || "none"}"`);
  return r.level === 10 && r.rank === "D" && rankups.length === 1
      && /RANK UP/.test(rankups[0].title);
});

check("only one rank table exists in the codebase", () => {
  const fs = require("fs"), path = require("path");
  const hits = [];
  for(const dir of ["services","core","views","app","content"]){
    const dp = path.join(ROOT, dir);
    if(!fs.existsSync(dp)) continue;
    for(const f of fs.readdirSync(dp)){
      if(!f.endsWith(".js")) continue;
      const src = fs.readFileSync(path.join(dp, f), "utf8");
      /* a rank ladder is a list mapping a threshold to a rank letter */
      if(/\bconst\s+RANKS\s*=/.test(src) || /\brankOf\s*=/.test(src)) hits.push(dir + "/" + f);
    }
  }
  console.log(`         level-keyed rank tables found: ${hits.length ? hits.join(", ") : "none"}`);
  return hits.length === 0;
});


/* ══════════════ v19 §7 — a stat is not paid for a tap ══════════════
   "Do not automatically claim a student has increased a stat merely because
   they clicked complete."

   Until v18.2, toggleQuest() paid grantStat(q.cat) on the tick. Ticking a
   Physics block moved Intellect, which is a claim that Physics was learnt made
   on no evidence beyond the student saying they sat down. XP is a different
   thing and still pays: effort is real, and the student is an honest witness to
   it. Capability is not, and now comes from mastery movement instead.

   Four checks: the withholding, the thing it must NOT break, the payment on
   real evidence, and that the payment cannot be farmed. */

function statFixture(body){
  return run(`
    const __hunters = DB.hunters, __active = DB.active;
    const h = { id:"ev", name:"Ev", title:"t", pin:"", avatar:"", level:5, xp:0, totalXp:500, rank:"E",
      stats:{STR:5,VIT:5,INT:5,PER:5,DIS:5}, quests:[], mode:"student", curriculum:"igcse",
      workout:"calisthenics", diff:"2", restDay:0, reroll:0, done:{}, penalties:[], deadlines:[],
      streak:1, lastActive:todayKey(), totalCleared:0, spotify:"", penaltyMode:"on", alarmMode:"on",
      workoutDone:{}, unlocked:false, created:todayKey(), goals:[], brain:null, focusLog:{} };
    h.quests = [
      { id:"qs", time:"09:00", name:"Physics", cat:"study",      days:[0,1,2,3,4,5,6], mand:true, xp:25 },
      { id:"qd", time:"05:20", name:"Wake Up", cat:"discipline", days:[0,1,2,3,4,5,6], mand:true, xp:30 },
    ];
    DB.hunters = { ev: Store.migrate({hunters:{ev:h}, schema:1}).hunters.ev }; DB.active = "ev";
    const toasts = [];
    const realToast = window.toast; window.toast = (a,b) => toasts.push(String(b||""));
    let out;
    try{ out = (function(){ ${body} })(); }
    finally{
      window.toast = realToast;
      DB.hunters = __hunters; DB.active = __active;
      if(typeof invalidateStats === "function") invalidateStats();
      if(typeof invalidateAcademy === "function") invalidateAcademy();
    }
    out.toasts = toasts;
    return out;`);
}

check("ticking a study quest pays XP but not Intellect", () => {
  const r = statFixture(`
    const before = { INT:H().stats.INT, PER:H().stats.PER, xp:H().totalXp };
    toggleQuest(H().quests[0]);
    return { dINT: H().stats.INT - before.INT, dPER: H().stats.PER - before.PER,
             dXP: H().totalXp - before.xp };`);
  const questToast = r.toasts.find(t => /Physics/.test(t)) || "";
  console.log(`         study tick → INT ${r.dINT >= 0 ? "+" : ""}${r.dINT} · XP +${r.dXP}`);
  console.log(`         all toasts: ${r.toasts.length} · quest toast: "${questToast.slice(0, 88)}"`);
  /* Assert on the QUEST toast specifically, not on any toast in the array. A
     substring match across everything shown would be satisfied by an unrelated
     world-unlock message and would pass with the feature removed. */
  return r.dINT === 0 && r.dPER === 0 && r.dXP > 0
      && /held/i.test(questToast) && /INT/.test(questToast);
});

check("turning up is still its own evidence — discipline is unaffected", () => {
  const r = statFixture(`
    const before = { DIS:H().stats.DIS, xp:H().totalXp };
    toggleQuest(H().quests[1]);
    return { dDIS: H().stats.DIS - before.DIS, dXP: H().totalXp - before.xp };`);
  console.log(`         discipline tick → DIS +${r.dDIS} · XP +${r.dXP}`);
  return r.dDIS > 0 && r.dXP > 0;
});

check("a practice answer that moves mastery DOES pay Intellect, with the evidence named", () => {
  const r = statFixture(`
    const s = addSubject({ name:"Physics" });
    const u = addUnit(s.id, "Mechanics");
    const t = addTopic(s.id, u.id, "Momentum");
    const ids = [];
    for(let i=0;i<4;i++) ids.push(addQuestion({ topicId:t.id, text:"q"+i, answer:"a" }).id);
    const before = H().stats.INT;
    let last = null;
    for(const id of ids) last = recordAnswer({ questionId:id, correct:true });
    return { dINT: Math.round((H().stats.INT - before) * 10) / 10,
             mastery: last && Math.round(last.mastery.pct * 100) };`);
  console.log(`         4 correct → mastery ${r.mastery}% · INT +${r.dINT}`);
  return r.dINT > 0 && r.mastery > 0;
});

check("the capability stat cannot be farmed by answering more of the same", () => {
  const r = statFixture(`
    const s = addSubject({ name:"Chem" });
    const u = addUnit(s.id, "Bonding");
    const t = addTopic(s.id, u.id, "Ionic");
    const ids = [];
    for(let i=0;i<24;i++) ids.push(addQuestion({ topicId:t.id, text:"q"+i, answer:"a" }).id);
    const gains = [];
    for(const id of ids){
      const b = H().stats.INT;
      recordAnswer({ questionId:id, correct:true });
      gains.push(Math.round((H().stats.INT - b) * 100) / 100);
    }
    const early = gains.slice(2, 8).reduce((a,b)=>a+b, 0);
    const late  = gains.slice(-6).reduce((a,b)=>a+b, 0);
    return { early: Math.round(early*100)/100, late: Math.round(late*100)/100 };`);
  console.log(`         INT from answers 3-8: +${r.early} · from the last 6: +${r.late}`);
  return r.early > 0 && r.late < r.early;      /* diminishing, not linear */
});

/* ---------- report ---------- */
setTimeout(() => {
  if(w.__AIR) console.log("         AI.ask fallback → " + w.__AIR);
  const S = w.__SYNC ? JSON.parse(w.__SYNC) : null;
  const syncChecks = [
    ["signing in switches to account mode",                    S && S.signedIn],
    ["a sync round-trips to the server and drains the queue",  S && S.pushOk && S.serverXp === 4242 && S.drained],
    ["a concurrent push is merged, not overwritten",           S && S.concurrentOk && S.keptTheirDay && S.keptHigherXp],
    ["a failed sync keeps the queue and backs off",            S && S.failOk && S.queueKept && S.retry > 0 && S.errorShown],
    ["signing out leaves local data untouched",                S && S.localIntact],
  ];
  if(S && S.threw) errors.push("sync chain threw: " + S.threw);
  console.log("");
  for(const [label, ok] of syncChecks){
    results.push((ok ? "  PASS  " : "  FAIL  ") + label);
    if(!ok) errors.push("assertion failed: " + label);
  }
  console.log("");
  results.forEach(r => console.log(r));
  console.log("");
  if(errors.length){
    console.log(`${errors.length} problem(s):`);
    errors.forEach(e => console.log("  - " + e));
    process.exit(1);
  }
  console.log(`all ${results.length} checks passed\n`);
  process.exit(0);
}, 900);
