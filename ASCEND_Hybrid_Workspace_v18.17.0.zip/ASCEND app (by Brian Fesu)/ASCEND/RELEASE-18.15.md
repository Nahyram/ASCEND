# ASCEND 18.15 — vacation mode, home quests, and checklists that can be ticked

---

## Vacation mode

ASCEND's board is a timetable. On the first day of a long holiday the System
starts asking for lessons that are not happening, marks them missed, docks XP
through `penalty.js`, and terminates a streak the student did nothing to lose.
Ghana's school year has three of those breaks. A product that punishes a student
for six weeks a year for being on holiday is one they stop opening.

**Path → Standing → Vacation mode.** Pick what you are keeping up — revision,
reading, coding, research, creative work, practical skills, movement — optionally
set the date term resumes, and the campaign takes the board.

**It hooks in at exactly one place: `questsFor()`.** Everything downstream then
needs no special case at all:

* campaign quests are never mandatory, so `penalty.js` never fires — and there is
  no mention of vacations anywhere in it
* they are real quests, so the streak advances on them honestly; a student who
  reads every day through December keeps their streak, and deserves to
* clearing one pays XP through `grantXp`, so the ledger, the event log and the
  server all see it without knowing vacations exist

The alternative was three special cases across the streak calculation, the
penalty engine and the rollover. The suite asserts the single hook directly — it
counts `vacationOn()` in `services/day.js` and fails if it is not exactly one.

**The timetable is never modified.** Vacation is a lens over the board, not a
change to it, so ending one restores exactly what was there because nothing was
removed. Expiry is checked on read rather than on a timer, because a phone that
was shut for the whole of December never ran a timer.

---

## Application checklists, finally visible

`buildChecklist()` has produced application checklists since v18, and
`toggleChecklistItem()` has ticked them and paid XP for each step. **Nothing ever
rendered one.** The list was built, stored on the opportunity, and invisible — the
student could not see the steps, could not tick them, and could never earn the XP
each step was worth.

They now render on the opportunity card, collapsed, and tick. The `once:` guard
in the anti-farm ledger has covered re-ticking since v9 and was simply never
reachable; the suite confirms six toggles pay once.

---

## The runtime, pinned

`.nvmrc` and `.node-version` now pin **22.22.2**, and `README-TESTING.md` leads
with it. Every suite failure ever reported against this project from a fresh
checkout has been the same thing — an older Node than `engines` requires, or
`npm ci` not run — and the symptom is alarming: architecture, modules, hooks,
brain and evidence all red at once, none of it real.

---

## On the v18.14 analysis you sent

Some of it is accurate. Two claims are not, and I checked rather than assumed.

**"Silent error handling still exists — `renderFrontier()` └── try{} catch{}"** —
`views/frontier.js` contains **zero** empty catch blocks and **five**
`safeRender()` calls. That was fixed in v18; `safeRender` exists precisely
because of it. The analysis is quoting the *known issues* section of
`ARCHITECTURE-v18.md`, which describes what v18 found, as if it described the
code today.

**"87 classic scripts, 734 top-level names, 43 mutable"** — the actual figures
are **77 / 739 / 46**, and 15 files are already ES modules with a ratchet
enforcing the direction. The scale of the problem is real; the claim that nothing
has been done about it is not.

**Where it is right, and sharply so:** its item 2. `DB` is mutable from
everywhere — though the real hotspot is not the 38 `DB.` references but the
**86 direct `h.x =` writes across 31 files**, which is where a store layer has to
bite. And its item 13 about environment standardisation was a fair hit, taken
above.

**Its central recommendation is the decision you already made.** It argues for
multi-tenancy, schools, teachers, parents, RBAC and cross-student leaderboards —
which is the path you declined last turn in favour of keeping ASCEND personal.
I have not switched on the strength of a document. If you want that direction,
say so and it becomes a separate product built on `shared/`, not a refactor.

---

## A ratchet went the wrong way, and it is worth saying why

`MAX_CLASSIC_SCRIPTS` went **76 → 77**. `services/vacation.js` is new service
code whose consumers — `services/day.js`, `views/progression.js` — are still
classic scripts. Written as an ES module it would have had to reach for `H()`,
`save()` and `uid()` as bare globals: a module depending on classic code, which
inverts the dependency the migration exists to establish.

That is 18.12's bridge growth from the other direction, and the same conclusion:
**the migration cannot progress by adding leaves, and new code cannot be a module
until its consumers are.** I have now recorded that twice without acting on it.
Converting the consumers is overdue, and this number will keep drifting until it
happens. It is the honest candidate for the next release.

---

## Verification

`vacation-test.js` — 12 checks: the board replaced without touching the
timetable; campaign quests never mandatory and `penalty.js` never taught about
vacations; the single hook counted; XP reaching the ledger; progression reported
separately; changing tracks preserving work already done; the board restored
exactly on end and on expiry; invalid starts refused; the panel rendering; and
checklists rendering, ticking, paying, and refusing to be farmed.

Two mutations pinned: making campaign quests mandatory, and letting vacation
write over the timetable.

**20 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra.

---

Still yours: the **host decision**, **`MAIL_TRANSPORT`** (recovery is built and
off), the **data-protection position**, and the **PIN with no recovery path**.
