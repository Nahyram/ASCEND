/* ASCEND — reachability-test.js
   Code that exists and cannot be reached, and the things that were unreachable
   until 18.14.

   ## What this suite is about

   §28 of the product spec says: do not create fake functionality — a button
   labelled "Complete Quest" must actually do something. This suite checks the
   same failure from the other side, which turned out to be the one this codebase
   actually had: **real functionality with no way in.**

   An audit of 554 declared functions found 33 that nothing anywhere calls.
   Among them:

     · safeUrl, sanitiseText, validNumber, guardedSave, recoverUnsaved — the
       entire protective half of services/integrity.js, shipped since v18,
       referenced by nothing outside its own file
     · entitlement / hasEntitlement — the SECOND time this exact defect has been
       found here. v18 found the rule declared and enforced nowhere; the fix then
       was to write the rule, not to call it
     · plannedRecommendations, scheduleActionAsQuest — both added in 18.12,
       reachable only from their own test suite

   A capability with no caller is indistinguishable from a capability that does
   not exist, except that it passes review and takes up space. So the last check
   here is a ratchet: the count may go down, never up. */
"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");
const nodeCrypto = require("node:crypto");
const { JSDOM, VirtualConsole } = require("jsdom");

const ROOT = process.env.ROOT || "./system";

/* A converted module lives under src/; an unconverted one is still at the top of
   system/. Resolving instead of hard-coding is what keeps these assertions
   honest across the migration — core/kernel.js moved in 18.16 and four suites
   went red on the path rather than on the behaviour. */
function appFile(rel){
  const a = path.join(ROOT, "src", rel), b = path.join(ROOT, rel);
  return fs.existsSync(a) ? a : b;
}


/* ── the ratchet ──────────────────────────────────────────────
   Update in the same commit that changes it, never separately. */
const MAX_UNREACHABLE = 28;    /* was 33 before 18.14; five were wired, not deleted */

const results = [], errors = [];
async function check(label, fn) {
  try { await fn(); results.push("  PASS  " + label); }
  catch (e) { results.push("  FAIL  " + label + " — " + e.message); errors.push(label); }
}

/* Every .js the browser actually loads, plus index.html for inline handlers. */
function shippedSources() {
  const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
  const files = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1])
    .filter(f => f !== "bundle.js")
    .map(f => path.join(ROOT, f));
  const mods = [];
  (function walk(d) {
    if (!fs.existsSync(d)) return;
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p); else if (e.name.endsWith(".js")) mods.push(p);
    }
  })(path.join(ROOT, "src"));
  return { files: [...files, ...mods], html };
}

(async () => {

  /* ---------- the wiring, as static fact ---------- */
  await check("save() routes through guardedSave, so a failed write holds the work", () => {
    const kernel = fs.readFileSync(appFile("core/kernel.js"), "utf8");
    const fn = (kernel.match(/function save\(\)\{[\s\S]*?\n\}/) || [])[0] || "";
    assert.ok(/guardedSave/.test(fn),
      "save() writes directly again — 186 call sites would lose work on a failed write instead of stashing it");
  });

  await check("a user-supplied link goes through safeUrl before it becomes an href", () => {
    const beyond = fs.readFileSync(appFile("views/beyond.js"), "utf8");
    assert.ok(/safeUrl/.test(beyond), "views/beyond.js no longer checks the scheme of a link");
    assert.ok(!/href="\$\{esc\(o\.url\)\}/.test(beyond),
      "an opportunity URL is being escaped straight into an href — esc() does not stop javascript:");
  });

  await check("the AI path consults the entitlement the server issues", () => {
    const ai = fs.readFileSync(appFile("services/ai.js"), "utf8");
    assert.ok(/hasEntitlement|entitlement\(/.test(ai),
      "services/ai.js does not check the entitlement — the rule would be declared and enforced nowhere for the second time");
  });

  await check("the 18.12 features are reachable from the interface", () => {
    const brain = fs.readFileSync(appFile("views/brain.js"), "utf8");
    assert.ok(/plannedRecommendations\(/.test(brain), "nothing renders a time-budgeted plan");
    assert.ok(/scheduleActionAsQuest\(/.test(brain), "nothing lets a student put a recommendation on the board");
    assert.ok(/data-budget/.test(brain), "there is no control for stating how much time you have");
  });

  /* ---------- safeUrl, against the input it exists for ---------- */
  await check("safeUrl refuses the schemes esc() lets through", async () => {
    const src = fs.readFileSync(appFile("services/integrity.js"), "utf8");
    const vm = require("node:vm");
    const ctx = vm.createContext({ URL, String, console });
    new vm.Script((src.match(/function safeUrl\(raw\)\{[\s\S]*?\n\}/) || [""])[0] + "\n;this.safeUrl = safeUrl;")
      .runInContext(ctx);
    const safeUrl = ctx.safeUrl;
    for (const bad of ["javascript:alert(1)", "JaVaScRiPt:alert(1)", "data:text/html,<script>x</script>",
      "vbscript:msgbox", "  javascript:alert(1)  ", "file:///etc/passwd", "not a url at all", ""]) {
      assert.strictEqual(safeUrl(bad).ok, false, `safeUrl accepted ${JSON.stringify(bad)}`);
    }
    for (const good of ["https://example.com/a?b=c", "http://localhost:8787/x"]) {
      assert.strictEqual(safeUrl(good).ok, true, `safeUrl rejected ${good}`);
    }
  });

  /* ---------- against the running app ---------- */
  const dom = new JSDOM(fs.readFileSync(path.join(ROOT, "index.html"), "utf8"), {
    runScripts: "dangerously", url: "https://local.test/",
    virtualConsole: new VirtualConsole(), pretendToBeVisual: true,
  });
  const w = dom.window, d = w.document;
  Object.defineProperty(w, "crypto", { value: {
    getRandomValues: a => { nodeCrypto.randomFillSync(Buffer.from(a.buffer, a.byteOffset, a.byteLength)); return a; },
    subtle: { importKey: async () => ({}), deriveBits: async () => new Uint8Array(32).buffer,
      digest: async () => new Uint8Array(32).buffer, deriveKey: async () => ({}),
      encrypt: async () => new Uint8Array(16).buffer, decrypt: async () => new Uint8Array(16).buffer },
  }, configurable: true });
  w.matchMedia = q => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
  w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {};
  w.AudioContext = function () { return { createGain: () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} } }), createOscillator: () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0, setValueAtTime() {} }, type: "" }), createBufferSource: () => ({ connect() {}, start() {}, stop() {}, buffer: null, loop: false }), createBuffer: () => ({ getChannelData: () => new Float32Array(1000) }), createBiquadFilter: () => ({ connect() {}, frequency: { value: 0 }, type: "", Q: { value: 0 } }), destination: {}, sampleRate: 44100, currentTime: 0, close() {}, resume() {} }; };
  w.indexedDB = undefined;
  for (const s of [...d.querySelectorAll("script[src]")].map(x => x.getAttribute("src"))) {
    const el = d.createElement("script");
    el.textContent = fs.readFileSync(path.join(ROOT, s), "utf8");
    d.body.appendChild(el);
  }
  await new Promise(r => setTimeout(r, 1600));
  d.getElementById("scr-login").classList.remove("hidden");
  d.getElementById("btnNewHunter").click();
  d.getElementById("regName").value = "Ledger";
  d.getElementById("regTitle").value = "The Audited";
  d.getElementById("regGo").click();
  d.querySelector('#obWorkout .chip[data-w="calisthenics"]').click();
  for (const n of ["2", "3", "4"]) d.querySelectorAll("[data-next]").forEach(b => { if (b.dataset.next === n) b.click(); });
  await new Promise(r => setTimeout(r, 50));
  d.getElementById("obFinish").click();
  await new Promise(r => setTimeout(r, 400));
  const br = d.createElement("script");
  br.textContent = 'window.__X = { grantXp, Log, H, save, renderLedger, go, renderPath };';
  d.body.appendChild(br);
  const S = w.__X;

  await check("the ledger renders the entries the log holds", () => {
    assert.strictEqual(typeof S.renderLedger, "function", "renderLedger is not reachable");
    for (const [n, why] of [[20, "Math homework"], [50, "Science project"], [40, "Algebra quest"]])
      S.grantXp(n, why);

    /* Through renderPath(), the real entry point — NOT by calling renderLedger()
       directly. Calling it directly passed against a build where the ledger had
       been unhooked from the render pipeline entirely, which is precisely the
       "reachable only from its own test" defect this whole suite exists to catch.
       Found by mutation, in this file, after it was written. */
    S.renderPath();
    const box = d.getElementById("pgLedger");
    assert.ok(box, "the ledger panel is not in the page");
    const text = box.textContent;
    assert.ok(/\+50/.test(text), "a 50 XP entry is missing from the ledger");
    assert.ok(/Science project/.test(text), "the reason for an entry is not shown");
    assert.ok(/Algebra quest/.test(text), "the most recent entry is missing");
    assert.strictEqual(box.querySelectorAll(".led-row").length, 3,
      "the ledger shows a different number of rows than the log holds");
  });

  await check("the ledger reports agreement between the record and the log", () => {
    const box = d.getElementById("pgLedger");
    assert.ok(/agree exactly/i.test(box.textContent),
      "the ledger does not say whether the record and the log agree");
    /* And when they do not, it must say so rather than quietly matching them. */
    const h = S.H(); h.totalXp += 999; S.save();
    S.renderPath();
    const t = d.getElementById("pgLedger").textContent;
    assert.ok(/disagree/i.test(t), "a divergence was not surfaced");
    assert.ok(/fault in ASCEND, not in your work/i.test(t),
      "the divergence message blames the record rather than the software");
    assert.strictEqual(S.H().totalXp, S.Log.progression().totalXp + 999,
      "the ledger silently corrected the record to match itself");
  });

  await check("held work is offered back on the next boot, not just stashed", () => {
    const boot = fs.readFileSync(appFile("ui/boot-auth.js"), "utf8");
    assert.ok(/recoverUnsaved\(\)/.test(boot),
      "nothing reads the stash at boot — a recovery copy nobody is shown is the same as no recovery copy");
    assert.ok(/SYSTEM_READY[\s\S]{0,900}recoverUnsaved/.test(boot),
      "the stash is read before the store has hydrated, so the retry would write against an empty record");
  });

  await check("a failed write holds the work instead of dropping it", () => {
    /* Break the store the way a full quota does. */
    const real = w.Store.writeJSON;
    w.Store.writeJSON = () => ({ ok: false, error: "quota" });
    const ok = S.save();
    w.Store.writeJSON = real;
    assert.strictEqual(ok, false, "save() reported success on a failed write");
    const stash = w.sessionStorage.getItem("system.unsaved");
    assert.ok(stash, "nothing was stashed — the student's work would be gone with only a toast to show for it");
    assert.ok(JSON.parse(stash).at > 0, "the stash has no timestamp");
  });

  dom.window.close();

  /* ---------- the ratchet ---------- */
  await check("the amount of unreachable code has not gone up", () => {
    const { files, html } = shippedSources();
    const sources = files.map(f => fs.readFileSync(f, "utf8"));
    const haystack = sources.join("\n") + "\n" + html;

    const declared = new Map();
    for (let i = 0; i < files.length; i++) {
      for (const m of sources[i].matchAll(/^(?:export )?function ([A-Za-z_$][\w$]*)/gm))
        if (!declared.has(m[1])) declared.set(m[1], path.relative(ROOT, files[i]));
    }

    const unreachable = [];
    for (const [name, file] of declared) {
      const re = new RegExp("(?<![\\w$.])" + name.replace(/\$/g, "\\$") + "(?![\\w$])", "g");
      const hits = (haystack.match(re) || []).length;
      if (hits <= 1) unreachable.push(`${name} (${file})`);
    }

    assert.ok(unreachable.length <= MAX_UNREACHABLE,
      `${unreachable.length} functions are declared and never called (ceiling ${MAX_UNREACHABLE}).\n` +
      "         Either wire them up or delete them — code with no caller is indistinguishable\n" +
      "         from code that does not exist, except that it passes review.\n         " +
      unreachable.sort().join("\n         "));
    results.push(`         ${unreachable.length} unreachable of ${declared.size} declared (ceiling ${MAX_UNREACHABLE})`);
  });

  console.log("\nASCEND — reachability: code that had no way in\n");
  console.log(results.join("\n"));
  if (errors.length) { console.log(`\n${errors.length} failed\n`); process.exit(1); }
  console.log(`\nall checks passed\n`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
