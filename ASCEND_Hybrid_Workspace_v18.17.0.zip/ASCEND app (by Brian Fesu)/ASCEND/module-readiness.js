/* THE SYSTEM — module-readiness analysis.

   arch-check.js measures the classic-script architecture as it stands. This
   asks a different question: what would break if every one of these files
   became an ES module tomorrow?

   Three things break a classic script when it becomes a module, and only
   three:

     1. REASSIGNMENT of a binding another file declared. An imported binding is
        read-only, so `renderAll = function(){...}` is a compile error. The
        hooks.js header says there were 22 of these; this counts what is left.

     2. A binding used across files that is declared with `const`/`let` at top
        level AND is genuinely mutated somewhere. Function declarations and
        immutable consts import cleanly; mutable state does not, and has to
        become an accessor or move into a module that owns it.

     3. LOAD-TIME cycles. A call-time cycle between hoisted functions resolves
        identically under ESM. A cycle where module A reads a value from B at
        module-evaluation time does not.

   Everything else — 749 top-level names, 140 call-time cycles, implicit load
   order — is noise for this purpose. Load order is exactly what the import
   graph replaces. */
"use strict";

const fs = require("fs");
const path = require("path");
const acorn = require("acorn");
const walk = require("acorn-walk");

const ROOT = process.env.ROOT || "./system";
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const files = [...html.matchAll(/<script src="([^"]+)"><\/script>/g)].map(m => m[1]);

const declaredIn = new Map();
const mutable = {};
const parsed = [];

for (const rel of files) {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) continue;
  const src = fs.readFileSync(p, "utf8");
  let ast;
  try { ast = acorn.parse(src, { ecmaVersion: 2022, sourceType: "script" }); }
  catch (e) { console.log(`PARSE FAIL ${rel}: ${e.message}`); continue; }
  parsed.push({ rel, src, ast });

  for (const node of ast.body) {
    if (node.type === "FunctionDeclaration" && node.id) declaredIn.set(node.id.name, rel);
    else if (node.type === "ClassDeclaration" && node.id) declaredIn.set(node.id.name, rel);
    else if (node.type === "VariableDeclaration") {
      for (const d of node.declarations) {
        if (d.id.type === "Identifier") {
          declaredIn.set(d.id.name, rel);
          if (node.kind !== "const") mutable[d.id.name] = rel;
        }
      }
    }
  }
}


/* ---------- blocker 1: reassignment of a foreign binding ----------
   Scope-aware. A first pass at this used walk.simple and reported five
   blockers, all of them the name `pct` — which services/coach.js declares at
   top level and services/curriculum.js re-declares as a function-local inside
   masteryOf(). The local shadows the global correctly and nothing is
   reassigned. Counting those as blockers would have overstated the work and,
   worse, sent someone to "fix" correct code. Walk the ancestor chain and skip
   any assignment whose target is declared in an enclosing function. */
function declaresLocally(fnNode, name){
  let found = false;
  const scan = (node) => {
    if(!node || typeof node.type !== "string") return;
    if(node !== fnNode && (node.type === "FunctionDeclaration" || node.type === "FunctionExpression"
       || node.type === "ArrowFunctionExpression")) return;      /* nested scope owns its own */
    if(node.type === "VariableDeclarator" && node.id.type === "Identifier" && node.id.name === name) found = true;
    if(node.type === "FunctionDeclaration" && node.id && node.id.name === name) found = true;
    for(const k of Object.keys(node)){
      const v = node[k];
      if(Array.isArray(v)) v.forEach(scan);
      else if(v && typeof v.type === "string") scan(v);
    }
  };
  for(const p of (fnNode.params || [])) if(p.type === "Identifier" && p.name === name) return true;
  scan(fnNode.body);
  return found;
}
function isLocal(ancestors, name){
  for(let i = ancestors.length - 1; i >= 0; i--){
    const a = ancestors[i];
    if(a.type === "FunctionDeclaration" || a.type === "FunctionExpression" || a.type === "ArrowFunctionExpression"){
      if(declaresLocally(a, name)) return true;
    }
  }
  return false;
}

const reassignments = [];
for (const { rel, ast } of parsed) {
  walk.ancestor(ast, {
    AssignmentExpression(n, _st, ancestors) {
      if (n.left.type !== "Identifier") return;
      const owner = declaredIn.get(n.left.name);
      if (!owner || owner === rel) return;
      if (isLocal(ancestors, n.left.name)) return;
      reassignments.push({ from: rel, name: n.left.name, owner });
    },
  });
}

/* ---------- blocker 2: mutable top-level bindings read by other files ---------- */
const mutableShared = [];
for (const [name, owner] of Object.entries(mutable)) {
  const readers = new Set();
  for (const { rel, ast } of parsed) {
    if (rel === owner) continue;
    walk.simple(ast, { Identifier(n) { if (n.name === name) readers.add(rel); } });
  }
  if (readers.size) mutableShared.push({ name, owner, readers: readers.size });
}

/* ---------- report ---------- */
console.log("\nmodule-readiness — what blocks native ES modules\n");
console.log(`  ${parsed.length} scripts parsed · ${declaredIn.size} top-level names\n`);

console.log(`  BLOCKER 1 · reassigning another file's binding: ${reassignments.length}`);
const byName = {};
for (const r of reassignments) (byName[r.name] = byName[r.name] || []).push(r.from);
for (const [name, froms] of Object.entries(byName).slice(0, 12))
  console.log(`      ${name}  ←  ${[...new Set(froms)].join(", ")}`);
if (!reassignments.length) console.log("      none — Hooks already absorbed these");

console.log(`\n  BLOCKER 2 · mutable top-level bindings other files touch: ${mutableShared.length}`);
for (const m of mutableShared.sort((a, b) => b.readers - a.readers).slice(0, 15))
  console.log(`      ${m.name.padEnd(22)} declared in ${m.owner.padEnd(26)} seen in ${m.readers} other file(s)`);

/* ---------- verdict ----------
   Blocker 1 must stay at zero: a reassignment of another file's binding is a
   hard compile error under ESM, and one reintroduced quietly would put the
   migration back where it was for four releases.

   Blocker 2 is a ratchet, not a threshold. It stands at 6 and must not grow.
   Every one that goes needs a real owner — an accessor, or the state moving
   into the module that owns it — so the number falling is the migration
   making progress and the number rising is it going backwards. */
const BLOCKER1_MAX = 0;
const BLOCKER2_MAX = 6;

let bad = false;
if(reassignments.length > BLOCKER1_MAX){
  console.log(`  FAIL  a file reassigns another file's binding — that is a compile error under ESM`);
  bad = true;
}
if(mutableShared.length > BLOCKER2_MAX){
  console.log(`  FAIL  shared mutable bindings rose to ${mutableShared.length}, ceiling is ${BLOCKER2_MAX}`);
  bad = true;
}
console.log(bad ? "\nmodule-readiness FAILED\n"
                : `\nmodule-readiness clean — 0 hard blockers · ${mutableShared.length}/${BLOCKER2_MAX} shared mutable bindings\n`);
process.exit(bad ? 1 : 0);
