/* ASCEND backend — database and migrations.

   node:sqlite, deliberately. It ships inside Node 22, so the backend installs
   with zero native dependencies and deploys anywhere Node runs — no build
   toolchain, no postinstall compile step, no managed database required to get
   started. The cost is that it is a single-file store on one machine; §"Scaling"
   in DEPLOYMENT.md says exactly when that stops being enough and what replaces
   it. Everything below goes through this module, so replacing the driver later
   is one file, not a search across the codebase.

   Migrations are numbered SQL files applied in order inside a transaction, with
   the applied set recorded in schema_migrations. Re-running is a no-op. There is
   no "down" migration on purpose: rolling a schema backwards over live student
   data loses data, and the recovery path is a restore from backup instead. */
"use strict";

const { DatabaseSync } = require("node:sqlite");
const fs = require("node:fs");
const path = require("node:path");

function open(dbPath){
  const dir = path.dirname(dbPath);
  if(dbPath !== ":memory:" && !fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec("PRAGMA journal_mode = WAL");
  db.exec("PRAGMA foreign_keys = ON");
  db.exec("PRAGMA busy_timeout = 5000");
  return db;
}

function migrate(db, dir = path.join(__dirname, "..", "migrations")){
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
             name TEXT PRIMARY KEY, applied_at INTEGER NOT NULL)`);
  const done = new Set(db.prepare("SELECT name FROM schema_migrations").all().map(r => r.name));
  const files = fs.readdirSync(dir).filter(f => f.endsWith(".sql")).sort();
  const applied = [];
  for(const f of files){
    if(done.has(f)) continue;
    const sql = fs.readFileSync(path.join(dir, f), "utf8");
    db.exec("BEGIN");
    try{
      db.exec(sql);
      db.prepare("INSERT INTO schema_migrations (name, applied_at) VALUES (?, ?)").run(f, Date.now());
      db.exec("COMMIT");
      applied.push(f);
    }catch(e){
      db.exec("ROLLBACK");
      throw new Error(`migration ${f} failed: ${e.message}`);
    }
  }
  return applied;
}

module.exports = { open, migrate };
