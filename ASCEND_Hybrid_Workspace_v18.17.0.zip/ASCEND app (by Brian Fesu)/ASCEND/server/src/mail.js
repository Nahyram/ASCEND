/* ASCEND backend — src/mail.js
   Getting a recovery link to a student.

   ## Why this is a transport rather than a vendor

   Sending email needs an account with somebody, a key, a sending domain and a
   deliverability reputation — four decisions that belong to whoever runs this
   server, not to this file. Hardcoding a provider would make that choice for
   them and would make the whole recovery flow untestable without a live account.

   So delivery is pluggable and the flow around it is real and tested:

     none    — default. Recovery is OFF, and every endpoint says so plainly
               rather than returning a cheerful 200 that sends nothing. A student
               waiting for an email that was never sent is worse off than one who
               was told there is no email.
     log     — writes the link to the server log and the audit trail. For local
               development and for a first deployment where the operator is
               willing to read it out of the log themselves.
     webhook — POSTs to MAIL_WEBHOOK_URL. Whatever is on the other end — a
               provider, a Zap, a school's own script — is not this file's
               business.

   ## The rule the transport must never break

   A transport failure must NOT be reported to the requester as a different
   outcome than success. `/auth/reset/request` answers identically whether the
   address exists, whether a token was made, and whether the send worked —
   otherwise the endpoint becomes a way to discover which students have accounts.
   Failures go to the audit trail, where the operator can see them and the
   internet cannot. */
"use strict";

const { cfg } = require("./config");

const TRANSPORT = (process.env.MAIL_TRANSPORT || "none").toLowerCase();
const WEBHOOK = process.env.MAIL_WEBHOOK_URL || null;
const FROM = process.env.MAIL_FROM || "ascend@localhost";
const APP_URL = (process.env.APP_URL || "").replace(/\/+$/, "");

function available(){
  if(TRANSPORT === "log") return true;
  if(TRANSPORT === "webhook") return !!WEBHOOK;
  return false;
}

function describe(){
  if(TRANSPORT === "log") return "log";
  if(TRANSPORT === "webhook") return WEBHOOK ? "webhook" : "webhook (MAIL_WEBHOOK_URL unset)";
  return "none";
}

/* The link a student clicks, or the code they paste if there is no web link
   configured. APP_URL is optional on purpose: a self-hoster who has not put the
   frontend anywhere yet still gets a working code. */
function link(kind, token){
  if(!APP_URL) return null;
  return `${APP_URL}/#${kind}=${encodeURIComponent(token)}`;
}

const BODIES = {
  reset: (token, url) => ({
    subject: "Reset your ASCEND password",
    text: [
      "Someone asked to reset the password on this ASCEND account.",
      "",
      url ? `Open this to set a new one: ${url}` : `Paste this code into ASCEND: ${token}`,
      "",
      "It stops working in one hour, and can only be used once.",
      "",
      "If this was not you, nothing has changed and you can ignore this. Your",
      "quests, progress and records are untouched either way — a password reset",
      "only affects signing in.",
    ].join("\n"),
  }),
  verify: (token, url) => ({
    subject: "Confirm your ASCEND email",
    text: [
      "Confirming this address is what makes it possible to recover the account",
      "later. Without it, a forgotten password cannot be reset.",
      "",
      url ? `Open this to confirm: ${url}` : `Paste this code into ASCEND: ${token}`,
      "",
      "It stops working in 24 hours.",
    ].join("\n"),
  }),
};

/* Never throws. The caller must behave identically whether this worked or not,
   so a rejected promise here would leak the outcome through timing or through a
   500. The return value is for the audit trail, not for the response. */
async function send(kind, email, token){
  const body = (BODIES[kind] || BODIES.reset)(token, link(kind, token));
  const payload = { to: email, from: FROM, subject: body.subject, text: body.text };

  try{
    if(TRANSPORT === "log"){
      /* Deliberately the whole thing, including the token: this transport exists
         so an operator can read it, and pretending otherwise would make it
         useless. It is why "log" must never be the transport in production, and
         why /health reports which one is in use. */
      console.log(`\n──── ASCEND mail (${kind}) ────\nto: ${email}\n${body.subject}\n\n${body.text}\n────────────────────────────\n`);
      return { ok: true, via: "log" };
    }

    if(TRANSPORT === "webhook"){
      if(!WEBHOOK) return { ok: false, via: "webhook", error: "MAIL_WEBHOOK_URL is not set" };
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), 10000);
      try{
        const res = await fetch(WEBHOOK, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(payload),
          signal: ac.signal,
        });
        return res.ok ? { ok: true, via: "webhook" }
                      : { ok: false, via: "webhook", error: "webhook returned " + res.status };
      } finally { clearTimeout(timer); }
    }

    return { ok: false, via: "none", error: "no mail transport configured" };
  }catch(e){
    return { ok: false, via: describe(), error: (e && e.message) || String(e) };
  }
}

void cfg;
module.exports = { send, available, describe, TRANSPORT };
