/* ASCEND backend — HTTP plumbing.

   node:http, no framework. The whole surface is a dozen routes; a framework
   would be more dependency-audit surface than code. Everything a framework
   would have given us that we actually need is here: body limits, JSON parsing
   that cannot throw into the socket, CORS, rate limiting, and a single error
   funnel so no handler can leak a stack trace to a client. */
"use strict";

const crypto = require("node:crypto");
const { cfg } = require("./config");

const MAX_BODY = 2 * 1024 * 1024;   /* 2 MB — a full sync payload, not more */

function clientIp(req){
  if(cfg.TRUST_PROXY){
    const f = req.headers["x-forwarded-for"];
    if(f) return String(f).split(",")[0].trim();
  }
  return req.socket.remoteAddress || "0.0.0.0";
}
/* Audit rows carry a hash, never an address: enough to correlate abuse, not
   enough to be a location record for a 13-year-old. */
const ipHash = ip => crypto.createHash("sha256").update(String(ip) + (cfg.SESSION_PEPPER || "")).digest("hex").slice(0, 16);

function readBody(req){
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => {
      size += c.length;
      if(size > MAX_BODY){ reject(Object.assign(new Error("Payload too large"), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      if(!raw) return resolve({});
      try{ resolve(JSON.parse(raw)); }
      catch(e){ reject(Object.assign(new Error("Malformed JSON"), { status: 400 })); }
    });
    req.on("error", reject);
  });
}

function send(res, status, body, extra = {}){
  const json = JSON.stringify(body === undefined ? null : body);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(json),
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
    "referrer-policy": "no-referrer",
    ...extra,
  });
  res.end(json);
}

/* CORS. An empty allow-list means same-origin only, which is the correct
   default: a misconfigured "*" on a credentialed API is an account-takeover
   primitive, so it is never reachable from configuration. */
function corsHeaders(origin){
  if(!origin || !cfg.CORS_ORIGINS.includes(origin)) return null;
  return {
    "access-control-allow-origin": origin,
    "access-control-allow-headers": "authorization, content-type",
    "access-control-allow-methods": "GET, POST, PUT, DELETE, OPTIONS",
    "access-control-max-age": "600",
    "vary": "origin",
  };
}

/* Fixed-window limiter, in memory. Adequate for one process; DEPLOYMENT.md
   states plainly that running more than one instance needs a shared store, so
   nobody discovers that by being rate-limited incorrectly in production. */
const buckets = new Map();
function rateLimited(key){
  const now = Date.now();
  const b = buckets.get(key);
  if(!b || now > b.reset){ buckets.set(key, { n: 1, reset: now + cfg.RATE_LIMIT_WINDOW_MS }); return false; }
  b.n++;
  if(buckets.size > 10000) for(const [k, v] of buckets) if(now > v.reset) buckets.delete(k);
  return b.n > cfg.RATE_LIMIT_MAX;
}

module.exports = { readBody, send, corsHeaders, rateLimited, clientIp, ipHash, MAX_BODY };
