/* ASCEND backend — src/events.js
   Ingest a client's event log, replay it, and answer whether the client's claim
   about itself is true.

   ## The one thing this file exists to do

   A browser can be edited. A student who opens devtools and sets `h.level = 99`
   has done nothing clever and nothing this app should punish them for, but the
   server must not be fooled by it. Because progression is a pure function of an
   event log, the server does not have to trust anything: it replays the same
   events with the same reducer the browser used and compares.

   ## The reducers are imported, not reimplemented

   `shared/domain/progression.js` is loaded here through dynamic import — the
   exact file esbuild bundles into the browser. Writing a Node copy of the level
   curve would give the server a second answer to "what level is this student",
   and this project has shipped the consequence of two implementations of one
   rule five times. One file, two runtimes.

   ## What divergence means, and what it does not

   A client that is AHEAD of the server is the normal case: it has events that
   have not synced yet. That is not tampering and must never be treated as such —
   a student on a Ghanaian school connection is ahead of the server most of the
   time by design.

   So the comparison is only made after the submitted batch has been ingested,
   against the client's claim about the same set. A mismatch there means the
   client's arithmetic and the server's disagree over identical inputs, which is
   either a tampered client or a real bug — and this file cannot tell which, so
   it records the fact and reports it rather than punishing anyone. Nothing here
   revokes XP or lowers a level. */
"use strict";

const path = require("node:path");

/* ---------- the shared domain, loaded once ---------- */
let _domain = null;
async function domain(){
  if(_domain) return _domain;
  const root = path.resolve(__dirname, "..", "..", "shared");
  const [events, progression] = await Promise.all([
    import(path.join(root, "events.js")),
    import(path.join(root, "domain", "progression.js")),
  ]);
  _domain = { events, progression };
  return _domain;
}

/* Deliberately modest. A student's whole year is a few thousand events, so a
   batch above this is either a bug or someone probing. Rejecting is cheaper for
   everyone than a request that times out halfway through a transaction. */
const MAX_BATCH = 2000;
const MAX_DATA_BYTES = 512;

function sanitise(raw, isEvent){
  const out = [], rejected = [];
  for(const e of Array.isArray(raw) ? raw.slice(0, MAX_BATCH) : []){
    if(!isEvent(e)){ rejected.push("malformed"); continue; }
    let data;
    try{ data = JSON.stringify(e.data === undefined ? {} : e.data); }
    catch(err){ rejected.push("unserialisable"); continue; }
    if(data.length > MAX_DATA_BYTES){ rejected.push("oversized"); continue; }
    /* The id is the dedupe key, so it must be exactly what it claims to be.
       A client that could send id "x" for device:seq a:1 could overwrite
       somebody else's event — or its own, silently losing XP. */
    if(e.id !== e.device + ":" + e.seq){ rejected.push("id does not match device and seq"); continue; }
    if(String(e.device).length > 64 || String(e.type).length > 64){ rejected.push("oversized field"); continue; }
    out.push({ id: e.id, device: String(e.device), seq: e.seq | 0, ts: Number(e.ts),
               type: String(e.type), data });
  }
  return { clean: out, rejected };
}

async function ingest(db, userId, batch){
  const { events: Ev } = await domain();
  const { clean, rejected } = sanitise(batch, Ev.isEvent);

  const maxRow = db.prepare("SELECT MAX(seq_global) AS m FROM events WHERE user_id=?").get(userId);
  let cursor = (maxRow && maxRow.m) || 0;
  const at = Date.now();

  /* INSERT OR IGNORE plus the (user_id, id) primary key is the whole dedupe
     story. changes() tells us how many were genuinely new, so the response can
     say "accepted 12, already had 340" instead of pretending. */
  const insert = db.prepare(`INSERT OR IGNORE INTO events
      (user_id, id, seq_global, device, seq, ts, type, data, received_at)
      VALUES (?,?,?,?,?,?,?,?,?)`);

  let accepted = 0;
  const tx = db.transaction ? db.transaction(rows => {
    for(const e of rows){
      const r = insert.run(userId, e.id, ++cursor, e.device, e.seq, e.ts, e.type, e.data, at);
      if(r.changes) accepted++; else cursor--;   /* not new — do not burn a cursor slot */
    }
  }) : null;

  if(tx) tx(clean);
  else for(const e of clean){
    const r = insert.run(userId, e.id, ++cursor, e.device, e.seq, e.ts, e.type, e.data, at);
    if(r.changes) accepted++; else cursor--;
  }

  return { accepted, duplicates: clean.length - accepted, rejected: rejected.length, rejections: rejected.slice(0, 5) };
}

function storedEvents(db, userId){
  return db.prepare(`SELECT id, device, seq, ts, type, data FROM events
                     WHERE user_id=? ORDER BY ts, device, seq`).all(userId)
    .map(r => ({ id: r.id, device: r.device, seq: r.seq, ts: r.ts, type: r.type,
                 data: JSON.parse(r.data) }));
}

function baseFor(db, userId){
  const b = db.prepare("SELECT xp, level, total_xp, grants FROM progression_base WHERE user_id=?").get(userId);
  return b ? { xp: b.xp, level: b.level, totalXp: b.total_xp, grants: b.grants }
           : { xp: 0, level: 1, totalXp: 0, grants: 0 };
}

/* A base only ever arrives from a client that compacted. The server keeps the
   SMALLEST one it has seen, because a larger base means events were folded away
   and the server may still hold them — adding a base on top of events it already
   counts would inflate the total. Refusing to advance is the safe direction:
   the worst case is the server replays more than it needed to. */
function offerBase(db, userId, base){
  if(!base || !Number.isFinite(Number(base.totalXp))) return;
  const cur = db.prepare("SELECT total_xp FROM progression_base WHERE user_id=?").get(userId);
  if(cur) return;                       /* never advanced automatically */
  db.prepare(`INSERT INTO progression_base (user_id, xp, level, total_xp, grants, set_at)
              VALUES (?,?,?,?,?,?)`)
    .run(userId, Number(base.xp) || 0, Number(base.level) || 1,
         Number(base.totalXp) || 0, Number(base.grants) || 0, Date.now());
}

async function replay(db, userId){
  const { progression: P } = await domain();
  return P.replayProgression(storedEvents(db, userId), baseFor(db, userId));
}

/* The comparison. Returns the server's answer plus whether the client's claim
   matched it — never a correction, never a penalty. */
async function verify(db, userId, claim){
  const { progression: P } = await domain();
  const server = await replay(db, userId);
  if(!claim) return { progression: server, checked: false };
  const cmp = P.compareProgression(claim, server);
  return { progression: server, checked: true, agrees: cmp.agrees, diffs: cmp.diffs };
}

/* Everything after a cursor, so another device can catch up without pulling the
   whole history every time. */
function since(db, userId, cursor, limit = 1000){
  return db.prepare(`SELECT id, seq_global, device, seq, ts, type, data FROM events
                     WHERE user_id=? AND seq_global > ? ORDER BY seq_global LIMIT ?`)
    .all(userId, Number(cursor) || 0, Math.min(Number(limit) || 1000, MAX_BATCH))
    .map(r => ({ id: r.id, cursor: r.seq_global, device: r.device, seq: r.seq,
                 ts: r.ts, type: r.type, data: JSON.parse(r.data) }));
}

function cursorFor(db, userId){
  const r = db.prepare("SELECT MAX(seq_global) AS m FROM events WHERE user_id=?").get(userId);
  return (r && r.m) || 0;
}

function wipe(db, userId){
  db.prepare("DELETE FROM events WHERE user_id=?").run(userId);
  db.prepare("DELETE FROM progression_base WHERE user_id=?").run(userId);
}

module.exports = { ingest, replay, verify, since, cursorFor, storedEvents, baseFor, offerBase, wipe, MAX_BATCH };
