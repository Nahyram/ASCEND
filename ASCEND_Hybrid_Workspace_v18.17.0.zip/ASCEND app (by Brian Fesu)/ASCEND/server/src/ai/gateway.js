/* ASCEND backend — the AI gateway.

   Everything between a student's question and the provider lives here: usage
   accounting, caching, context minimisation and prompt selection. The tutor
   calls this; nothing calls the provider directly.

   ## Context minimisation

   The client sends a context object. This module does NOT forward it. It picks
   named fields, truncates them, and drops everything else — so a client bug (or
   a tampered client) cannot cause a student's whole record to be posted to a
   third party. The allow-list is the security boundary; adding a field is a
   deliberate edit here, not something a caller can do. */
"use strict";

const crypto = require("node:crypto");
const { cfg } = require("../config");
const provider = require("./openai");

const CACHE_TTL_MS = 6 * 60 * 60 * 1000;

/* The only student information permitted to leave this server. No name, no
   email, no id, no free-form record — a subject, a topic, a mastery number, and
   a short list of recent error kinds. */
function minimiseContext(raw){
  const c = raw && typeof raw === "object" ? raw : {};
  const str = (v, n) => (v === undefined || v === null ? null : String(v).slice(0, n));
  const out = {
    subject:   str(c.subject, 60),
    /* Added deliberately in 18.7, per the rule above. An IGCSE answer and a
       WASSCE answer to the same question differ in vocabulary, notation and what
       the examiner rewards, and the client already computes this. It is a
       syllabus label, not a fact about a person. */
    curriculum: str(c.curriculum, 60),
    topic:     str(c.topic, 80),
    skill:     str(c.skill, 80),
    mastery:   typeof c.mastery === "number" ? Math.round(c.mastery * 100) / 100 : null,
    level:     Number.isFinite(c.level) ? Math.min(999, Math.max(1, Math.round(c.level))) : null,
    recentErrors: Array.isArray(c.recentErrors)
      ? c.recentErrors.slice(0, 5).map(e => str(e, 60)).filter(Boolean) : [],
    objective: str(c.objective, 160),
  };
  for(const k of Object.keys(out)) if(out[k] === null) delete out[k];
  if(!out.recentErrors || !out.recentErrors.length) delete out.recentErrors;
  return out;
}

const MODES = {
  tutor: `You are ASCEND's tutor. Explain at the student's level, using their curriculum's vocabulary. Be concise.`,
  socratic: `You are ASCEND's tutor in Socratic mode. Do NOT give the final answer. Ask one question at a time that moves the student's own reasoning forward. If they are stuck twice, give a hint, not the answer.`,
  diagnose: `You are ASCEND's diagnostician. From the student's recent errors, name the single most likely underlying misconception and how to confirm it. Do not guess beyond the evidence given.`,
  practice: `You are ASCEND's practice generator. Produce questions targeting the stated skill at the stated mastery. Return questions only, numbered, with answers in a separate ANSWERS section.`,
  feedback: `You are ASCEND's marker. Analyse the student's attempt, identify the specific skill that failed, and give one corrective exercise. Be specific about what was wrong, not encouraging about what was right.`,
  plan: `You are ASCEND's planner. Given mastery, deadlines and available time, produce a short prioritised study plan. Be realistic about time. Never recommend sleep deprivation or study blocks over 90 minutes without a break.`,
};

function systemPrompt(mode, context){
  const base = MODES[mode] || MODES.tutor;
  const ctx = Object.keys(context).length ? `\n\nStudent context (all that is known to you):\n${JSON.stringify(context)}` : "";
  return base + ctx +
    `\n\nNever claim the student has mastered something on the strength of one correct answer. Never invent facts about the student beyond the context above.`;
}

function cacheKey(mode, prompt, context, history, task){
  /* Everything that can change the answer is in the key. Leaving history out
     would serve the first turn's reply to every follow-up, which looks exactly
     like a model that has stopped listening. */
  return crypto.createHash("sha256")
    .update([cfg.OPENAI_MODEL, mode, JSON.stringify(context), JSON.stringify(history || []),
             String(task || ""), prompt.trim().toLowerCase()].join("\n"))
    .digest("hex");
}

function usageToday(db, userId){
  const day = new Date().toISOString().slice(0, 10);
  const row = db.prepare("SELECT calls, tokens FROM ai_usage WHERE user_id=? AND day=?").get(userId, day);
  return { day, calls: (row && row.calls) || 0, tokens: (row && row.tokens) || 0 };
}

function recordUsage(db, userId, tokens){
  const day = new Date().toISOString().slice(0, 10);
  db.prepare(`INSERT INTO ai_usage (user_id, day, calls, tokens) VALUES (?, ?, 1, ?)
              ON CONFLICT(user_id, day) DO UPDATE SET calls = calls + 1, tokens = tokens + excluded.tokens`)
    .run(userId, day, tokens || 0);
}

/* The tutor is a conversation: "explain that again, simpler" means nothing
   without the turn it refers to. Until 18.7 the gateway took a single prompt and
   discarded everything before it, so every follow-up question arrived contextless
   and the model answered a different question than the student asked.

   History is accepted, but on the server's terms — a fixed number of turns, a
   fixed length, and two permitted roles. A client cannot enlarge any of those,
   which is what stops "history" becoming an unmetered channel for arbitrary
   prompt text. */
const MAX_HISTORY_TURNS = 8;
const MAX_TURN_CHARS    = 2000;
function sanitiseHistory(raw){
  if(!Array.isArray(raw)) return [];
  return raw
    .filter(m => m && typeof m === "object")
    .slice(-MAX_HISTORY_TURNS)
    .map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content == null ? "" : m.content).slice(0, MAX_TURN_CHARS),
    }))
    .filter(m => m.content.trim());
}

async function ask(db, userId, { mode = "tutor", prompt = "", context = {}, history = [], task = "" } = {}){
  const text = String(prompt || "").trim();
  if(!text) { const e = new Error("A question is required."); e.status = 400; throw e; }
  if(text.length > 4000) { const e = new Error("That question is too long."); e.status = 400; throw e; }

  const min = minimiseContext(context);
  const turns = sanitiseHistory(history);
  /* The caller's own instruction. It is carried as user-side text on purpose: a
     client that could set the system prompt could talk the model out of every
     rule in MODES, which is the usual way a gateway stops being one. */
  const note = String(task || "").slice(0, 1200).trim();
  const key = cacheKey(mode, text, min, turns, note);

  const cached = db.prepare("SELECT response, created_at FROM ai_cache WHERE key=?").get(key);
  if(cached && Date.now() - cached.created_at < CACHE_TTL_MS){
    db.prepare("UPDATE ai_cache SET hits = hits + 1 WHERE key=?").run(key);
    return { text: cached.response, cached: true, usage: usageToday(db, userId), contextSent: min };
  }

  /* The limit is enforced here, on the server, against a row only the server
     can write. A client that edits its own copy changes nothing. */
  const used = usageToday(db, userId);
  if(used.calls >= cfg.AI_DAILY_LIMIT){
    const e = new Error(`Daily AI limit reached (${cfg.AI_DAILY_LIMIT}). It resets at midnight UTC.`);
    e.status = 429; throw e;
  }

  const out = await provider.complete({
    system: systemPrompt(mode, min),
    messages: [
      ...turns,
      { role: "user", content: note ? note + "\n\n" + text : text },
    ],
  });

  recordUsage(db, userId, out.usage.total);
  db.prepare(`INSERT INTO ai_cache (key, model, response, created_at, hits) VALUES (?,?,?,?,0)
              ON CONFLICT(key) DO UPDATE SET response=excluded.response, created_at=excluded.created_at`)
    .run(key, out.model, out.text, Date.now());

  return { text: out.text, cached: false, usage: usageToday(db, userId), contextSent: min };
}

module.exports = { ask, minimiseContext, sanitiseHistory, usageToday, MODES, available: provider.AVAILABLE };
