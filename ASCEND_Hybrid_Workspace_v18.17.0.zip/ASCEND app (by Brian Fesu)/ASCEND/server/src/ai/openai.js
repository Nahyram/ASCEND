/* ASCEND backend — the OpenAI adapter.

   This is the ONLY file in the entire repository that reads OPENAI_API_KEY, and
   the only one that may. The key:

     · is read from the environment at call time, never at import time
     · is never returned, logged, cached, or included in an error
     · never appears in a response body, including error responses

   errorFor() below exists specifically for the last point: an upstream failure
   is translated into a short, safe message, because provider errors routinely
   echo request headers back and that is how keys end up in log aggregators.

   The provider interface is deliberately small so a second provider is a new
   file rather than a change to the tutor. */
"use strict";

const { cfg } = require("../config");

const AVAILABLE = () => !!cfg.OPENAI_API_KEY;

function errorFor(status, upstreamText){
  /* Never surface upstream text: it can contain the request echo. Map instead. */
  if(status === 401 || status === 403) return "The AI provider rejected the server's credentials.";
  if(status === 429) return "The AI provider is rate limiting requests. Try again shortly.";
  if(status >= 500) return "The AI provider is unavailable.";
  return "The AI request could not be completed.";
}

/* Chat completion against the configured model. Returns { text, usage } or
   throws an Error whose message is always safe to show a student. */
async function complete({ system, messages, maxOutput, timeoutMs }){
  if(!AVAILABLE()){
    const e = new Error("AI is not configured on this server.");
    e.status = 503; throw e;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs || cfg.OPENAI_TIMEOUT_MS);
  try{
    const res = await fetch(`${cfg.OPENAI_BASE_URL}/chat/completions`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "content-type": "application/json",
        "authorization": `Bearer ${cfg.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: cfg.OPENAI_MODEL,
        max_tokens: maxOutput || cfg.OPENAI_MAX_OUTPUT,
        messages: [
          ...(system ? [{ role: "system", content: system }] : []),
          ...messages,
        ],
      }),
    });
    if(!res.ok){
      const e = new Error(errorFor(res.status));
      e.status = res.status === 429 ? 429 : 502;
      throw e;
    }
    const data = await res.json();
    const text = (data.choices && data.choices[0] && data.choices[0].message
                  && data.choices[0].message.content) || "";
    return {
      text: String(text).trim(),
      usage: {
        prompt: (data.usage && data.usage.prompt_tokens) || 0,
        output: (data.usage && data.usage.completion_tokens) || 0,
        total: (data.usage && data.usage.total_tokens) || 0,
      },
      model: data.model || cfg.OPENAI_MODEL,
    };
  }catch(e){
    if(e.name === "AbortError"){
      const t = new Error("The AI request timed out."); t.status = 504; throw t;
    }
    if(!e.status) e.status = 502;
    throw e;
  }finally{ clearTimeout(timer); }
}

module.exports = { complete, AVAILABLE };
