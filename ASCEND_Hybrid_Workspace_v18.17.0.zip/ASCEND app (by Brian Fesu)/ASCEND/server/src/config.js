/* ASCEND backend — configuration.

   Every value is read from the environment, with a default only where a wrong
   default cannot cause harm. Two rules govern this file:

     1. No secret has a default. If OPENAI_API_KEY or SESSION_PEPPER is absent,
        the feature that needs it is disabled and says so — it never falls back
        to a built-in value, because a built-in secret is the same as no secret.

     2. Nothing here is ever logged. describe() returns a redacted view for the
        health endpoint, and that is the only thing allowed out of this module. */
"use strict";

const num  = (v, d) => (v === undefined || v === "" || Number.isNaN(Number(v)) ? d : Number(v));
const bool = (v, d) => (v === undefined || v === "" ? d : /^(1|true|yes|on)$/i.test(String(v)));

const cfg = {
  APP_ENV:  process.env.APP_ENV || "development",
  PORT:     num(process.env.PORT, 8787),
  HOST:     process.env.HOST || "0.0.0.0",

  DATABASE_PATH: process.env.DATABASE_PATH || "./data/ascend.db",

  /* Sessions. The pepper is mixed into token hashes so that a database leak on
     its own does not yield usable tokens. Missing in development is tolerated
     with a warning; missing in production is fatal — see assertProduction(). */
  SESSION_PEPPER:    process.env.SESSION_PEPPER || null,
  SESSION_TTL_HOURS: num(process.env.SESSION_TTL_HOURS, 720),

  CORS_ORIGINS: (process.env.CORS_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean),

  /* AI. The key is read in exactly one place, src/ai/openai.js, and never
     leaves this process. Unset means the gateway reports itself unavailable
     rather than failing at request time. */
  OPENAI_API_KEY:    process.env.OPENAI_API_KEY || null,
  OPENAI_MODEL:      process.env.OPENAI_MODEL || "gpt-4o-mini",
  OPENAI_BASE_URL:   process.env.OPENAI_BASE_URL || "https://api.openai.com/v1",
  OPENAI_TIMEOUT_MS: num(process.env.OPENAI_TIMEOUT_MS, 30000),
  OPENAI_MAX_OUTPUT: num(process.env.OPENAI_MAX_OUTPUT, 800),
  AI_DAILY_LIMIT:    num(process.env.AI_DAILY_LIMIT, 40),

  RATE_LIMIT_WINDOW_MS: num(process.env.RATE_LIMIT_WINDOW_MS, 60000),
  RATE_LIMIT_MAX:       num(process.env.RATE_LIMIT_MAX, 120),

  TRUST_PROXY: bool(process.env.TRUST_PROXY, false),
};

/* Fatal checks, applied only when actually serving production traffic. Tests
   and local development must run with a completely empty environment. */
function assertProduction(){
  if(cfg.APP_ENV !== "production") return [];
  const missing = [];
  if(!cfg.SESSION_PEPPER) missing.push("SESSION_PEPPER");
  if(!cfg.CORS_ORIGINS.length) missing.push("CORS_ORIGINS");
  return missing;
}

/* The only permitted external view of configuration: booleans, never values. */
function describe(){
  return {
    env: cfg.APP_ENV,
    database: cfg.DATABASE_PATH,
    sessionsHardened: !!cfg.SESSION_PEPPER,
    corsConfigured: cfg.CORS_ORIGINS.length > 0,
    ai: { configured: !!cfg.OPENAI_API_KEY, model: cfg.OPENAI_MODEL, dailyLimit: cfg.AI_DAILY_LIMIT },
  };
}

module.exports = { cfg, describe, assertProduction };
