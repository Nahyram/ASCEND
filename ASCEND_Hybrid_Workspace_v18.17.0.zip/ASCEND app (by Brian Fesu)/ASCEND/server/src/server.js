/* ASCEND backend — routes.

   The client contract is documented at the bottom of system/services/cloud.js
   and this implements exactly it, plus auth and AI. The rule stated there is
   the rule enforced here: **the account id in a URL is never trusted.** Every
   :id route resolves identity from the bearer token and compares — a mismatch
   is 403, not "well, they asked for it". */
"use strict";

const http = require("node:http");
const crypto = require("node:crypto");
const { cfg, describe, assertProduction } = require("./config");
const dbmod = require("./db");
const auth = require("./auth");
const httpx = require("./http");
const gateway = require("./ai/gateway");
const evts = require("./events");
const mail = require("./mail");
const recovery = require("./recovery");

const now = () => Date.now();
const uid = () => crypto.randomUUID();

function audit(db, userId, kind, detail, ipH){
  try{
    db.prepare("INSERT INTO audit_events (at, user_id, kind, detail, ip_hash) VALUES (?,?,?,?,?)")
      .run(now(), userId || null, kind, detail ? String(detail).slice(0, 200) : null, ipH || null);
  }catch(e){ /* audit must never break a request */ }
}

/* ---------- identity from the token, never from the path ---------- */
function authenticate(db, req){
  const h = req.headers.authorization || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  if(!m) return null;
  const id = auth.tokenId(m[1]);
  const s = db.prepare(`SELECT s.id, s.user_id, s.expires_at, s.revoked_at, u.email, u.display_name, u.disabled_at
                        FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?`).get(id);
  if(!s || s.revoked_at || s.disabled_at) return null;
  if(s.expires_at < now()) return null;
  db.prepare("UPDATE sessions SET last_seen=? WHERE id=?").run(now(), id);
  return { sessionId: id, userId: s.user_id, email: s.email, displayName: s.display_name };
}

const DEFAULT_ENTITLEMENTS = {
  AI_COACH: true, CLOUD_SYNC: true, ADVANCED_ANALYTICS: true,
  PREMIUM_THEMES: true, ADVANCED_TUTOR: true, UNLIMITED_PROJECTS: true,
};
function entitlementsFor(db, userId){
  const out = { ...DEFAULT_ENTITLEMENTS };
  for(const r of db.prepare("SELECT key, allowed, expires_at FROM entitlements WHERE user_id=?").all(userId)){
    if(r.expires_at && r.expires_at < now()) continue;
    out[r.key] = !!r.allowed;
  }
  return out;
}

function createServer(db){
  return http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const p = url.pathname.replace(/\/+$/, "") || "/";
    const ip = httpx.clientIp(req);
    const ipH = httpx.ipHash(ip);
    const cors = httpx.corsHeaders(req.headers.origin);
    const reply = (status, body) => httpx.send(res, status, body, cors || {});

    if(req.method === "OPTIONS") return httpx.send(res, cors ? 204 : 403, null, cors || {});
    if(req.headers.origin && !cors && p !== "/health")
      return httpx.send(res, 403, { error: "Origin not allowed." });
    if(httpx.rateLimited(ipH)) return reply(429, { error: "Too many requests." });

    try{
      /* ---------- health: reports reality, never green-checks ---------- */
      if(p === "/health" && req.method === "GET"){
        let dbOk = true; try{ db.prepare("SELECT 1").get(); }catch(e){ dbOk = false; }
        return httpx.send(res, dbOk ? 200 : 503, {
          service: "ascend", ok: dbOk,
          database: dbOk ? "healthy" : "unreachable",
          ai: gateway.available() ? "configured" : "not configured",
          config: describe(),
          time: new Date().toISOString(),
        }, cors || {});
      }

      /* ---------- registration ---------- */
      if(p === "/auth/register" && req.method === "POST"){
        const b = await httpx.readBody(req);
        const ep = auth.emailProblem(b.email); if(ep) return reply(400, { error: ep });
        const pp = auth.passwordProblem(b.password); if(pp) return reply(400, { error: pp });
        const name = String(b.displayName || "").trim().slice(0, 60) || String(b.email).split("@")[0];
        const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(String(b.email).trim());
        if(exists){
          audit(db, null, "register.duplicate", null, ipH);
          /* Same shape and status as success would be nicer for enumeration, but
             a registration form must tell the truth or the student is stuck. */
          return reply(409, { error: "An account with that email already exists." });
        }
        const { hash, salt } = auth.hashPassword(b.password);
        const id = uid();
        db.prepare(`INSERT INTO users (id, email, display_name, password_hash, password_salt, created_at)
                    VALUES (?,?,?,?,?,?)`).run(id, String(b.email).trim(), name, hash, salt, now());
        db.prepare("INSERT INTO records (user_id, rev, payload, updated_at) VALUES (?,0,'null',?)").run(id, now());
        audit(db, id, "register", null, ipH);
        return reply(201, { id, displayName: name, provider: "ascend" });
      }

      /* ---------- account recovery ----------

         Before 18.13 a forgotten password was an unrecoverable account. These
         four routes fix that, and every one of them is written around a single
         constraint: an unauthenticated caller must not be able to learn which
         email addresses have ASCEND accounts. These are schoolchildren, and
         "who uses this app" is not a list the internet gets to assemble.

         So /request answers identically whether the address exists, whether a
         token was issued, whether the send succeeded, and whether the transport
         is even configured. Everything an operator needs to debug it goes to the
         audit trail, where they can see it and nobody else can. */
      if(p === "/auth/reset/request" && req.method === "POST"){
        const b = await httpx.readBody(req);
        const email = String(b.email || "").trim();
        const same = { ok: true, message: "If that address has an account, a reset link is on its way. It expires in an hour." };

        if(!mail.available()){
          /* The one honest exception. Telling a student to wait for an email
             that can never arrive is worse than telling them recovery is off,
             and this answer does not depend on whether the address exists. */
          audit(db, null, "reset.unavailable", mail.describe(), ipH);
          return reply(503, { error: "Password reset is not available on this server yet. Ask whoever runs it." });
        }

        const u = email ? db.prepare("SELECT id, email, disabled_at FROM users WHERE email = ?").get(email) : null;
        if(u && !u.disabled_at){
          if(recovery.throttled(db, u.id, "reset")){
            /* Same body as success. The throttle protects the student's inbox,
               and saying "you are being throttled" would confirm the account. */
            audit(db, u.id, "reset.throttled", null, ipH);
            return reply(200, same);
          }
          const token = recovery.issue(db, u.id, "reset", ipH);
          const sent = await mail.send("reset", u.email, token);
          audit(db, u.id, sent.ok ? "reset.sent" : "reset.send-failed",
                sent.ok ? sent.via : String(sent.error).slice(0, 120), ipH);
        } else {
          audit(db, null, "reset.unknown-address", null, ipH);
        }
        return reply(200, same);
      }

      if(p === "/auth/reset/confirm" && req.method === "POST"){
        const b = await httpx.readBody(req);
        const pp = auth.passwordProblem(b.password);
        if(pp) return reply(400, { error: pp });

        const userId = recovery.consume(db, String(b.token || ""), "reset");
        if(!userId){
          audit(db, null, "reset.bad-token", null, ipH);
          /* Expired, already used, wrong, and never existed are one answer. */
          return reply(400, { error: "That reset link is not valid any more. Ask for a new one." });
        }

        const { hash, salt } = auth.hashPassword(b.password);
        db.prepare("UPDATE users SET password_hash=?, password_salt=? WHERE id=?").run(hash, salt, userId);
        /* If the reset happened because somebody else had the account, leaving
           their phone signed in would make the whole exercise decorative. */
        const killed = recovery.revokeAllSessions(db, userId);
        /* Completing a reset proves the address receives mail, which is the
           thing verification was going to establish anyway. */
        recovery.markVerified(db, userId);
        audit(db, userId, "reset.complete", `sessions revoked: ${killed}`, ipH);
        return reply(200, { ok: true, sessionsRevoked: killed,
          message: "Password changed. Every device has been signed out — sign in again with the new one. Nothing on your devices was touched." });
      }

      if(p === "/auth/verify/request" && req.method === "POST"){
        const me = authenticate(db, req);
        if(!me) return reply(401, { error: "Authentication required." });
        if(!mail.available()) return reply(503, { error: "Email is not configured on this server yet." });
        if(recovery.throttled(db, me.userId, "verify")) return reply(429, { error: "Too many requests. Try again later." });
        const u = db.prepare("SELECT email FROM users WHERE id=?").get(me.userId);
        const token = recovery.issue(db, me.userId, "verify", ipH);
        const sent = await mail.send("verify", u.email, token);
        audit(db, me.userId, sent.ok ? "verify.sent" : "verify.send-failed", null, ipH);
        return reply(200, { ok: true, message: "Check your email." });
      }

      if(p === "/auth/verify/confirm" && req.method === "POST"){
        const b = await httpx.readBody(req);
        const userId = recovery.consume(db, String(b.token || ""), "verify");
        if(!userId) return reply(400, { error: "That link is not valid any more." });
        recovery.markVerified(db, userId);
        audit(db, userId, "verify.complete", null, ipH);
        return reply(200, { ok: true });
      }

      /* ---------- sign in — POST /auth/session ---------- */
      if(p === "/auth/session" && req.method === "POST"){
        const b = await httpx.readBody(req);
        const u = db.prepare("SELECT * FROM users WHERE email = ?").get(String(b.email || "").trim());
        const ok = u && !u.disabled_at && auth.verifyPassword(b.password, u.password_hash, u.password_salt);
        if(!ok){
          audit(db, u ? u.id : null, "signin.fail", null, ipH);
          /* One message for both causes: which of the two it was is exactly what
             an attacker enumerating accounts wants to learn. */
          return reply(401, { error: "Email or password is incorrect." });
        }
        const token = auth.newToken();
        db.prepare(`INSERT INTO sessions (id, user_id, created_at, expires_at, last_seen, device)
                    VALUES (?,?,?,?,?,?)`)
          .run(auth.tokenId(token), u.id, now(), now() + cfg.SESSION_TTL_HOURS * 3600e3, now(),
               String(b.device || "").slice(0, 64) || null);
        audit(db, u.id, "signin", null, ipH);
        return reply(200, {
          token, id: u.id, displayName: u.display_name, provider: "ascend",
          entitlements: entitlementsFor(db, u.id),
        });
      }

      /* everything below requires a session */
      const me = authenticate(db, req);
      if(p === "/auth/session" && req.method === "DELETE"){
        if(me){ db.prepare("UPDATE sessions SET revoked_at=? WHERE id=?").run(now(), me.sessionId);
                audit(db, me.userId, "signout", null, ipH); }
        return reply(200, { ok: true });
      }
      if(!me && (p.startsWith("/records") || p.startsWith("/ai") || p === "/me"))
        return reply(401, { error: "Authentication required." });

      if(p === "/me" && req.method === "GET")
        return reply(200, { id: me.userId, displayName: me.displayName, email: me.email,
                            entitlements: entitlementsFor(db, me.userId),
                            ai: gateway.usageToday(db, me.userId) });

      /* ---------- records: pull / push / wipe ---------- */
      const rec = /^\/records\/([^/]+)$/.exec(p);
      if(rec){
        /* The contract's rule, enforced. The id in the path is a claim. */
        if(rec[1] !== me.userId){
          audit(db, me.userId, "records.forbidden", rec[1], ipH);
          return reply(403, { error: "That record does not belong to this account." });
        }
        const row = db.prepare("SELECT rev, payload, updated_at, device FROM records WHERE user_id=?").get(me.userId);

        if(req.method === "GET"){
          if(!row || row.payload === "null") return reply(200, null);
          return reply(200, { rev: row.rev, payload: JSON.parse(row.payload), updatedAt: row.updated_at });
        }
        if(req.method === "PUT"){
          const b = await httpx.readBody(req);
          const baseRev = Number(b.baseRev || 0);
          const cur = row ? row.rev : 0;
          if(baseRev !== cur){
            /* Somebody else pushed since this client pulled. Hand back the
               server's copy; cloud.js merges and retries. */
            return reply(409, { ok: false, conflict: true,
              server: { rev: cur, payload: row && row.payload !== "null" ? JSON.parse(row.payload) : null,
                        updatedAt: row ? row.updated_at : null } });
          }
          const next = cur + 1;
          db.prepare(`INSERT INTO records (user_id, rev, payload, updated_at, device) VALUES (?,?,?,?,?)
                      ON CONFLICT(user_id) DO UPDATE SET rev=excluded.rev, payload=excluded.payload,
                        updated_at=excluded.updated_at, device=excluded.device`)
            .run(me.userId, next, JSON.stringify(b.payload === undefined ? null : b.payload), now(),
                 String(b.device || "").slice(0, 64) || null);
          audit(db, me.userId, "records.push", "rev " + next, ipH);
          return reply(200, { ok: true, rev: next });
        }
        if(req.method === "DELETE"){
          db.prepare("UPDATE records SET rev=0, payload='null', updated_at=? WHERE user_id=?").run(now(), me.userId);
          /* The event log is the student's data too. Leaving a complete history
             behind after "delete my cloud data" would make that button a lie,
             and would be the wrong answer to give a parent asking what is held. */
          evts.wipe(db, me.userId);
          audit(db, me.userId, "records.wipe", null, ipH);
          return reply(200, { ok: true });
        }
      }

      /* ---------- events: submit, replay, catch up ----------

         This is what makes "the server is the record of truth" compatible with
         "the student keeps working offline". The client stays free to compute
         its own progression at any time; the server recomputes the same events
         with the same reducer and is the authority on what the ACCOUNT says.

         Nothing here lowers a level or takes XP away. A disagreement is recorded
         and reported, because this endpoint cannot tell a tampered client from a
         bug in the reducer, and guessing wrong in the punishing direction would
         cost an honest student their year. */
      const evp = /^\/records\/([^/]+)\/events$/.exec(p);
      if(evp){
        if(evp[1] !== me.userId){
          audit(db, me.userId, "events.forbidden", evp[1], ipH);
          return reply(403, { error: "That record does not belong to this account." });
        }

        if(req.method === "GET"){
          const cursor = Number(url.searchParams.get("since") || 0);
          return reply(200, {
            cursor: evts.cursorFor(db, me.userId),
            events: evts.since(db, me.userId, cursor),
            progression: await evts.replay(db, me.userId),
          });
        }

        if(req.method === "POST"){
          const b = await httpx.readBody(req);
          if(Array.isArray(b.events) && b.events.length > evts.MAX_BATCH)
            return reply(413, { error: "That batch is too large. Send it in parts." });

          evts.offerBase(db, me.userId, b.base);
          const ing = await evts.ingest(db, me.userId, b.events);
          const out = await evts.verify(db, me.userId, b.claim);

          audit(db, me.userId, "events.push", `+${ing.accepted} dup ${ing.duplicates}`, ipH);
          if(out.checked && !out.agrees){
            /* Recorded so a pattern is visible later; a single mismatch during a
               sync is not evidence of anything on its own. */
            audit(db, me.userId, "events.divergence", JSON.stringify(out.diffs).slice(0, 180), ipH);
          }

          return reply(200, {
            ok: true, ...ing,
            cursor: evts.cursorFor(db, me.userId),
            progression: out.progression,
            checked: out.checked, agrees: out.checked ? out.agrees : undefined,
            diffs: out.checked && !out.agrees ? out.diffs : undefined,
          });
        }

        if(req.method === "DELETE"){
          evts.wipe(db, me.userId);
          audit(db, me.userId, "events.wipe", null, ipH);
          return reply(200, { ok: true });
        }
      }

      /* ---------- AI ---------- */
      if(p === "/ai/ask" && req.method === "POST"){
        if(!entitlementsFor(db, me.userId).AI_COACH)
          return reply(403, { error: "This account does not include the AI tutor." });
        const b = await httpx.readBody(req);
        const out = await gateway.ask(db, me.userId, b);
        audit(db, me.userId, "ai.ask", b.mode || "tutor", ipH);
        return reply(200, out);
      }
      if(p === "/ai/usage" && req.method === "GET")
        return reply(200, { ...gateway.usageToday(db, me.userId), limit: cfg.AI_DAILY_LIMIT });

      return reply(404, { error: "Not found." });
    }catch(e){
      const status = e.status || 500;
      /* A 500 never carries its cause outward; it goes to the log with an id
         the student can quote instead. */
      if(status >= 500){
        const ref = crypto.randomBytes(4).toString("hex");
        console.error(`[error ${ref}] ${req.method} ${p} — ${e.message}`);
        return reply(status, { error: "Something went wrong on the server.", ref });
      }
      return reply(status, { error: e.message });
    }
  });
}

function start(){
  const missing = assertProduction();
  if(missing.length){
    console.error(`ASCEND refuses to start in production without: ${missing.join(", ")}`);
    process.exit(1);
  }
  if(cfg.APP_ENV !== "production" && !cfg.SESSION_PEPPER)
    console.warn("ASCEND: SESSION_PEPPER is unset. Fine locally, fatal in production.");
  const db = dbmod.open(cfg.DATABASE_PATH);
  const applied = dbmod.migrate(db);
  if(applied.length) console.log(`ASCEND: applied ${applied.length} migration(s): ${applied.join(", ")}`);
  const server = createServer(db);
  server.listen(cfg.PORT, cfg.HOST, () =>
    console.log(`ASCEND backend on ${cfg.HOST}:${cfg.PORT} · env=${cfg.APP_ENV} · ai=${gateway.available() ? "configured" : "off"}`));
  return { server, db };
}

module.exports = { createServer, start, authenticate, entitlementsFor };
if(require.main === module) start();
