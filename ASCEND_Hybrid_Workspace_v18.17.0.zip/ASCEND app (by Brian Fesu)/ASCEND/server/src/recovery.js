/* ASCEND backend — src/recovery.js
   Issuing and consuming the one-time tokens behind password reset and email
   verification.

   ## Rules, and the reason for each

   1. **Stored hashed.** Same treatment as session tokens. A database dump must
      not be a working key to every account.

   2. **Single use, short life.** Reset expires in an hour; verification in a
      day. A reset link that stays valid for a week is a live credential sitting
      in an inbox the student may share with a sibling.

   3. **Every outstanding token of the same kind dies when one is issued.**
      Otherwise a student who clicks "forgot password" three times has three live
      keys, and the two they abandoned are the ones nobody is watching.

   4. **A completed reset revokes every session.** If the reset happened because
      somebody else had the account, leaving their phone signed in makes the
      whole exercise decorative.

   5. **Throttled per address, not only per IP.** IP throttling stops a scan; it
      does nothing about pointing the endpoint at one student's mailbox from a
      different address each time. The person harmed there is the student whose
      inbox fills up, so the limit follows the address.

   6. **The caller can never tell whether the address existed.** Nothing in this
      file returns "no such user" upward in a way that changes a response body.
      Enumeration through an unauthenticated endpoint is how you turn "who has an
      ASCEND account" into a public list, and these are schoolchildren. */
"use strict";

const crypto = require("node:crypto");
const auth = require("./auth");

const TTL = { reset: 60 * 60 * 1000, verify: 24 * 60 * 60 * 1000 };

/* Deliberately low. A student legitimately needs one or two of these; anything
   above that is somebody else's traffic arriving in their inbox. */
const MAX_PER_ADDRESS = 3;
const THROTTLE_WINDOW_MS = 60 * 60 * 1000;

function hash(token){ return auth.tokenId(token); }

function issue(db, userId, kind, ipHash){
  const now = Date.now();
  /* Rule 3 — one live token per kind. */
  db.prepare("UPDATE auth_tokens SET used_at=? WHERE user_id=? AND kind=? AND used_at IS NULL")
    .run(now, userId, kind);

  const token = auth.newToken();
  db.prepare(`INSERT INTO auth_tokens (token_hash, user_id, kind, created_at, expires_at, ip_hash)
              VALUES (?,?,?,?,?,?)`)
    .run(hash(token), userId, kind, now, now + (TTL[kind] || TTL.reset), ipHash || null);
  return token;
}

/* Returns the user id, or null. Never says WHY it returned null to the caller's
   response — expired, used, wrong and unknown are one outcome from outside. */
function consume(db, token, kind){
  if(typeof token !== "string" || token.length < 20) return null;
  const row = db.prepare("SELECT * FROM auth_tokens WHERE token_hash=? AND kind=?").get(hash(token), kind);
  if(!row) return null;
  if(row.used_at) return null;
  if(row.expires_at < Date.now()) return null;
  db.prepare("UPDATE auth_tokens SET used_at=? WHERE token_hash=?").run(Date.now(), row.token_hash);
  return row.user_id;
}

function throttled(db, userId, kind){
  const since = Date.now() - THROTTLE_WINDOW_MS;
  const r = db.prepare("SELECT COUNT(*) AS n FROM auth_tokens WHERE user_id=? AND kind=? AND created_at > ?")
    .get(userId, kind, since);
  return (r && r.n) >= MAX_PER_ADDRESS;
}

/* Rule 4. Called on a completed reset, not on the request. */
function revokeAllSessions(db, userId){
  const r = db.prepare("UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL")
    .run(Date.now(), userId);
  return r.changes || 0;
}

function markVerified(db, userId){
  db.prepare("UPDATE users SET email_verified_at=? WHERE id=?").run(Date.now(), userId);
}

/* Housekeeping. Expired tokens are not dangerous — they are already refused —
   but keeping them forever turns a small table into a slow one. */
function sweep(db, olderThanMs = 7 * 24 * 60 * 60 * 1000){
  const r = db.prepare("DELETE FROM auth_tokens WHERE expires_at < ?").run(Date.now() - olderThanMs);
  return r.changes || 0;
}

void crypto;
module.exports = { issue, consume, throttled, revokeAllSessions, markVerified, sweep,
                   TTL, MAX_PER_ADDRESS, THROTTLE_WINDOW_MS };
