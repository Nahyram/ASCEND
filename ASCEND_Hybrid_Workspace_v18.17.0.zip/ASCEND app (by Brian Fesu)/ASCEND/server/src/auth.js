/* ASCEND backend — identity.

   Passwords are hashed with scrypt from node:crypto. scrypt rather than a
   bcrypt/argon2 package for one reason that matters here: it is in the standard
   library, so the backend has no native dependency and deploys on any host that
   runs Node. Parameters below are the OWASP-recommended floor for scrypt.

   Session tokens are 32 random bytes, returned to the client once and never
   stored. What is stored is sha256(token + SESSION_PEPPER), so a database leak
   yields hashes that cannot be replayed without also holding the pepper, which
   lives in the host's secret manager and not in the database. */
"use strict";

const crypto = require("node:crypto");
const { cfg } = require("./config");

/* OWASP's scrypt floor is N=2^15, r=8, p=1. That needs 128*N*r = 32 MiB, which
   is exactly Node's default scrypt maxmem — so the default rejects the
   recommended parameters. maxmem is raised rather than N lowered: weakening the
   cost factor to fit a library default is the wrong direction. */
const SCRYPT = { N: 2 ** 15, r: 8, p: 1, keylen: 64, maxmem: 96 * 1024 * 1024 };

function hashPassword(password){
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(password), salt, SCRYPT.keylen, SCRYPT).toString("hex");
  return { hash, salt };
}

/* Constant-time compare. A length mismatch is answered with a dummy comparison
   so that "no such user" and "wrong password" take indistinguishable time. */
function verifyPassword(password, hash, salt){
  try{
    const derived = crypto.scryptSync(String(password), salt, SCRYPT.keylen, SCRYPT);
    const stored = Buffer.from(hash, "hex");
    if(stored.length !== derived.length) return false;
    return crypto.timingSafeEqual(derived, stored);
  }catch(e){ return false; }
}

function newToken(){ return crypto.randomBytes(32).toString("base64url"); }

function tokenId(token){
  return crypto.createHash("sha256")
    .update(String(token) + (cfg.SESSION_PEPPER || ""))
    .digest("hex");
}

/* Passwords are the one place where a weak default would be invisible until it
   mattered, so the rule is stated here rather than in the route. */
function passwordProblem(pw){
  const s = String(pw || "");
  if(s.length < 10) return "Password must be at least 10 characters.";
  if(s.length > 200) return "Password must be under 200 characters.";
  return null;
}

function emailProblem(email){
  const s = String(email || "").trim();
  if(s.length < 3 || s.length > 320) return "Enter a valid email address.";
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) return "Enter a valid email address.";
  return null;
}

module.exports = { hashPassword, verifyPassword, newToken, tokenId, passwordProblem, emailProblem, SCRYPT };
