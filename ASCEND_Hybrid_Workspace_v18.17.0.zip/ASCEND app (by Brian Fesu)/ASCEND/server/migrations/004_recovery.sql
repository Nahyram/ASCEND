-- ASCEND 18.13 — account recovery.
--
-- Until this release a forgotten password meant an unrecoverable account. The
-- Gate said so before a student set one, which was the minimum honest handling
-- and not a solution: the first student who forgets is an account lost, and
-- with it their cross-device backup.
--
-- Design notes:
--
--  * Tokens are stored HASHED, never in plaintext, for the same reason session
--    tokens are: a database dump or a stray backup must not be a set of working
--    keys to every account. The column is named token_hash so nobody adds a
--    plaintext sibling next to it later.
--
--  * One table for both kinds. A reset token and a verification token have
--    identical mechanics — issue, expire, use once — and two tables would drift
--    into two sets of rules, which is how this project has repeatedly ended up
--    with two implementations of one thing.
--
--  * `used_at` rather than DELETE. A used token is evidence: it is how you tell
--    "the reset worked" from "the email never arrived", and it is what makes a
--    replay attempt visible instead of silent.

CREATE TABLE IF NOT EXISTS auth_tokens (
  token_hash  TEXT    PRIMARY KEY,
  user_id     TEXT    NOT NULL,
  kind        TEXT    NOT NULL,          -- 'reset' | 'verify'
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL,
  used_at     INTEGER,
  ip_hash     TEXT
);

CREATE INDEX IF NOT EXISTS idx_auth_tokens_user ON auth_tokens (user_id, kind, created_at);

-- Whether an address has been proven to belong to whoever registered it.
-- Registration does not verify, and never has; adding the column now means the
-- state is recorded from this release forward rather than inferred later.
ALTER TABLE users ADD COLUMN email_verified_at INTEGER;
