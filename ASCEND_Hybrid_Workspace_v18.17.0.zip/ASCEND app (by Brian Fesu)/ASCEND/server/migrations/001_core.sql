-- ASCEND 001 — accounts, sessions, records, audit.
-- The client contract this satisfies is documented at the bottom of
-- system/services/cloud.js. Account id in a URL is never trusted; the session
-- token in the Authorization header is the only identity.

CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  display_name  TEXT NOT NULL,
  password_hash TEXT NOT NULL,       -- scrypt, salt embedded; never a plaintext
  password_salt TEXT NOT NULL,
  created_at    INTEGER NOT NULL,
  disabled_at   INTEGER
);

CREATE TABLE sessions (
  id          TEXT PRIMARY KEY,      -- sha256(token + pepper); the token itself is never stored
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL,
  last_seen   INTEGER NOT NULL,
  device      TEXT,
  revoked_at  INTEGER
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

-- One record per user: the synced payload plus its revision. The revision is
-- what makes conflict detection possible — a push carrying a stale base_rev is
-- rejected with the server's copy so the client can merge and retry.
CREATE TABLE records (
  user_id     TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  rev         INTEGER NOT NULL DEFAULT 0,
  payload     TEXT NOT NULL,
  updated_at  INTEGER NOT NULL,
  device      TEXT
);

-- Server-authoritative entitlements. Absence of a row means the default policy
-- applies; the client may cache the answer but never decides it.
CREATE TABLE entitlements (
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key        TEXT NOT NULL,
  allowed    INTEGER NOT NULL,
  source     TEXT NOT NULL,
  expires_at INTEGER,
  PRIMARY KEY (user_id, key)
);

-- AI usage, counted per user per UTC day so a daily limit is enforceable
-- server-side rather than by the browser.
CREATE TABLE ai_usage (
  user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day      TEXT NOT NULL,
  calls    INTEGER NOT NULL DEFAULT 0,
  tokens   INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);

-- Append-only. Nothing sensitive: no payloads, no prompts, no tokens.
CREATE TABLE audit_events (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  at       INTEGER NOT NULL,
  user_id  TEXT,
  kind     TEXT NOT NULL,
  detail   TEXT,
  ip_hash  TEXT
);
CREATE INDEX idx_audit_at ON audit_events(at);
