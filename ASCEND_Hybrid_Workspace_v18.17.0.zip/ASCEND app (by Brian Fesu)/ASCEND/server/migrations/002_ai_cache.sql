-- ASCEND 002 — response cache for the AI gateway.
-- Keyed by a hash of (model + normalised prompt), so an identical question from
-- the same student inside the TTL costs nothing. Cached rows carry no student
-- identifiers: the key is a hash and the value is the model's reply.

CREATE TABLE ai_cache (
  key        TEXT PRIMARY KEY,
  model      TEXT NOT NULL,
  response   TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  hits       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_ai_cache_created ON ai_cache(created_at);
