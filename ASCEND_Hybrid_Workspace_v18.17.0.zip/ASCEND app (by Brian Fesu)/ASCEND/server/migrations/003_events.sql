-- ASCEND 18.11 — the event log, server-side.
--
-- The client has held an append-only log since 18.10. This is where it lands so
-- the server can replay it with the same reducers the browser uses and answer
-- the one question a client cannot be trusted with: is this total real?
--
-- Design notes that matter:
--
--  * The primary key is (user_id, id), and an event id is device:seq. That makes
--    ingestion idempotent by construction — a retried sync, a restored backup or
--    a client that pushes its whole log every time all collapse to the same
--    rows. Double-counted XP is the failure a student would notice and never
--    forgive, so it is made impossible in the schema rather than guarded in code.
--
--  * `seq_global` is a server-assigned monotonic number, separate from the
--    device's own `seq`. It exists so another device can ask "what have I not
--    seen?" with a cursor, without trusting anyone's clock.
--
--  * The server does NOT compact. It has a real database and a real disk; the
--    client compacts because a phone replays on every boot. Keeping every event
--    server-side means the server can always recompute from zero, which is what
--    makes tamper detection meaningful.

CREATE TABLE IF NOT EXISTS events (
  user_id     TEXT    NOT NULL,
  id          TEXT    NOT NULL,          -- device:seq, unique per account
  seq_global  INTEGER NOT NULL,          -- server-assigned, monotonic per account
  device      TEXT    NOT NULL,
  seq         INTEGER NOT NULL,          -- the device's own sequence
  ts          INTEGER NOT NULL,          -- the device's clock, used only for ordering
  type        TEXT    NOT NULL,
  data        TEXT    NOT NULL,          -- JSON
  received_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, id)
);

-- The two questions asked of this table: "everything for this account, in
-- canonical order" and "everything after this cursor".
CREATE INDEX IF NOT EXISTS idx_events_order  ON events (user_id, ts, device, seq);
CREATE INDEX IF NOT EXISTS idx_events_cursor ON events (user_id, seq_global);

-- The account's compaction snapshot. A client that has compacted sends the base
-- it folded into; the server keeps the earliest one it has ever been given and
-- never advances it on its own, because the server holds every event and has no
-- reason to throw any away.
CREATE TABLE IF NOT EXISTS progression_base (
  user_id  TEXT PRIMARY KEY,
  xp       INTEGER NOT NULL DEFAULT 0,
  level    INTEGER NOT NULL DEFAULT 1,
  total_xp INTEGER NOT NULL DEFAULT 0,
  grants   INTEGER NOT NULL DEFAULT 0,
  set_at   INTEGER NOT NULL
);
