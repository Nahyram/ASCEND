/* ASCEND — secret leakage scan.

   §26/§27 require proof, not assurance, that the OpenAI key cannot reach a
   browser. Three claims, each checked mechanically:

     1. Nothing that ships to the client mentions OPENAI_API_KEY or contains a
        key-shaped string.
     2. Only one server file reads the key at all.
     3. Nothing key-shaped is committed anywhere in the repository.

   The pattern below matches the shape of an OpenAI key, so this also catches a
   real key pasted into a file by accident — which is the failure this project
   has already had twice, via chat rather than via a file. */
"use strict";

const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.join(__dirname, "..", "..");
const results = [], errors = [];
const check = (label, fn) => {
  try{ const r = fn(); results.push((r === true ? "  PASS  " : "  FAIL  ") + label); if(r !== true) errors.push(label + (typeof r === "string" ? " — " + r : "")); }
  catch(e){ results.push("  ERR   " + label + " — " + e.message); errors.push(label + ": " + e.message); }
};

const KEY_SHAPE = /\bsk-[A-Za-z0-9_-]{20,}/;

function walk(dir, out = [], skip = /node_modules|\.git|\/data$/){
  if(!fs.existsSync(dir) || skip.test(dir)) return out;
  for(const e of fs.readdirSync(dir, { withFileTypes: true })){
    const p = path.join(dir, e.name);
    if(skip.test(p)) continue;
    if(e.isDirectory()) walk(p, out, skip);
    else out.push(p);
  }
  return out;
}
const textFiles = f => /\.(js|html|css|json|md|sql|txt|yml|yaml|example)$/.test(f);

check("no key-shaped string anywhere in the repository", () => {
  const hits = walk(ROOT).filter(textFiles)
    .filter(f => !/secret-scan\.js$/.test(f))
    .filter(f => KEY_SHAPE.test(fs.readFileSync(f, "utf8")))
    .map(f => path.relative(ROOT, f));
  return hits.length === 0 || hits.join(", ");
});

check("nothing shipped to the browser mentions the key variable", () => {
  const hits = walk(path.join(ROOT, "system")).filter(textFiles)
    .filter(f => /OPENAI_API_KEY/.test(fs.readFileSync(f, "utf8")))
    .map(f => path.relative(ROOT, f));
  return hits.length === 0 || hits.join(", ");
});

check("exactly one server file reads the key", () => {
  const hits = walk(path.join(ROOT, "server")).filter(textFiles)
    .filter(f => /process\.env\.OPENAI_API_KEY|cfg\.OPENAI_API_KEY/.test(fs.readFileSync(f, "utf8")))
    .map(f => path.relative(path.join(ROOT, "server"), f))
    .filter(f => !f.startsWith("test/"));
  const allowed = ["src/config.js", "src/ai/openai.js"];
  const bad = hits.filter(h => !allowed.includes(h.split(path.sep).join("/")));
  return bad.length === 0 || "unexpected reader(s): " + bad.join(", ");
});

check(".env is ignored by git, and .env.example carries no value", () => {
  const gi = fs.readFileSync(path.join(ROOT, ".gitignore"), "utf8");
  if(!/^\.env$|^\.env\b/m.test(gi)) return ".env is not in .gitignore";
  const ex = fs.readFileSync(path.join(ROOT, "server", ".env.example"), "utf8");
  const filled = ex.split("\n").filter(l => /^(OPENAI_API_KEY|SESSION_PEPPER)=.+/.test(l.trim()));
  return filled.length === 0 || "a secret has a value in .env.example: " + filled.join(", ");
});

console.log("\nASCEND — secret leakage scan\n");
results.forEach(r => console.log(r));
console.log("");
if(errors.length){ console.log(`${errors.length} problem(s):`); errors.forEach(e => console.log("  - " + e)); process.exit(1); }
console.log(`all ${results.length} checks passed\n`);
