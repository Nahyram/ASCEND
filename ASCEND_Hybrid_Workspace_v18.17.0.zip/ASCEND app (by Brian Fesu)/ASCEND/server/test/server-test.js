/* ASCEND backend — integration suite.

   Runs the real server on a real socket against a real (temporary) database.
   Nothing here is mocked except the AI provider, which is stubbed because this
   container cannot reach api.openai.com and because a test suite that spends
   money on every run is a test suite people stop running.

   The security checks are the point of this file. Each one is a claim the
   directive makes about what a client must not be able to do. */
"use strict";

process.env.APP_ENV = "test";
process.env.DATABASE_PATH = ":memory:";
process.env.SESSION_PEPPER = "test-pepper-not-a-real-secret";
process.env.AI_DAILY_LIMIT = "3";
process.env.RATE_LIMIT_MAX = "1000";

const assert = require("node:assert");
const dbmod = require("../src/db");
const { createServer } = require("../src/server");

const results = [], errors = [];
function check(label, fn){
  return Promise.resolve().then(fn).then(() => results.push("  PASS  " + label))
    .catch(e => { results.push("  FAIL  " + label + " — " + e.message); errors.push(label + ": " + e.message); });
}

const db = dbmod.open(":memory:");
dbmod.migrate(db);
const server = createServer(db);

let base;
function api(path, opts = {}){
  return fetch(base + path, {
    method: opts.method || "GET",
    headers: { "content-type": "application/json", ...(opts.token ? { authorization: "Bearer " + opts.token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  }).then(async r => ({ status: r.status, body: await r.json().catch(() => null) }));
}

(async () => {
  await new Promise(r => server.listen(0, "127.0.0.1", r));
  base = `http://127.0.0.1:${server.address().port}`;

  /* ---------- health ---------- */
  await check("health reports reality, and never a secret", async () => {
    const r = await api("/health");
    assert.equal(r.status, 200);
    assert.equal(r.body.database, "healthy");
    const s = JSON.stringify(r.body);
    assert.ok(!/sk-|SESSION_PEPPER|test-pepper/.test(s), "health leaked a secret");
    assert.equal(typeof r.body.config.ai.configured, "boolean");
  });

  /* ---------- registration and sign-in ---------- */
  await check("a weak password is refused", async () => {
    const r = await api("/auth/register", { method: "POST", body: { email: "a@b.co", password: "short" } });
    assert.equal(r.status, 400);
  });

  let tokenA, idA;
  await check("registration then sign-in issues a token", async () => {
    const reg = await api("/auth/register", { method: "POST",
      body: { email: "hunter@ascend.test", password: "a-long-enough-password", displayName: "Hunter" } });
    assert.equal(reg.status, 201);
    idA = reg.body.id;
    const s = await api("/auth/session", { method: "POST",
      body: { email: "hunter@ascend.test", password: "a-long-enough-password" } });
    assert.equal(s.status, 200);
    assert.ok(s.body.token, "no token issued");
    tokenA = s.body.token;
  });

  await check("the raw token is never stored — only its hash", async () => {
    const rows = db.prepare("SELECT id FROM sessions").all();
    assert.ok(rows.length, "no session row");
    assert.ok(!rows.some(r => r.id === tokenA), "the token itself is in the database");
  });

  await check("the password is never stored in plaintext", async () => {
    const u = db.prepare("SELECT password_hash FROM users WHERE id=?").get(idA);
    assert.ok(!/a-long-enough-password/.test(u.password_hash));
  });

  await check("a wrong password and an unknown email give the same answer", async () => {
    const wrong = await api("/auth/session", { method: "POST", body: { email: "hunter@ascend.test", password: "nope-nope-nope" } });
    const absent = await api("/auth/session", { method: "POST", body: { email: "ghost@ascend.test", password: "nope-nope-nope" } });
    assert.equal(wrong.status, 401);
    assert.equal(absent.status, 401);
    assert.equal(wrong.body.error, absent.body.error, "the two answers differ — that enumerates accounts");
  });

  /* ---------- authorization ---------- */
  await check("an unauthenticated request to a record is refused", async () => {
    const r = await api("/records/" + idA);
    assert.equal(r.status, 401);
  });

  let tokenB, idB;
  await check("a second account cannot read the first account's record", async () => {
    const reg = await api("/auth/register", { method: "POST",
      body: { email: "other@ascend.test", password: "another-long-password", displayName: "Other" } });
    idB = reg.body.id;
    const s = await api("/auth/session", { method: "POST",
      body: { email: "other@ascend.test", password: "another-long-password" } });
    tokenB = s.body.token;
    const r = await api("/records/" + idA, { token: tokenB });
    assert.equal(r.status, 403, "account isolation broken");
  });

  await check("a forged token is rejected", async () => {
    const r = await api("/records/" + idA, { token: "not-a-real-token" });
    assert.equal(r.status, 401);
  });

  /* ---------- sync: revisions and conflict ---------- */
  await check("push then pull round-trips the payload and bumps the revision", async () => {
    const push = await api("/records/" + idA, { method: "PUT", token: tokenA,
      body: { baseRev: 0, payload: { xp: 4242, level: 12 } } });
    assert.equal(push.status, 200);
    assert.equal(push.body.rev, 1);
    const pull = await api("/records/" + idA, { token: tokenA });
    assert.equal(pull.body.rev, 1);
    assert.equal(pull.body.payload.xp, 4242);
  });

  await check("a stale push is rejected as a conflict, with the server's copy", async () => {
    const r = await api("/records/" + idA, { method: "PUT", token: tokenA,
      body: { baseRev: 0, payload: { xp: 1 } } });          /* stale: server is at rev 1 */
    assert.equal(r.status, 409);
    assert.equal(r.body.conflict, true);
    assert.equal(r.body.server.rev, 1);
    assert.equal(r.body.server.payload.xp, 4242, "conflict response must carry the server copy");
  });

  await check("merging against the server copy then re-pushing succeeds", async () => {
    const r = await api("/records/" + idA, { method: "PUT", token: tokenA,
      body: { baseRev: 1, payload: { xp: 5000, level: 13 } } });
    assert.equal(r.status, 200);
    assert.equal(r.body.rev, 2);
  });

  /* ---------- entitlements are the server's ---------- */
  await check("a client cannot grant itself an entitlement", async () => {
    const before = (await api("/me", { token: tokenB })).body.entitlements.ADVANCED_TUTOR;
    await api("/records/" + idB, { method: "PUT", token: tokenB,
      body: { baseRev: 0, payload: { entitlements: { ADVANCED_TUTOR: true }, cloud: { entitlements: { ADVANCED_TUTOR: true } } } } });
    db.prepare("INSERT INTO entitlements (user_id, key, allowed, source) VALUES (?,?,0,'test')").run(idB, "ADVANCED_TUTOR");
    const after = (await api("/me", { token: tokenB })).body.entitlements.ADVANCED_TUTOR;
    assert.equal(before, true);
    assert.equal(after, false, "the server's answer must win over anything in the payload");
  });

  /* ---------- AI ---------- */
  await check("the AI daily limit is enforced server-side", async () => {
    const gw = require("../src/ai/gateway");
    const openai = require("../src/ai/openai");
    const real = openai.complete;
    openai.complete = async () => ({ text: "stub", usage: { prompt: 1, output: 1, total: 2 }, model: "stub" });
    try{
      let last;
      for(let i = 0; i < 5; i++)
        last = await api("/ai/ask", { method: "POST", token: tokenA,
          body: { mode: "tutor", prompt: "question number " + i, context: { subject: "Physics" } } });
      assert.equal(last.status, 429, "limit of 3 was not enforced");
    } finally { openai.complete = real; }
  });

  await check("AI is refused without a session", async () => {
    const r = await api("/ai/ask", { method: "POST", body: { prompt: "hello" } });
    assert.equal(r.status, 401);
  });

  await check("no route can return the API key", async () => {
    /* Assembled at runtime rather than written as a literal: the secret scan
       forbids key-shaped strings in every file with no exemption for tests,
       because a test-file exemption is precisely where a real key would sit
       unnoticed. */
    const canary = ["sk", "canary", "MUSTNEVERAPPEARINARESPONSE0000"].join("-");
    process.env.OPENAI_API_KEY = canary;
    const paths = ["/health", "/me", "/ai/usage", "/records/" + idA];
    for(const p of paths){
      const r = await api(p, { token: tokenA });
      assert.ok(!JSON.stringify(r.body || {}).includes(canary), p + " leaked the key");
    }
    delete process.env.OPENAI_API_KEY;
  });

  /* ---------- input handling ---------- */
  await check("malformed JSON is rejected, not crashed on", async () => {
    const r = await fetch(base + "/auth/session", { method: "POST",
      headers: { "content-type": "application/json" }, body: "{not json" });
    assert.equal(r.status, 400);
  });

  await check("signing out revokes the session immediately", async () => {
    const s = await api("/auth/session", { method: "POST",
      body: { email: "other@ascend.test", password: "another-long-password" } });
    const t = s.body.token;
    assert.equal((await api("/me", { token: t })).status, 200);
    await api("/auth/session", { method: "DELETE", token: t });
    assert.equal((await api("/me", { token: t })).status, 401, "a revoked token still works");
  });

  server.close();
  console.log("\nASCEND backend — integration suite\n");
  results.forEach(r => console.log(r));
  console.log("");
  if(errors.length){ console.log(`${errors.length} problem(s):`); errors.forEach(e => console.log("  - " + e)); process.exit(1); }
  console.log(`all ${results.length} checks passed\n`);
})();
