/* ASCEND — hooks-test.js
   The dispatch registry, and the guard hole that hid two dead functions.

   ## What this is protecting

   Twenty-two places used to reassign a function another file declared. renderAll
   was wrapped six deep that way, and the composition order was the <script>
   order in index.html — nothing recorded it, nothing tested it, and a moved
   script tag would have silently reordered a render pass. Those twenty-two are
   now Hooks registrations.

   A refactor of a render chain is exactly the kind of change that passes a test
   suite and ships a blank screen; v16 did precisely that with 137 checks green.
   So these checks assert the COMPOSITION, not just that nothing threw.

   ## The guard hole

   The v15 collision guard reads `^(function|const|let|var)\s+NAME` — it finds
   DECLARATIONS. views/shelves.js did not declare renderLibrary, it ASSIGNED to
   it: `renderLibrary = function(){...}`. content/library.js declared the same
   name 43 lines long, loaded eleven scripts earlier, and was overwritten every
   single time. Same for renderScreen in views/v9-views.js, 38 lines. Eighty-one
   lines of code that could never run, in a guard built specifically to catch
   this, because assignment is not declaration.
*/
"use strict";
const fs = require("fs");
const path = require("path");
const { JSDOM, VirtualConsole } = require("jsdom");

const ROOT = path.join(__dirname, "system");

/* A converted module lives under src/; an unconverted one is still at the top of
   system/. Resolving instead of hard-coding means the next conversion pass does
   not silently turn this assertion into a false pass. */
function appFile(rel){
  const a = path.join(ROOT, "src", rel), b = path.join(ROOT, rel);
  return fs.existsSync(a) ? a : b;
}

let pass = 0, fail = 0;
function ok(name, cond, detail) {
  if (cond) { pass++; console.log("  PASS  " + name); }
  else { fail++; console.log("  FAIL  " + name); }
  if (detail) console.log("         " + detail);
}

/* ---------- part 1: the registry in isolation ---------- */
console.log("\n  — the dispatch registry —\n");

/* Against a build with no registry — the shipped v18.1 — this must REPORT a
   failure rather than crash the runner. A suite that throws an ENOENT tells you
   nothing about which guarantee is missing. */
const hooksPath = appFile("core/hooks.js");
if (!fs.existsSync(hooksPath)) {
  ok("a dispatch registry exists at core/hooks.js", false,
    "no registry in this build — the 22 cross-file function reassignments are still in place, and none of the guarantees below can hold");
  console.log("\n  " + pass + " passed \u00b7 " + fail + " failed\n");
  process.exit(1);
}
/* core/hooks.js is an ES module as of 18.8, so its export statement is stripped
   before the source is run in a plain vm context. Evaluating the source rather
   than importing it is deliberate: this suite tests the registry in isolation,
   with nothing else of the app loaded, which is what makes a failure here point
   at the registry instead of at whatever it happened to be loaded beside. */
const hooksSrc = fs.readFileSync(hooksPath, "utf8").replace(/^export\s*\{[^}]*\};?\s*$/m, "");
const sandbox = { console: { warn() {} } };
new (require("vm").Script)(hooksSrc + "\n;this.Hooks = Hooks;").runInNewContext(sandbox);
const Hooks = sandbox.Hooks;

/* Order is the whole point: the reassignment idiom made the LAST file to wrap
   the OUTERMOST, because each wrapped whatever it found. If dispatch composed
   the other way, renderAll's five wrappers would run inside out and the app
   would repaint in the wrong order — a bug no "did it throw" check would see. */
{
  const seq = [];
  const base = () => { seq.push("base"); return "b"; };
  Hooks._reset();
  Hooks.wrap("t", "first", (next) => { seq.push("first-in"); const r = next(); seq.push("first-out"); return r; });
  Hooks.wrap("t", "second", (next) => { seq.push("second-in"); const r = next(); seq.push("second-out"); return r; });
  const out = Hooks.dispatch("t", base, null, []);
  ok("the last registered wrapper is the outermost, as reassignment was",
    seq.join(" ") === "second-in first-in base first-out second-out",
    seq.join(" "));
  ok("the base's return value survives the chain", out === "b");
}

{
  Hooks._reset();
  const seq = [];
  Hooks.before("t", "b", () => seq.push("before"));
  Hooks.after("t", "a", (r) => seq.push("after:" + r));
  const out = Hooks.dispatch("t", () => { seq.push("base"); return 7; }, null, []);
  ok("before runs first, after runs last, and neither changes the result",
    seq.join(" ") === "before base after:7" && out === 7, seq.join(" ") + " → " + out);
}

{
  Hooks._reset();
  Hooks.wrap("t", "short circuit", () => "stopped");
  let ran = false;
  const out = Hooks.dispatch("t", () => { ran = true; return "base"; }, null, []);
  ok("a wrapper that does not call next stops the base, as recovery does to penalties",
    out === "stopped" && !ran);
}

{
  Hooks._reset();
  Hooks.wrap("t", "arg rewriter", (next, n, why) => next(n * 2, why));
  const out = Hooks.dispatch("t", (n, why) => n + ":" + why, null, [5, "x"]);
  ok("a wrapper can rewrite the arguments the base receives", out === "10:x", out);
}

/* P1-04: unexpected errors must be observable. The old chain gave you an
   anonymous stack in the middle of renderAll and no way to tell which of six
   wrappers threw. */
{
  Hooks._reset();
  Hooks.wrap("t", "the broken one", () => { throw new Error("boom"); });
  let threw = false;
  try { Hooks.dispatch("t", () => 1, null, []); } catch (e) { threw = true; }
  const f = Hooks.failures();
  ok("a throwing hook still propagates — behaviour is unchanged by the refactor", threw);
  ok("a throwing hook is recorded against its name and label, not swallowed",
    f.length === 1 && f[0].name === "t" && f[0].label === "the broken one" && /boom/.test(f[0].message),
    f.length ? f[0].name + " · " + f[0].label + " · " + f[0].message : "nothing recorded");
}

{
  Hooks._reset();
  const off = Hooks.after("t", "temporary", () => {});
  const before = Hooks.count("t");
  off();
  ok("registering returns a working unsubscribe", before === 1 && Hooks.count("t") === 0);
}

{
  Hooks._reset();
  ok("dispatching a name with no hooks calls the base directly",
    Hooks.dispatch("nothing-registered", () => "plain", null, []) === "plain");
}

/* ---------- part 2: no reassignment survives in the source ---------- */
console.log("\n  — the source no longer reassigns across files —\n");

const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const files = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1])
  .filter(f => fs.existsSync(path.join(ROOT, f)));

const acorn = require("acorn"), walk = require("acorn-walk");
const declaredSomewhere = new Set();
const parsed = new Map();
for (const f of files) {
  const src = fs.readFileSync(path.join(ROOT, f), "utf8");
  const ast = acorn.parse(src, { ecmaVersion: 2022, sourceType: "script" });
  parsed.set(f, { src, ast });
  for (const n of ast.body) {
    if ((n.type === "FunctionDeclaration" || n.type === "ClassDeclaration") && n.id) declaredSomewhere.add(n.id.name);
    if (n.type === "VariableDeclaration") for (const d of n.declarations) if (d.id.type === "Identifier") declaredSomewhere.add(d.id.name);
  }
}

const crossFileAssign = [];
for (const [f, { src, ast }] of parsed) {
  const local = new Set();
  walk.full(ast, n => {
    if (n.type === "VariableDeclarator" && n.id.type === "Identifier") local.add(n.id.name);
    if ((n.type === "FunctionDeclaration" || n.type === "FunctionExpression" || n.type === "ClassDeclaration") && n.id) local.add(n.id.name);
    if (n.type === "FunctionDeclaration" || n.type === "FunctionExpression" || n.type === "ArrowFunctionExpression")
      for (const p of n.params) walk.full(p, x => { if (x.type === "Identifier") local.add(x.name); });
    if (n.type === "CatchClause" && n.param) walk.full(n.param, x => { if (x.type === "Identifier") local.add(x.name); });
  });
  walk.full(ast, n => {
    if (n.type === "AssignmentExpression" && n.left.type === "Identifier"
      && !local.has(n.left.name) && declaredSomewhere.has(n.left.name)) {
      crossFileAssign.push(f + " → " + n.left.name);
    }
  });
}
ok("no file reassigns a function another file declared",
  crossFileAssign.length === 0,
  crossFileAssign.length ? crossFileAssign.join("; ")
    : "22 such reassignments in v18.1, 0 now — an ES module cannot express one, because an imported binding is read-only");

/* ---------- part 3: the closed guard hole ---------- */
console.log("\n  — the collision guard sees assignments too —\n");

const owners = {};
for (const [f, { ast }] of parsed) {
  for (const n of ast.body) {
    let name = null;
    if ((n.type === "FunctionDeclaration" || n.type === "ClassDeclaration") && n.id) name = n.id.name;
    else if (n.type === "VariableDeclaration" && n.declarations[0] && n.declarations[0].id.type === "Identifier") name = n.declarations[0].id.name;
    if (name) (owners[name] = owners[name] || new Set()).add(f + " (declares)");
    /* the half the v15 guard could not see: a top-level assignment to a name
       another file declared. Parsed, not regexed, so a declaration inside an
       IIFE — armory.js and online.js both wrap themselves — is correctly not
       global. */
    if (n.type === "ExpressionStatement" && n.expression.type === "AssignmentExpression"
      && n.expression.left.type === "Identifier"
      && /Function|Arrow/.test(n.expression.right.type)) {
      (owners[n.expression.left.name] = owners[n.expression.left.name] || new Set()).add(f + " (assigns)");
    }
  }
}
const collisions = Object.entries(owners).filter(([, v]) => v.size > 1).map(([k, v]) => k + ": " + [...v].join(" + "));
ok("no global function is both declared in one file and assigned in another",
  collisions.length === 0,
  collisions.length ? collisions.join("; ")
    : "renderLibrary and renderScreen were each declared in one file and overwritten by assignment in another — 81 lines that never ran");

/* ---------- part 4: the composition, in the real app ---------- */
console.log("\n  — the real render chain —\n");

const vc = new VirtualConsole();
const bootErrors = [];
vc.on("jsdomError", e => bootErrors.push(String(e.message || e)));
const dom = new JSDOM(fs.readFileSync(path.join(ROOT, "index.html"), "utf8"), {
  runScripts: "dangerously", pretendToBeVisual: true, url: "https://localhost/app/index.html",
});
const w = dom.window, d = w.document;
const nodeCrypto = require("crypto");
/* jsdom 30 exposes window.crypto as a getter-only accessor in a secure context,
   so the assignment the older suites use throws here. Only fill the gap. */
try {
  if (!w.crypto) Object.defineProperty(w, "crypto", { value: {}, configurable: true });
  if (!w.crypto.getRandomValues) {
    w.crypto.getRandomValues = a => { nodeCrypto.randomFillSync(Buffer.from(a.buffer, a.byteOffset, a.byteLength)); return a; };
  }
} catch (e) { /* a real crypto is already present, which is what we wanted */ }
w.matchMedia = w.matchMedia || (q => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }));
w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {}; w.indexedDB = undefined;
w.AudioContext = function () { return { createGain: () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} } }), createOscillator: () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0, setValueAtTime() {} }, type: "" }), createBufferSource: () => ({ connect() {}, start() {}, stop() {}, buffer: null, loop: false }), createBuffer: () => ({ getChannelData: () => new Float32Array(100) }), createBiquadFilter: () => ({ connect() {}, frequency: { value: 0 }, type: "", Q: { value: 0 } }), destination: {}, sampleRate: 44100, currentTime: 0, close() {}, resume() {} }; };

for (const f of files) {
  const el = d.createElement("script");
  el.textContent = fs.readFileSync(path.join(ROOT, f), "utf8");
  d.body.appendChild(el);
}

function evalIn(code) {
  const el = d.createElement("script");
  el.textContent = `try{ window.__H = JSON.stringify((function(){ ${code} })()); }catch(e){ window.__H = JSON.stringify({__err:String(e&&e.message||e)}); }`;
  d.body.appendChild(el);
  return JSON.parse(w.__H);
}

(async () => {

ok("every script loads with no error", bootErrors.length === 0, bootErrors.slice(0, 3).join(" | ") || "clean");

const chain = evalIn("return { renderAll: Hooks.list('renderAll').map(h=>h.kind+':'+h.label), names: Hooks.names() };");
ok("renderAll's five wrappers all registered, in script order",
  Array.isArray(chain.renderAll) && chain.renderAll.length === 5
  && chain.renderAll[0].endsWith("v9 panels")
  && chain.renderAll[1].endsWith("forge + arena")
  && chain.renderAll[2].endsWith("v11 panels")
  && chain.renderAll[3].endsWith("shell chrome")
  && chain.renderAll[4].endsWith("intelligence layer"),
  (chain.renderAll || chain.__err || []).toString());

ok("every function that used to be reassigned now dispatches",
  ["renderAll", "enterSystem", "go", "grantXp", "toggleQuest", "issuePenalty",
   "renderGoals", "renderBeyond", "renderPath", "renderOnlineGate", "renderHome"]
    .every(n => (chain.names || []).includes(n)),
  "dispatched names: " + (chain.names || []).join(", "));

/* A render pass needs a hunter — renderStatus reads h.avatar and has always
   thrown without one. Seed one through the app's own factory, the way
   brain-test.js does, rather than clicking through onboarding: the boot
   animation is timer-driven and this suite is about composition, not onboarding. */
await new Promise(r => setTimeout(r, 1700));
const seeded = evalIn(`
  const h = { id:"hk1", name:"Hook Probe", title:"The Composer", pin:"", avatar:"", level:3, xp:10,
    totalXp:300, rank:"E", stats:{STR:5,VIT:5,INT:5,PER:5,DIS:5},
    quests:[{ id:"q1", time:"07:00", name:"Morning study", stat:"INT", days:[0,1,2,3,4,5,6], workout:false, xp:20 }],
    mode:"student", curriculum:"igcse", workout:"calisthenics", diff:"2", restDay:0, reroll:0,
    done:{}, penalties:[], deadlines:[], streak:2, lastActive:null, totalCleared:0, spotify:"",
    penaltyMode:"on", alarmMode:"on", workoutDone:{}, unlocked:false, created:todayKey(),
    goals:[], brain:null, focusLog:{} };
  DB.hunters["hk1"] = h; DB.active = "hk1"; save();
  return { ok:true, has: !!H() };
`);
ok("a hunter seeds, so a real render pass is possible",
  !seeded.__err && seeded.ok && seeded.has,
  seeded.__err ? "threw: " + seeded.__err : (seeded.why || "seeded"));

/* The chain is not just registered — it must run end to end. router.js registers
   renderHome as an after-hook on renderAll, and frontier.js registers the loop
   map as an after-hook on renderHome: a hook on a hook. If dispatch is wrong
   anywhere, this is where a blank Home comes from. */
const ran = evalIn(`
  const seen = [];
  const offA = Hooks.after("renderAll", "__probe_all", () => seen.push("renderAll"));
  const offH = Hooks.after("renderHome", "__probe_home", () => seen.push("renderHome"));
  const before = Hooks.failures().length;
  try{ renderAll(); }
  catch(e){ return { err: String(e && e.message || e) }; }
  finally{ offA(); offH(); }
  return { seen, failures: Hooks.failures().slice(before).map(f => f.name + "/" + f.label + ": " + f.message) };
`);
ok("calling renderAll reaches renderHome through two levels of registration",
  !ran.err && (ran.seen || []).includes("renderAll") && (ran.seen || []).includes("renderHome"),
  ran.err ? "threw: " + ran.err : "reached: " + (ran.seen || []).join(", "));
ok("no hook failed during a full render pass",
  !ran.err && (ran.failures || []).length === 0,
  (ran.failures || []).slice(0, 3).join(" | ") || "no recorded hook failures");

/* world.js used to reassign grantXp for the duration of a toggleQuest call.
   The replacement is a module-local tag read by a registered wrap: XP granted
   inside toggleQuest carries the quest's once-tag, XP granted outside does not. */
const tagged = evalIn(`
  const got = [];
  const off = Hooks.wrap("grantXp", "__probe_xp", (next, n, why, ctx) => { got.push(ctx && ctx.once ? String(ctx.once) : "none"); return next(n, why, ctx); });
  try{ grantXp(5, "outside a quest"); } finally { off(); }
  return { got };
`);
ok("XP granted outside a quest carries no once-tag",
  !tagged.__err && (tagged.got || []).length === 1 && tagged.got[0] === "none",
  tagged.__err ? "threw: " + tagged.__err : "ctx.once: " + (tagged.got || []).join(", "));

/* Observing the injected ctx from a probe is impossible by design: a probe
   registers last and is therefore OUTERMOST, so it sees the arguments before
   world.js's wrap rewrites them. Assert the outcome instead — the ledger entry
   the tag exists to create. brain-test.js's "clearing a quest twice in a day
   pays once" covers the same rule from the other end. */
const inQuest = evalIn(`
  const h = H();
  const q = (h.quests || [])[0];
  if(!q) return { skip:true };
  const b = brain(); if(b) b.xpLedger = { day: todayKey(), total:0, paid:{} };
  try{
    toggleQuest(q);
    const led = brain() && brain().xpLedger;
    return { paid: led ? Object.keys(led.paid) : [], tag: "q:" + q.id };
  } catch(e){ return { err: String(e && e.message || e) }; }
`);
ok("clearing a quest tags its XP once-per-day without reassigning grantXp",
  inQuest.skip || (!inQuest.err && (inQuest.paid || []).includes(inQuest.tag)),
  inQuest.skip ? "no quest on the board — check skipped"
    : inQuest.err ? "threw: " + inQuest.err
    : "ledger paid: [" + (inQuest.paid || []).join(", ") + "] (expected " + inQuest.tag + ")");

console.log(`\n  ${pass} passed · ${fail} failed\n`);
dom.window.close();
process.exit(fail ? 1 : 0);
})();
