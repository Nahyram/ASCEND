/* ASCEND — recovery-test.js
   Password reset and email verification, over a real socket.

   ## Why this suite is written the way it is

   Two failure modes, and they pull in opposite directions.

   **Too weak** and a reset endpoint becomes a way to take over accounts, or —
   more likely and more quietly — a way to find out which email addresses have
   ASCEND accounts. The users here are 13 to 18 years old. "Who uses this app" is
   not a list the internet gets to assemble, and an unauthenticated endpoint that
   answers differently for a known address is exactly how that list gets built.

   **Too strict** and a student who forgets their password loses a year of work,
   which is the situation this release exists to end.

   So most of what follows checks that two paths are *indistinguishable* from
   outside, and the rest checks that the recovery actually recovers. */
"use strict";

process.env.APP_ENV = "test";
process.env.DATABASE_PATH = ":memory:";
process.env.SESSION_PEPPER = "test-pepper-not-a-real-secret";
process.env.RATE_LIMIT_MAX = "5000";
/* The webhook transport, pointed at a socket this suite owns, so delivery is
   genuinely exercised rather than stubbed — including the token that arrives. */
const http = require("node:http");
let inbox = [];
const mailbox = http.createServer((req, res) => {
  let body = "";
  req.on("data", c => { body += c; });
  req.on("end", () => {
    try{ inbox.push(JSON.parse(body)); }catch(e){ inbox.push({ raw: body }); }
    res.writeHead(200, { "content-type": "application/json" });
    res.end("{}");
  });
});

const assert = require("node:assert");

const results = [], errors = [];
async function check(label, fn){
  try{ await fn(); results.push("  PASS  " + label); }
  catch(e){ results.push("  FAIL  " + label + " — " + e.message); errors.push(label); }
}

let BASE = null, db = null, server = null;

async function api(pathname, { method = "GET", body, token } = {}){
  const headers = { accept: "application/json" };
  if(body !== undefined) headers["content-type"] = "application/json";
  if(token) headers.authorization = "Bearer " + token;
  const res = await fetch(BASE + pathname, { method, headers,
    body: body === undefined ? undefined : JSON.stringify(body) });
  let data = null;
  try{ data = await res.json(); }catch(e){}
  return { status: res.status, data };
}

const PASSWORD = "correct-horse-battery";
const NEWPASS  = "a-different-long-passphrase";

async function account(label){
  const email = `${label}-${Date.now()}-${Math.random().toString(36).slice(2,8)}@example.com`;
  await api("/auth/register", { method:"POST", body:{ email, password: PASSWORD, displayName: label } });
  const s = await api("/auth/session", { method:"POST", body:{ email, password: PASSWORD, device: label } });
  return { email, token: s.data.token, id: s.data.id };
}

/* The token as it actually travelled — pulled out of the delivered message, not
   read from the database. A test that reads the token from the table would pass
   against a server that never sent anything. */
function tokenFromInbox(email){
  const m = [...inbox].reverse().find(x => x.to === email);
  if(!m) return null;
  const code = /code into ASCEND: (\S+)/.exec(m.text) || /reset=([^\s"']+)/.exec(m.text);
  return code ? code[1] : null;
}

(async () => {
  await new Promise(r => mailbox.listen(0, "127.0.0.1", r));
  process.env.MAIL_TRANSPORT = "webhook";
  process.env.MAIL_WEBHOOK_URL = `http://127.0.0.1:${mailbox.address().port}/`;

  /* Required after the env is set: config and mail read it at require time. */
  const dbmod = require("./server/src/db");
  const { createServer } = require("./server/src/server");
  db = dbmod.open(":memory:");
  dbmod.migrate(db);
  server = createServer(db);
  await new Promise(r => server.listen(0, "127.0.0.1", r));
  BASE = `http://127.0.0.1:${server.address().port}`;

  /* ---------- the happy path ---------- */
  const A = await account("forgetful");

  await check("a reset link is actually delivered, and the code in it works", async () => {
    inbox = [];
    const req = await api("/auth/reset/request", { method:"POST", body:{ email: A.email } });
    assert.strictEqual(req.status, 200, JSON.stringify(req.data));
    await new Promise(r => setTimeout(r, 60));
    assert.strictEqual(inbox.length, 1, "nothing was delivered");
    assert.strictEqual(inbox[0].to, A.email);

    const token = tokenFromInbox(A.email);
    assert.ok(token && token.length > 20, "no usable code in the message");

    const done = await api("/auth/reset/confirm", { method:"POST", body:{ token, password: NEWPASS } });
    assert.strictEqual(done.status, 200, JSON.stringify(done.data));

    const signIn = await api("/auth/session", { method:"POST", body:{ email: A.email, password: NEWPASS } });
    assert.strictEqual(signIn.status, 200, "the new password does not work");
    A.token = signIn.data.token;
  });

  await check("the old password stops working", async () => {
    const r = await api("/auth/session", { method:"POST", body:{ email: A.email, password: PASSWORD } });
    assert.strictEqual(r.status, 401, "the old password still signs in");
  });

  await check("a reset signs out every device", async () => {
    const B = await account("multi");
    const second = await api("/auth/session", { method:"POST", body:{ email: B.email, password: PASSWORD, device:"tablet" } });
    assert.strictEqual((await api("/me", { token: second.data.token })).status, 200);

    inbox = [];
    await api("/auth/reset/request", { method:"POST", body:{ email: B.email } });
    await new Promise(r => setTimeout(r, 60));
    const done = await api("/auth/reset/confirm", { method:"POST",
      body:{ token: tokenFromInbox(B.email), password: NEWPASS } });
    assert.ok(done.data.sessionsRevoked >= 2, `only ${done.data.sessionsRevoked} sessions revoked`);
    /* If the reset happened because somebody else had the account, leaving their
       device signed in makes the whole exercise decorative. */
    assert.strictEqual((await api("/me", { token: B.token })).status, 401, "the first device is still signed in");
    assert.strictEqual((await api("/me", { token: second.data.token })).status, 401, "the second device is still signed in");
  });

  await check("a reset does not touch the record or the event log", async () => {
    const C = await account("keeper");
    await api(`/records/${C.id}`, { method:"PUT", token: C.token,
      body:{ payload:{ progress:{ totalXp: 4242 } }, baseRev: 0, device:"phone" } });
    const Ev = await import(require("node:path").resolve("./shared/events.js"));
    const events = Array.from({ length: 10 }, (_, i) =>
      Ev.makeEvent({ type:"XP_GRANTED", data:{ n: 30 }, ts: 1_700_000_000_000 + i, device:"phone", seq: i }));
    await api(`/records/${C.id}/events`, { method:"POST", token: C.token, body:{ events } });

    inbox = [];
    await api("/auth/reset/request", { method:"POST", body:{ email: C.email } });
    await new Promise(r => setTimeout(r, 60));
    await api("/auth/reset/confirm", { method:"POST", body:{ token: tokenFromInbox(C.email), password: NEWPASS } });

    const back = await api("/auth/session", { method:"POST", body:{ email: C.email, password: NEWPASS } });
    const rec = await api(`/records/${C.id}`, { token: back.data.token });
    const log = await api(`/records/${C.id}/events`, { token: back.data.token });
    assert.strictEqual(rec.data.payload.progress.totalXp, 4242, "the record changed during a password reset");
    assert.strictEqual(log.data.events.length, 10, "the event log changed during a password reset");
    assert.strictEqual(log.data.progression.totalXp, 300);
  });

  /* ---------- the token itself ---------- */
  await check("a token is stored hashed, never in plaintext", async () => {
    const D = await account("hashed");
    inbox = [];
    await api("/auth/reset/request", { method:"POST", body:{ email: D.email } });
    await new Promise(r => setTimeout(r, 60));
    const token = tokenFromInbox(D.email);
    const rows = db.prepare("SELECT token_hash FROM auth_tokens WHERE user_id=?").all(D.id);
    assert.ok(rows.length >= 1, "no token row was written");
    for(const r of rows) assert.notStrictEqual(r.token_hash, token,
      "the reset token is in the database in plaintext — a backup would be a set of working keys");
    /* And nothing else in the row holds it either. */
    const full = db.prepare("SELECT * FROM auth_tokens WHERE user_id=?").all(D.id);
    assert.ok(!JSON.stringify(full).includes(token), "the token appears somewhere in its own row");
  });

  await check("a token works once and only once", async () => {
    const E = await account("once");
    inbox = [];
    await api("/auth/reset/request", { method:"POST", body:{ email: E.email } });
    await new Promise(r => setTimeout(r, 60));
    const token = tokenFromInbox(E.email);
    assert.strictEqual((await api("/auth/reset/confirm", { method:"POST", body:{ token, password: NEWPASS } })).status, 200);
    const replay = await api("/auth/reset/confirm", { method:"POST", body:{ token, password: "yet-another-long-one" } });
    assert.strictEqual(replay.status, 400, "a used reset token worked a second time");
    assert.strictEqual((await api("/auth/session", { method:"POST", body:{ email: E.email, password: "yet-another-long-one" } })).status, 401,
      "the replayed token changed the password anyway");
  });

  await check("asking again invalidates the link that was already sent", async () => {
    const F = await account("reissue");
    inbox = [];
    await api("/auth/reset/request", { method:"POST", body:{ email: F.email } });
    await new Promise(r => setTimeout(r, 60));
    const first = tokenFromInbox(F.email);
    inbox = [];
    await api("/auth/reset/request", { method:"POST", body:{ email: F.email } });
    await new Promise(r => setTimeout(r, 60));
    const second = tokenFromInbox(F.email);
    assert.notStrictEqual(first, second, "the same token was reissued");
    assert.strictEqual((await api("/auth/reset/confirm", { method:"POST", body:{ token: first, password: NEWPASS } })).status, 400,
      "the abandoned link still works — three clicks would mean three live keys");
    assert.strictEqual((await api("/auth/reset/confirm", { method:"POST", body:{ token: second, password: NEWPASS } })).status, 200);
  });

  await check("an expired token is refused", async () => {
    const G = await account("expired");
    inbox = [];
    await api("/auth/reset/request", { method:"POST", body:{ email: G.email } });
    await new Promise(r => setTimeout(r, 60));
    const token = tokenFromInbox(G.email);
    db.prepare("UPDATE auth_tokens SET expires_at=? WHERE user_id=?").run(Date.now() - 1000, G.id);
    assert.strictEqual((await api("/auth/reset/confirm", { method:"POST", body:{ token, password: NEWPASS } })).status, 400,
      "an expired reset link still worked");
  });

  await check("a guessed or malformed token gets nowhere", async () => {
    for(const t of ["", "x", "null", "a".repeat(64), "../../etc/passwd", null, 12345, {}]){
      const r = await api("/auth/reset/confirm", { method:"POST", body:{ token: t, password: NEWPASS } });
      assert.strictEqual(r.status, 400, `token ${JSON.stringify(t)} was not refused`);
    }
  });

  await check("a weak new password is refused, as it is at registration", async () => {
    const H = await account("weakpass");
    inbox = [];
    await api("/auth/reset/request", { method:"POST", body:{ email: H.email } });
    await new Promise(r => setTimeout(r, 60));
    const token = tokenFromInbox(H.email);
    const r = await api("/auth/reset/confirm", { method:"POST", body:{ token, password: "short" } });
    assert.strictEqual(r.status, 400, "a weak password was accepted on reset");
    /* And the token must survive, or a typo would burn the student's one link. */
    assert.strictEqual((await api("/auth/reset/confirm", { method:"POST", body:{ token, password: NEWPASS } })).status, 200,
      "a rejected weak password consumed the reset link");
  });

  /* ---------- enumeration ---------- */
  await check("the endpoint answers identically for a real and an unknown address", async () => {
    const I = await account("known");
    inbox = [];
    const real = await api("/auth/reset/request", { method:"POST", body:{ email: I.email } });
    const fake = await api("/auth/reset/request", { method:"POST", body:{ email: "nobody-here-at-all@example.com" } });
    assert.strictEqual(real.status, fake.status, "the status code differs between a real and an unknown address");
    assert.deepStrictEqual(real.data, fake.data,
      "the response body differs between a real and an unknown address — that is an account list for anyone who wants one");
  });

  await check("being throttled looks exactly like succeeding", async () => {
    const J = await account("throttled");
    inbox = [];
    const seen = [];
    for(let i = 0; i < 5; i++){
      const r = await api("/auth/reset/request", { method:"POST", body:{ email: J.email } });
      seen.push(JSON.stringify({ s: r.status, d: r.data }));
    }
    await new Promise(r => setTimeout(r, 80));
    assert.strictEqual(new Set(seen).size, 1, "the response changed once the throttle engaged: " + [...new Set(seen)].join(" | "));
    const delivered = inbox.filter(m => m.to === J.email).length;
    assert.ok(delivered <= 3, `${delivered} messages were sent to one address — that is a way to flood a student's inbox`);
    assert.ok(delivered >= 1, "the throttle blocked even the first request");
  });

  /* ---------- verification ---------- */
  await check("email verification is recorded, and a completed reset counts as proof", async () => {
    const K = await account("verify");
    const before = db.prepare("SELECT email_verified_at FROM users WHERE id=?").get(K.id);
    assert.strictEqual(before.email_verified_at, null, "a fresh account is marked verified");

    inbox = [];
    await api("/auth/verify/request", { method:"POST", token: K.token });
    await new Promise(r => setTimeout(r, 60));
    const m = [...inbox].reverse().find(x => x.to === K.email);
    const token = (/code into ASCEND: (\S+)/.exec(m.text) || /verify=([^\s"']+)/.exec(m.text) || [])[1];
    assert.ok(token, "no verification code was delivered");
    assert.strictEqual((await api("/auth/verify/confirm", { method:"POST", body:{ token } })).status, 200);
    const after = db.prepare("SELECT email_verified_at FROM users WHERE id=?").get(K.id);
    assert.ok(after.email_verified_at > 0, "verification was not recorded");
  });

  await check("verification cannot be requested for somebody else", async () => {
    const r = await api("/auth/verify/request", { method:"POST" });
    assert.strictEqual(r.status, 401, "an unauthenticated caller could trigger a verification email");
  });

  server.close();
  mailbox.close();

  /* ---------- with no transport configured ---------- */
  await check("with no mail transport, recovery says so instead of pretending", async () => {
    /* A fresh process-level config: the point is the default, and the default is
       what a first deployment will be running. */
    const { execFileSync } = require("node:child_process");
    const script = `
      process.env.APP_ENV="test"; process.env.SESSION_PEPPER="p"; process.env.RATE_LIMIT_MAX="500";
      delete process.env.MAIL_TRANSPORT; delete process.env.MAIL_WEBHOOK_URL;
      const dbmod=require("./server/src/db"); const {createServer}=require("./server/src/server");
      const db=dbmod.open(":memory:"); dbmod.migrate(db); const s=createServer(db);
      s.listen(0,"127.0.0.1", async () => {
        const b="http://127.0.0.1:"+s.address().port;
        const r=await fetch(b+"/auth/reset/request",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({email:"x@example.com"})});
        console.log(JSON.stringify({status:r.status, body:await r.json()}));
        s.close(); process.exit(0);
      });`;
    const out = execFileSync(process.execPath, ["-e", script], { encoding:"utf8", stdio:["ignore","pipe","ignore"] });
    const res = JSON.parse(out.trim().split("\n").pop());
    assert.strictEqual(res.status, 503, "recovery reported success with no way to send anything");
    assert.ok(/not available/i.test(res.body.error),
      "the message does not tell the student recovery is off: " + JSON.stringify(res.body));
  });

  console.log("\nASCEND — password reset and email verification\n");
  console.log(results.join("\n"));
  if(errors.length){ console.log(`\n${errors.length} of ${results.length} checks failed\n`); process.exit(1); }
  console.log(`\nall ${results.length} checks passed\n`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
