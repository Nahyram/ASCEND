/* ASCEND — build.js
   Compiles system/src/*.js (ES modules) into system/bundle.js (a classic script).

   ## Why a build step, and why the output is committed

   ASCEND's central promise is that it works with no server and no connection.
   `system/index.html` opens from a file:// path today, and a build step that had
   to run before the app would start would quietly end that. So the bundle is
   committed alongside the source: a student, a school, or anyone who downloads
   the folder gets a working app with no toolchain, and only someone changing the
   source needs Node.

   A committed build artefact drifts — that is not a risk, it is a certainty, and
   this project has already shipped it twice. The service worker's precache list
   drifted 20 modules behind index.html and broke the app offline for three
   releases; the version drifted across five files, and again into package-lock
   during 18.7. Both were fixed the same way and this is fixed the same way:
   `module-check.js` rebuilds from source and fails if the committed bundle does
   not match byte for byte.

   ## Why not minified

   The output is readable and diffable on purpose. A minified blob in the diff is
   a blob nobody reviews, and this codebase's own history is a list of things that
   shipped because nobody could see them. Roughly 100 KB of legible JavaScript
   also compresses to about the same as a minified one over the wire; the cost is
   disk, which is not what a student on a data bundle is paying for.

   Run: npm run build        (npm run build:check to verify without writing) */
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const esbuild = require("esbuild");

const ROOT = process.env.ROOT || "./system";
const ENTRY = path.join(ROOT, "src", "entry.js");
const OUT = path.join(ROOT, "bundle.js");
const checkOnly = process.argv.includes("--check");

const BANNER = `/* ASCEND — bundle.js — GENERATED FILE, DO NOT EDIT.

   Built from system/src/ by build.js. Edit the modules there and run:

       npm run build

   Committed so that index.html opens with no toolchain. module-check.js fails
   the suite if this file and system/src/ disagree, so it cannot silently drift
   the way the precache list and the version string both did. */`;

async function build() {
  const result = await esbuild.build({
    entryPoints: [ENTRY],
    bundle: true,
    /* iife, not esm: the output is loaded by a plain <script src> so that the
       jsdom suites can keep injecting it, and so index.html keeps working from
       file:// where module scripts are blocked by CORS. */
    format: "iife",
    /* Matches the browsers a mid-range Android phone in Ghana actually runs. */
    target: ["es2020"],
    minify: false,
    banner: { js: BANNER },
    /* Deterministic output — the drift check compares bytes. */
    charset: "utf8",
    legalComments: "none",
    write: false,
    logLevel: "silent",
  });
  return result.outputFiles[0].text;
}

build().then(text => {
  const existing = fs.existsSync(OUT) ? fs.readFileSync(OUT, "utf8") : null;

  if (checkOnly) {
    if (existing === text) { console.log("bundle.js matches system/src — no drift"); return; }
    console.error(existing === null
      ? "bundle.js is missing. Run: npm run build"
      : "bundle.js does not match system/src. Run: npm run build");
    process.exit(1);
  }

  if (existing === text) { console.log("bundle.js already current  ·  " + text.length + " bytes"); return; }
  fs.writeFileSync(OUT, text);
  console.log("bundle.js written  ·  " + text.length + " bytes  ·  from " + ENTRY);
}).catch(e => { console.error(e.message || e); process.exit(1); });
