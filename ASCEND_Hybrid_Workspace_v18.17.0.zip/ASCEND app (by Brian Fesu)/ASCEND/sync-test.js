/* ASCEND 18.7 — sync-test.js
   The frontend and the backend, introduced.

   ## Why this file exists

   v18.6 shipped a complete server and a complete client that had never spoken to
   each other. Both halves were tested: server-test.js drove the API over a real
   socket, brain-test.js drove the sync engine against the in-memory loopback
   driver, and both suites were green. Nothing tested the seam, because there was
   no seam — cloud.js carried a comment describing the REST adapter instead of
   containing one.

   That is the failure mode this project keeps producing: two implementations of
   the same idea that agree with themselves and never meet. Six duplicate-global
   defects, an entitlement rule declared and enforced nowhere, a Wi-Fi-only switch
   read by no code. So the adapter does not ship until something runs it.

   ## What this does

   Boots the REAL backend on a real socket against a temporary database, boots the
   REAL frontend in jsdom (every script index.html loads, in order), points the
   real `rest` driver at the real server, and then behaves like two students'
   devices sharing one account.

   Nothing is mocked except the OpenAI provider, for the same reasons
   server-test.js gives: this container cannot reach api.openai.com, and a suite
   that spends money on every run is a suite people stop running.

   ## jsdom and fetch

   jsdom has no fetch, so Node's is installed on the window — along with Node's
   AbortController, because undici rejects a signal from a foreign realm and the
   failure looks like a network error rather than a type error. */
"use strict";

process.env.APP_ENV = "test";
process.env.DATABASE_PATH = ":memory:";
process.env.SESSION_PEPPER = "test-pepper-not-a-real-secret";
process.env.CORS_ORIGINS = "https://local.test";
process.env.AI_DAILY_LIMIT = "3";
process.env.RATE_LIMIT_MAX = "5000";

const assert = require("node:assert");
const fs = require("fs");
const path = require("path");
const nodeCrypto = require("crypto");
const { JSDOM, VirtualConsole } = require("jsdom");

const dbmod = require("./server/src/db");
const { createServer } = require("./server/src/server");

const ROOT = "./system";
const PASSWORD = "correct-horse-battery";

const results = [], errors = [];
async function check(label, fn){
  try{ await fn(); results.push("  PASS  " + label); }
  catch(e){ results.push("  FAIL  " + label + " — " + e.message); errors.push(label + ": " + e.message); }
}
/* A capability the build does not have is a failed check, not a crashed run. */
function need(S, ...names){
  for(const n of names) if(typeof S[n] !== "function" && typeof S[n] !== "object")
    throw new Error("this build has no " + n + "()");
}

/* ---------- the real backend ---------- */
const db = dbmod.open(":memory:");
dbmod.migrate(db);
const server = createServer(db);
let BASE = null;

/* ---------- a device ----------
   One jsdom window running the whole application, booted far enough to have a
   hunter — cloud() reads H(), so an app with no hunter has no cloud record. The
   boot path is the app's own: click through registration and onboarding exactly
   as harness.js does, rather than fabricating a hunter object this test invented
   and the app has never seen. */
async function boot(name){
  const vc = new VirtualConsole();
  const noise = [];
  vc.on("jsdomError", e => noise.push("JSDOM: " + (e.message || e)));
  vc.on("error", (...a) => noise.push("console.error: " + a.join(" ")));

  const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
  const dom = new JSDOM(html, {
    runScripts: "dangerously", url: "https://local.test/",
    virtualConsole: vc, pretendToBeVisual: true,
  });
  const w = dom.window, d = w.document;

  /* shims jsdom lacks — same set as harness.js, plus the network.

     window.crypto is getter-only in jsdom 30, so it is defined rather than
     assigned. harness.js assigns to it in sloppy mode, where the write fails
     silently; under "use strict" the same line throws, which is how this was
     noticed. */
  const cryptoStub = {
    getRandomValues: a => { nodeCrypto.randomFillSync(Buffer.from(a.buffer, a.byteOffset, a.byteLength)); return a; },
    subtle: { importKey: async () => ({}), deriveBits: async () => new Uint8Array(32).buffer, digest: async () => new Uint8Array(32).buffer, deriveKey: async () => ({}), encrypt: async () => new Uint8Array(16).buffer, decrypt: async () => new Uint8Array(16).buffer },
    randomUUID: () => nodeCrypto.randomUUID(),
  };
  Object.defineProperty(w, "crypto", { value: cryptoStub, configurable: true, writable: true });
  w.matchMedia = w.matchMedia || (q => ({ matches:false, media:q, addEventListener(){}, removeEventListener(){}, addListener(){}, removeListener(){} }));
  w.scrollTo = () => {};
  w.HTMLElement.prototype.scrollIntoView = () => {};
  w.AudioContext = function(){ return { createGain:()=>({connect(){},gain:{value:0,setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}}}), createOscillator:()=>({connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}},type:""}), createBufferSource:()=>({connect(){},start(){},stop(){},buffer:null,loop:false}), createBuffer:()=>({getChannelData:()=>new Float32Array(1000)}), createBiquadFilter:()=>({connect(){},frequency:{value:0},type:"",Q:{value:0}}), destination:{}, sampleRate:44100, currentTime:0, close(){}, resume(){} }; };
  w.indexedDB = undefined;
  /* Node's, not jsdom's: undici type-checks the signal against its own realm. */
  w.fetch = (...a) => fetch(...a);
  w.AbortController = AbortController;
  w.AbortSignal = AbortSignal;

  for(const s of [...d.querySelectorAll("script[src]")].map(x => x.getAttribute("src"))){
    const p = path.join(ROOT, s);
    if(!fs.existsSync(p)) throw new Error("missing script " + s);
    const el = d.createElement("script");
    el.textContent = fs.readFileSync(p, "utf8");
    d.body.appendChild(el);
  }

  await new Promise(r => setTimeout(r, 1600));
  d.getElementById("scr-login").classList.remove("hidden");
  d.getElementById("btnNewHunter").click();
  d.getElementById("regName").value = name;
  d.getElementById("regTitle").value = "The Verifier";
  d.getElementById("regGo").click();
  d.querySelector('#obWorkout .chip[data-w="calisthenics"]').click();
  for(const n of ["2","3","4"]) d.querySelectorAll("[data-next]").forEach(b => { if(b.dataset.next === n) b.click(); });
  await new Promise(r => setTimeout(r, 50));
  d.getElementById("obFinish").click();
  await new Promise(r => setTimeout(r, 400));

  /* One bridge script, so the test reaches the app's real globals rather than a
     copy of them.

     Each name is guarded with typeof. A bare object literal listing them would
     throw a ReferenceError on the first name a build does not have, `window.__S`
     would never be assigned, and 21 checks would collapse into one unreadable
     "cannot read properties of undefined". Run against v18.6 — which has none of
     the rest adapter — the guarded version reports which capability is missing,
     check by check, which is what a regression suite is for. */
  const BRIDGE = ["H","save","cloud","signIn","signOut","syncNow","markChanged","pendingChanges",
    "setCloudDriver","cloudDriver","cloudApiBase","cloudApiProblem","cloudHealth","gateStatus",
    "refreshEntitlements","entitlement","deleteCloudData","cloudSettings","restFetch","AI",
    "AI_PROVIDERS","buildPayload","applyPayload","syncLog","Log","grantXp","requestPasswordReset","confirmPasswordReset"];
  const bridge = d.createElement("script");
  bridge.textContent = "window.__S = {" +
    BRIDGE.map(n => `${n}: (typeof ${n} === "undefined" ? undefined : ${n})`).join(", ") + "};";
  d.body.appendChild(bridge);
  return { w, d, S: w.__S, noise };
}

(async () => {
  await new Promise(r => server.listen(0, "127.0.0.1", r));
  BASE = `http://127.0.0.1:${server.address().port}`;

  const A = await boot("Device A");
  const email = `hunter-${Date.now()}@example.com`;

  /* ---------- configuration ---------- */
  await check("an http address that is not localhost is refused, with the reason", () => {
    need(A.S, "cloudApiProblem");
    const why = A.S.cloudApiProblem("http://ascend.example.com");
    assert.ok(why && /https/i.test(why), "expected an https warning, got: " + why);
    assert.strictEqual(A.S.cloudApiProblem("https://ascend.example.com"), null);
    assert.strictEqual(A.S.cloudApiProblem(BASE), null, "loopback over http must be allowed");
  });

  await check("health is read from the real server before an address is accepted", async () => {
    need(A.S, "cloudHealth");
    const h = await A.S.cloudHealth(BASE);
    assert.ok(h.ok, "health check failed: " + h.text);
    assert.strictEqual(h.health.service, "ascend");
    const bad = await A.S.cloudHealth("https://127.0.0.1:1/");
    assert.ok(!bad.ok, "an unreachable address must not report ok");
  });

  await check("the address is stored and the rest driver selected", () => {
    need(A.S, "cloudApiBase", "setCloudDriver");
    A.S.cloudApiBase(BASE);
    A.S.setCloudDriver("rest");
    assert.strictEqual(A.S.cloudApiBase(), BASE);
    assert.strictEqual(A.S.cloudDriver().name, "rest");
  });

  /* ---------- account ---------- */
  await check("register and sign in through the real driver returns a session", async () => {
    need(A.S, "signIn", "cloud");
    const acct = await A.S.signIn({ email, password: PASSWORD, register: true, displayName: "Device A" });
    assert.ok(acct, "sign-in returned null: " + (A.S.gateStatus() || {}).lastError);
    const c = A.S.cloud();
    assert.ok(c.token, "no token stored");
    assert.strictEqual(c.mode, "account");
    assert.ok(c.account.id, "no account id");
  });

  await check("a wrong password fails without disturbing local data or the session", async () => {
    need(A.S, "signIn");
    const before = A.S.H().level;
    const B2 = await A.S.signIn({ email, password: "wrong-password-entirely" });
    assert.strictEqual(B2, null, "a wrong password must not sign in");
    assert.strictEqual(A.S.H().level, before, "local record changed on a failed sign-in");
  });

  await check("no password is stored anywhere on the hunter record", () => {
    need(A.S, "cloudApiBase");
    A.S.cloudApiBase(BASE); A.S.setCloudDriver("rest");
    const dump = JSON.stringify(A.S.H());
    assert.ok(!dump.includes(PASSWORD), "the password is in the local record");
    assert.ok(!dump.includes("wrong-password-entirely"), "a rejected password is in the local record");
  });

  /* re-establish the session the wrong-password check cleared */
  if(typeof A.S.signIn === "function") await A.S.signIn({ email, password: PASSWORD, displayName: "Device A" });

  /* ---------- the round trip ---------- */
  await check("local progress is queued at sign-in rather than replaced by an empty server record", async () => {
    need(A.S, "syncNow", "markChanged");
    const h = A.S.H();
    h.totalXp = 4200; h.level = 12;
    A.S.save();
    A.S.markChanged("progress", "test");
    assert.ok(A.S.pendingChanges().length > 0, "nothing queued");
    const r = await A.S.syncNow({ force:true });
    assert.ok(r.ok, "sync failed: " + JSON.stringify(r));
    assert.strictEqual(A.S.H().totalXp, 4200, "the empty server record overwrote local progress");
    assert.strictEqual(A.S.pendingChanges().length, 0, "the queue was not cleared");
  });

  await check("the payload actually reached the database, and carries no token", () => {
    need(A.S, "cloud");
    if(!A.S.cloud().account) throw new Error("no account was established");
    const row = db.prepare("SELECT rev, payload FROM records WHERE user_id=?").get(A.S.cloud().account.id);
    assert.ok(row, "no record row");
    assert.ok(row.rev >= 1, "revision did not advance");
    const stored = JSON.parse(row.payload);
    assert.strictEqual(stored.progress.totalXp, 4200);
    /* A sync payload that carried the session token would put a credential in
       every backup and every export. buildPayload() names its fields, so this
       is a guard against someone later making it generic. */
    assert.ok(!row.payload.includes(A.S.cloud().token), "the session token is inside the synced payload");
    assert.ok(!row.payload.includes(PASSWORD), "the password is inside the synced payload");
  });

  /* ---------- a second device ---------- */
  const B = await boot("Device B");
  await check("a second device signing into the same account pulls the first device's work", async () => {
    need(B.S, "cloudApiBase");
    B.S.cloudApiBase(BASE); B.S.setCloudDriver("rest");
    const acct = await B.S.signIn({ email, password: PASSWORD, displayName: "Device B" });
    assert.ok(acct, "device B could not sign in: " + (B.S.gateStatus() || {}).lastError);
    const r = await B.S.syncNow({ force:true });
    assert.ok(r.ok, "device B sync failed: " + JSON.stringify(r));
    assert.strictEqual(B.S.H().totalXp, 4200, "device B did not receive device A's progress");
  });

  await check("two devices editing different quests on the same day is a merge, not a conflict", async () => {
    need(A.S, "syncNow"); need(B.S, "syncNow");
    const today = B.S.H().__today || null;
    const ha = A.S.H(), hb = B.S.H();
    ha.done = ha.done || {}; hb.done = hb.done || {};
    ha.done["2026-01-01"] = { ...(ha.done["2026-01-01"] || {}), "quest-a": true };
    hb.done["2026-01-01"] = { ...(hb.done["2026-01-01"] || {}), "quest-b": true };
    A.S.save(); B.S.save();
    A.S.markChanged("progress", "A ticks a quest");
    B.S.markChanged("progress", "B ticks a different quest");

    const ra = await A.S.syncNow({ force:true });
    assert.ok(ra.ok, "A failed: " + JSON.stringify(ra));
    const rb = await B.S.syncNow({ force:true });
    assert.ok(rb.ok, "B failed: " + JSON.stringify(rb));

    const merged = B.S.H().done["2026-01-01"];
    assert.ok(merged["quest-a"], "A's tick was lost");
    assert.ok(merged["quest-b"], "B's tick was lost");
    void today;
  });

  await check("a stale push is answered with a real 409 and settled by re-merging", async () => {
    need(A.S, "syncNow"); need(B.S, "cloud");
    if(!B.S.cloud().account) throw new Error("no account was established");
    /* Force the race: A pushes while B still holds an old revision. B's own
       engine must recover without B's student noticing. */
    const ha = A.S.H(); ha.totalXp = 9001; A.S.save(); A.S.markChanged("progress", "A moves ahead");
    await A.S.syncNow({ force:true });

    const c = B.S.cloud();
    c.serverRev = 0;                                  /* B is now stale by construction */
    const hb = B.S.H(); hb.streak = 33; B.S.save();
    B.S.markChanged("progress", "B moves too");

    const rb = await B.S.syncNow({ force:true });
    assert.ok(rb.ok, "B could not settle the conflict: " + JSON.stringify(rb));
    const row = db.prepare("SELECT payload FROM records WHERE user_id=?").get(c.account.id);
    const stored = JSON.parse(row.payload);
    assert.strictEqual(stored.progress.totalXp, 9001, "A's higher total was lost in the merge");
    assert.strictEqual(stored.progress.streak, 33, "B's change was lost in the merge");
  });

  /* ---------- isolation ---------- */
  await check("a second account cannot read the first account's record through the driver", async () => {
    need(A.S, "restFetch");
    const other = `intruder-${Date.now()}@example.com`;
    const C = B;                                       /* reuse the window, swap the account */
    const mine = C.S.cloud().account.id;
    await C.S.signOut();
    await C.S.signIn({ email: other, password: PASSWORD, register: true, displayName: "Intruder" });
    let status = 0;
    try{ await C.S.restFetch("/records/" + mine); }
    catch(e){ status = e.status; }
    assert.strictEqual(status, 403, "expected 403, got " + status);
  });

  /* ---------- entitlements ---------- */
  await check("entitlements come from the server once signed in, not from the browser", async () => {
    need(A.S, "refreshEntitlements", "entitlement");
    const before = A.S.entitlement("CLOUD_SYNC");
    assert.ok(["server","local"].includes(before.source));
    const me = await A.S.refreshEntitlements();
    assert.ok(me && me.entitlements, "/me returned no entitlements");
    assert.strictEqual(A.S.entitlement("CLOUD_SYNC").source, "server");

    /* The server's answer must win even when it says no. */
    db.prepare("INSERT INTO entitlements (user_id, key, allowed, source) VALUES (?,?,?,?) " +
               "ON CONFLICT(user_id, key) DO UPDATE SET allowed=excluded.allowed")
      .run(A.S.cloud().account.id, "ADVANCED_TUTOR", 0, "test");
    await A.S.refreshEntitlements();
    const after = A.S.entitlement("ADVANCED_TUTOR");
    assert.strictEqual(after.allowed, false, "a server refusal was overridden by the client");
    assert.strictEqual(after.source, "server");
  });

  /* ---------- sessions ---------- */
  await check("a session revoked on the server signs this device out without touching local data", async () => {
    need(A.S, "cloud", "syncNow");
    const c = A.S.cloud();
    if(!c.account) throw new Error("no account was established");
    const xp = A.S.H().totalXp;
    db.prepare("UPDATE sessions SET revoked_at=? WHERE user_id=?").run(Date.now(), c.account.id);
    const r = await A.S.syncNow({ force:true });
    assert.ok(!r.ok, "sync succeeded with a revoked session");
    assert.strictEqual(A.S.cloud().token, null, "the dead token was kept");
    assert.strictEqual(A.S.cloud().mode, "local", "the app did not fall back to local mode");
    assert.strictEqual(A.S.H().totalXp, xp, "local progress was lost when the session ended");
    assert.ok(/session/i.test(A.S.cloud().lastError || ""), "no explanation was recorded");
  });

  await check("signing out revokes the session on the server, not just in the tab", async () => {
    const C = await boot("Device C");
    need(C.S, "cloudApiBase");
    C.S.cloudApiBase(BASE); C.S.setCloudDriver("rest");
    const mail = `signout-${Date.now()}@example.com`;
    await C.S.signIn({ email: mail, password: PASSWORD, register: true, displayName: "Device C" });
    const token = C.S.cloud().token;
    await C.S.signOut();
    const res = await fetch(BASE + "/me", { headers: { authorization: "Bearer " + token } });
    assert.strictEqual(res.status, 401, "the token still works after signing out");
    C.w.close();
  });

  /* ---------- the Wi-Fi-only switch ---------- */
  await check("Wi-Fi only actually suppresses a sync on a metered connection", async () => {
    const D = await boot("Device D");
    need(D.S, "cloudApiBase", "cloudSettings");
    D.S.cloudApiBase(BASE); D.S.setCloudDriver("rest");
    const mail = `metered-${Date.now()}@example.com`;
    await D.S.signIn({ email: mail, password: PASSWORD, register: true, displayName: "Device D" });
    await D.S.syncNow({ force:true });

    Object.defineProperty(D.w.navigator, "connection", { value: { type:"cellular" }, configurable: true });
    D.S.cloudSettings({ wifiOnly: true });
    D.S.markChanged("progress", "on mobile data");
    const blocked = await D.S.syncNow();
    assert.strictEqual(blocked.reason, "metered", "sync ran on cellular with Wi-Fi-only set");
    assert.ok(D.S.pendingChanges().length > 0, "the change was dropped rather than held");

    Object.defineProperty(D.w.navigator, "connection", { value: { type:"wifi" }, configurable: true });
    const allowed = await D.S.syncNow();
    assert.ok(allowed.ok, "sync did not resume on Wi-Fi: " + JSON.stringify(allowed));
    D.w.close();
  });

  /* ---------- AI routing ---------- */
  await check("a signed-in device routes the tutor to the ASCEND server, not to a provider", async () => {
    const E = await boot("Device E");
    need(E.S, "cloudApiBase");
    if(!E.S.AI_PROVIDERS.ascend) throw new Error("this build has no ascend AI provider");
    E.S.cloudApiBase(BASE); E.S.setCloudDriver("rest");
    /* Before signing in there is no server provider available. */
    assert.ok(!E.S.AI_PROVIDERS.ascend.available(), "the server provider claimed to be available while signed out");
    const mail = `tutor-${Date.now()}@example.com`;
    await E.S.signIn({ email: mail, password: PASSWORD, register: true, displayName: "Device E" });
    assert.ok(E.S.AI_PROVIDERS.ascend.available(), "the server provider is not available while signed in");
    assert.strictEqual(E.S.AI.provider.name, "ascend", "the server is not the preferred provider");

    /* The server has no OPENAI_API_KEY in this environment, so the call fails —
       and the point of the check is that failing costs the student nothing. */
    const res = await E.S.AI.ask("tutor", {
      system: "Teach this.",
      messages: [{ role:"user", content:"Explain the discriminant." }],
      context: { subject:"Maths", curriculum:"IGCSE", level:12 },
      local: () => "LOCAL ANSWER",
    });
    assert.strictEqual(res.source, "local", "expected the local answer when the gateway cannot answer");
    assert.strictEqual(res.text, "LOCAL ANSWER");
    assert.ok(res.note, "no explanation was given for falling back");
    E.w.close();
  });

  await check("the browser never holds an OpenAI key and never calls OpenAI", () => {
    /* The architectural claim, checked against what actually ships to a browser
       rather than against intent. */
    const files = [];
    (function walk(dir){
      for(const f of fs.readdirSync(dir, { withFileTypes:true })){
        const full = path.join(dir, f.name);
        if(f.isDirectory()) walk(full);
        else if(/\.(js|html|json)$/.test(f.name)) files.push(full);
      }
    })(ROOT);
    for(const f of files){
      const src = fs.readFileSync(f, "utf8");
      assert.ok(!/api\.openai\.com/.test(src), `${f} references api.openai.com`);
      assert.ok(!/OPENAI_API_KEY/.test(src), `${f} references OPENAI_API_KEY`);
      assert.ok(!/\bsk-[A-Za-z0-9_-]{20,}/.test(src), `${f} contains a key-shaped string`);
    }
  });

  /* ---------- the event log, end to end ---------- */
  await check("a signed-in device pushes its event log and the server agrees with it", async () => {
    const L = await boot("Device L");
    need(L.S, "cloudApiBase");
    L.S.cloudApiBase(BASE); L.S.setCloudDriver("rest");
    const mail = `log-${Date.now()}@example.com`;
    await L.S.signIn({ email: mail, password: PASSWORD, register: true, displayName: "Device L" });

    /* Real XP through the app's own funnel, so the events are the ones a
       student would actually generate. */
    for(let i = 0; i < 12; i++) L.w.grantXp(30, "quest cleared");
    const local = L.w.Log.progression();
    assert.ok(local.totalXp > 0, "no XP was granted locally");

    const r = await L.w.syncLog();
    assert.ok(r.ok, "syncLog failed: " + JSON.stringify(r));
    assert.ok(r.accepted > 0, "no events reached the server");
    assert.strictEqual(r.agrees, true,
      "the server disagreed with the client over the same events: " + JSON.stringify(L.S.cloud().progressionDiffs));
    assert.strictEqual(r.progression.totalXp, local.totalXp,
      `server ${r.progression.totalXp} vs client ${local.totalXp}`);

    /* The acknowledgement is what lets the client compact later. Without it a
       long offline stretch would be folded away before the server saw it. */
    assert.ok(L.w.Log.acked() >= r.accepted, "the client did not record the acknowledgement");

    const row = db.prepare("SELECT COUNT(*) AS n FROM events WHERE user_id=?").get(L.S.cloud().account.id);
    assert.ok(row.n >= 12, `only ${row.n} events reached the database`);
    L.w.close();
  });

  await check("a second device pulls the first device's events and lands on the same total", async () => {
    const M = await boot("Device M");
    need(M.S, "cloudApiBase");
    M.S.cloudApiBase(BASE); M.S.setCloudDriver("rest");
    const mail = `two-${Date.now()}@example.com`;
    const pw = PASSWORD;
    await M.S.signIn({ email: mail, password: pw, register: true, displayName: "Device M" });
    for(let i = 0; i < 8; i++) M.w.grantXp(40, "quest cleared");
    await M.w.syncLog();
    const firstTotal = M.w.Log.progression().totalXp;

    const N = await boot("Device N");
    N.S.cloudApiBase(BASE); N.S.setCloudDriver("rest");
    await N.S.signIn({ email: mail, password: pw, displayName: "Device N" });
    const r = await N.w.syncLog();
    assert.ok(r.ok, "the second device could not sync: " + JSON.stringify(r));
    assert.strictEqual(N.w.Log.progression().totalXp, firstTotal,
      `device N replayed ${N.w.Log.progression().totalXp} against device M's ${firstTotal}`);
    M.w.close(); N.w.close();
  });

  /* ---------- recovery, through the real client ---------- */
  await check("a student who forgets their password can get back in from the Gate", async () => {
    const R = await boot("Device R");
    need(R.S, "cloudApiBase");
    if(typeof R.w.requestPasswordReset !== "function") throw new Error("this build has no requestPasswordReset()");
    R.S.cloudApiBase(BASE); R.S.setCloudDriver("rest");
    const mail = `forgot-${Date.now()}@example.com`;
    await R.S.signIn({ email: mail, password: PASSWORD, register: true, displayName: "Device R" });

    /* Work that must survive the reset. */
    const h = R.S.H(); h.totalXp = 3131; R.S.save();
    R.S.markChanged("progress", "before the reset");
    await R.S.syncNow({ force:true });
    const accountId = R.S.cloud().account.id;

    /* This server has no mail transport in the sync-test environment, so the
       honest answer is the 503 — and the client must surface it rather than
       telling the student to check an inbox nothing was sent to. */
    const req = await R.w.requestPasswordReset(mail);
    assert.strictEqual(req.ok, false, "the client reported success on a server that cannot send email");
    assert.ok(/not available/i.test(req.error), "the message does not explain why: " + req.error);

    /* With the token issued directly — this suite is testing the client half,
       and server-side issuance has its own suite. */
    const recovery = require("./server/src/recovery");
    const token = recovery.issue(db, accountId, "reset", null);
    const done = await R.w.confirmPasswordReset(token, "a-brand-new-long-passphrase");
    assert.ok(done.ok, "the reset failed: " + done.error);

    /* The dead token must be dropped locally, and nothing local may be lost. */
    assert.strictEqual(R.S.cloud().token, null, "the app kept a session the server just revoked");
    assert.strictEqual(R.S.H().totalXp, 3131, "a password reset lost local progress");

    const back = await R.S.signIn({ email: mail, password: "a-brand-new-long-passphrase" });
    assert.ok(back, "could not sign in with the new password");
    const row = db.prepare("SELECT payload FROM records WHERE user_id=?").get(accountId);
    assert.strictEqual(JSON.parse(row.payload).progress.totalXp, 3131,
      "the synced record did not survive the reset");
    R.w.close();
  });

  /* ---------- CORS ---------- */
  await check("an origin outside the allow-list is refused, and the configured one is not", async () => {
    const bad = await fetch(BASE + "/me", { headers: { origin: "https://evil.example.com" } });
    assert.strictEqual(bad.status, 403, "a foreign origin was not refused");
    const ok = await fetch(BASE + "/me", { headers: { origin: "https://local.test" } });
    assert.strictEqual(ok.status, 401, "the configured origin should reach auth, not CORS");
    assert.strictEqual(ok.headers.get("access-control-allow-origin"), "https://local.test");
  });

  /* ---------- deletion ---------- */
  await check("deleting cloud data clears the server copy and leaves the device intact", async () => {
    const F = await boot("Device F");
    need(F.S, "cloudApiBase");
    F.S.cloudApiBase(BASE); F.S.setCloudDriver("rest");
    const mail = `delete-${Date.now()}@example.com`;
    await F.S.signIn({ email: mail, password: PASSWORD, register: true, displayName: "Device F" });
    const h = F.S.H(); h.totalXp = 777; F.S.save();
    F.S.markChanged("progress", "before deletion");
    await F.S.syncNow({ force:true });

    const id = F.S.cloud().account.id;
    assert.ok(await F.S.deleteCloudData(), "deleteCloudData reported failure");
    const row = db.prepare("SELECT rev, payload FROM records WHERE user_id=?").get(id);
    assert.strictEqual(row.payload, "null", "the server copy survived deletion");
    assert.strictEqual(F.S.H().totalXp, 777, "deleting the cloud copy deleted the local one");
    F.w.close();
  });

  /* ---------- offline ---------- */
  await check("with the network down the app keeps working and holds the change", async () => {
    const G = await boot("Device G");
    need(G.S, "cloudApiBase");
    G.S.cloudApiBase(BASE); G.S.setCloudDriver("rest");
    const mail = `offline-${Date.now()}@example.com`;
    await G.S.signIn({ email: mail, password: PASSWORD, register: true, displayName: "Device G" });
    await G.S.syncNow({ force:true });

    Object.defineProperty(G.w.navigator, "onLine", { value: false, configurable: true });
    const h = G.S.H(); h.totalXp = 1234; G.S.save();
    G.S.markChanged("progress", "worked on the bus");
    const r = await G.S.syncNow({ force:true });
    assert.strictEqual(r.reason, "offline");
    assert.strictEqual(G.S.H().totalXp, 1234, "the offline edit was lost");
    assert.ok(G.S.pendingChanges().length > 0, "the offline change was not queued");

    Object.defineProperty(G.w.navigator, "onLine", { value: true, configurable: true });
    const back = await G.S.syncNow({ force:true });
    assert.ok(back.ok, "sync did not resume: " + JSON.stringify(back));
    const row = db.prepare("SELECT payload FROM records WHERE user_id=?").get(G.S.cloud().account.id);
    assert.strictEqual(JSON.parse(row.payload).progress.totalXp, 1234, "the queued change never arrived");
    G.w.close();
  });

  A.w.close(); B.w.close();
  server.close();
  try{ db.close(); }catch(e){}

  console.log("\nASCEND — client ↔ server integration\n");
  console.log(results.join("\n"));
  if(errors.length){
    console.log(`\n${errors.length} of ${results.length} checks failed\n`);
    process.exit(1);
  }
  console.log(`\nall ${results.length} checks passed\n`);
  /* Explicit, like harness.js and brain-test.js. The app installs its own
     intervals — transmissions, the sync heartbeat — and jsdom keeps the event
     loop alive on them even after close(). Without this the suite prints a
     clean result and then hangs, which reads as a failure. */
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
