/* ASCEND — server-replay-test.js
   The server replaying the client's log, over a real socket.

   ## What is being decided here

   18.10 proved that the same events give the same state in two runtimes. That is
   necessary and not sufficient: it says nothing about whether the server can tell
   a real total from an invented one, and nothing about whether two devices that
   have never met converge.

   This suite runs the real backend against a temporary database and drives the
   real endpoints. Every check below is a claim the v19 architecture makes and
   would otherwise be making on trust.

   ## The claim that must NOT hold

   "A client ahead of the server is cheating." It is not, and a design that
   treated it that way would be unusable in Ghana, where being ahead of the
   server is the normal state of a school connection. There is a check for that
   specifically, because getting it wrong in the punishing direction costs an
   honest student their year. */
"use strict";

process.env.APP_ENV = "test";
process.env.DATABASE_PATH = ":memory:";
process.env.SESSION_PEPPER = "test-pepper-not-a-real-secret";
process.env.RATE_LIMIT_MAX = "5000";

const assert = require("node:assert");
const path = require("node:path");

const dbmod = require("./server/src/db");
const { createServer } = require("./server/src/server");

const PASSWORD = "correct-horse-battery";
const results = [], errors = [];
async function check(label, fn){
  try{ await fn(); results.push("  PASS  " + label); }
  catch(e){ results.push("  FAIL  " + label + " — " + e.message); errors.push(label); }
}

const db = dbmod.open(":memory:");
dbmod.migrate(db);
const server = createServer(db);
let BASE = null;

async function api(pathname, { method = "GET", body, token } = {}){
  const headers = { accept: "application/json" };
  if(body !== undefined) headers["content-type"] = "application/json";
  if(token) headers.authorization = "Bearer " + token;
  const res = await fetch(BASE + pathname, { method, headers,
    body: body === undefined ? undefined : JSON.stringify(body) });
  let data = null;
  try{ data = await res.json(); }catch(e){}
  return { status: res.status, data };
}

async function account(label){
  const email = `${label}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}@example.com`;
  await api("/auth/register", { method: "POST", body: { email, password: PASSWORD, displayName: label } });
  const s = await api("/auth/session", { method: "POST", body: { email, password: PASSWORD, device: label } });
  return { email, token: s.data.token, id: s.data.id };
}

(async () => {
  const Ev = await import(path.resolve("./shared/events.js"));
  const P = await import(path.resolve("./shared/domain/progression.js"));

  const ev = (device, seq, ts, n) => Ev.makeEvent({ type: "XP_GRANTED", data: { n }, ts, device, seq });
  const run = (device, count, from = 0, xp = 40) =>
    Array.from({ length: count }, (_, i) => ev(device, from + i, 1_700_000_000_000 + (from + i) * 1000, xp));

  await new Promise(r => server.listen(0, "127.0.0.1", r));
  BASE = `http://127.0.0.1:${server.address().port}`;

  const A = await account("phone");

  await check("the server replays a submitted log and returns the same state the client computes", async () => {
    const events = run("phone", 120);
    const claim = P.replayProgression(Ev.canonical(events));
    const r = await api(`/records/${A.id}/events`, { method: "POST", token: A.token, body: { events, claim } });
    assert.strictEqual(r.status, 200, JSON.stringify(r.data));
    assert.strictEqual(r.data.accepted, 120, "not every event was stored");
    assert.strictEqual(r.data.checked, true, "the server did not check the claim");
    assert.strictEqual(r.data.agrees, true, "server and client disagreed: " + JSON.stringify(r.data.diffs));
    for(const k of ["xp", "level", "totalXp"])
      assert.strictEqual(r.data.progression[k], claim[k], `${k} differed`);
    assert.ok(claim.level > 5, "the fixture was too small to be meaningful");
  });

  await check("submitting the same batch again changes nothing", async () => {
    const events = run("phone", 120);
    const before = await api(`/records/${A.id}/events`, { token: A.token });
    const r = await api(`/records/${A.id}/events`, { method: "POST", token: A.token, body: { events } });
    assert.strictEqual(r.data.accepted, 0, "a resend created new events");
    assert.strictEqual(r.data.duplicates, 120);
    assert.strictEqual(r.data.progression.totalXp, before.data.progression.totalXp,
      "a retried sync changed the total");
  });

  await check("an inflated claim is caught, and nothing is taken away", async () => {
    const honest = await api(`/records/${A.id}/events`, { token: A.token });
    const lie = { ...honest.data.progression, level: 99, totalXp: 999999 };
    const r = await api(`/records/${A.id}/events`, { method: "POST", token: A.token,
      body: { events: [], claim: lie } });
    assert.strictEqual(r.data.agrees, false, "the server believed a level-99 claim");
    assert.ok(r.data.diffs.some(d => d.field === "level"), "the level difference was not reported");
    /* The point of the design: detection without punishment. */
    assert.strictEqual(r.data.progression.totalXp, honest.data.progression.totalXp,
      "the server changed the real total in response to a false claim");
    const after = await api(`/records/${A.id}/events`, { token: A.token });
    assert.strictEqual(after.data.progression.level, honest.data.progression.level,
      "the stored progression moved");
  });

  await check("the divergence is recorded for later, not acted on now", () => {
    const row = db.prepare("SELECT COUNT(*) AS n FROM audit_events WHERE user_id=? AND kind='events.divergence'").get(A.id);
    assert.ok(row.n >= 1, "no audit entry was written for the mismatch");
  });

  await check("a client ahead of the server is not treated as cheating", async () => {
    /* The normal case on a school connection: the phone has worked offline and
       holds events the server has never seen. It claims a total that includes
       them, and submits them in the same request — so after ingestion the two
       agree. Nothing about being ahead is suspicious. */
    const extra = run("phone", 40, 120, 55);
    const all = Ev.merge(run("phone", 120), extra);
    const claim = P.replayProgression(all);
    const r = await api(`/records/${A.id}/events`, { method: "POST", token: A.token,
      body: { events: extra, claim } });
    assert.strictEqual(r.data.agrees, true,
      "a client that synced its offline work was reported as divergent: " + JSON.stringify(r.data.diffs));
    assert.strictEqual(r.data.accepted, 40);
  });

  await check("two devices that never met converge on the same history", async () => {
    const B = await account("laptop");
    const phone = run("d-phone", 30, 0, 30);
    const laptop = run("d-laptop", 30, 0, 30);

    await api(`/records/${B.id}/events`, { method: "POST", token: B.token, body: { events: phone } });
    const laptopSees = await api(`/records/${B.id}/events?since=0`, { token: B.token });
    await api(`/records/${B.id}/events`, { method: "POST", token: B.token, body: { events: laptop } });

    const server1 = await api(`/records/${B.id}/events`, { token: B.token });
    const bothSides = P.replayProgression(Ev.merge(phone, laptop));

    assert.strictEqual(laptopSees.data.events.length, 30, "the cursor did not hand over the other device's work");
    for(const k of ["xp", "level", "totalXp", "grants"])
      assert.strictEqual(server1.data.progression[k], bothSides[k],
        `${k}: server ${server1.data.progression[k]} vs merged ${bothSides[k]}`);
  });

  await check("the cursor returns only what a device has not seen", async () => {
    const C = await account("cursor");
    await api(`/records/${C.id}/events`, { method: "POST", token: C.token, body: { events: run("c1", 10) } });
    const first = await api(`/records/${C.id}/events?since=0`, { token: C.token });
    assert.strictEqual(first.data.events.length, 10);
    const caughtUp = await api(`/records/${C.id}/events?since=${first.data.cursor}`, { token: C.token });
    assert.strictEqual(caughtUp.data.events.length, 0, "the cursor replayed events already seen");
    await api(`/records/${C.id}/events`, { method: "POST", token: C.token, body: { events: run("c2", 5) } });
    const more = await api(`/records/${C.id}/events?since=${first.data.cursor}`, { token: C.token });
    assert.strictEqual(more.data.events.length, 5, "new events were not returned after the cursor");
  });

  await check("hostile events are rejected without corrupting the account", async () => {
    const D = await account("hostile");
    const good = run("h1", 5);
    const honest = P.replayProgression(Ev.canonical(good));
    const evil = [
      { id: "somebody-elses-id", device: "h1", seq: 900, ts: 1, type: "XP_GRANTED", data: { n: 5000 } },
      { id: "h1:901", device: "h1", seq: 901, ts: 2, type: "XP_GRANTED", data: { n: "1e400" } },
      { id: "h1:902", device: "h1", seq: 902, ts: 3, type: "XP_GRANTED", data: { big: "x".repeat(5000) } },
      { id: "h1:903", device: "h1", seq: 903, ts: 4, type: "XP_GRANTED", data: { n: -99999 } },
    ];
    const r = await api(`/records/${D.id}/events`, { method: "POST", token: D.token,
      body: { events: [...good, ...evil] } });
    assert.strictEqual(r.status, 200);
    assert.ok(r.data.rejected >= 2, "malformed events were stored rather than rejected: " + JSON.stringify(r.data));
    assert.strictEqual(r.data.progression.totalXp, honest.totalXp,
      "hostile input changed the total: " + JSON.stringify(r.data.progression));
    assert.ok(Number.isFinite(r.data.progression.level) && r.data.progression.level >= 1);
  });

  await check("an id that does not match its device and seq is refused", async () => {
    const E = await account("spoof");
    const r = await api(`/records/${E.id}/events`, { method: "POST", token: E.token, body: { events: [
      { id: "victim:1", device: "attacker", seq: 1, ts: 1, type: "XP_GRANTED", data: { n: 10 } },
    ] } });
    assert.strictEqual(r.data.accepted, 0, "an event whose id lies about its origin was stored");
    assert.ok(r.data.rejected >= 1);
  });

  await check("one account cannot read or write another's event log", async () => {
    const F = await account("intruder");
    const read = await api(`/records/${A.id}/events`, { token: F.token });
    assert.strictEqual(read.status, 403, "another account read the log");
    const write = await api(`/records/${A.id}/events`, { method: "POST", token: F.token,
      body: { events: run("evil", 5, 0, 10000) } });
    assert.strictEqual(write.status, 403, "another account wrote to the log");
  });

  await check("an oversized batch is refused rather than half-applied", async () => {
    const G = await account("batch");
    const r = await api(`/records/${G.id}/events`, { method: "POST", token: G.token,
      body: { events: run("g", 2500) } });
    assert.strictEqual(r.status, 413, "a 2500-event batch was accepted");
    const after = await api(`/records/${G.id}/events`, { token: G.token });
    assert.strictEqual(after.data.events.length, 0, "part of the refused batch was stored");
  });

  await check("deleting cloud data deletes the event log too", async () => {
    const H = await account("delete");
    await api(`/records/${H.id}/events`, { method: "POST", token: H.token, body: { events: run("h", 20) } });
    const before = await api(`/records/${H.id}/events`, { token: H.token });
    assert.ok(before.data.events.length === 20);
    await api(`/records/${H.id}`, { method: "DELETE", token: H.token });
    const after = await api(`/records/${H.id}/events`, { token: H.token });
    assert.strictEqual(after.data.events.length, 0,
      "a full event history survived 'delete my cloud data', which makes that button a lie");
    assert.strictEqual(after.data.progression.totalXp, 0);
  });

  await check("a compaction base is accepted once and never advanced by the server", async () => {
    const I = await account("base");
    /* A phone that worked a long time offline, compacted, and is now syncing. */
    await api(`/records/${I.id}/events`, { method: "POST", token: I.token,
      body: { events: run("i", 10, 0, 20), base: { xp: 0, level: 3, totalXp: 500, grants: 12 } } });
    const first = await api(`/records/${I.id}/events`, { token: I.token });
    assert.strictEqual(first.data.progression.totalXp, 500 + 200, "the base was not counted");

    /* A second, larger base must not stack on top — that would inflate the total
       every time a client compacted again. */
    await api(`/records/${I.id}/events`, { method: "POST", token: I.token,
      body: { events: [], base: { xp: 0, level: 20, totalXp: 90000, grants: 900 } } });
    const second = await api(`/records/${I.id}/events`, { token: I.token });
    assert.strictEqual(second.data.progression.totalXp, first.data.progression.totalXp,
      "a second base was applied on top of the first");
  });

  /* ---------- the client-side invariant the whole thing rests on ---------- */
  await check("the client cannot compact away events the server has not acknowledged", async () => {
    const fs = require("node:fs");
    const src = fs.readFileSync("./system/src/core/log.js", "utf8");
    assert.ok(/log\.acked/.test(src), "core/log.js has no acknowledgement watermark");
    const fn = (src.match(/function compact\(log\)[\s\S]*?\n  \}/) || [])[0] || "";
    assert.ok(/Math\.min\([^)]*acked/.test(fn),
      "compact() does not clamp to the acknowledged watermark — a term of offline work could be folded away " +
      "before the server ever saw it, and the server would then look like it was taking XP back");
  });

  server.close();
  console.log("\nASCEND — the server replaying the log\n");
  console.log(results.join("\n"));
  if(errors.length){ console.log(`\n${errors.length} of ${results.length} checks failed\n`); process.exit(1); }
  console.log(`\nall ${results.length} checks passed\n`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
