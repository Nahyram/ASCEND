/* THE SYSTEM v18 — syntax-check.js
   `node --check` over every JavaScript file the project ships or tests with.

   This exists because of a defect from the v15 era: a <script> that fails to
   *parse* never runs, and in a classic-script app that is silent. The page
   still loads, the globals from that file are simply absent, and the first
   symptom is a feature that quietly stopped working. A parse error should be
   caught by a command, not by a student.

   It also checks that every script index.html loads actually exists on disk,
   which is the other half of the same failure. */
"use strict";

const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const ROOT = process.env.ROOT || "./system";
let failed = 0, checked = 0;

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.name === "node_modules" || e.name === ".git") continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.name.endsWith(".js")) out.push(p);
  }
  return out;
}

console.log("syntax-check — node --check over every .js file\n");

/* Every JS file in the project: the app, the service worker, and the suites. */
const files = [...walk(ROOT), ...fs.readdirSync(".").filter(f => f.endsWith(".js")).map(f => "./" + f)];

for (const f of files) {
  checked++;
  try {
    execFileSync(process.execPath, ["--check", f], { stdio: "pipe" });
  } catch (err) {
    failed++;
    console.log("  FAIL  " + f);
    console.log("        " + String(err.stderr || err.message).split("\n").slice(0, 4).join("\n        "));
  }
}

/* Half of a parse failure is a file that is not there at all. */
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const refs = [
  ...[...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]),
  ...[...html.matchAll(/<link[^>]+href="([^"]+\.css)"/g)].map(m => m[1]),
  /* Images were never in this list, so the page could reference artwork that was
     not there and nothing said so until a student saw a broken tile. */
  ...[...html.matchAll(/<img[^>]+src="([^"]+)"/g)].map(m => m[1]),
  ...[...html.matchAll(/<link[^>]+rel="(?:icon|apple-touch-icon)"[^>]+href="([^"]+)"/g)].map(m => m[1]),
];
const missing = refs.filter(r => !/^(https?:|data:)/.test(r) && !fs.existsSync(path.join(ROOT, r)));
if (missing.length) {
  failed += missing.length;
  for (const m of missing) console.log("  FAIL  index.html references a file that does not exist: " + m);
}

/* ---------- icons ----------

   Through 18.7 the manifest was the only place icons were declared. That is
   enough for Chrome on Android and enough for nothing else: iOS does not read
   manifest icons for Add to Home Screen — it reads apple-touch-icon, and with
   none present it installs a screenshot of the page. The mark existed, shipped,
   was precached, and never appeared on an iPhone home screen or in a browser tab.

   A missing icon has no error, no console warning and no failing test. It is
   only visible to someone who installs the app on the right device, which is why
   it survived a release. So it is asserted here. */
function pngSize(file){
  /* PNG IHDR: 8-byte signature, 4-byte length, "IHDR", then width and height as
     big-endian uint32. No dependency needed to ask an image how big it is. */
  const b = fs.readFileSync(file);
  if (b.length < 24 || b.toString("ascii", 12, 16) !== "IHDR") return null;
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}

function iconCheck(label, fn) {
  let problem;
  try { problem = fn(); } catch (e) { problem = e.message; }
  if (problem) { failed++; console.log("  FAIL  " + label + " — " + problem); }
}

iconCheck("index.html declares a favicon", () =>
  /<link[^>]+rel="icon"/.test(html) ? null : "no <link rel=\"icon\"> — the tab and every bookmark show a blank square");

iconCheck("index.html declares an apple-touch-icon", () =>
  /<link[^>]+rel="apple-touch-icon"/.test(html) ? null
    : "no <link rel=\"apple-touch-icon\"> — iOS ignores the manifest icons and installs a screenshot of the page instead of the mark");

iconCheck("every icon the manifest declares exists at the size it claims", () => {
  const man = JSON.parse(fs.readFileSync(path.join(ROOT, "manifest.json"), "utf8"));
  const bad = [];
  for (const i of man.icons || []) {
    const abs = path.join(ROOT, i.src);
    if (!fs.existsSync(abs)) { bad.push(i.src + " is missing"); continue; }
    const [w, h] = String(i.sizes || "").split("x").map(Number);
    const real = pngSize(abs);
    if (real && w && (real.w !== w || real.h !== h))
      bad.push(`${i.src} declares ${i.sizes} but is ${real.w}x${real.h}`);
  }
  return bad.length ? bad.join("; ") : null;
});

iconCheck("a maskable icon is declared, and it is not the same file as the plain one", () => {
  const man = JSON.parse(fs.readFileSync(path.join(ROOT, "manifest.json"), "utf8"));
  const mask = (man.icons || []).filter(i => /maskable/.test(i.purpose || ""));
  if (!mask.length) return "no maskable icon — Android crops the plain icon and cuts the mark";
  const plain = (man.icons || []).filter(i => !/maskable/.test(i.purpose || "")).map(i => i.src);
  const shared = mask.filter(m => plain.includes(m.src)).map(m => m.src);
  /* Reusing one file for both is the common shortcut and it always loses: a
     maskable source needs a safe zone the plain one does not have. */
  return shared.length ? "the same file is used as both plain and maskable: " + shared.join(", ") : null;
});

/* ---------- precache payload ----------

   assets/ascend-lockup.webp was in the precache list from v18 and referenced by
   nothing: 43 KB downloaded to every device, on the first load, to render
   nowhere. Bytes in the precache are bytes a student on a data bundle pays for,
   so an entry that nothing points at is a bug rather than an oversight. */
const swSrc = fs.readFileSync(path.join(ROOT, "sw.js"), "utf8");
const precached = [...swSrc.matchAll(/"\.\/([^"]+\.(?:png|jpg|jpeg|webp|svg))"/g)].map(m => m[1]);
if (precached.length) {
  const haystack = [html, fs.readFileSync(path.join(ROOT, "manifest.json"), "utf8"),
    ...walk(ROOT).filter(f => /\.(js|css)$/.test(f) && !/sw\.js$/.test(f)).map(f => fs.readFileSync(f, "utf8")),
  ].join("\n");
  const orphans = precached.filter(a => !haystack.includes(a));
  if (orphans.length) {
    failed += orphans.length;
    for (const o of orphans)
      console.log("  FAIL  precached but referenced nowhere, so it is downloaded and never shown: " + o);
  }
}

console.log(`\n  ${checked} JS files parsed · ${refs.length} page assets resolved · ${precached.length} precached images traced · ${failed} failure(s)`);
if (failed) { console.log("\nsyntax-check FAILED"); process.exit(1); }
console.log("\nsyntax-check clean");
