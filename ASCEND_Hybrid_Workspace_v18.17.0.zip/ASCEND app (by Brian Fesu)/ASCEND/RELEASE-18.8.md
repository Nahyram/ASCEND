# ASCEND 18.8 — step 1 of v19: ES modules, leaf-first

The module conversion has been the top outstanding item for six releases. It
starts here, and it starts small on purpose.

---

## What changed

**Fourteen files are now real ES modules** with explicit exports, under
`system/src/`:

```
src/core/     bus.js  hooks.js  store.js
src/content/  balance.js  library.js  screen.js  tools.js  careers.js
src/app/      version.js  theme.js
src/          lore.js  data.js  data-v11.js  skills.js
```

These were chosen because they are the graph's true leaves — measured, not
guessed. Every one of them depends on nothing else in the app, so converting them
cannot reorder anything.

**A build step**, `npm run build`, compiles `system/src/entry.js` into
`system/bundle.js` with esbuild. `index.html` loads the bundle first and then the
75 scripts that have not been converted.

**Classic scripts: 89 → 76. Top-level global names: 756 → 718.**

---

## Three decisions worth knowing

**The bundle is committed.** ASCEND's promise is that it works with no server and
no connection, and `index.html` opens from a `file://` path today. A build step
that had to run before the app would start would quietly end that. Committing the
output means a student, a school, or anyone who downloads the folder gets a
working app with no toolchain; only someone editing the source needs Node.

**It is not minified.** A minified blob in a diff is a blob nobody reviews, and
this codebase's history is a list of things that shipped because nobody could see
them. Legible JavaScript compresses to roughly the same size over the wire; the
cost is disk, which is not what a student on a data bundle is paying for.

**The output is IIFE, not ESM.** A `<script type="module">` is blocked by CORS on
`file://`, and the jsdom suites work by injecting script text — neither survives
native modules. A classic bundle keeps both.

---

## The bridge, and why it is designed to shrink

`src/entry.js` republishes 32 module exports onto `window` so the unconverted
classic scripts still resolve `BALANCE`, `Store`, `Hooks` and the rest as bare
globals. That is exactly the pattern this migration exists to remove, and a
temporary measure with no expiry is just an architecture.

So `module-check.js` fails the suite if a bridged name is **not** referenced by
any remaining classic script. When a consumer converts, its import becomes
explicit and the name comes off the list. **The migration is finished when the
bridge is empty.**

---

## `module-check.js` — 9 checks

1. `bundle.js` is what `src/` compiles to — rebuilt and compared byte for byte
2. `index.html` loads the bundle, not the module source
3. classic-script count has not gone up (ceiling 76, was 89)
4. converted-module count has not gone down (floor 15)
5. every file under `src/` exports something
6. the bridge can be read out of the shipped bundle
7. the bridge has not grown (ceiling 32)
8. **no name is bridged that nothing still needs**
9. only `entry.js` writes to global scope

The ceilings are literals a person edits, not values computed from the build. A
check that measures the build and compares it to itself always passes; the point
is to make going backwards require a decision.

Drift is the real target. This project has shipped a stale generated file twice —
the precache list drifted 20 modules behind `index.html` and broke the app
offline for three releases, and the version drifted across four files and then
into `package-lock` during 18.7. A generated file nobody regenerates is a
generated file that lies.

---

## Two things the new checks caught immediately

**`THEMES` was bridged and used by nothing.** My own scan for which leaf names the
classic scripts still needed had an over-escaped regex — `(?<![\\w$.])` where I
meant `(?<![\w$.])` — so the character class held a literal backslash instead of
the word-character shorthand, and `PREMIUM_THEMES` matched a search for `THEMES`.
Check 8 found it on its first run.

**A mutation test nearly recorded a false pass.** Appending an unused export to a
module left the bundle byte-identical, because esbuild tree-shook it — correct
behaviour, and a useless mutation. Changing a value that reaches the output does
fail the drift check, which is what was actually verified.

---

## Also fixed

Four suites hard-coded paths of files that moved. They now resolve through a
shared `appFile()` that checks `src/` first, so the next conversion pass does not
silently turn an assertion into a false pass — `offline-test`, `hooks-test`,
`brain-test`, `release-test`, and `sync-version.js`, which had begun reporting
`missing: app/version.js`.

`hooks-test` evaluates `core/hooks.js` in a bare vm context to test the registry
in isolation, so it now strips the export statement first. Isolation is the point
of that suite: a failure there must point at the registry, not at whatever it
happened to be loaded beside.

The `THE SYSTEM v13/v14` headers were rewritten to ASCEND on the fourteen files
this pass touched — the rename folded into work already happening, rather than a
separate sweep that re-churns every file a second time.

---

## Verification

**13 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra. Both `module-check` guards were mutation-tested.

---

## What is next, in order

2. **One store, one owner.** localStorage plus the two ad-hoc IndexedDB stores in
   `online.js` and `armory.js` behind a single async interface. Async is the
   forcing function: 186 synchronous `save()` call sites cannot survive it, which
   is what finally kills the 86 direct `h.x =` writes across 31 files.
3. **Event log and deterministic replay.**
4. **The server replays** and becomes the record of truth for what it should be.
5. **The next-action engine** — a deterministic scorer. The AI explains the
   choice; it never makes it.

The remaining conversion continues underneath those, one layer at a time: the
next tranche is whatever becomes a leaf once these fourteen are out of the graph.

Still unblocked by any of this, and still yours: **password reset**, the **host
decision**, and the **data-protection position** for 13–18 year olds.
