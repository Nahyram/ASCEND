# ASCEND 18.7 — the client meets the server

*(18.7.1 adds the icon fixes at the end of this file.)*

18.6 built a backend. 18.7 connects to it.

That gap was the whole point of this release, and it is worth being precise about
what it was: 18.6 shipped a complete server and a complete client that had never
spoken to each other. Both were tested. `server-test.js` drove the API over a real
socket; `brain-test.js` drove the sync engine against the in-memory `loopback`
driver. Both suites were green. `services/cloud.js` carried a *comment* describing
the REST adapter it did not contain, and no suite could notice, because every
suite tested one side.

---

## What now works

**Accounts on a real server.** `CloudDrivers.rest` implements the contract that
was previously only documented: register, sign in, pull, push, wipe, sign out,
`/me`. The 409 conflict response returns the same shape as `loopback`, so one
merge engine serves both drivers rather than two that drift apart.

**Sync across devices.** Sign in on a second device and the first device's work
arrives. Two devices ticking different quests on the same day is a union merge,
not a conflict. A stale push gets a real 409 and is settled by re-merging against
what is actually on the server.

**The AI tutor routes through your server.** `browser → ASCEND → OpenAI → back.`
The new `ascend` provider in `services/ai.js` is listed first, so a signed-in
student uses it and a self-hosted worker becomes the fallback. The browser holds
no key and never contacts a provider — checked mechanically against every file
that ships to a browser, not asserted.

The client deliberately **cannot** set the system prompt. The server composes it
from a fixed set of modes and the client's capability name selects one. A client
that could supply the system prompt could talk the model out of every rule in it,
which is the usual way a "secure proxy" turns out not to be one. The caller's own
instruction rides along as user-side text instead.

**Conversation history.** The gateway previously took a single prompt and
discarded everything before it, so "explain that again, simpler" arrived with no
referent and the model answered a different question than the student asked.
History is now accepted on the server's terms: eight turns, two roles, 2000
characters each, none of it enlargeable by a client.

**Entitlements come from the server.** `/me` is the authority. A server refusal
is honoured; the browser cannot grant itself anything.

**Server address is a setting, not a constant.** One build serves your server, a
school's, or a student's own. The Gate checks `/health` before accepting an
address and refuses `http://` unless it is localhost — over http the session
token travels in clear text on the school Wi-Fi and the student cannot tell.

---

## Two defects found and fixed

Both had shipped in 18.6. Both were found by the new suite on its first run,
which is the argument for the suite existing.

**`wifiOnly` was enforced nowhere.** It had been a switch in the Gate since v14,
read by the view and by no other code. A student could set "Wi-Fi only" and still
be synced over a data bundle. Same class as the entitlement rule v18 found with
no call sites, and the same fix: ask at the point where it costs money.

The metered check returns three answers, and the third is the point — `true`,
`false`, and `null` for "the browser will not say". Only Chromium exposes
`connection.type`. Where the answer is unknown, sync proceeds: a switch that
silently stopped syncing on every iPhone would be a worse failure than one that
occasionally syncs on cellular. The Gate shows which of the three it got.

**A dead session reported the wrong thing.** `syncNow`'s generic catch overwrote
the explanation ("your session ended, everything on this device is untouched")
with the server's `Authentication required.` — accurate and useless. It also
scheduled exponential backoff retries on a token that could never work, spending
data to fail on a timer.

---

## A third place the version drifted

`release-test.js` caught 18.7 with a lockfile still saying 18.6.0. `npm version`
updates it; a hand-edit of `package.json` does not. `sync-version.js` now owns
`package-lock.json` too, for the reason its own header already gave: a fifth file
holding the version is one entry in that table, not one more thing to remember.

---

## Verification

`sync-test.js` — 21 checks. Boots the real backend on a real socket against a
temporary database, boots the real frontend in jsdom (every script `index.html`
loads, in order), and behaves like two students' devices sharing one account.

* **18 of 21 fail against 18.6.** The three that pass there are guard checks that
  were already true (no key in the browser, CORS, local-first conversion).
* Both defect fixes are **mutation-pinned**: reverting the `wifiOnly` gate and the
  401 branch fails exactly those two checks and no others.
* Its bridge into the page guards every global with `typeof`. A bare object
  literal throws on the first missing name and collapses 21 checks into one
  unreadable error; guarded, it reports which capability is missing, check by
  check.

Full suite: **12 suites, all green**, in UTC, America/New_York, Asia/Tokyo and
Africa/Accra, from a clean `npm ci`.

---

## Still not built

Named rather than half-built, because a half-built version of any of these is
worse than the gap.

**Push notifications.** Needs VAPID keys, a subscription table, a delivery
service, and a decision about pushing to 13–18 year olds' devices. That is a
design conversation, not a patch.

**Curriculum delivery from the server.** The server can already hold and version
content; nothing serves it yet, and the client has no update path for it.

**Live information** (scholarships, competitions, deadlines). `services/api.js`
and `services/opportunities.js` exist and ship no listings. Serving these means
the server fetches and *validates* them, and validation is the hard half —
a stale deadline shown as current is worse than no deadline.

**Email verification and password reset.** A forgotten password today means a new
account. The Gate says so before a student sets one, which is the minimum honest
handling, not a solution.

**Multi-instance rate limiting.** The limiter is per-process. Running two
instances needs a shared store, and `DEPLOYMENT.md` says so plainly rather than
letting someone discover it by being limited incorrectly.

---

## Still yours to decide

Unchanged from 18.6, and all of it still blocking a real deployment:

1. **Revoke every OpenAI key pasted into chat** — three now. Do this first.
2. **Choose a host** with a persistent disk (~$3–7/month). SQLite is a file;
   a host with an ephemeral filesystem discards every account on each deploy.
3. `SESSION_PEPPER`, a fresh key in the host's secret manager, an OpenAI spending
   cap, `CORS_ORIGINS`, the frontend's host, backups.
4. **Your data-protection position** for students who may be 13–18: controller,
   retention, parental deletion, and whether Ghana's Data Protection Act
   registration applies to you.

`DEPLOYMENT.md` PART 1 is the checklist.


---

# 18.7.1 — the mark was shipping and not displaying

The artwork was already in the build and byte-identical to the supplied files.
It was the *declarations* that were missing.

**iOS installed a screenshot instead of the app icon.** `index.html` declared no
icons at all — the manifest was the only place they were listed. That is enough
for Chrome on Android and enough for nothing else: iOS does not read manifest
icons for Add to Home Screen. It reads `apple-touch-icon`, and finding none, it
uses a snapshot of the page. Every browser tab and bookmark showed a blank square
for the same reason.

Two icons are now generated from the maskable master and declared:

* `apple-touch-icon.png` (180×180). Built from the **maskable** rather than the
  plain 512, because the plain one has rounded corners baked in and iOS applies
  its own squircle on top — the corners double-round. The maskable's Android safe
  zone leaves the mark at 53% width, which reads as small on a home screen, so it
  is centre-cropped to 78%: mark at ~68%, margin at 14%, inside what the squircle
  trims.
* `icon-32.png` (2 KB). A 32px favicon has no room for a safe zone, so it is
  cropped harder. A 200 KB PNG as a tab icon is a real cost on a data bundle.

**`assets/ascend-lockup.webp` was precached and rendered nowhere.** 43 KB
downloaded to every device on first load, to display nothing. It is now on the
boot and login screens — the two screens that exist before a hunter does.
`width`/`height` are on the element so the boot log does not jump when it decodes,
and it hides under 520px of height so a phone in landscape keeps the hunter list.

**Link previews** now have `og:` tags. The paths are relative, which most scrapers
resolve and the strict ones do not — make them absolute at deploy if you want a
guaranteed card. The origin is not known at build time.

## Why it survived a release

A missing icon produces no error, no console warning and no failing test. It is
visible only to someone who installs the app on the right device. So it is
asserted now, in `syntax-check.js`:

* index.html declares a favicon, and an apple-touch-icon
* every icon the manifest declares exists, at the pixel size it claims
  (PNG IHDR read directly — no dependency needed to ask an image how big it is)
* a maskable icon exists and is **not the same file** as the plain one, which is
  the usual shortcut and always loses
* nothing in the precache list is referenced nowhere — bytes in the precache are
  bytes a student pays for
* `<img src>` is resolved against disk, which it never was before

The first three checks fail against 18.7.0. The manifest-size and maskable checks
pass there — they are guards against a future mistake, not fixes — and both were
mutation-tested to confirm they catch it.
