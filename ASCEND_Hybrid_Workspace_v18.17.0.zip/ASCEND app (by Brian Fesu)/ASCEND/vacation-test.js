/* ASCEND — vacation-test.js
   Vacation mode, home quests, and application checklists.

   ## What vacation mode is actually for

   ASCEND's board is a timetable. On the first day of a long holiday the System
   starts asking for lessons that are not happening, marks them missed, docks XP
   through penalty.js and terminates a streak the student did nothing to lose.
   Ghana's school year contains three of these breaks. A product that punishes a
   student for six weeks a year for being on holiday is one they stop opening.

   ## The design claim under test

   It hooks in at ONE place — questsFor() — and everything downstream then needs
   no special case:

     · campaign quests are never mandatory, so penalty.js never fires
     · they are real quests, so the streak advances on them honestly
     · clearing one pays XP through grantXp, so the ledger, the event log and
       the server see it without knowing vacations exist

   The alternative was three special cases across the streak calculation, the
   penalty engine and the rollover. Every check below is really testing that the
   single hook was enough. */
"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");
const nodeCrypto = require("node:crypto");
const { JSDOM, VirtualConsole } = require("jsdom");

const ROOT = process.env.ROOT || "./system";
const results = [], errors = [];
async function check(label, fn) {
  try { await fn(); results.push("  PASS  " + label); }
  catch (e) { results.push("  FAIL  " + label + " — " + e.message); errors.push(label); }
}

(async () => {
  const dom = new JSDOM(fs.readFileSync(path.join(ROOT, "index.html"), "utf8"), {
    runScripts: "dangerously", url: "https://local.test/",
    virtualConsole: new VirtualConsole(), pretendToBeVisual: true,
  });
  const w = dom.window, d = w.document;
  Object.defineProperty(w, "crypto", { value: {
    getRandomValues: a => { nodeCrypto.randomFillSync(Buffer.from(a.buffer, a.byteOffset, a.byteLength)); return a; },
    subtle: { importKey: async () => ({}), deriveBits: async () => new Uint8Array(32).buffer,
      digest: async () => new Uint8Array(32).buffer, deriveKey: async () => ({}),
      encrypt: async () => new Uint8Array(16).buffer, decrypt: async () => new Uint8Array(16).buffer },
  }, configurable: true });
  w.matchMedia = q => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
  w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {};
  w.AudioContext = function () { return { createGain: () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} } }), createOscillator: () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0, setValueAtTime() {} }, type: "" }), createBufferSource: () => ({ connect() {}, start() {}, stop() {}, buffer: null, loop: false }), createBuffer: () => ({ getChannelData: () => new Float32Array(1000) }), createBiquadFilter: () => ({ connect() {}, frequency: { value: 0 }, type: "", Q: { value: 0 } }), destination: {}, sampleRate: 44100, currentTime: 0, close() {}, resume() {} }; };
  w.indexedDB = undefined;
  for (const s of [...d.querySelectorAll("script[src]")].map(x => x.getAttribute("src"))) {
    const el = d.createElement("script");
    el.textContent = fs.readFileSync(path.join(ROOT, s), "utf8");
    d.body.appendChild(el);
  }
  await new Promise(r => setTimeout(r, 1600));
  d.getElementById("scr-login").classList.remove("hidden");
  d.getElementById("btnNewHunter").click();
  d.getElementById("regName").value = "Holiday";
  d.getElementById("regTitle").value = "The Rested";
  d.getElementById("regGo").click();
  d.querySelector('#obWorkout .chip[data-w="calisthenics"]').click();
  for (const n of ["2", "3", "4"]) d.querySelectorAll("[data-next]").forEach(b => { if (b.dataset.next === n) b.click(); });
  await new Promise(r => setTimeout(r, 50));
  d.getElementById("obFinish").click();
  await new Promise(r => setTimeout(r, 400));
  const br = d.createElement("script");
  br.textContent = 'window.__V = { H, save, questsFor, startVacation, endVacation, vacationOn, vacationSummary, ' +
    'setVacationTracks, vacationQuests, VACATION_TRACKS, todayKey, renderPath, grantXp, Log, ' +
    'addOpportunity, buildChecklist, toggleChecklistItem, getOpp, renderBeyond, go };';
  d.body.appendChild(br);
  const S = w.__V;

  const dayKey = ms => new Date(ms).toISOString().slice(0, 10);
  let timetable = null;

  await check("the app ships with a timetable board before any vacation", () => {
    assert.strictEqual(typeof S.startVacation, "function", "vacation mode is not present in this build");
    timetable = S.questsFor().map(q => q.id);
    assert.ok(S.H().quests.length > 0, "the fixture has no timetable at all");
    assert.strictEqual(S.vacationOn(), false);
  });

  await check("starting a vacation replaces the board without touching the timetable", () => {
    const before = JSON.stringify(S.H().quests);
    const r = S.startVacation({ to: dayKey(Date.now() + 20 * 86400000), tracks: ["revision", "reading", "physical"] });
    assert.ok(r.ok, "could not start: " + r.why);
    assert.strictEqual(r.quests, 3);
    assert.strictEqual(S.vacationOn(), true);
    assert.strictEqual(JSON.stringify(S.H().quests), before,
      "the timetable was modified — ending the vacation could not restore it");
    const board = S.questsFor();
    assert.ok(board.length > 0, "the vacation board is empty");
    assert.ok(board.every(q => q.vacation), "a timetable quest is still on the board during a vacation");
  });

  await check("a vacation quest can never be mandatory, so no penalty can fire", () => {
    /* penalty.js only ever looks at mandatory quests. Making the campaign
       non-mandatory is what lets the penalty engine stay completely unchanged —
       there is no "is it a vacation?" branch anywhere in it. */
    assert.ok(S.vacationQuests().every(q => q.mand === false),
      "a campaign quest is mandatory — a holiday would generate penalties");
    const penalty = fs.readFileSync(path.join(ROOT, "services/penalty.js"), "utf8");
    assert.ok(!/vacation/i.test(penalty),
      "penalty.js was taught about vacations — that is the special case this design exists to avoid");
    const day = fs.readFileSync(path.join(ROOT, "services/day.js"), "utf8");
    const hooks = (day.match(/vacationOn\(\)/g) || []).length;
    assert.strictEqual(hooks, 1, `vacation is hooked into services/day.js ${hooks} times; the design claim is exactly one`);
  });

  await check("a campaign quest pays XP through the normal funnel and reaches the ledger", () => {
    const before = S.Log.progression().totalXp;
    const q = S.questsFor()[0];
    S.grantXp(q.xp, "home quest — " + q.name);
    assert.ok(S.Log.progression().totalXp > before,
      "XP earned on holiday never reached the event log");
    assert.ok(S.Log.events().some(e => /home quest/.test((e.data && e.data.why) || "")),
      "the ledger has no entry for the holiday work");
  });

  await check("vacation progression is reported separately from the year's total", () => {
    const sum = S.vacationSummary();
    assert.ok(sum, "no summary");
    assert.ok(sum.xp > 0, "no XP attributed to the vacation");
    assert.ok(sum.xp <= S.H().totalXp, "the vacation reports more XP than the hunter has ever earned");
    assert.strictEqual(sum.tracks.length, 3);
    assert.ok(sum.daysLeft >= 19 && sum.daysLeft <= 20, "days left is wrong: " + sum.daysLeft);
  });

  await check("changing the campaign keeps the work already done", () => {
    const before = S.vacationSummary();
    const kept = S.vacationQuests().find(q => q.track === "reading").id;
    const r = S.setVacationTracks(["reading", "coding"]);
    assert.ok(r.ok, r.why);
    const after = S.vacationSummary();
    assert.strictEqual(after.xp, before.xp, "changing tracks reset the vacation's progression");
    assert.strictEqual(S.vacationQuests().find(q => q.track === "reading").id, kept,
      "a track that was kept got a new quest id — its completions for today would be orphaned");
    assert.strictEqual(S.vacationQuests().length, 2);
  });

  await check("ending a vacation restores exactly the board that was there before", () => {
    S.endVacation("test");
    assert.strictEqual(S.vacationOn(), false);
    assert.deepStrictEqual(S.questsFor().map(q => q.id), timetable,
      "the timetable did not come back as it was");
  });

  await check("a vacation with a passed end date ends itself, even after months closed", () => {
    S.startVacation({ to: dayKey(Date.now() + 3 * 86400000), tracks: ["revision"] });
    assert.strictEqual(S.vacationOn(), true);
    /* The phone was shut for the whole holiday: no timer ever ran. Expiry is
       therefore checked on read, not on a schedule. */
    S.H().vacation.to = dayKey(Date.now() - 86400000);
    S.save();
    assert.strictEqual(S.vacationOn(), false, "an expired vacation was still running");
    assert.deepStrictEqual(S.questsFor().map(q => q.id), timetable,
      "the timetable did not return when the vacation expired");
  });

  await check("a vacation cannot be started with no tracks or a date in the past", () => {
    assert.strictEqual(S.startVacation({ tracks: [] }).ok, false);
    assert.strictEqual(S.startVacation({ tracks: ["reading"], to: "2020-01-01" }).ok, false);
    assert.strictEqual(S.startVacation({ tracks: ["reading"], to: "not-a-date" }).ok, false);
    assert.strictEqual(S.vacationOn(), false, "a refused start left a vacation running");
  });

  await check("the vacation panel renders and offers the tracks", () => {
    S.renderPath();
    const box = d.getElementById("pgVacation");
    assert.ok(box, "the vacation panel is not in the page");
    assert.ok(/Start a vacation/.test(box.textContent), "there is no way to start one");
    box.querySelector("#pgVacStart").click();
    const boxes = d.querySelectorAll("[data-vt]");
    assert.strictEqual(boxes.length, S.VACATION_TRACKS.length,
      `the picker offers ${boxes.length} tracks, the data defines ${S.VACATION_TRACKS.length}`);
  });

  /* ---------- application checklists ---------- */
  await check("an application checklist renders and can be ticked", () => {
    assert.strictEqual(typeof S.addOpportunity, "function", "opportunities are not present in this build");
    const o = S.addOpportunity({ name: "Mastercard Foundation Scholars", kind: "scholarship",
      deadline: dayKey(Date.now() + 30 * 86400000), url: "https://example.com/apply" });
    assert.ok(o && o.id, "the opportunity was not created");
    const items = S.buildChecklist(o.id);
    assert.ok(items.length >= 2, "the checklist is empty");

    S.go("beyond", "b-opps");
    S.renderBeyond();
    const rows = d.querySelectorAll("[data-chk]");
    assert.ok(rows.length >= 2,
      "the checklist is built and stored but nothing renders it — the student cannot see or tick the steps");

    const before = S.H().totalXp;
    const first = [...rows][0];
    first.checked = true;
    first.onchange();
    assert.strictEqual(S.getOpp(o.id).checklist.find(i => i.id === first.dataset.chkitem).done, true,
      "ticking a step did not record it");
    assert.ok(S.H().totalXp > before, "ticking an application step paid no XP");
  });

  await check("unticking and reticking a step cannot farm the XP", () => {
    const o = S.H().opportunities.items.find(x => (x.checklist || []).length);
    const item = o.checklist.find(i => i.done);
    const at = S.H().totalXp;
    for (let i = 0; i < 6; i++) S.toggleChecklistItem(o.id, item.id);
    assert.strictEqual(S.H().totalXp, at,
      "toggling a checklist item repeatedly paid XP each time — the once: guard is not holding");
  });

  dom.window.close();

  console.log("\nASCEND — vacation mode, home quests and application checklists\n");
  console.log(results.join("\n"));
  if (errors.length) { console.log(`\n${errors.length} of ${results.length} checks failed\n`); process.exit(1); }
  console.log(`\nall ${results.length} checks passed\n`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
