# ASCEND 18.9 — step 2 of v19: the record moves to IndexedDB

The store gains an IndexedDB driver, and an existing student is carried onto it
by a migration that verifies itself.

---

## What changed

**`StoreDrivers.idb`.** IndexedDB is asynchronous and the store's driver contract
is not, so the driver is a synchronous facade over an in-memory cache: hydrated
once at boot, flushed asynchronously after every write, with writes coalesced so
fifty `save()` calls in one tick become one transaction. That is what keeps the
**186 existing `save()` call sites working unchanged** — the caller sees the same
synchronous function it always did.

Driver order is `idb → local → memory`. localStorage stays, because IndexedDB is
refused in Safari private windows and some school-managed browsers, and an app
that boots empty there would be worse than one that keeps using the old backend.

**Boot is genuinely asynchronous now.** `kernel.js` re-reads the record once
`Store.hydrate()` settles and `boot-auth.js` waits on it rather than on the
1.3-second boot animation finishing first. Hydration takes tens of milliseconds,
so the animation almost always covers it — and "almost always" is exactly the
race that reaches a student and not a test.

That is only safe because **nothing outside `kernel.js` touches `DB` or `H()` at
script-load time.** I measured that across all 76 classic scripts before writing
any of this, and `store-test.js` now asserts it so it stays true.

---

## The migration, and the three rules

On the other side of this code is a student's entire record. Nothing else in the
app can destroy that in one release.

1. **Copy, never move.**
2. **Verify by reading back out of IndexedDB** — not out of the cache that was
   just written from, which would be comparing a value to itself.
3. **Do not delete the source.** Not this release, not the next one.

A migration that deletes on the strength of a successful write is trusting a
write it has never read. The localStorage copy costs about 6 KB and is the
difference between a bad release and a lost term of work. It is also what makes a
rollback survivable — and if both stores hold data, **IndexedDB wins**, because
arriving there means a rollback happened and overwriting newer work with older
work is the worst available outcome.

Two more guards worth naming:

- **A `save()` racing boot cannot write an empty record over a real one.** The
  driver refuses to flush until it is hydrated.
- **A failed write is retried, not dropped**, and the student is told. A storage
  failure nobody sees looks exactly like work that vanished.

---

## The honest cost of leaving localStorage

localStorage is synchronous and therefore cannot lose the last write. IndexedDB
can: if the tab is killed in the window between a `save()` and its flush, that
write is gone. The flush is eager rather than idle-scheduled, and `pagehide` and
`visibilitychange` force one, which turns the common cases — switching apps,
closing a tab — into flushed ones. The residual window is small. It is not zero,
and it is a second reason the localStorage copy stays.

**What this does not fix:** the whole record is still one key, so a write is
still all-or-nothing. Splitting it per domain is what actually fixes corruption
granularity, and it belongs with the event log in step 3 rather than as a second
risky change in the same release.

---

## `store-test.js` — 17 checks

Run against **fake-indexeddb**, which is a full implementation of the spec —
real transactions, cursors, key ordering and errors — not a stub. A hand-written
mock agrees with whatever the driver does, which is the failure mode this project
keeps finding.

Covered: driver selection across all three backends; that the driver reports
nothing rather than a wrong answer before hydration; the copy and its
verification; that the source survives; that a second boot does not re-migrate;
that newer IndexedDB work is never overwritten by an older local copy; the
race-at-boot guard; persistence across a new session; write coalescing; retry
after a failed write; fallback when IndexedDB throws; and the two structural
assumptions the async boot rests on.

---

## Two bugs found while building this

**I broke five cloud checks and the suite caught it.** The re-read after hydration
was unconditional. On localStorage the record is already readable at load, so
re-reading discards anything changed since — and `brain-test` builds a hunter and
syncs it inside one tick. The re-read is now conditional on the driver being
`idb`, and that condition is mutation-pinned.

**Three of my own store checks were passing by accident.** `require("fake-indexeddb")`
is a module singleton, so every case shared one set of databases and results
depended on execution order — worse than having no check. Each case now
constructs its own `FDBFactory`; the one case that deliberately models two page
loads shares a factory on purpose.

A fourth check was failing against code that was correct: it looked for the
re-read "somewhere after the first mention of `SYSTEM_READY`", and the first
mention is in a comment.

---

## Verification

**14 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra.

---

## Next, in order

3. **Event log and deterministic replay.** The keystone — it makes
   server-side progression work without breaking offline, gives per-domain
   writes, and is what the adaptive engine needs instead of a snapshot.
4. **The server replays** and becomes the record of truth for what it should be.
5. **The next-action engine** — a deterministic scorer; the AI explains the
   choice, never makes it.

Still deferred and still named: the two ad-hoc IndexedDB stores in `online.js`
and `armory.js` each open their own database with their own versioning. Folding
them into `Store` is the rest of "one store, one owner", and it was not worth
stacking onto the release that moves the student record.

Still yours, and still unblocked by any of this: **password reset**, the **host
decision**, and the **data-protection position** for 13–18 year olds.
