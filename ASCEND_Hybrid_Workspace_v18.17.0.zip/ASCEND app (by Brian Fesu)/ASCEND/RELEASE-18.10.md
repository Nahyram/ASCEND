# ASCEND 18.10 — step 3 of v19: the event log

The keystone. Everything in the v19 plan rests on one property, and this release
is about establishing it and proving it:

> **The same events produce the same state everywhere.**

If that holds, "offline-first" and "server-authoritative" stop contradicting each
other. A student levels up on a dead connection, and the server later recomputes
the identical result and can tell a real total from a tampered one. If it does
not hold, every layer built on top inherits a lie.

---

## `shared/` — one domain, two runtimes

`shared/events.js` and `shared/domain/progression.js` are imported by the browser
bundle through esbuild **and** by the Node server through dynamic import. One
file, two runtimes, byte-identical arithmetic.

`xpNeeded` moved here out of `services/progression.js`, which now reads it through
the bridge. Two copies of a level curve is two answers to "what level am I", and
the student believes whichever they saw first.

**Nothing in `shared/` may read the environment** — no clock, no randomness, no
locale, no timezone. A reducer that reads the clock replays differently than it
recorded, which silently destroys the property above. `log-test.js` parses the
directory and fails on any of them.

---

## Ordering, and why device id breaks the tie

Two devices offline at once produce events with equal or near-equal timestamps,
and clocks disagree. Order is therefore total by construction:
**timestamp, then device id, then sequence.**

Device id rather than "whichever arrived first", because arrival order differs
per device — two phones would derive two different histories from identical
events, which is exactly the bug this design exists to make impossible.

Merging two logs is concatenation plus that sort. An event id is `device:seq`, so
a retried sync or a restored backup collapses instead of double-counting. Double
-counted XP is the failure a student would notice and never forgive.

---

## Shadow mode — the log is not authoritative yet

Events are emitted alongside the existing writes, replayed in parallel, and the
two are compared by `Log.audit()`. A mismatch is **surfaced, never
auto-corrected**: silently rewriting a student's level to match a log turns one
bug into a lost term of work.

Flipping authority before the comparison agrees over real usage would repeat
18.6's mistake exactly — complete, plausible, never run against the thing it
replaces.

`grantXp` is the app's only XP funnel, which is what makes this tractable: **one
emit site, not eighty-six.**

---

## Per-hunter keys

Each hunter's log is its own Store key, so appending an event rewrites the log
rather than the entire record. This is the first thing in ASCEND that lives
outside the one `system.v1` blob, and the beginning of the fix for all-or-nothing
writes that 18.9 deliberately left open. Compaction folds events past 2,000 into a
snapshot; `log-test.js` proves compaction gives the identical answer, which is
what makes the log safely boundable.

---

## What is deliberately NOT here

**Rank.** §6 of your notes — rank is not a renamed XP level. It stays in
`services/records.js`, gated on quests cleared, a streak held, achievements and
bosses. It moves under replay once the events those depend on exist. Adding a
second rank implementation here to make the release look complete is precisely
how this project shipped five duplicate-rule collisions.

**A server endpoint.** The server imports the reducers and agreement is proven,
but nothing submits a log yet. That is step 4, where the server replays and
becomes the record of truth.

---

## `log-test.js` — 12 checks

Purity of `shared/`; total ordering under reversal and shuffling; replay
independent of arrival order; dedupe; two devices merging to one history;
compaction equivalence; replay idempotence; hostile input (NaN, `1e400`, negative,
`1e18`, unknown types) unable to corrupt the record; **the browser bundle and the
Node server replaying to identical state**; one definition of the level curve; and
a year of real usage through the app's own funnel.

The year-long fixture drives a controllable clock. Without it, a year of XP lands
inside one simulated day, the anti-farm cap correctly refuses most of it, and the
test lies about its scope.

---

## Three things worth telling you

**The ratchet from 18.8 fired, correctly.** Adding `Log` and `xpNeeded` to the
bridge tripped the ceiling, and `replayProgression` tripped "no name is bridged
that nothing still needs" — because no classic script consumes it. Exposing a
function as a compatibility shim purely so a test could reach it would have
turned that rule into a place to hide things. So there is now a second, deliberate
surface: `globalThis.ASCEND`, frozen, for things that are genuinely API rather
than migration debt. The bridge ceiling moved 32 → 34 as a recorded decision,
which is what a ceiling is for.

**A mutation test found a claim I could not support.** I had written that the log
records XP *paid* rather than XP *requested* — true by construction, since the
emit sits downstream of the anti-farm wrapper. But moving the emit upstream did
not fail any check: the year-long fixture advances the day, which resets the
ledger, so no grant was ever refused. A rule nothing exercises is a rule nothing
enforces. There is now a case that hammers a single day past the cap; under the
same mutation it fails loudly, with the log claiming 60,363 XP against a record of
41,263.

**A cross-realm comparison, not a real difference.** The client/server check
initially failed while printing two identical objects — `deepStrictEqual` compares
prototypes, and jsdom's differ from Node's. It compares field by field now.

---

## Verification

**15 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra. Purity, ordering and the paid-not-requested rule are
each mutation-pinned.

---

## Next

4. **The server replays.** Submit the log, recompute server-side, compare against
   what the client claims, and make the server the record of truth for what it
   should be — identity, entitlements and the XP total — without taking offline
   progression away from the student.
5. **The next-action engine** — a deterministic scorer over goals, mastery,
   errors, deadlines and available time. The AI explains the choice; it never
   makes it.

Then the remaining domains move onto the log one at a time: quests, mastery,
achievements, rank.

Still yours: **password reset**, the **host decision**, and the
**data-protection position** for 13–18 year olds.
