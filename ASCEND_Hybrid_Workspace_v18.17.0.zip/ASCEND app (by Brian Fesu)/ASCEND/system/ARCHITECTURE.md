# THE SYSTEM v13 — architecture

This document is for whoever works on the code next, including future you.
The v12 feature README still ships alongside it and still describes what the app
*does*. This one describes how it is put together.

---

## What changed from v12, in one paragraph

v12 was one 4,242-line `index.html` holding 600 lines of CSS, 790 lines of markup
and 2,833 lines of JavaScript, plus six sibling scripts. v13 is a 907-line shell
plus 31 extracted JS modules, 6 stylesheets, and 8 new modules written for this
version. **No feature logic was retyped.** The split was performed by script and
asserted byte-identical against the original before anything new was added, so a
feature cannot have been silently dropped in transit. The information architecture
was reorganised, a dashboard and an analytics view were added, and the browser's
grey `alert`/`confirm`/`prompt` boxes were replaced throughout.

---

## Folder layout

```
system/
├── index.html              shell only — screens, section skeletons, script order
├── manifest.json           PWA manifest (+ shortcuts to Quests, Focus, Insight)
├── sw.js                   service worker; precache list generated from index.html
│
├── styles/
│   ├── 01-tokens.css       colour, type, the "Arise window" palette
│   ├── 02-panel.css        the signature System panel and its corner brackets
│   ├── 03-shell.css        original shell + boot/auth screens
│   ├── 04-views.css        status, quests, nav dock, takeover, modals, toast
│   ├── 05-modules.css      v10/v11 additions — skills, armory, ward, gate
│   └── 06-v13.css          NEW — spacing scale, rail, dashboard, palette,
│                           dialogs, analytics, themes, focus rings
│
├── core/
│   ├── kernel.js           localStorage contract, load/save, H(), DOM helpers
│   └── seeds.js            timetables, curricula, starting quest sets
│
├── services/               logic, no markup
│   ├── progression.js      ranks, XP curve, stat grants, workout generation
│   ├── penalty.js          penalty issuance
│   ├── day.js              daily rollover, quest helpers, crypto helpers
│   ├── clock.js            the one-second tick, quest firing, screen takeover
│   ├── audio.js            focus tones, Enforcer sessions, pomodoro, notifications
│   ├── security.js         PBKDF2 PINs, lockout, auto-lock, encrypted export
│   ├── transfer.js         import sanitiser, export, wipe, logout
│   └── coach.js            NEW — behaviour analysis (pure functions, no DOM)
│
├── content/                data packs and the renderers tied to them
│   ├── quotes.js  library.js  screen.js  tools.js  careers.js  merge.js
│
├── views/                  everything that paints
│   ├── core-views.js       status, quests, training, deadlines, records, settings
│   ├── growth.js  tutor.js  wealth.js  wall.js  access.js  why.js
│   ├── shelves.js  forge.js  arena.js  v9-views.js
│   ├── home.js             NEW — the dashboard
│   └── insight.js          NEW — analytics
│
├── ui/
│   ├── boot-auth.js  onboarding.js  toast.js
│   ├── dialog.js           NEW — sysAlert / sysConfirm / sysPrompt
│   └── palette.js          NEW — Ctrl+K search and commands
│
└── app/
    ├── legacy-shell.js     v12 enterSystem + sub-tab wiring (still the base)
    ├── net.js              service-worker registration, online/offline events
    ├── theme.js            NEW — Void / Abyss / Daylight / match device
    ├── router.js           NEW — view registry, navigation, hash routes
    └── wiring.js           NEW — loads last; reconnects moved screens
```

Sibling scripts kept as-is from v12: `data.js`, `data-v11.js`, `lore.js`,
`skills.js`, `armory.js`, `online.js`, `ui-v11.js`.

---

## How the modules relate

These are **classic scripts, not ES modules** — they share one global scope, the
same way v12 did. That is deliberate. Converting 5,400 lines of interdependent
global functions to `import`/`export` in the same pass as an IA redesign would
have meant two risky changes at once with no way to tell which one broke
something. The file boundaries deliver the maintainability win now; the module
system can follow later, one folder at a time, once there are tests.

**Load order is the dependency graph.** `index.html` lists scripts in the order
v12 executed them, because top-level statements (event wiring, the boot sequence,
the data-pack merge) run at parse time. Two rules follow:

1. New modules load **after** the extracted ones, so they can safely register.
2. Extending another file's behaviour is done through `core/hooks.js`, not by
   reassignment.

**Superseded in v18.1.** Rule 2 used to read: *"Overriding is done by
redeclaring, which is the codebase's existing idiom — v9 already did this with
`__renderAllV8`."* Twenty-two places did exactly that, and `renderAll` ended up
wrapped six deep:

    const __renderAllV12 = renderAll;
    renderAll = function(){ __renderAllV12(); renderHome(); refreshTally(); };

Three costs. It was undiscoverable — reading `views/home.js` you could not tell
that `renderAll` would call `renderHome`, because `home.js` never said so;
`router.js` did, in a different directory. It was load-order fragile — the
composition order *was* the `<script>` order and nothing recorded it. And it
could not survive ES modules, because an imported binding is read-only, which is
the concrete reason the module migration stayed blocked for four releases.

The declaring file now keeps its body private and exposes a dispatcher:

    function renderAll(){ return Hooks.dispatch("renderAll", renderAllBase, this, arguments); }

and other files register:

    Hooks.after("renderAll", "shell chrome", () => { renderHome(); refreshTally(); });

Registration order is still load order and the last registered is still the
outermost — the semantics are unchanged deliberately — but the chain is now a
list you can print with `Hooks.list("renderAll")`, and a hook that throws is
recorded against its name and label instead of appearing as an anonymous frame
inside `renderAll`.

Eleven functions dispatch: `renderAll`, `enterSystem`, `go`, `grantXp`,
`toggleQuest`, `issuePenalty`, `renderGoals`, `renderBeyond`, `renderPath`,
`renderOnlineGate`, `renderHome`. Cross-file reassignments: 22 in v18.0, 0 now.

---

## Information architecture

v12 had eight flat tabs, each with its own strip of sub-tabs, and everything
visible at once. v13 has eight sections with one job each:

| Section  | Holds                                                    |
|----------|----------------------------------------------------------|
| Home     | ring, directive, coach, standing, next quest, transmission |
| Quests   | Today · Focus · Timed · Goals                             |
| Grow     | Skills · Training · Forge · Why · The Wall                |
| Learn    | Books · Screen · Tools · Archive · Tutor                  |
| Wealth   | Vault · Academy · Careers · Arena · Open Gate             |
| Armory   | Materials · Intake · The Ward                             |
| Insight  | Patterns · Record                                         |
| Settings | Appearance, then everything v12 had                       |

Navigation is a sidebar at ≥960px and a four-item dock plus **More** below that.
`More` opens the command palette rather than a second menu, which keeps mobile to
one navigation surface.

`VIEWS` in `app/router.js` is the single registry. To add a section: add an entry
there, add a `<section id="tab-…" class="tabpane hidden">` to `index.html`, and it
appears in the rail, the palette and the hash router with no other edits.

Deep links work: `#grow/tr-forge` opens Grow on the Forge. PWA shortcuts use this.

---

## The data contract — why old saves still open

Everything still lives under **`localStorage["system.v1"]`**, with the hunter
record unchanged: 51 fields, same names, same shapes. v13 adds no required
fields. Two new keys sit *beside* it and are cosmetic only:

- `system.view` — the last section you were on
- `system.theme` — Void / Abyss / Daylight / system

If either is missing or corrupt the app falls back to Home and Void. A v12 export
imports into v13 untouched, and a v13 export still opens in v12 — the shape did
not change.

---

## The coach (`services/coach.js`)

Pure functions over the record already on the device. No network, no model, no
external service. `coachSample()` walks the last 60 days and returns one row per
quest per day: which quest, what category, what hour, which weekday, cleared or
not. Everything else groups that sample.

Rules only fire when there is real separation to report:

| Note                | Fires when                                            |
|---------------------|-------------------------------------------------------|
| weak weekday        | best − worst ≥ 20 points **and** worst under 70%       |
| time-of-day         | best band − worst band ≥ 18 points, ≥ 5 observations   |
| most-skipped quest  | ≤ 50% across ≥ 4 scheduled appearances                 |
| a real strength     | a category at ≥ 80% across ≥ 5 observations            |
| direction of travel | last 7 days vs the 7 before differ by ≥ 15 points      |
| load too heavy      | 14-day clear rate under 45%                            |
| load too light      | 14-day clear rate at or above 92%                      |

Below 20 quest-days it says so rather than guessing. This was tested both ways:
given uniform data it stays silent; given a seeded pattern (bad Thursdays, weak
evenings, one dead quest) it found all three without being told they existed.

**Adaptive difficulty is proposed, never applied silently.** The coach will tell a
student to cut the list or raise the tier; it will not rewrite their schedule
behind their back. A system that quietly edits your plan is one you stop trusting.

`views/insight.js` renders the same functions as charts and states the sample size
on every panel. Under 12 quest-days it refuses to draw a trend at all.

---

## Dialogs

`ui/dialog.js` exposes three promises:

```js
await sysAlert(title, msg)
await sysConfirm(title, msg, { ok, cancel, danger, kick })   // → true | false
await sysPrompt(title, { msg, inputType, placeholder, value, ok })  // → string | null
```

All 25 native call sites were converted, which meant making their handlers
`async`. `window.alert` is also redirected, so a stray call still lands in a
System window. `confirm` and `prompt` are synchronous by nature and cannot be
monkey-patched into promises — any new code must call the `sys*` versions
directly. Escape cancels, Enter confirms, focus is trapped on the dialog.

---

## Command palette

`Ctrl`/`Cmd`+`K`, or `/` when you are not typing in a field. Indexes every
section, every sub-tab, the standing commands, and each of your quests by name —
77 entries on a fresh install. Matching is subsequence-based, so `fofs` finds
*Focus session*. Sub-tabs are discovered from the DOM, so a new segpane appears in
the palette automatically; give it a label in `SEGLABEL`.

Number keys `1`–`8` jump straight to a section when no field has focus.

---

## Themes

`html[data-theme]` with token overrides in `06-v13.css`:

- **Void** — the original
- **Abyss** — true black, easier on OLED and battery
- **Daylight** — light
- **Match my device** — follows `prefers-color-scheme`

Being straight about Daylight: it retints the shell, every System panel, buttons
and cards, but a handful of deep-glow effects inside the older views still read
cool-toned, because v9–v11 CSS hardcodes `rgba()` values instead of using tokens.
Settings says so rather than hiding it. Converting those files to tokens is the
follow-up, and it is mechanical.

`prefers-reduced-motion` is respected globally, and focus rings are visible on
every interactive element.

---

## Performance

The load is now 47 files instead of 8, which matters on a first visit over a slow
connection and not at all afterwards — the service worker precaches all 64 assets
on install, and its file list is generated from `index.html` so a new module
cannot be added and forgotten. For a hosted build, concatenating `styles/*.css`
and the `<script>` list in order produces exactly the v12 payload; the order is
the manifest.

---

## Testing

`harness.js` (kept outside the app folder) boots the whole thing in jsdom, creates
a hunter, walks all eight sections and every sub-tab, seeds 40 days of history,
and exercises the coach, analytics, palette, dialogs, themes and the storage
contract. It exits non-zero on any console error or thrown exception.

Because `services/coach.js` is pure — no DOM, no storage writes — its rules can be
unit-tested directly by handing `coachNotes` a fabricated record. That is the
pattern to follow when logic moves out of the view files.

---

## What is deliberately still open

Honest list, so nobody rediscovers these as surprises:

1. **ES modules and a bundler.** Wanted, but only after tests exist.
2. **Light-theme token conversion** in `04-views.css` and `05-modules.css`.
3. **View files still hold logic.** `views/core-views.js` is 243 lines of mixed
   rendering and business rules. Extracting the rules into `services/` is the
   next refactor, and `coach.js` is the shape to copy.
4. **Cloud sync, accounts, leaderboards, guilds.** The storage layer is not yet
   abstracted behind an interface, so this is not one commit away. Do the
   interface first: everything goes through `load()`/`save()` in
   `core/kernel.js`, which is the correct single seam.
5. **Widget rearranging on Home** — the grid is CSS, not yet data-driven.
6. **A browser still cannot wake a closed phone.** Unchanged from v12, and the
   Why Engine still says so in plain words rather than promising otherwise.


## v17 — repair release

No new features. Five defects, four of them silent, one of them fatal.

| # | Defect | File | Effect |
|---|--------|------|--------|
| 1 | Duplicate `id="app"`; an unclosed `main` from the v12 topbar wrapped the v13 shell | `index.html` | **The app rendered nothing after login.** `getElementById` returned the vestigial wrapper, so the container holding every tabpane kept `.hidden` |
| 2 | `skipWaiting()` in the install handler | `sw.js` | No worker ever reached the waiting state, so the Phase 13 update prompt could never appear and new builds took over mid-session |
| 3 | A day with no scheduled quests fell through to `streak = 0` | `services/day.js` | Anyone who left a day empty lost their streak the next morning |
| 4 | `new Date(dateKey)` parses as UTC midnight | `services/day.js`, `ui-v11.js` | West of Greenwich, yesterday was judged against the wrong weekday's quests |
| 5 | `exportHunter()` never existed; a `typeof` guard hid it | `views/gate.js` | "Export everything" silently navigated to Settings instead of exporting |

Also: `cache.addAll()` at install is atomic, so a single dropped request left the
app with **no** offline cache at all. The shell is now required and the rest is
best-effort. And the quadratic `indexOf(row)` shelf rank returned from v15; it is
the loop index again.

### The pattern worth naming

Defects 2 and 5, and the shelf rank, were all fixed in v15 and were all present
again in v16 — which was rebuilt from a v14 container. Three fixes, one lost
lineage. The guards added in v17 are the durable form of those fixes: each was
confirmed to **fail** against the v16 source before being confirmed to pass here.

Defect 1 is the sharper lesson. The suite reported 137/137 green on a build that
displayed a topbar and nothing else, because the check for "is the app visible"
asked the same ambiguous question the bug itself turned on. A test that shares an
assumption with the code cannot find a bug in that assumption.

### Still open

Unchanged from v13: no ES modules or bundler, so load order remains the
dependency graph and shared global scope remains the collision risk that has now
produced defects in four separate releases. That conversion is still the
highest-value outstanding work — and duplicate ids in a 1,350-line `index.html`
are the same failure in markup.
