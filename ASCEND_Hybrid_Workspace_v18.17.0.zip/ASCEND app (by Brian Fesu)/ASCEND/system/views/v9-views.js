/* THE SYSTEM v13 — views/v9-views.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ v9: RENDER — Careers ══════════════ */
function renderCareers(){
  const h = H(); if(!h || !$("#careerChips")) return;
  h.careers = Array.isArray(h.careers) ? h.careers : [];
  const chips = $("#careerChips"); chips.innerHTML = "";
  CAREERS.forEach(c => {
    const b = document.createElement("button");
    b.className = "chip" + (h.careers.includes(c.k) ? " on" : "");
    b.textContent = c.n.replace("THE OWNER'S PATH — ","◆ ");
    b.onclick = () => {
      h.careers = h.careers.includes(c.k) ? h.careers.filter(x=>x!==c.k) : [...h.careers, c.k];
      save(); renderCareers();
    };
    chips.appendChild(b);
  });
  const box = $("#careerList"); box.innerHTML = "";
  const chosen = CAREERS.filter(c => h.careers.includes(c.k));
  const rest   = CAREERS.filter(c => !h.careers.includes(c.k));
  const put = (c) => {
    const el = document.createElement("div");
    el.className = "book career" + (h.careers.includes(c.k) ? " sel" : "");
    el.innerHTML = `<div class="bi">
      <div class="bt">${esc(c.n)} <span class="tag t-custom">${esc(c.f)}</span></div>
      <div class="pay">${esc(c.pay)}</div>
      <div class="bw">${esc(c.d)}</div>
      <div class="bw" style="margin-top:5px;color:var(--paper)"><span style="color:var(--gold);font-family:var(--display);font-size:9px;letter-spacing:.18em">START NOW · </span>${esc(c.s)}</div>
    </div>`;
    box.appendChild(el);
  };
  if(chosen.length){
    const gh = document.createElement("div"); gh.className = "genre-head"; gh.textContent = "Your chosen paths (" + chosen.length + ")";
    box.appendChild(gh); chosen.forEach(put);
    const note = document.createElement("div"); note.className = "build-step";
    note.innerHTML = `<b>SKILL STACKING</b>You've chosen ${chosen.length}. Good — one profession is a job, two that combine are a moat. A doctor who codes, an engineer who sells, a designer who understands money: the stack is rare even when each piece is common. Your daily quests are where the stack gets built.`;
    box.appendChild(note);
    const gh2 = document.createElement("div"); gh2.className = "genre-head"; gh2.textContent = "The rest of the hall";
    box.appendChild(gh2);
  }
  rest.forEach(put);
}

/* ══════════════ v9: RENDER — Open Gate ══════════════ */
function renderGate(){
  const h = H(); if(!h || !$("#gateList")) return;
  h.gateDone = h.gateDone || {};
  const box = $("#gateList"); box.innerHTML = "";
  GATE.forEach((L,i) => {
    const done = !!h.gateDone[i];
    const el = document.createElement("div");
    el.className = "lesson" + (done ? " done" : "");
    el.innerHTML = `<div class="lesson-head"><span class="ln">${pad(i+1)}</span><span class="lt">${esc(L.t)}</span>
      <span class="lstate">${done ? "STUDIED" : "OPEN"}</span></div>
      <div class="lesson-body">${esc(L.b)}\n\n</div>`;
    el.querySelector(".lesson-head").onclick = () => el.classList.toggle("open");
    const btn = document.createElement("button");
    btn.className = "btn sm " + (done ? "ghost" : "gold");
    btn.textContent = done ? "Studied ✓" : "Mark studied · +10 XP";
    btn.disabled = done;
    btn.onclick = () => { h.gateDone[i] = true; grantXp(10, "Open Gate: " + L.t); grantStat("mind",1); save(); renderGate(); };
    el.querySelector(".lesson-body").appendChild(btn);
    box.appendChild(el);
  });
}

/* ══════════════ v9: RENDER — Screen ══════════════ */
/* v18.1: renderScreen() used to be defined here and never ran — views/shelves.js
   (script 40) assigns over it and this file is script 37. Removed with
   renderLibrary for the same reason; see content/library.js. */

/* ══════════════ v9: RENDER — Arsenal (learning tools) ══════════════ */
function renderTools(){
  if(!$("#toolList")) return;
  const box = $("#toolList"); box.innerHTML = "";
  TOOLS.forEach(([group, items]) => {
    const head = document.createElement("div"); head.className = "genre-head"; head.textContent = group;
    box.appendChild(head);
    items.forEach(([name, url, w]) => {
      const el = document.createElement("div");
      el.className = "book tool";
      el.innerHTML = `<div class="bi"><div class="bt">${esc(name)}</div>
        <div class="ba"><a href="https://${esc(url)}" target="_blank" rel="noopener">${esc(url)}</a></div>
        <div class="bw">${esc(w)}</div></div>`;
      box.appendChild(el);
    });
  });
}

/* ══════════════ v9: wiring ══════════════ */
if($("#whyAdd")) $("#whyAdd").onclick = whyAdd;
if($("#whyIn")) $("#whyIn").addEventListener("keydown", e => { if(e.key === "Enter") whyAdd(); });
if($("#whyTest")) $("#whyTest").onclick = () => whyPing(true);
if($("#whyFreq")) $("#whyFreq").onchange = () => {
  const h = H(); if(!h) return;
  h.whyFreq = $("#whyFreq").value; save();
  const label = {off:"Off", "60":"every hour", "120":"every 2 hours", "240":"every 4 hours", day:"once a day"}[h.whyFreq];
  if(h.whyFreq !== "off"){
    toast("Reminders armed", "The System will transmit your WHY " + label + " between 07:00 and 21:00, while it is running.", "gold");
    if("Notification" in window && Notification.permission === "default") Notification.requestPermission();
  } else toast("Reminders off", "The WHY wall stays. The transmissions stop.");
};

Hooks.after("renderAll", "v9 panels", () => {
  renderWhy(); renderWhyLine(); renderCareers(); renderGate(); renderScreen(); renderTools();
});
/* if a hunter is already inside when this loads, paint the new panels */
/* v18.1: renderScreen() dropped from this load-time repaint. It now lives in
   views/shelves.js, which is script 40 while this file is script 37 — calling it
   here is a ReferenceError, because a function declaration does not hoist across
   <script> boundaries. views/arena.js (script 42) already repaints the shelves in
   exactly this situation, so nothing is lost. arch-check caught this the moment
   the duplicate declaration was removed. */
if(!$("#app").classList.contains("hidden")){ renderWhy(); renderWhyLine(); renderCareers(); renderGate(); renderTools(); }
setInterval(renderWhyLine, 60000);

