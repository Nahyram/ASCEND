/* THE SYSTEM v14 — views/apply.js
   The surfaces for Phases 10, 11, 13 and 14.

   One file rather than four because each is a handful of panels bolted onto
   sections that already exist — Phase 10 into Beyond, Phase 11 into the Path,
   Phases 13 and 14 into the Gate. Phase 12 spent this session removing
   destinations; adding four more to carry these would have undone it. */
"use strict";

/* ══════════════ Phase 13 — the network banner ══════════════ */
function renderNetBanner(){
  const el = $("#netBanner"); if(!el) return;
  const n = typeof networkNotice === "function" ? networkNotice() : null;
  if(!n){ el.innerHTML = ""; el.className = "net-banner"; return; }
  el.className = "net-banner" + (n.tone === "saver" ? " saver" : "");
  el.innerHTML = `<span>${esc(n.text)}</span>` +
    (n.tone === "saver" ? `<button class="btn sm ghost" id="nbSaver">Turn off</button>` : "");
  const b = $("#nbSaver");
  if(b) b.onclick = () => { dataSaver(false); renderNetBanner(); if(typeof renderOnlineGate === "function") renderOnlineGate(); };
}

/* ══════════════ Phase 10 — applications ══════════════ */
function renderApplications(){
  const box = $("#apDash"); if(!box) return;
  const d = applicationDashboard();
  const gaps = profileGaps();

  const row = x => {
    const r = x;
    return `<div class="appl ${r.days != null && r.days <= 7 ? "urgent" : ""}" data-pkg="${r.pkg.id}">
      <div class="appl-h"><b>${esc(r.pkg.name)}</b>
        <span>${r.days == null ? "no deadline recorded" : r.days < 0 ? "closed" : `${r.days} day${r.days===1?"":"s"} left`}</span></div>
      <div class="ms-bar"><i style="width:${Math.round(r.pct*100)}%"></i></div>
      <div class="appl-m">${r.ready}/${r.total} documents ready · ${r.evidence} item${r.evidence===1?"":"s"} of your own evidence attached</div>
      ${r.alert ? `<div class="appl-alert">${esc(r.alert)}</div>` : ""}
      ${r.eligibility ? `<div class="fac ${r.eligibility.state.tone === "ok" ? "pass" : r.eligibility.state.tone === "bad" ? "fail" : "unknown"}">
        <span>Eligibility</span><em>${esc(r.eligibility.state.label)}</em></div>` : ""}
      <div class="opp-acts">
        <button class="btn sm ghost" data-docs="${r.pkg.id}">Documents</button>
        <button class="btn sm ghost" data-attach="${r.pkg.id}">Attach evidence</button>
        ${r.pkg.submitted ? `<span class="tiny" style="color:var(--ok)">Submitted ${esc(r.pkg.submitted)}</span>`
          : `<button class="btn sm gold" data-submit="${r.pkg.id}">Mark submitted</button>`}
      </div>
    </div>`;
  };

  const sections = [
    ["Needs attention", d.urgent], ["In progress", d.inProgress],
    ["Submitted", d.submitted], ["Results", d.results],
  ].filter(([, list]) => list.length);

  box.innerHTML =
    (d.load ? `<div class="rv-change" style="margin-bottom:12px">${esc(d.load)}</div>` : "") +
    (sections.length
      ? sections.map(([title, list]) => `<div class="panel-sub" style="margin:10px 0 6px">${esc(title)}</div>${list.map(row).join("")}`).join("")
      : `<div class="empty"><b>No applications tracked.</b>
          <p>Add an opportunity in "All", then start a package here. THE SYSTEM will pull in projects and results you already have rather than asking you to type them again.</p>
          <button class="btn sm gold" id="apNew">Start one</button></div>`) +
    (gaps.length ? `<div class="sep"></div><div class="panel-sub">These would improve what can be checked for you</div>${
      gaps.map(g => `<div class="fac unknown"><span>${esc(g.what)}</span><em>${esc(g.why)}</em></div>`).join("")}` : "");

  const nb = $("#apNew"); if(nb) nb.onclick = () => startPackageFlow();

  box.querySelectorAll("[data-docs]").forEach(b => b.onclick = async () => {
    const r = packageReadiness(b.dataset.docs); if(!r) return;
    const list = r.docs.map((x,i) => `${i+1}. ${x.label} — ${x.state}`).join("\n");
    const pick = await sysPrompt("Which document?", { msg:list, inputType:"number", placeholder:"1", ok:"Next" });
    const doc = r.docs[Number(pick)-1]; if(!doc) return;
    const sp = await sysPrompt("State", { msg: DOC_STATES.map((s,i) => `${i+1}. ${s}`).join("\n"), inputType:"number", placeholder:"2", ok:"Set" });
    const st = DOC_STATES[Number(sp)-1]; if(!st) return;
    setDocState(b.dataset.docs, doc.k, st); renderApply();
  });
  box.querySelectorAll("[data-attach]").forEach(b => b.onclick = async () => {
    const projs = typeof projects === "function" ? projects().filter(p => !p.archived) : [];
    if(!projs.length) return toast("Nothing to attach","Finish a project first — a package points at real work rather than describing it.","blood");
    const list = projs.map((p,i) => `${i+1}. ${p.title}`).join("\n");
    const pick = await sysPrompt("Attach which project?", { msg:list + "\n\nNothing is copied — the package points at it.", inputType:"number", placeholder:"1", ok:"Attach" });
    const p = projs[Number(pick)-1]; if(!p) return;
    togglePackageItem(b.dataset.attach, "project", p.id); renderApply();
  });
  box.querySelectorAll("[data-submit]").forEach(b => b.onclick = async () => {
    const r = packageReadiness(b.dataset.submit);
    const open = r.finalCheck.filter(c => !c.done);
    if(open.length){
      const ok = await sysConfirm("Some checks are still open",
        open.map(c => "• " + c.k).join("\n") + "\n\nMark it submitted anyway? THE SYSTEM only records what you tell it — it cannot submit anything for you.",
        { ok:"Yes, I submitted it" });
      if(!ok) return;
    }
    const ref = (await sysPrompt("Confirmation reference (optional)", {
      msg:"Whatever the site gave you. Worth keeping — it is the only proof you applied.", ok:"Save" }) || "").trim();
    markSubmitted(b.dataset.submit, ref); renderApply(); renderAll();
  });

  /* funding + eligibility detail for the nearest application */
  const det = $("#apDetail"); if(!det) return;
  const first = (d.urgent[0] || d.inProgress[0] || d.submitted[0]);
  if(!first || !first.opp){ det.innerHTML = `<p class="muted tiny">Start an application to see its funding breakdown and what can be checked about your eligibility.</p>`; return; }
  const f = fundingBreakdown(first.opp);
  const e = checkEligibility(first.opp);
  det.innerHTML = `
    <div class="panel-sub" style="margin-bottom:8px">${esc(first.opp.name)}</div>
    <div class="fund-head">${esc(f.headline)}</div>
    ${f.caution ? `<p class="tiny" style="color:var(--gold);line-height:1.6;margin:6px 0 10px">${esc(f.caution)}</p>` : ""}
    <div class="rv-list">${f.lines.map(l => `<div><span>${esc(l.label)}</span><b class="cov-${l.tone}">${esc(l.label2 || COVER[l.state].label)}</b></div>`).join("")}</div>
    <div class="sep"></div>
    <div class="panel-sub" style="margin-bottom:8px">Eligibility — ${esc(e.state.label)}</div>
    ${e.factors.map(x => `<div class="fac ${x.state === "ok" ? "pass" : x.state === "bad" ? "fail" : "unknown"}"><span>${esc(x.k)}</span><em>${esc(x.text)}</em></div>`).join("")}
    <p class="tiny muted" style="margin-top:10px">The strongest thing THE SYSTEM will ever say is "nothing you have told me contradicts this". It cannot see a passport, a transcript or a bank statement, and an app that implied otherwise would be setting you up.</p>
    <button class="btn sm ghost" id="apFund" style="margin-top:10px">Record what it covers</button>`;
  const fb = $("#apFund");
  if(fb) fb.onclick = async () => {
    for(const c of COST_LINES){
      const v = await sysPrompt(c.label, {
        msg:"1. Covered  2. Partly  3. Not covered  4. Not specified\n\nLeave anything you have not read on the official page as 'not specified'.",
        inputType:"number", placeholder:"4", ok:"Next" });
      const map = { "1":"covered", "2":"partial", "3":"not", "4":"unspecified" };
      if(map[String(v)]) setFunding(first.opp.id, { [c.k]: map[String(v)] });
    }
    renderApply();
  };
}
async function startPackageFlow(){
  const list = typeof oppList === "function" ? oppList() : [];
  if(!list.length) return toast("Nothing to apply to","Add an opportunity first.","blood");
  const pick = await sysPrompt("Which opportunity?", {
    msg:list.map((o,i) => `${i+1}. ${o.name}`).join("\n"), inputType:"number", placeholder:"1", ok:"Create" });
  const o = list[Number(pick)-1]; if(!o) return;
  createPackage(o.id); renderApply();
}

/* ══════════════ Phase 11 — evidence & personal boards ══════════════ */
function renderVerification(){
  const box = $("#pgVerify"); if(!box) return;
  const sum = verificationSummary();
  const led = achievementLedger().slice(0, 20);
  const sig = integritySignals();

  box.innerHTML = `
    <div class="grid g3">
      <div class="kpi"><b>${sum.total}</b><small>Achievements recorded</small></div>
      <div class="kpi"><b>${sum.external}</b><small>Outside this app</small></div>
      <div class="kpi"><b>${sum.checkable}</b><small>Somebody could check</small></div>
    </div>
    <div class="sep"></div>
    ${sig.map(s => `<div class="br-row"><div class="br-k">Note</div><div class="br-v"><b>${esc(s.text)}</b><em>${esc(s.note)}</em></div></div>`).join("")}
    ${led.length ? led.map(a => {
      const v = VERIFY_STATES.find(x => x.k === a.verification) || VERIFY_STATES[0];
      return `<div class="ach ${a.internal ? "" : "on"}">
        <div class="ach-mark">${a.internal ? "◇" : "◆"}</div>
        <div class="ach-b"><b>${esc(a.title)}</b>
          <em>${esc(a.internal ? a.note : (a.organisation || a.category || ""))}</em>
          <span class="conf ${v.weight >= 2 ? "cf-hi" : v.weight === 1 ? "cf-md" : "cf-lo"}">${esc(v.label)}</span></div>
        ${!a.internal && a.verification === "selfreported" ? `<button class="btn sm ghost" data-req="${a.source}|${a.id}">Request review</button>` : ""}
      </div>`;
    }).join("") : `<p class="muted tiny">Nothing recorded yet.</p>`}
    <p class="tiny muted" style="margin-top:12px">Achievements marked ◇ are THE SYSTEM's own — they describe how you have used this app, not something the outside world would recognise. That distinction is kept deliberately.</p>`;

  box.querySelectorAll("[data-req]").forEach(b => b.onclick = async () => {
    const [kind, id] = b.dataset.req.split("|");
    const r = requestVerification(kind === "competition" ? "opportunity" : kind, id);
    await sysAlert(r.ok ? "Marked as pending" : "Cannot do that", r.ok ? r.note : r.reason);
    renderApply();
  });

  /* personal boards */
  const bb = $("#pgBoards"); if(!bb) return;
  const boards = personalBoards();
  const imp = improvementReport();
  bb.innerHTML = boards.map(b => `
    <div class="board">
      <div class="board-h"><b>${esc(b.label)}</b><span>${b.now}${b.isBest ? " · personal best" : ` · best ${b.best}`}</span></div>
      <div class="board-m">${esc(b.metric)}</div>
      <div class="ms-bar"><i style="width:${Math.min(100, b.best ? Math.round(b.now/Math.max(b.best,1)*100) : 0)}%"></i></div>
    </div>`).join("") + `
    <div class="sep"></div>
    ${imp.enough
      ? imp.rows.map(r => `<div class="fac pass"><span>${esc(r.k)}</span><em>${r.from != null ? `${r.from}${r.unit} → ` : ""}${r.to}${r.unit} · ${esc(r.measure)}</em></div>`).join("")
      : `<p class="muted tiny">${esc(imp.note)}</p>`}
    <p class="tiny muted" style="margin-top:12px">${esc(rankingConfidence(1).text)}</p>
    <button class="btn sm ghost" id="pgSnap" style="margin-top:10px">Save this month's standing</button>`;
  const sn = $("#pgSnap");
  if(sn) sn.onclick = () => {
    const s = takeSnapshot();
    toast(s ? "Snapshot saved" : "Already saved this month",
      s ? "A standing you can compare against later, which is the only comparison available here." : "One per month is enough.", "gold");
    renderApply();
  };
}

/* ══════════════ Phases 13 & 14 — health ══════════════ */
function renderHealth(){
  const box = $("#gDevice"); if(!box) return;
  const d = deviceProfile();
  const inst = installOffer();
  box.innerHTML = `
    <div class="rv-list">
      <div><span>Screen</span><b>${d.width}px · ${esc(d.size)}</b></div>
      <div><span>Input</span><b>${d.touch ? "touch" : "pointer"}</b></div>
      <div><span>Connection</span><b>${esc(d.effectiveType || (d.online ? "unknown" : "offline"))}</b></div>
      <div><span>Device class</span><b>${d.lowEnd ? "modest — the app trims accordingly" : "capable"}</b></div>
      <div><span>Running as</span><b>${d.standalone ? "installed app" : "browser tab"}</b></div>
      <div><span>Data saver</span><b><button class="btn sm ghost" id="hSaver">${dataSaver() ? "On" : "Off"}</button></b></div>
    </div>
    <details class="opp-why"><summary>What data saver changes</summary>
      ${dataSaverEffects().map(t => `<div class="fac unknown"><span></span><em>${esc(t)}</em></div>`).join("")}
    </details>
    ${inst.available ? `<button class="btn sm gold" id="hInstall" style="margin-top:10px">Install THE SYSTEM</button>
      <p class="tiny muted" style="margin-top:6px">${esc(inst.text)}</p>`
      : inst.installed ? `<p class="tiny muted" style="margin-top:10px">Already installed.</p>`
      : `<p class="tiny muted" style="margin-top:10px">An install prompt is offered once you have used THE SYSTEM for a few days — ${inst.days} so far. Interrupting a first visit to ask would be the wrong trade.</p>`}
    ${updateWaiting() ? `<button class="btn sm gold" id="hUpdate" style="margin-top:10px">Apply the update</button>` : ""}`;
  const sv = $("#hSaver"); if(sv) sv.onclick = () => { dataSaver(!dataSaver()); renderApply(); renderNetBanner(); };
  const ib = $("#hInstall"); if(ib) ib.onclick = async () => { await runInstall(); renderApply(); };
  const ub = $("#hUpdate"); if(ub) ub.onclick = () => applyUpdate();

  /* record health */
  const ib2 = $("#gIntegrity"); if(!ib2) return;
  const chk = integrityCheck();
  ib2.innerHTML = chk.issues.length
    ? chk.issues.map(i => `<div class="fac ${i.sev === "high" ? "fail" : i.sev === "medium" ? "unknown" : "unknown"}">
        <span>${esc(i.what)}</span><em>${esc(i.detail)} — ${esc(i.fix)}</em></div>`).join("") +
      `<button class="btn sm ghost" id="hRepair" style="margin-top:10px">Repair what can be repaired</button>`
    : `<p class="muted tiny">No problems found. ${chk.counts ? "" : ""}Broken references, impossible values and overstated evidence are all checked.</p>`;
  const rb = $("#hRepair");
  if(rb) rb.onclick = async () => {
    if(!await sysConfirm("Repair the record?", "Only the safe repairs run: orphaned history, impossible numbers, packages pointing at deleted opportunities, and evidence counts that exceed their attempts. Nothing you wrote is touched.", { ok:"Repair" })) return;
    const r = repairIntegrity();
    renderApply(); renderAll();
    toast("Repaired", `${r.fixed} item${r.fixed===1?"":"s"} corrected.`, "gold");
  };

  /* security posture */
  const pb = $("#gPosture"); if(!pb) return;
  const sec = securityPosture();
  pb.innerHTML = `
    <p class="tiny" style="line-height:1.6;margin-bottom:10px"><b>${esc(sec.model)}</b></p>
    <div class="panel-sub" style="margin-bottom:6px">Protected</div>
    ${sec.protects.map(x => `<div class="fac pass"><span>${esc(x.k)}</span><em>${esc(x.how)}</em></div>`).join("")}
    <div class="panel-sub" style="margin:12px 0 6px">Not protected</div>
    ${sec.doesNotProtect.map(x => `<div class="fac fail"><span>${esc(x.k)}</span><em>${esc(x.why)}</em></div>`).join("")}
    <p class="tiny muted" style="margin-top:12px">${esc(sec.note)}</p>
    <div class="sep"></div>
    ${(() => { const q = qaRegister();
      return `<div class="panel-sub" style="margin-bottom:6px">Automated coverage — ${q.covered} of ${q.total} areas</div>` +
        q.areas.map(a => `<div class="fac ${a.covered ? "pass" : "unknown"}"><span>${esc(a.label)}</span><em>${a.covered ? "checked automatically" : esc(a.why)}</em></div>`).join("") +
        `<p class="tiny muted" style="margin-top:10px">${esc(q.note)}</p>`; })()}`;
}

/* ---------- wiring ---------- */
function renderApply(){
  safeRender("net banner", renderNetBanner);
  if($("#apDash")) safeRender("applications", renderApplications, { into:"#apDash" });
  if($("#pgVerify")) safeRender("verification", renderVerification, { into:"#pgVerify" });
  if($("#gDevice")) safeRender("device health", renderHealth, { into:"#gDevice" });
}

/* fold into the existing renderers so everything repaints together */
Hooks.after("renderBeyond", "applications", () => safeRender("applications", renderApplications, { into:"#apDash" }));
Hooks.after("renderPath", "verification", () => safeRender("verification", renderVerification, { into:"#pgVerify" }));
Hooks.after("renderOnlineGate", "device health", () => safeRender("device health", renderHealth, { into:"#gDevice" }));
document.addEventListener("DOMContentLoaded", () => { if(typeof initDevice === "function") initDevice(); renderNetBanner(); });
if(document.readyState !== "loading"){ if(typeof initDevice === "function") initDevice(); renderNetBanner(); }
