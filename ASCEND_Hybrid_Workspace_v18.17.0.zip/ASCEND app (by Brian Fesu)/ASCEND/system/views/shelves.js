/* THE SYSTEM v13 — views/shelves.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- shared shelf renderer ---------- */
function shelfChips(el, source, chosenKey, rerender){
  const h = H();
  h[chosenKey] = Array.isArray(h[chosenKey]) ? h[chosenKey] : [];
  el.innerHTML = "";
  Object.entries(source).forEach(([k,g]) => {
    if(g.adult && !matureOn()) return;
    const b = document.createElement("button");
    b.className = "chip" + (h[chosenKey].includes(k) ? " on" : "") + (g.adult ? " locked" : "");
    b.textContent = (g.adult ? "⚠ " : "") + g.label;
    b.onclick = () => {
      h[chosenKey] = h[chosenKey].includes(k) ? h[chosenKey].filter(x=>x!==k) : [...h[chosenKey], k];
      save(); rerender();
    };
    el.appendChild(b);
  });
}

/* ---------- BOOKS ---------- */
function renderLibrary(){
  const h = H(); if(!h || !$("#genreChips")) return;
  h.genres = Array.isArray(h.genres) ? h.genres : [];
  h.booksRead = h.booksRead || {};
  renderMatBtn();
  shelfChips($("#genreChips"), GENRES, "genres", renderLibrary);

  const q = ($("#bookSeek") && $("#bookSeek").value || "").trim().toLowerCase();
  const box = $("#bookList"); box.innerHTML = "";

  let keys = h.genres.filter(k => GENRES[k] && (!GENRES[k].adult || matureOn()));
  if(q) keys = Object.keys(GENRES).filter(k => !GENRES[k].adult || matureOn());

  if(!keys.length){
    box.innerHTML = `<p class="muted tiny">No shelves chosen. Pick as many as you want above — a hunter who doesn't read is training half a body. Or just search: the box above looks across every shelf.</p>`;
    return;
  }

  let anyHit = false;
  keys.forEach(k => {
    const g = GENRES[k];
    let rows = g.books;
    if(q) rows = rows.filter(r => (r[0]+" "+(r[1]||"")).toLowerCase().includes(q));
    if(!rows.length) return;
    anyHit = true;

    const head = document.createElement("div"); head.className = "genre-head";
    head.textContent = g.label + "  ·  " + g.books.length;
    box.appendChild(head);

    if(g.warn){
      const wb = document.createElement("div"); wb.className = "lockrow"; wb.textContent = g.warn;
      box.appendChild(wb);
    }

    const limit = q ? rows.length : (bookOpen[k] ? rows.length : PAGE);
    rows.slice(0, limit).forEach((row, i) => {
      const [t,a,w] = row;
      const id = k + "::" + t;
      const read = !!h.booksRead[id];
      const el = document.createElement("div");
      el.className = "book ranked" + (read ? " read" : "");
      /* rank is only shown when there is no query, and without a query rows IS
         g.books — so the position is the loop index. indexOf() rescanned the
         whole shelf for every row, making an expanded 450-title shelf quadratic. */
      const rank = q ? "" : `<div class="rank">#${i+1}</div>`;
      el.innerHTML = `${rank}<div class="bi"><div class="bt">${esc(t)}</div><div class="ba">${esc(a||"")}</div>
        ${w ? `<div class="bw">${esc(w)}</div>` : ""}</div>
        <button class="btn sm ${read?"ghost":"gold"}">${read ? "Read ✓" : "Finished · +30 XP"}</button>`;
      const btn = el.querySelector("button");
      btn.disabled = read;
      btn.onclick = async () => {
        if(!await sysConfirm("Finished it?",
          "\u201c" + t + "\u201d\n\nThe System takes your word. Do not make your word worthless.",
          {ok:"I finished it"})) return;
        h.booksRead[id] = true; grantXp(30, "Finished: " + t, "book"); grantStat("mind",1); save(); renderLibrary();
      };
      box.appendChild(el);
    });

    if(!q && rows.length > PAGE){
      const more = document.createElement("button");
      more.className = "showmore";
      more.textContent = bookOpen[k] ? "SHOW LESS" : `SHOW ALL ${rows.length} →`;
      more.onclick = () => { bookOpen[k] = !bookOpen[k]; renderLibrary(); };
      box.appendChild(more);
    }
  });
  if(!anyHit) box.innerHTML = `<p class="muted tiny">Nothing matches that. Try an author's surname, or part of a title.</p>`;
};
if($("#bookSeek")) $("#bookSeek").addEventListener("input", () => renderLibrary());

/* ---------- SCREEN ---------- */
function renderScreen(){
  const h = H(); if(!h || !$("#screenChips")) return;
  h.screenGenres = Array.isArray(h.screenGenres) ? h.screenGenres : [];
  h.watched = h.watched || {};
  shelfChips($("#screenChips"), SCREEN, "screenGenres", renderScreen);

  const q = ($("#screenSeek") && $("#screenSeek").value || "").trim().toLowerCase();
  const box = $("#screenList"); box.innerHTML = "";

  let keys = h.screenGenres.filter(k => SCREEN[k] && (!SCREEN[k].adult || matureOn()));
  if(q) keys = Object.keys(SCREEN).filter(k => !SCREEN[k].adult || matureOn());

  if(!keys.length){
    box.innerHTML = `<p class="muted tiny">No genres chosen. Pick above. Rest is part of training — but the System chooses what feeds the mind, not the algorithm.</p>`;
    return;
  }

  let anyHit = false;
  keys.forEach(k => {
    const g = SCREEN[k];
    let rows = g.picks;
    if(q) rows = rows.filter(r => String(r[0]).toLowerCase().includes(q));
    if(!rows.length) return;
    anyHit = true;

    const head = document.createElement("div"); head.className = "genre-head";
    head.textContent = g.label + "  ·  " + g.picks.length;
    box.appendChild(head);
    if(g.warn){ const wb = document.createElement("div"); wb.className = "lockrow"; wb.textContent = g.warn; box.appendChild(wb); }

    const limit = q ? rows.length : (screenOpen[k] ? rows.length : PAGE);
    rows.slice(0, limit).forEach((row, i) => {
      const [t,type,w] = row;
      const id = k + "::" + t;
      const seen = !!h.watched[id];
      const el = document.createElement("div");
      el.className = "book ranked" + (seen ? " read" : "");
      /* same quadratic indexOf() as the book shelf above — see the note there */
      const rank = q ? "" : `<div class="rank">#${i+1}</div>`;
      el.innerHTML = `${rank}<span class="mtag ${esc(type)}">${esc(type)}</span>
        <div class="bi"><div class="bt">${esc(t)}</div>${w ? `<div class="bw">${esc(w)}</div>` : ""}</div>
        <button class="btn sm ${seen?"ghost":"gold"}">${seen ? "Seen ✓" : "Watched · +10 XP"}</button>`;
      const btn = el.querySelector("button");
      btn.disabled = seen;
      btn.onclick = () => { h.watched[id] = true; grantXp(10, "Watched: " + t); save(); renderScreen(); };
      box.appendChild(el);
    });

    if(!q && rows.length > PAGE){
      const more = document.createElement("button");
      more.className = "showmore";
      more.textContent = screenOpen[k] ? "SHOW LESS" : `SHOW ALL ${rows.length} →`;
      more.onclick = () => { screenOpen[k] = !screenOpen[k]; renderScreen(); };
      box.appendChild(more);
    }
  });
  if(!anyHit) box.innerHTML = `<p class="muted tiny">Nothing matches that.</p>`;
};
if($("#screenSeek")) $("#screenSeek").addEventListener("input", () => renderScreen());

