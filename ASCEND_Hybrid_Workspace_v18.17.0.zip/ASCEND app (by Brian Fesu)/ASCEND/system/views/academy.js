/* THE SYSTEM v14 — views/academy.js
   The Academy's seven surfaces.

   §48 governs the overview: only what matters today. §50 governs everything else
   — an empty screen must teach, not just report emptiness. A student opening a
   brand-new Academy sees what to do first, not "No data."

   §26: while a session is running, analytics get out of the way. */
"use strict";

const MSTATE_CLASS = { new:"m-new", learning:"m-learn", practice:"m-prac", review:"m-rev", mastered:"m-mast" };

function masteryBar(m){
  return `<div class="mst ${MSTATE_CLASS[m.state]}">
    <div class="mst-bar"><i style="width:${Math.round(m.pct*100)}%"></i></div>
    <span class="mst-lab">${esc(m.label)}${m.decayed ? " · fading" : ""}</span></div>`;
}

/* ══════════════ overview (§48) ══════════════ */
function renderAcademyHome(){
  if(!$("#acToday")) return;
  const o = academyOverview(true);
  const load = reviewLoad();

  if(!o.subjects.length){
    $("#acHeadline").textContent = "Nothing set up yet.";
    $("#acToday").innerHTML = `<div class="empty">
      <b>Your Academy is empty.</b>
      <p>Add one subject and paste its syllabus outline. The System will track which topics you have evidence for and which you only think you know — those are different things, and the difference is what costs marks.</p>
      <button class="btn sm gold" id="acEmptyGo">Add your first subject</button></div>`;
    const b = $("#acEmptyGo"); if(b) b.onclick = () => { go("academy","ac-subjects"); const a = $("#acAddSubject"); if(a) a.click(); };
    $("#acStand").innerHTML = ""; $("#acWeak").innerHTML = "";
    return;
  }

  const ex = o.nextExam;
  $("#acHeadline").textContent = ex
    ? `${o.subjects.length} subjects · ${Math.round(o.avg*100)}% of your syllabus has evidence behind it · next exam in ${ex.in} day${ex.in===1?"":"s"}`
    : `${o.subjects.length} subjects · ${Math.round(o.avg*100)}% of your syllabus has evidence behind it`;

  /* one recommended action, with its reason */
  const parts = [];
  if(load.due) parts.push(`<div class="br-row hi"><div class="br-k">Review</div><div class="br-v"><b>${load.due} card${load.due===1?"":"s"} due</b><em>Recall due today. This is the cheapest thing on the list and the one that actually holds knowledge in place.</em></div></div>`);
  const plan = ex ? revisionPlan(ex.id) : null;
  if(plan && plan.today) parts.push(`<div class="br-row hi"><div class="br-k">Exam</div><div class="br-v"><b>${esc(plan.today.text)}</b><em>${esc(plan.today.why || "")}</em></div></div>`);
  const rec = recoveryCandidates()[0];
  if(rec) parts.push(`<div class="br-row warn"><div class="br-k">Mistakes</div><div class="br-v"><b>${esc(rec.topic.name)} — ${rec.errors} unresolved errors</b><em>The same topic keeps going wrong. More questions will not fix it; going back to the material will.</em></div></div>`);
  const ep = errorPattern();
  if(ep) parts.push(`<div class="br-row"><div class="br-k">Pattern</div><div class="br-v"><b>${esc(ep.text)}</b><em>${esc(ep.fix)}</em></div></div>`);
  if(!parts.length) parts.push(`<p class="muted tiny">Nothing due. Add questions or cards to a weak topic and the Academy will have something to give you.</p>`);
  $("#acToday").innerHTML = parts.join("");

  /* standing */
  $("#acStand").innerHTML = `
    <div class="grid g3">
      <div class="kpi"><b>${o.mastered}</b><small>Topics mastered</small></div>
      <div class="kpi"><b>${o.topics}</b><small>Topics tracked</small></div>
      <div class="kpi"><b>${studyMinutes(7)}</b><small>Minutes this week</small></div>
    </div>
    <div class="sep"></div>
    ${o.subjects.map(s => `<div class="subj-row" data-subj="${s.subject.id}" role="button" tabindex="0">
      <div class="subj-n"><b>${esc(s.subject.name)}</b><small>${s.total} topics${s.exam ? ` · exam in ${s.exam.in}d` : ""}</small></div>
      ${masteryBar({ pct:s.avg, state: s.avg >= 0.9 ? "mastered" : s.avg >= 0.7 ? "review" : s.avg >= 0.4 ? "practice" : s.avg > 0 ? "learning" : "new",
                     label: Math.round(s.avg*100) + "%" })}
    </div>`).join("")}`;
  $$("[data-subj]").forEach(el => { el.onclick = () => go("academy","ac-subjects"); });

  /* weakest */
  const weak = o.weak;
  $("#acWeak").innerHTML = weak.length
    ? weak.map(x => `<div class="tp">
        <div class="tp-n"><b>${esc(x.t.name)}</b><small>${esc(x.t.subject.name)}</small></div>
        <div class="tp-m">${masteryBar(x.m)}<em>${esc(x.m.why)}</em></div>
      </div>`).join("")
    : `<p class="muted tiny">No weak topics — either you are in good shape, or nothing has been tested yet. The System can only report what it has evidence for.</p>`;
}

/* ══════════════ subjects & syllabus (§5, §7) ══════════════ */
function renderAcademySubjects(){
  const box = $("#acSubjects"); if(!box) return;
  const list = subjects();
  if(!list.length){
    box.innerHTML = `<div class="empty"><b>No subjects yet.</b>
      <p>Start with one. Add its units and topics from the syllabus \u2014 not from memory, or you will quietly leave out the parts you dislike.</p></div>`;
    return;
  }
  box.innerHTML = list.map(s => {
    const sum = subjectSummary(s.id);
    return `<div class="subj" data-s="${s.id}">
      <div class="subj-head">
        <b>${esc(s.name)}</b>
        <span>${sum.total} topics · ${Math.round(sum.avg*100)}%${s.target ? ` · target ${esc(s.target)}` : ""}</span>
        <button class="btn sm ghost" data-addunit="${s.id}">+ Unit</button>
        <button class="btn sm danger" data-delsubj="${s.id}">\u2715</button>
      </div>
      ${(s.units || []).map(u => `<div class="unit">
        <div class="unit-h">${esc(u.name)} <button class="btn sm ghost" data-addtopic="${s.id}|${u.id}">+ topic</button></div>
        ${(u.topics || []).map(t => {
          const m = masteryOf(t);
          return `<div class="tp small">
            <div class="tp-n"><b>${esc(t.name)}</b></div>
            <div class="tp-m">${masteryBar(m)}</div>
            <button class="btn sm ghost" data-studied="${t.id}" title="Mark studied">\u25cb</button>
            <button class="btn sm danger" data-deltopic="${t.id}">\u2715</button>
          </div>`;
        }).join("") || `<p class="muted tiny" style="margin-left:12px">No topics in this unit yet.</p>`}
      </div>`).join("") || `<p class="muted tiny">No units yet. Add one \u2014 or use "Paste a syllabus outline" below.</p>`}
    </div>`;
  }).join("");

  box.querySelectorAll("[data-addunit]").forEach(b => b.onclick = async () => {
    const n = (await sysPrompt("Unit name", { msg:"A chapter, paper or module.", placeholder:"e.g. Mechanics", ok:"Add" }) || "").trim();
    if(n){ addUnit(b.dataset.addunit, n); renderAcademy(); }
  });
  box.querySelectorAll("[data-addtopic]").forEach(b => b.onclick = async () => {
    const [sid, uid_] = b.dataset.addtopic.split("|");
    const n = (await sysPrompt("Topic name", { msg:"One thing you could be asked a question about.", placeholder:"e.g. Newton's second law", ok:"Add" }) || "").trim();
    if(n){ addTopic(sid, uid_, n); renderAcademy(); }
  });
  box.querySelectorAll("[data-studied]").forEach(b => b.onclick = () => {
    markStudied(b.dataset.studied); renderAcademy();
    toast("Marked studied", "That records that you covered it. It does not record that you can do it — questions do that.", "gold");
  });
  box.querySelectorAll("[data-deltopic]").forEach(b => b.onclick = async () => {
    if(await sysConfirm("Remove this topic?", "Its evidence record goes with it.", { ok:"Remove", danger:true })){ removeTopic(b.dataset.deltopic); renderAcademy(); }
  });
  box.querySelectorAll("[data-delsubj]").forEach(b => b.onclick = async () => {
    if(await sysConfirm("Remove this subject?", "Every unit, topic and exam under it is removed. Questions and cards are kept.", { ok:"Remove", danger:true })){ removeSubject(b.dataset.delsubj); renderAcademy(); }
  });
}

/* ══════════════ study (§25–28) ══════════════ */
let _liveSession = null;
function renderAcademyStudy(){
  const box = $("#acStudy"); if(!box) return;
  const topics = allTopics();
  if(!topics.length){ box.innerHTML = `<div class="empty"><b>No topics yet.</b><p>Add a subject and its topics first \u2014 a session with nothing attached to it cannot become evidence.</p></div>`; return; }

  if(_liveSession){
    /* §26 — focus mode: the objective, the timer, and nothing else */
    box.innerHTML = `<div class="focusmode">
      <div class="fm-obj">${esc(_liveSession.objective || "Study session")}</div>
      <div class="fm-topic">${esc((getTopic(_liveSession.topicId) || {}).name || "")}</div>
      <div class="fm-time" id="fmTime">${_liveSession.minutes}:00</div>
      <button class="btn gold" id="fmDone">Finish</button>
    </div>`;
    $("#fmDone").onclick = async () => {
      const acc = (await sysPrompt("What did you actually get done?", {
        msg:"One line. This is the part that turns time into evidence.", placeholder:"e.g. worked through 6 examples on moments", ok:"Save" }) || "").trim();
      const conf = await sysPrompt("How confident are you now? 1\u20135", { inputType:"number", placeholder:"3", ok:"Finish" });
      finishSession(_liveSession.id, { accomplished:acc, confidence:Number(conf) || 3 });
      _liveSession = null; renderAcademy(); renderAll();
    };
    return;
  }

  box.innerHTML = `
    <label class="tiny muted">Topic</label>
    <select id="acStTopic" class="in">${topics.map(t => `<option value="${t.id}">${esc(t.subject.name)} — ${esc(t.name)}</option>`).join("")}</select>
    <label class="tiny muted" style="margin-top:10px;display:block">Minutes</label>
    <select id="acStMins" class="in"><option>15</option><option selected>25</option><option>45</option><option>60</option><option>90</option></select>
    <label class="tiny muted" style="margin-top:10px;display:block">Objective for this session</label>
    <input id="acStObj" class="in" placeholder="e.g. understand why the formula has a minus sign">
    <button class="btn gold" id="acStGo" style="margin-top:12px">Start</button>
    <div class="sep"></div>
    <div class="rv-list">
      <div><span>Minutes this week</span><b>${studyMinutes(7)}</b></div>
      <div><span>Sessions recorded</span><b>${(academy().sessions || []).filter(s => s.done).length}</b></div>
    </div>`;
  $("#acStGo").onclick = () => {
    const tid = $("#acStTopic").value;
    const t = getTopic(tid);
    _liveSession = startSession({ subjectId: t ? t.subject.id : null, topicId: tid,
      minutes: Number($("#acStMins").value) || 25, objective: $("#acStObj").value.trim() });
    renderAcademyStudy();
  };
}

/* ══════════════ practice (§15, §17) ══════════════ */
let _practice = null;
function renderAcademyPractice(){
  const box = $("#acPractice"); if(!box) return;
  const a = academy();
  const topics = allTopics();

  if(!topics.length){ box.innerHTML = `<div class="empty"><b>No topics yet.</b><p>Practice needs somewhere to attach itself. Add a subject first.</p></div>`; return; }

  if(_practice && _practice.queue.length){
    const item = _practice.queue[0];
    box.innerHTML = `<div class="prac">
      <div class="prac-meta">${esc(item.topic.subject.name)} · ${esc(item.topic.name)} · ${esc(item.q.difficulty)} · ${_practice.done + 1} of ${_practice.total}</div>
      <div class="prac-q">${esc(item.q.text)}</div>
      ${item.q.options.length ? `<div class="prac-opts">${item.q.options.map(o => `<div class="opt">${esc(o)}</div>`).join("")}</div>` : ""}
      <div id="pracReveal" class="hidden">
        <div class="prac-a"><b>Answer:</b> ${esc(item.q.answer || "(none recorded)")}</div>
        ${item.q.explanation ? `<div class="prac-e">${esc(item.q.explanation)}</div>` : ""}
      </div>
      <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
        <button class="btn sm ghost" id="pracShow">Show answer</button>
        <button class="btn sm gold" id="pracRight">I got it right</button>
        <button class="btn sm danger" id="pracWrong">I got it wrong</button>
      </div></div>`;
    $("#pracShow").onclick = () => $("#pracReveal").classList.remove("hidden");
    $("#pracRight").onclick = () => { recordAnswer({ questionId:item.q.id, correct:true }); advancePractice(true); };
    $("#pracWrong").onclick = async () => {
      const opts = MISTAKE_KINDS.map((k,i) => `${i+1}. ${k.label}`).join("\n");
      const pick = await sysPrompt("What kind of mistake?", {
        msg: opts + "\n\nThis is the whole value of an error log. Guessing here makes it useless.",
        inputType:"number", placeholder:"1", ok:"Log it" });
      const kind = (MISTAKE_KINDS[Number(pick) - 1] || MISTAKE_KINDS[0]).k;
      recordAnswer({ questionId:item.q.id, correct:false, mistakeKind:kind });
      advancePractice(false);
    };
    return;
  }

  const counts = { q:(a.questions || []).length };
  box.innerHTML = `
    ${counts.q ? "" : `<div class="empty"><b>No questions yet.</b>
      <p>Write your own, or type in ones from material you legitimately have. THE SYSTEM will not reproduce exam-board papers \u2014 use the official source for those and record how you did here.</p></div>`}
    <label class="tiny muted">Subject</label>
    <select id="acPrSubj" class="in"><option value="">All subjects</option>${subjects().map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join("")}</select>
    <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn sm gold" id="acPrStart" ${counts.q ? "" : "disabled"}>Start a set of 10</button>
      <button class="btn sm ghost" id="acPrAdd">+ Add a question</button>
    </div>
    <div class="sep"></div>
    <div class="rv-list">
      <div><span>Questions in your bank</span><b>${counts.q}</b></div>
      <div><span>Unresolved mistakes</span><b>${errorLog().length}</b></div>
    </div>`;

  $("#acPrStart").onclick = () => {
    const set = buildPracticeSet($("#acPrSubj").value || null, 10);
    if(!set.length) return toast("Nothing to practise","Add questions to a topic first.","blood");
    _practice = { queue:set, total:set.length, done:0, recent:[] };
    renderAcademyPractice();
  };
  $("#acPrAdd").onclick = async () => {
    const tops = allTopics($("#acPrSubj").value || null);
    if(!tops.length) return toast("No topics","Add a subject and a topic first.","blood");
    const list = tops.slice(0, 30).map((t,i) => `${i+1}. ${t.subject.name} — ${t.name}`).join("\n");
    const pick = await sysPrompt("Which topic?", { msg:list, inputType:"number", placeholder:"1", ok:"Next" });
    const topic = tops[Number(pick) - 1]; if(!topic) return;
    const text = (await sysPrompt("The question", { placeholder:"Write it as it would be asked", ok:"Next" }) || "").trim();
    if(!text) return;
    const answer = (await sysPrompt("The answer", { placeholder:"What a correct answer contains", ok:"Next" }) || "").trim();
    const expl = (await sysPrompt("Why (optional)", { msg:"The explanation you will want in three weeks.", ok:"Save" }) || "").trim();
    addQuestion({ topicId:topic.id, text, answer, explanation:expl, difficulty:"moderate" });
    renderAcademy(); toast("Question added", `${topic.name} — it will surface when that topic is weak.`, "gold");
  };
}
function advancePractice(correct){
  if(!_practice) return;
  _practice.recent.push(correct);
  _practice.done++;
  _practice.queue.shift();
  if(!_practice.queue.length){
    const right = _practice.recent.filter(Boolean).length;
    const total = _practice.total;
    _practice = null;
    renderAcademy(); renderAll();
    toast("Set finished", `${right} of ${total} correct. Every wrong one is now in the error log with its cause.`, "gold");
    return;
  }
  renderAcademyPractice();
}

/* ══════════════ spaced review (§21, §22) ══════════════ */
let _cardUp = null;
function renderAcademyCards(){
  const box = $("#acCards"); if(!box) return;
  const load = reviewLoad();
  const due = dueCards();

  if(_cardUp){
    const c = _cardUp;
    box.innerHTML = `<div class="card-rev">
      <div class="cr-front">${esc(c.front)}</div>
      <div id="crBack" class="hidden"><div class="cr-back">${esc(c.back)}</div></div>
      <button class="btn ghost" id="crShow" style="margin-top:12px">Show</button>
      <div id="crGrades" class="hidden row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
        ${REVIEW_GRADES.map(g => `<button class="btn sm ${g.k==="again"?"danger":g.k==="easy"?"gold":"ghost"}" data-g="${g.k}">${g.label}</button>`).join("")}
      </div></div>`;
    $("#crShow").onclick = () => { $("#crBack").classList.remove("hidden"); $("#crGrades").classList.remove("hidden"); $("#crShow").classList.add("hidden"); };
    box.querySelectorAll("[data-g]").forEach(b => b.onclick = () => {
      const r = reviewCard(c.id, b.dataset.g);
      const next = dueCards()[0];
      _cardUp = next || null;
      renderAcademyCards();
      if(!next && r) toast("Review done", `Next card back in ${r.nextIn} day${r.nextIn===1?"":"s"}.`, "gold");
    });
    return;
  }

  box.innerHTML = `
    <div class="grid g3">
      <div class="kpi"><b>${load.due}</b><small>Due now</small></div>
      <div class="kpi"><b>${load.week}</b><small>Next 7 days</small></div>
      <div class="kpi"><b>${load.total}</b><small>Cards total</small></div>
    </div>
    ${load.total ? "" : `<div class="empty" style="margin-top:12px"><b>No cards yet.</b>
      <p>The highest-value card you can make is one built from a question you got wrong. Go to Mistakes and turn one into a card.</p></div>`}
    <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn sm gold" id="acCardGo" ${due.length ? "" : "disabled"}>Review ${due.length} due</button>
      <button class="btn sm ghost" id="acCardAdd">+ Add a card</button>
    </div>`;
  $("#acCardGo").onclick = () => { _cardUp = dueCards()[0] || null; renderAcademyCards(); };
  $("#acCardAdd").onclick = async () => {
    const tops = allTopics();
    if(!tops.length) return toast("No topics","Add a subject first.","blood");
    const list = tops.slice(0, 30).map((t,i) => `${i+1}. ${t.subject.name} — ${t.name}`).join("\n");
    const pick = await sysPrompt("Which topic?", { msg:list, inputType:"number", placeholder:"1", ok:"Next" });
    const topic = tops[Number(pick) - 1]; if(!topic) return;
    const front = (await sysPrompt("Front", { placeholder:"The prompt", ok:"Next" }) || "").trim();
    const back  = (await sysPrompt("Back", { placeholder:"What you should be able to say", ok:"Save" }) || "").trim();
    if(front && back){ addCard({ topicId:topic.id, front, back }); renderAcademy(); }
  };
}

/* ══════════════ error log (§18–20) ══════════════ */
function renderAcademyErrors(){
  const box = $("#acErrors"); if(!box) return;
  const log = errorLog({ unresolvedOnly:true });
  const pat = errorPattern();
  const rec = recoveryCandidates();

  box.innerHTML = `
    ${pat ? `<div class="rv-change" style="margin-bottom:14px"><b>${esc(pat.text)}</b><br>${esc(pat.fix)}</div>` : ""}
    ${rec.length ? `<div class="panel-sub" style="margin-bottom:10px">Topics going wrong repeatedly:</div>
      ${rec.slice(0,3).map(r => `<div class="tp">
        <div class="tp-n"><b>${esc(r.topic.name)}</b><small>${r.errors} unresolved errors</small></div>
        <button class="btn sm gold" data-bossify="${r.topic.id}">Make it a boss</button></div>`).join("")}<div class="sep"></div>` : ""}
    ${log.length ? log.slice(0, 20).map(e => `<div class="err">
        <div class="err-h"><span class="err-kind">${esc(e.kindInfo.label)}</span><span class="tiny muted">${esc(e.date)} · ${esc(e.topic ? e.topic.name : "")}</span></div>
        <div class="err-q">${esc(e.question ? e.question.text : "(question removed)")}</div>
        <div class="err-fix">${esc(e.kindInfo.fix)}</div>
        <div class="row" style="gap:8px;margin-top:8px">
          <button class="btn sm ghost" data-tocard="${e.id}">Make a card</button>
          <button class="btn sm ghost" data-resolve="${e.id}">Mark fixed</button>
        </div></div>`).join("")
      : `<div class="empty"><b>No unresolved mistakes.</b><p>Either you have not practised yet, or you have worked through everything you got wrong. The second one is the good version.</p></div>`}`;

  box.querySelectorAll("[data-bossify]").forEach(b => b.onclick = () => {
    const boss = bossFromTopic(b.dataset.bossify);
    if(boss){ renderAll(); toast("Boss summoned", `${boss.name} — five stages on the Path.`, "gold"); }
  });
  box.querySelectorAll("[data-tocard]").forEach(b => b.onclick = () => {
    const c = cardFromError(b.dataset.tocard);
    if(c){ renderAcademy(); toast("Card made", "It comes back tomorrow, then at widening gaps if you keep getting it.", "gold"); }
  });
  box.querySelectorAll("[data-resolve]").forEach(b => b.onclick = () => {
    const a = academy(); const e = (a.errors || []).find(x => x.id === b.dataset.resolve);
    if(e){ e.resolved = true; save(); invalidateAcademy(); renderAcademy(); }
  });
}

/* ══════════════ exams, plan, grades (§29–36) ══════════════ */
function renderAcademyExams(){
  const box = $("#acExams"); if(!box) return;
  const list = upcomingExams();
  box.innerHTML = list.length
    ? list.map(e => `<div class="exam">
        <div class="exam-h"><b>${esc(e.name)}</b><span>${esc(e.subject.name)} · ${esc(e.date)}</span></div>
        <div class="exam-c">${e.in === 0 ? "today" : e.in + " day" + (e.in===1?"":"s")}</div>
        <div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap">
          <button class="btn sm ghost" data-hours="${e.id}">${e.hoursPerWeek} h/week</button>
          <button class="btn sm gold" data-exboss="${e.id}">Make it a boss</button>
          <button class="btn sm danger" data-exdel="${e.id}">\u2715</button>
        </div></div>`).join("")
    : `<div class="empty"><b>No exams registered.</b><p>Add one with its date and the System will build a revision plan from what you actually know, recalculated every time you open it.</p></div>`;

  box.querySelectorAll("[data-hours]").forEach(b => b.onclick = async () => {
    const v = await sysPrompt("Hours a week for this subject", {
      msg:"Be honest rather than aspirational. The plan warns you when the arithmetic does not work, and it can only do that if this number is real.",
      inputType:"number", placeholder:"5", ok:"Save" });
    if(v){ setExamHours(b.dataset.hours, v); renderAcademy(); }
  });
  box.querySelectorAll("[data-exboss]").forEach(b => b.onclick = () => {
    const boss = bossFromExam(b.dataset.exboss);
    if(boss){ renderAll(); toast("Boss summoned", boss.name, "gold"); }
  });
  box.querySelectorAll("[data-exdel]").forEach(b => b.onclick = () => { removeExam(b.dataset.exdel); renderAcademy(); });

  /* the plan */
  const pbox = $("#acPlan"); if(!pbox) return;
  const next = list[0];
  if(!next){ pbox.innerHTML = `<p class="muted tiny">Register an exam to get a plan.</p>`; return; }
  const plan = revisionPlan(next.id);
  if(!plan){ pbox.innerHTML = `<p class="muted tiny">Add topics to ${esc(next.subject.name)} so the plan has something to order.</p>`; return; }

  pbox.innerHTML = `
    <div class="plan-head"><b>${esc(plan.exam.name)}</b> · ${plan.days} days · ~${plan.hoursTotal} hours at ${plan.hoursPerWeek}/week</div>
    <p class="tiny muted" style="margin:6px 0 12px">${esc(plan.verdict)}</p>
    ${plan.warning ? `<div class="rv-change" style="margin-bottom:12px">${esc(plan.warning)}</div>` : ""}
    ${plan.phases.filter(p => !p.skipped).map(p => `<div class="phase">
      <div class="phase-h"><b>${esc(p.label)}</b><span>${p.days} days · ~${p.hours}h</span></div>
      <div class="phase-b">${esc(p.blurb)}</div>
      ${p.focus.length ? `<div class="phase-f">${p.focus.map(f => `<span>${esc(f.t.name)}</span>`).join("")}</div>` : `<p class="tiny muted">Nothing in this phase — good.</p>`}
    </div>`).join("")}`;

  /* grades */
  const gbox = $("#acGrades"); if(!gbox) return;
  const trends = subjects().map(s => ({ s, t:gradeTrend(s.id) })).filter(x => x.t);
  gbox.innerHTML = trends.length
    ? trends.map(({ s, t }) => `<div class="grade">
        <div class="grade-h"><b>${esc(s.name)}</b><span>${t.n} recorded · latest ${Math.round(t.latest.pct*100)}%${t.delta ? ` · ${t.delta > 0 ? "▲" : "▼"} ${Math.abs(Math.round(t.delta*100))}pts` : ""}</span></div>
        ${t.gap ? `<div class="tiny muted">${esc(t.gap)}</div>` : ""}
      </div>`).join("")
    : `<p class="muted tiny">No scores recorded. Logging real results is what stops mastery from becoming a number that only reflects how you feel.</p>`;
}

/* ---------- wiring ---------- */
function renderAcademy(){
  if(!$("#acToday")) return;
  invalidateAcademy();
  try{
    renderAcademyHome(); renderAcademySubjects(); renderAcademyStudy();
    renderAcademyPractice(); renderAcademyCards(); renderAcademyErrors(); renderAcademyExams();
  }catch(e){}
}

function wireAcademy(){
  const add = $("#acAddSubject");
  if(add) add.onclick = async () => {
    const n = (await sysPrompt("Subject name", { msg:"As your school calls it.", placeholder:"e.g. Physics", ok:"Next" }) || "").trim();
    if(!n) return;
    const target = (await sysPrompt("Target grade (optional)", { msg:"Your own target. The System will never claim to predict whether you will hit it.", placeholder:"e.g. A", ok:"Add" }) || "").trim();
    addSubject({ name:n, target });
    renderAcademy(); toast("Subject added", "Now add its units and topics — or paste the syllabus outline.", "gold");
  };
  const imp = $("#acImport");
  if(imp) imp.onclick = async () => {
    const list = subjects();
    if(!list.length) return toast("No subject yet","Add a subject first.","blood");
    const pick = await sysPrompt("Which subject?", {
      msg:list.map((s,i) => `${i+1}. ${s.name}`).join("\n"), inputType:"number", placeholder:"1", ok:"Next" });
    const s = list[Number(pick) - 1]; if(!s) return;
    const text = await sysPrompt("Paste the outline", {
      msg:"Unindented lines become units. Lines starting with a space, dash or bullet become topics under the unit above.",
      placeholder:"Mechanics\n - Forces\n - Moments\nWaves\n - Refraction", ok:"Build it" });
    if(!text) return;
    const r = importOutline(s.id, text);
    renderAcademy();
    if(r) toast("Syllabus built", `${r.units} units, ${r.topics} topics. Everything starts at "not started" — that is accurate, not discouraging.`, "gold");
  };
  const ex = $("#acAddExam");
  if(ex) ex.onclick = async () => {
    const list = subjects();
    if(!list.length) return toast("No subject yet","Add a subject first.","blood");
    const pick = await sysPrompt("Which subject?", {
      msg:list.map((s,i) => `${i+1}. ${s.name}`).join("\n"), inputType:"number", placeholder:"1", ok:"Next" });
    const s = list[Number(pick) - 1]; if(!s) return;
    const date = await sysPrompt("Exam date", { msg:"YYYY-MM-DD", inputType:"date", ok:"Register" });
    if(!date) return;
    addExam({ subjectId:s.id, name:`${s.name} exam`, date });
    renderAcademy(); toast("Exam registered", "The plan below is built from days left and what you actually know.", "gold");
  };
  const gr = $("#acAddGrade");
  if(gr) gr.onclick = async () => {
    const list = subjects();
    if(!list.length) return toast("No subject yet","Add a subject first.","blood");
    const pick = await sysPrompt("Which subject?", {
      msg:list.map((s,i) => `${i+1}. ${s.name}`).join("\n"), inputType:"number", placeholder:"1", ok:"Next" });
    const s = list[Number(pick) - 1]; if(!s) return;
    const name = (await sysPrompt("What was it?", { placeholder:"e.g. mock paper 1", ok:"Next" }) || "").trim();
    const score = await sysPrompt("Score", { inputType:"number", placeholder:"58", ok:"Next" });
    const max = await sysPrompt("Out of", { inputType:"number", placeholder:"80", ok:"Save" });
    if(score == null || max == null) return;
    addGrade({ subjectId:s.id, name, score, max });
    renderAcademy();
  };
}
document.addEventListener("DOMContentLoaded", wireAcademy);
if(document.readyState !== "loading") wireAcademy();
