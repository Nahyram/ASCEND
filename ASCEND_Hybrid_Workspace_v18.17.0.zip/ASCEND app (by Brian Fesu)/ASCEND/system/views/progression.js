/* ASCEND — views/progression.js
   The Path: one page that answers "where am I, and what is next".

   Phase 4 §36 asks for exactly this and §45 explains why: v12 scattered level, XP,
   rank, skills and the Archive across four different screens, so no single view
   ever told a hunter how they were doing. Everything progression-shaped now lives
   here, and only here.

   §38 and §39 govern the feedback: fast, specific, dismissible. Nobody should
   have to sit through an animation to find out they went up a level. */
"use strict";

/* ---------- announcements (§38) ---------- */
function announceAchievements(list){
  if(!list || !list.length) return;
  const a = list[0];
  if(typeof takeover === "function") takeover({
    kind:"levelup", title:"ACHIEVEMENT UNLOCKED",
    sub:`${a.name} — ${a.blurb}`,
    reward: list.length > 1 ? `+${list.length - 1} more unlocked` : "Recorded on your Path",
  });
  else if(typeof toast === "function") toast("Achievement", a.name, "gold");
}
function announceAreas(list){
  if(!list || !list.length) return;
  const a = list[0];
  if(typeof toast === "function") toast(`${a.name} opened`, a.blurb, "gold");
}

/* ---------- standing ---------- */
function renderStanding(){
  const box = $("#pgStanding"); if(!box) return;
  const h = H(); if(!h) return;
  const s = progressStats(true);
  const rp = rankProgress();
  const need = xpNeeded(h.level);
  const season = currentSeason();

  box.innerHTML = `
    <div class="pg-hero">
      <div class="pg-lvl"><b>${h.level}</b><small>${esc(levelTitle(h.level))}</small></div>
      <div class="pg-rank"><b>${esc(rp.rank)}</b><small>${esc(rp.name)}</small></div>
    </div>
    <div class="xpbar" style="margin:12px 0 4px"><i style="width:${Math.min(100, Math.round(h.xp/need*100))}%"></i></div>
    <div class="tiny muted">${h.xp} / ${need} XP to level ${h.level + 1} · ${h.totalXp} earned in total</div>
    <div class="sep"></div>
    <div class="grid g3">
      <div class="kpi"><b>${s.cleared}</b><small>Quests cleared</small></div>
      <div class="kpi"><b>${h.streak}</b><small>Day streak</small></div>
      <div class="kpi"><b>${s.achievements}</b><small>Achievements</small></div>
    </div>
    ${rp.next ? `<div class="sep"></div>
      <div class="pg-nextrank"><b>Next rank — ${esc(rp.next.name)}</b>
      <div class="rv-list">${rp.next.missing.map(m =>
        `<div><span>${esc(m.what)}</span><b>${m.have} / ${m.need}</b></div>`).join("")}</div>
      <p class="tiny muted" style="margin-top:8px">Rank is not time served. Level gets you to the door; cleared quests, a held streak and fallen bosses open it.</p></div>`
      : `<p class="tiny muted" style="margin-top:12px">Highest rank reached.</p>`}
    ${season ? `<div class="sep"></div><p class="tiny muted">Season: <b>${esc(season.name)}</b>. Seasons only re-zero the comparison window — nothing you have earned expires with one.</p>` : ""}`;
}

/* ---------- next milestone (§37) ---------- */
function renderNextMilestone(){
  const box = $("#pgNext"); if(!box) return;
  const m = nextMilestone();
  if(!m || !m.primary){ box.innerHTML = `<p class="muted tiny">Nothing tracked yet.</p>`; return; }
  box.innerHTML = m.all.slice(0, 4).map((x, i) => `
    <div class="ms ${i === 0 ? "lead" : ""}">
      <div class="ms-k">${esc(x.kind)}</div>
      <div class="ms-b">
        <b>${esc(x.label)}</b>
        <div class="ms-bar"><i style="width:${Math.round(x.pct*100)}%"></i></div>
        <em>${esc(x.detail || "")}</em>
      </div>
      <div class="ms-n">${Math.round(x.pct*100)}%</div>
    </div>`).join("");
}

/* ---------- titles (§19) ---------- */
function renderTitles(){
  const box = $("#pgTitles"); if(!box) return;
  const list = titleList();
  const cur = equippedTitle();
  box.innerHTML = `
    <div class="ttl-cur">Currently: <b>${cur ? esc(cur.name) : "no title"}</b></div>
    <div class="ttl-grid">
      ${list.map(t => `<button class="ttl ${t.unlocked ? "" : "locked"} ${t.equipped ? "on" : ""}" data-ttl="${t.id}"
          ${t.unlocked ? "" : "disabled"} title="${esc(t.blurb)}">
          <b>${esc(t.name)}</b><small>${esc(t.blurb)}</small></button>`).join("")}
      <button class="ttl ${cur ? "" : "on"}" data-ttl="">
        <b>No title</b><small>Just your name.</small></button>
    </div>`;
  box.querySelectorAll("[data-ttl]").forEach(b => b.onclick = () => {
    equipTitle(b.dataset.ttl || null);
    renderTitles();
    if(typeof renderStatus === "function") renderStatus();
  });
}

/* ---------- bosses (§14) ---------- */
function renderBosses(){
  const box = $("#pgBosses"); if(!box) return;
  const list = allBosses();
  if(!list.length){
    box.innerHTML = `<p class="muted tiny">No boss summoned. A boss is the thing you have been avoiding for weeks — a topic that keeps costing you marks, a paper you have not sat, a project stuck at 70%. Naming it and breaking it into stages is most of the work.</p>`;
    return;
  }
  box.innerHTML = list.map((b, i) => {
    const p = bossProgress(b);
    const d = BALANCE.difficulty.find(x => x.k === b.difficulty) || {};
    return `<div class="boss ${b.done ? "done" : ""}" data-boss="${i}">
      <div class="boss-head">
        <b>${esc(b.name)}</b>
        <span class="boss-diff">${esc(d.label || b.difficulty)}</span>
        ${b.done ? `<span class="boss-tag">defeated ${esc(b.doneAt)}</span>` : `<span class="boss-tag">${p.done}/${p.n}</span>`}
      </div>
      <div class="ms-bar"><i style="width:${Math.round(p.pct*100)}%"></i></div>
      <div class="boss-stages">
        ${b.stages.map(st => `<div class="boss-st ${st.done ? "on" : ""}" data-stage="${st.id}" role="button" tabindex="0">
          <span class="tick">${st.done ? "✔" : "○"}</span><span>${esc(st.text)}</span></div>`).join("")}
      </div>
      <button class="btn sm danger" data-del="${b.id}" style="margin-top:8px">Remove</button>
    </div>`;
  }).join("");

  box.querySelectorAll("[data-boss]").forEach(el => {
    const b = list[Number(el.dataset.boss)];
    el.querySelectorAll("[data-stage]").forEach(row => {
      const act = () => {
        const st = b.stages.find(x => x.id === row.dataset.stage);
        if(st && st.done) undoBossStage(b.id, st.id);
        else clearBossStage(b.id, row.dataset.stage);
        renderPath(); if(typeof renderAll === "function") renderAll();
      };
      row.onclick = act;
      row.onkeydown = e => { if(e.key === "Enter" || e.key === " "){ e.preventDefault(); act(); } };
    });
    const del = el.querySelector("[data-del]");
    if(del) del.onclick = async () => {
      if(await sysConfirm("Remove this boss?", "The chain and its record are deleted. XP already earned from it is kept.", { ok:"Remove", danger:true })){
        deleteBoss(del.dataset.del); renderPath();
      }
    };
  });
}

function wireBossButton(){
  const btn = $("#pgBossNew"); if(!btn) return;
  btn.onclick = async () => {
    const opts = BOSS_TEMPLATES.map((t,i) => `${i+1}. ${t.name} — ${t.blurb}`).join("\n");
    const pick = await sysPrompt("What kind of boss?", {
      msg: opts + "\n\nEnter a number.", inputType:"number", placeholder:"1", ok:"Next" });
    const idx = Number(pick) - 1;
    const t = BOSS_TEMPLATES[idx]; if(!t) return;
    const name = (await sysPrompt("Name it", {
      msg: t.k === "custom"
        ? "Say what the obstacle actually is. Vague bosses do not fall."
        : `${t.blurb}\n\nName the specific one — "Quadratics", not "maths".`,
      placeholder:t.name, ok:"Summon" }) || "").trim();
    if(!name) return;
    const b = createBoss({ name, template:t.k });
    renderPath(); if(typeof renderAll === "function") renderAll();
    if(b) toast("Boss summoned", `${b.name} — ${b.stages.length} stages. Every stage pays; finishing pays properly.`, "gold");
  };
}

/* ---------- achievements (§18) ---------- */
const ACH_CAT = { progression:"Progression", consistency:"Consistency", learning:"Learning",
                  milestone:"Milestones", exploration:"Exploration", secret:"Secret" };
function renderAchievements(){
  const box = $("#pgAch"); if(!box) return;
  const list = achievementList();
  const earned = list.filter(a => a.earned).length;
  const secrets = secretsRemaining();
  const sum = $("#pgAchSum");
  if(sum) sum.textContent = `${earned} of ${list.length} shown earned${secrets ? ` · ${secrets} secret achievement${secrets===1?"":"s"} still hidden` : ""}.`;

  const groups = {};
  for(const a of list){ (groups[a.cat] = groups[a.cat] || []).push(a); }
  box.innerHTML = Object.entries(groups).map(([cat, items]) => `
    <div class="ach-group">
      <div class="ach-cat">${esc(ACH_CAT[cat] || cat)}</div>
      ${items.map(a => `<div class="ach ${a.earned ? "on" : ""}">
        <div class="ach-mark">${a.earned ? "◆" : "◇"}</div>
        <div class="ach-b"><b>${esc(a.name)}</b><em>${esc(a.blurb)}</em>
          ${a.earned ? `<span class="ach-at">earned ${esc(a.at)}</span>`
                     : `<div class="ms-bar sm"><i style="width:${Math.round(a.progress*100)}%"></i></div>`}</div>
      </div>`).join("")}
    </div>`).join("");
}

/* ---------- the world (§30) ---------- */
function renderWorld(){
  const box = $("#pgWorld"); if(!box) return;
  const map = worldMap();
  box.innerHTML = map.map(a => `
    <div class="area ${a.unlocked ? "on" : ""}">
      <div class="area-h"><b>${esc(a.name)}</b><span>${esc(a.maps)}</span></div>
      <div class="area-b">${esc(a.blurb)}</div>
      ${a.unlocked ? `<div class="area-s open">Open</div>`
        : `<div class="area-s">${a.missing.map(m => `${esc(m.what)} ${m.have}/${m.need}`).join(" · ")}</div>`}
    </div>`).join("");
}

/* ---------- personal bests (§35) ---------- */
/* views/core-views.js has owned renderRecords since v12 — it draws the 90-day
   heatmap. Naming this one the same shadowed it and the heatmap stopped being
   redrawn. Renamed rather than merged: they are two different panels. */
function renderPersonalBests(){
  const box = $("#pgRecords"); if(!box) return;
  updateRecords();
  box.innerHTML = `<div class="rv-list">${personalBests().map(r =>
    `<div><span>${esc(r.label)}</span><b>${r.v}${r.unit ? " " + esc(r.unit) : ""}</b></div>`).join("")}</div>
    <p class="tiny muted" style="margin-top:12px">Phase 4's rule, and the one worth keeping: a personal best beats a ranking. Nobody else's record changes what yours says.</p>`;
}

/* ---------- the page ---------- */
function renderPath(){ return Hooks.dispatch("renderPath", renderPathBase, this, arguments); }
/* ══════════════ the progression ledger (18.14) ══════════════

   ASCEND has kept an append-only event log since 18.10 — every XP grant, with
   its reason, its device and its timestamp — and replayed it deterministically
   on the client and again on the server. Nothing in any view rendered a single
   line of it. The student had a complete, auditable history of their own year
   and no screen showing it.

   This is that screen. Three things, in the order a student would ask them:

     what did I earn, and for what        — the entries
     does the record agree with the log   — shadow mode, shown rather than hidden
     does the server agree too            — when signed in

   The audit line is the part worth being careful about. A disagreement between
   the record and the replayed log is a defect in ASCEND, not a defect in the
   student, and the wording says so. It is never silently corrected. */
const LEDGER_PAGE = 40;
let _ledgerShown = LEDGER_PAGE;

function ledgerEntries(){
  if(typeof Log === "undefined") return [];
  return Log.events().slice().reverse();          /* newest first */
}

function renderLedger(){
  const box = $("#pgLedger");
  if(!box) return;
  if(typeof Log === "undefined"){
    box.innerHTML = `<p class="muted tiny">The ledger is not available in this build.</p>`;
    return;
  }

  const all = ledgerEntries();
  const shown = all.slice(0, _ledgerShown);
  const replayed = Log.progression();
  const audit = Log.audit();
  const base = Log.base();

  /* Grouped by day, because "what did I do on Tuesday" is the question a
     student actually asks of a history. */
  const byDay = new Map();
  for(const e of shown){
    const k = new Date(e.ts).toISOString().slice(0, 10);
    if(!byDay.has(k)) byDay.set(k, []);
    byDay.get(k).push(e);
  }

  const head = `
    <div class="rv-list">
      <div><span>Recorded</span><b>${all.length} entr${all.length === 1 ? "y" : "ies"}</b></div>
      <div><span>XP the log accounts for</span><b>${replayed.totalXp.toLocaleString()}</b></div>
      <div><span>Level the log replays to</span><b>${replayed.level}</b></div>
      ${base.totalXp ? `<div><span>Folded into the snapshot</span><b>${base.totalXp.toLocaleString()} XP</b></div>` : ""}
    </div>`;

  const auditLine = !audit ? "" : audit.agrees
    ? `<p class="tiny muted" style="margin-top:10px">The log and your record agree exactly. Every point on your profile can be traced to an entry below.</p>`
    : `<p class="tiny" style="margin-top:10px;color:var(--blood)">The log and your record disagree: ${
        audit.diffs.map(d => `${esc(d.field)} reads ${d.live} but the log replays to ${d.replayed}`).join("; ")
      }. That is a fault in ASCEND, not in your work, and nothing has been changed to hide it. Your record is untouched.</p>`;

  const serverLine = (() => {
    const c = typeof cloud === "function" ? cloud() : null;
    if(!c || c.mode !== "account") return "";
    if(c.progressionAgrees === null || c.progressionAgrees === undefined)
      return `<p class="tiny muted">The server has not replayed this log yet. Sync to have it check.</p>`;
    return c.progressionAgrees
      ? `<p class="tiny muted">Your server replayed the same entries and reached the same total.</p>`
      : `<p class="tiny" style="color:var(--blood)">Your server replays this log to a different total. Nothing has been taken away; it is recorded so it can be looked at.</p>`;
  })();

  const body = !shown.length
    ? `<p class="muted tiny">Nothing recorded yet. Clear a quest and the first entry appears here.</p>`
    : [...byDay.entries()].map(([day, evs]) => {
        const total = evs.reduce((n, e) => n + (Number(e.data && e.data.n) || 0), 0);
        return `
        <div class="led-day">
          <div class="led-head"><b>${esc(new Date(day + "T12:00:00").toDateString())}</b><span>+${total} XP</span></div>
          ${evs.map(e => `
            <div class="led-row">
              <span class="led-xp">+${Number(e.data && e.data.n) || 0}</span>
              <span class="led-why">${esc((e.data && e.data.why) || "XP granted")}</span>
              <span class="led-when">${esc(new Date(e.ts).toTimeString().slice(0, 5))}</span>
            </div>`).join("")}
        </div>`;
      }).join("");

  const more = all.length > _ledgerShown
    ? `<button class="btn sm ghost" id="pgLedMore">Show ${Math.min(LEDGER_PAGE, all.length - _ledgerShown)} more</button>`
    : "";

  box.innerHTML = head + auditLine + serverLine + `<div class="ledger">${body}</div>` + more;
  const btn = $("#pgLedMore");
  if(btn) btn.onclick = () => { _ledgerShown += LEDGER_PAGE; renderLedger(); };
}

/* ══════════════ vacation mode (18.15) ══════════════ */

/* The track picker is inline in the panel rather than in a dialog. sysPrompt()
   takes a title, a message and one input — it has no multi-select, and inventing
   an `html:` option for it would have added a second dialog API to maintain for
   one screen. Checkboxes in the panel are also simply better here: the student
   can see all seven with their descriptions at once. */
let _vacPicking = false;

function renderVacation(){
  const box = $("#pgVacation"); if(!box) return;
  if(typeof vacationOn !== "function"){ box.innerHTML = ""; return; }

  const on = vacationOn();
  const sum = typeof vacationSummary === "function" ? vacationSummary() : null;
  const current = on && sum ? sum.tracks.map(t => t.k) : [];

  const picker = (chosen) => `
    <div class="vac-tracks-list">
      ${VACATION_TRACKS.map(t => `
        <label class="chk-row${chosen.includes(t.k) ? " on" : ""}">
          <input type="checkbox" data-vt="${t.k}"${chosen.includes(t.k) ? " checked" : ""}>
          <span><b>${esc(t.label)}</b> — ${esc(t.blurb)}</span>
        </label>`).join("")}
    </div>
    <p class="tiny muted">Pick as few as one. A holiday campaign as heavy as term time is one nobody finishes.</p>`;

  if(on && sum && !_vacPicking){
    box.innerHTML = `
      <div class="vac-sum">
        <span>Day <b>${sum.daysIn}</b></span>
        ${sum.daysLeft !== null ? `<span><b>${sum.daysLeft}</b> left</span>` : `<span>no end date set</span>`}
        <span><b>${sum.xp.toLocaleString()}</b> XP earned</span>
        <span><b>${sum.cleared}</b> cleared</span>
      </div>
      <p class="tiny muted" style="margin-top:8px">Your timetable is untouched and comes back exactly as it was. While this is on, the board is the campaign and no mandatory quest can be missed — a holiday cannot cost you a penalty or a streak.</p>
      <div class="vac-tracks">${sum.tracks.map(t => `<span class="chip on">${esc(t.label)}</span>`).join("")}</div>
      <div class="row" style="gap:8px;flex-wrap:wrap">
        <button class="btn sm ghost" id="pgVacEdit">Change what I am keeping up</button>
        <button class="btn sm gold" id="pgVacEnd">Back to school</button>
      </div>`;
    $("#pgVacEnd").onclick = async () => {
      if(await sysConfirm("End vacation mode?", "Your timetable returns exactly as it was. Everything you cleared during the vacation stays on your record.", { ok:"Back to school" })){
        endVacation("ended by the hunter"); renderPath(); if(typeof renderHome === "function") renderHome();
      }
    };
    $("#pgVacEdit").onclick = () => { _vacPicking = true; renderVacation(); };
    return;
  }

  if(_vacPicking){
    box.innerHTML = picker(current) + `
      <div class="row" style="gap:8px;flex-wrap:wrap">
        <button class="btn sm gold" id="pgVacSave">${on ? "Update the campaign" : "Next"}</button>
        <button class="btn sm ghost" id="pgVacCancel">Cancel</button>
      </div>`;
    $("#pgVacCancel").onclick = () => { _vacPicking = false; renderVacation(); };
    $("#pgVacSave").onclick = async () => {
      const tracks = [...box.querySelectorAll("[data-vt]:checked")].map(x => x.dataset.vt);
      if(!tracks.length){ sysAlert("Pick at least one", "A vacation with nothing on the board is just an app you stop opening."); return; }
      if(on){
        const r = setVacationTracks(tracks);
        _vacPicking = false;
        if(!r.ok) sysAlert("Not changed", r.why);
        renderPath(); if(typeof renderHome === "function") renderHome();
        return;
      }
      const to = (await sysPrompt("When does school start again?", {
        msg:"Optional. With a date, vacation mode ends itself on the day term resumes — including if the app was closed the whole time.",
        inputType:"date", ok:"Start" }) || "").trim();
      const r = startVacation({ to: to || null, tracks });
      _vacPicking = false;
      if(!r.ok){ sysAlert("Could not start", r.why); renderVacation(); return; }
      renderPath(); if(typeof renderHome === "function") renderHome();
      toast("Vacation mode", `${r.quests} home quest${r.quests === 1 ? "" : "s"} on the board. Your timetable is waiting where you left it.`, "gold");
    };
    return;
  }

  box.innerHTML = `
    <p class="tiny muted">School terms end. The board does not know that on its own: it keeps asking for lessons that are not happening, marks them missed, and takes a streak you did nothing to lose. Turn this on for the holidays.</p>
    <button class="btn sm gold" id="pgVacStart" style="margin-top:10px">Start a vacation</button>`;
  $("#pgVacStart").onclick = () => { _vacPicking = true; renderVacation(); };
}

function renderPathBase(){
  if(!$("#pgStanding")) return;
  /* Three separate awards. They shared one try block, so a throw in
     checkAchievements() silently skipped the world check and the rank
     recalculation too — the student would simply not be promoted, with nothing
     anywhere saying why. */
  safeRender("achievements", checkAchievements);
  safeRender("world check", checkWorld);
  safeRender("rank", applyRank);
  renderNextMilestone();
  renderStanding();
  renderTitles();
  renderBosses();
  renderAchievements();
  renderWorld();
  renderPersonalBests();
  safeRender("vacation", renderVacation);
  safeRender("ledger", renderLedger);
}

document.addEventListener("DOMContentLoaded", wireBossButton);
if(document.readyState !== "loading") wireBossButton();
