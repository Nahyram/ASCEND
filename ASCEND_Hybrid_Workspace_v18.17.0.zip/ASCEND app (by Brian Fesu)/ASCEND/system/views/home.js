/* THE SYSTEM v18 — views/home.js
   Home is the command centre. It answers six questions and nothing else:

     1 What am I trying to achieve?     the current objective
     2 What should I do now?            one action, chosen
     3 Why?                             the reason, in numbers
     4 How am I progressing?            today, and the streak behind it
     5 What is blocking me?             the weakest important area
     6 What is the next milestone?      the nearest fixed date

   v17 answered two of those. The directive picked the first overdue quest by its
   own rule and then called nextBestAction() only to *annotate* that choice — so
   the ranked engine was consulted after the decision was made and ignored
   whenever it disagreed. Home's rendered text mentioned no goal, no mastery and
   no project at all.

   So the directive is now the ranked engine's top result, whatever subsystem it
   came from, and the reason printed underneath is that engine's own sentence.
   Nothing is invented here: every number below is read from a service, and where
   a service has nothing to say the block says so plainly rather than filling the
   space with a zero. An empty Academy reads "no subjects yet", because a student
   who has recorded nothing is not weak at everything — they are unmeasured. */
"use strict";

function greeting(){
  const hr = new Date().getHours();
  if(hr < 5)  return "Still awake";
  if(hr < 12) return "Good morning";
  if(hr < 17) return "Good afternoon";
  if(hr < 22) return "Good evening";
  return "Late shift";
}

/* ---------- 1 · the objective ----------
   The goal most at risk: behind pace first, then nearest due. */
function homeObjective(){
  if(typeof allGoals !== "function") return null;
  const live = allGoals()
    .map(g => ({ g, p: goalProgress(g) }))
    .filter(x => x.p.steps > 0 && x.p.done < x.p.steps);
  if(!live.length) return null;
  live.sort((a,b) => {
    const ad = a.p.daysLeft ?? 9999, bd = b.p.daysLeft ?? 9999;
    return (Number(b.p.behind) - Number(a.p.behind)) || (ad - bd);
  });
  const top = live[0];
  const chain = typeof goalChain === "function" ? goalChain(top.g.id) : [top.g];
  return { goal: top.g, progress: top.p, chain: chain.map(x => x.name), others: live.length - 1 };
}

/* ---------- 5 · the weakest important area ----------
   Weakness only counts where it has been demonstrated. A topic nobody has
   attempted is not weak, it is unknown, and calling it weak would be the
   "arbitrary number without evidence" the spec rules out. */
function homeWeakest(){
  if(typeof academyOverview !== "function") return null;
  let ov = null;
  try{ ov = academyOverview(); }catch(e){ return null; }
  if(!ov || !ov.subjects.length) return { empty:"No subjects added yet." };

  let stuck = [];
  try{ stuck = typeof recoveryCandidates === "function" ? recoveryCandidates() : []; }catch(e){}
  if(stuck[0] && stuck[0].topic){
    return {
      kind:"errors",
      name: stuck[0].topic.name,
      detail: `${stuck[0].errors} unresolved mistakes · ${Math.round(((stuck[0].mastery || {}).pct || 0) * 100)}% mastery`,
      why:"Repeated mistakes on one topic are the only signal here that never fixes itself by moving on.",
      go:["academy","ac-practice"],
    };
  }
  const weak = (ov.weak || [])[0];
  if(weak && weak.t){
    return {
      kind:"mastery",
      name: weak.t.name,
      detail: `${Math.round(weak.m.pct * 100)}% mastery`,
      why:"The lowest demonstrated mastery of everything you have actually attempted.",
      go:["academy","ac-subjects"],
    };
  }
  if(!ov.topics) return { empty:"Subjects added, but no topics yet." };
  return { empty:"Nothing is measurably weak yet." };
}

/* ---------- 6 · the next milestone ----------
   The nearest immovable date across exams, deadlines and applications — dates
   other people set, which is what separates them from a quest. */
function homeMilestone(){
  const out = [];
  const h = typeof H === "function" ? H() : null;
  if(!h) return null;
  const until = d => {
    if(typeof daysUntil === "function") return daysUntil(d);
    if(!d) return null;
    return Math.round((new Date(d + "T00:00:00") - new Date(todayKey() + "T00:00:00")) / 86400000);
  };

  for(const d of (h.deadlines || [])){
    const days = until(d.date);
    if(days !== null && days >= 0) out.push({ kind:"Deadline", name:d.name, days, go:["quests","q-timed"] });
  }
  try{
    const ov = typeof academyOverview === "function" ? academyOverview() : null;
    if(ov && ov.nextExam) out.push({ kind:"Exam", name: ov.nextExam.name || "Exam", days: ov.nextExam.in, go:["academy","ac-exams"] });
  }catch(e){}
  try{
    if(typeof oppList === "function"){
      const DONE = ["applied","registered","participating","result","completed","rejected","withdrawn"];
      for(const o of oppList()){
        if(!o.deadline || DONE.includes(o.stage)) continue;
        const days = until(o.deadline);
        if(days !== null && days >= 0) out.push({ kind:"Application", name:o.name, days, go:["beyond","bo-apply"] });
      }
    }
  }catch(e){}
  out.sort((a,b) => a.days - b.days);
  return out[0] || null;
}

function renderHome(){ return Hooks.dispatch("renderHome", renderHomeBase, this, arguments); }
function renderHomeBase(){
  const h = typeof H === "function" ? H() : null;
  if(!h || !$("#gateRing")) return;

  /* ---------- 4 · progression: today, not lifetime ---------- */
  const qs = questsFor(), done = qs.filter(isDone).length;
  const fill = qs.length ? Math.round(done / qs.length * 100) : 0;
  $("#gateRing").style.setProperty("--fill", fill);
  $("#gatePct").textContent = qs.length ? fill + "% today" : "no quests";
  $("#gateHello").textContent = greeting() + ",";
  const line = $("#gateLine"); if(line) line.textContent = coachHeadline();

  /* ---------- 1 · the objective ---------- */
  const ob = $("#homeObjective");
  if(ob){
    const o = homeObjective();
    if(!o){
      ob.innerHTML = `<div class="eyebrow">Current objective</div>
        <div class="what">No goal with steps yet.</div>
        <div class="when">A goal that never becomes an action is a wish. Set one and break it down.</div>
        <button class="btn sm" id="obGo">Set a goal</button>`;
    } else {
      const p = o.progress;
      ob.innerHTML = `<div class="eyebrow">Current objective${o.others ? ` · ${o.others} other${o.others === 1 ? "" : "s"} live` : ""}</div>
        <div class="what">${esc(o.goal.name)}</div>
        ${o.chain.length > 1 ? `<div class="when">${esc(o.chain.slice(0, -1).join(" → "))}</div>` : ""}
        <div class="objbar"><i style="width:${Math.round(p.pct * 100)}%"></i></div>
        <div class="when">${p.done} of ${p.steps} steps${p.daysLeft !== null ? ` · ${p.daysLeft} day${p.daysLeft === 1 ? "" : "s"} left` : ""}${p.behind ? ` · <b class="warn">behind pace</b>` : ""}</div>
        ${p.next ? `<div class="when">Next step: ${esc(p.next.text || p.next.name || "")}</div>` : ""}
        <button class="btn sm" id="obGo">Open the ladder</button>`;
    }
    const b = $("#obGo"); if(b) b.onclick = () => go("quests", "q-goals");
  }

  /* ---------- 2 + 3 · the directive, and why ----------
     One ranked call across every engine. Whatever comes back first is the
     directive — a quest, a failing topic, a stalled project or a closing
     application. v17 could only ever show a quest. */
  const box = $("#directive");
  if(box){
    let top = null;
    try{ top = typeof nextBestAction === "function" ? nextBestAction() : null; }catch(e){}

    if(!top){
      const open = qs.filter(q => !isDone(q));
      if(open.length){
        const q0 = open[0];
        box.innerHTML = `<div class="mark">▸</div><div class="body">
          <div class="eyebrow">Do this next</div>
          <div class="what">${esc(q0.name)}</div>
          <div class="when">${fmt12(q0.time)} · ${q0.xp} XP</div></div>
          <button class="btn sm" id="dirGo">Clear it</button>`;
        const b = $("#dirGo"); if(b) b.onclick = () => toggleQuest(q0);
      } else {
        box.innerHTML = `<div class="mark">✔</div><div class="body">
          <div class="eyebrow">Directive</div>
          <div class="what">Nothing is owed. The day is cleared.</div>
          <div class="when">Rest counts. Tomorrow's quests are already waiting.</div></div>`;
      }
    } else {
      const q = top.quest;
      const late = q ? toMin(q.time) < nowMin() : false;
      const mins = q ? Math.abs(toMin(q.time) - nowMin()) : null;
      let chain = null;
      try{ chain = q && typeof questChain === "function" ? questChain(q) : null; }catch(e){}
      const label = (typeof TIER_LABEL === "object" && TIER_LABEL[top.tier]) || "Do this next";
      box.innerHTML = `<div class="mark">${late ? "!" : "▸"}</div><div class="body">
        <div class="eyebrow">${esc(late ? "Overdue" : label)}</div>
        <div class="what">${esc(top.title)}</div>
        ${q ? `<div class="when">${fmt12(q.time)} · ${late ? `${mins} min late` : `in ${mins} min`} · ${q.xp} XP${q.mand ? " · mandatory" : ""}</div>` : ""}
        <div class="why">${esc(top.because)}</div>
        ${chain ? `<div class="when chainline">Serves: ${chain.map(c => esc(c.text)).join(" · ")}</div>` : ""}
        </div>
        <button class="btn sm" id="dirGo">${esc(q ? "Clear it" : (top.action || "Open"))}</button>`;
      const b = $("#dirGo");
      if(b) b.onclick = () => {
        if(q) toggleQuest(q);
        else if(top.go) go(top.go[0], top.go[1]);
      };
    }
  }

  /* ---------- 5 · what is blocking me ---------- */
  const wk = $("#homeWeak");
  if(wk){
    const w = homeWeakest();
    if(!w || w.empty){
      wk.innerHTML = `<div class="eyebrow">Weakest area</div>
        <div class="when">${esc((w && w.empty) || "The Academy has nothing recorded yet.")} Practice is what makes this block say something useful.</div>
        <button class="btn sm ghost" id="wkGo">Open the Academy</button>`;
      const b = $("#wkGo"); if(b) b.onclick = () => go("academy", "ac-subjects");
    } else {
      wk.innerHTML = `<div class="eyebrow">Weakest area</div>
        <div class="what">${esc(w.name)}</div>
        <div class="when">${esc(w.detail)}</div>
        <div class="why">${esc(w.why)}</div>
        <button class="btn sm" id="wkGo">Work on it</button>`;
      const b = $("#wkGo"); if(b) b.onclick = () => go(w.go[0], w.go[1]);
    }
  }

  /* ---------- 6 · the next milestone ---------- */
  const msb = $("#homeMilestone");
  if(msb){
    const m = homeMilestone();
    if(!m){
      msb.innerHTML = `<div class="eyebrow">Next milestone</div>
        <div class="when">No fixed dates recorded. Exams, deadlines and application closes land here once they exist.</div>`;
    } else {
      const urgent = m.days <= 3;
      msb.innerHTML = `<div class="eyebrow">Next milestone</div>
        <div class="what">${esc(m.name)}</div>
        <div class="when">${esc(m.kind)} · ${m.days === 0 ? "today" : `in ${m.days} day${m.days === 1 ? "" : "s"}`}${urgent ? ` · <b class="warn">close</b>` : ""}</div>
        <button class="btn sm ${urgent ? "" : "ghost"}" id="msGo">Open</button>`;
      const b = $("#msGo"); if(b) b.onclick = () => go(m.go[0], m.go[1]);
    }
  }

  /* ---------- the coach ---------- */
  const cb = $("#coachBox");
  if(cb){
    const notes = coachNotes(4);
    cb.innerHTML = notes.length ? notes.map((n, i) =>
      `<div class="coach-note ${n.tone}"${n.go ? ` data-coachgo="${i}"` : ""} ${n.go ? 'role="button" tabindex="0" style="cursor:pointer"' : ""}>
         <div class="k">${esc(n.icon)}</div>
         <div class="t">${esc(n.text)}<em>${esc(n.detail)}</em></div>
       </div>`).join("")
      : `<p class="coach-empty">Nothing worth flagging today. That is a good sign, not an empty one.</p>`;
    $$("[data-coachgo]").forEach(el => {
      const n = notes[Number(el.dataset.coachgo)];
      const jump = () => go(n.go[0], n.go[1]);
      el.onclick = jump;
      el.onkeydown = e => { if(e.key === "Enter" || e.key === " "){ e.preventDefault(); jump(); } };
    });
  }
}

/* quick actions — the four things reached for most, one tap from Home */
function wireQuickActions(){
  const map = {
    qaFocus:   () => go("quests", "q-focus"),
    qaTimer:   () => { go("quests", "q-focus"); const b = $("#btnSession"); if(b) b.click(); },
    qaTrain:   () => go("grow", "tr-quest"),
    qaTutor:   () => go("learn", "l-tutor"),
    qaLibrary: () => go("learn", "l-books"),
    qaVault:   () => go("wealth", "w-vault"),
    qaRecord:  () => go("insight"),
    qaWhy:     () => go("grow", "st-why"),
  };
  for(const [id, fn] of Object.entries(map)){
    const el = $("#" + id); if(el) el.onclick = fn;
  }
}
document.addEventListener("DOMContentLoaded", wireQuickActions);
if(document.readyState !== "loading") wireQuickActions();
