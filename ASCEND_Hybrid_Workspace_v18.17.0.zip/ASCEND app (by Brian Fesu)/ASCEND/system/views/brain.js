/* ASCEND — views/brain.js
   Everything the intelligence layer paints.

   Phase 3 §34 says intelligence should appear where the work is, not sit in a
   chatbot page. So this file renders in four places rather than one: the focus
   strip and recovery banner on Home, the briefing, the pattern list with its
   confidence labels, the proposal queue, and the weekly review. The services
   compute; nothing here decides anything.

   The confidence label is printed next to every claim on purpose. A student who
   can see "early signal, 14 observations" learns to weigh it. Hiding it would make
   the panel look more authoritative and be worth less. */
"use strict";

const CONF_PILL = {
  high:   { t:"high confidence",  c:"cf-hi" },
  medium: { t:"moderate",         c:"cf-md" },
  low:    { t:"early signal",     c:"cf-lo" },
};
function confPill(conf){
  if(!conf) return "";
  const p = CONF_PILL[conf.level] || CONF_PILL.low;
  return `<span class="conf ${p.c}" title="Based on ${conf.n} observations">${p.t} · n=${conf.n}</span>`;
}

/* ══════════════ Home: focus strip ══════════════ */
function renderFocusStrip(hostId){
  const host = $("#" + hostId); if(!host) return;
  const g = focusGuidance();
  const cur = g && g.asked ? g.level : null;
  host.innerHTML = `
    <div class="fs-label">Focus today</div>
    <div class="fs-btns">${[1,2,3,4,5].map(n =>
      `<button class="fs-b${cur === n ? " on" : ""}" data-f="${n}" aria-pressed="${cur===n}" title="${n} of 5">${n}</button>`).join("")}</div>
    <div class="fs-note">${esc(g ? g.text : "")}</div>`;
  host.querySelectorAll(".fs-b").forEach(b => b.onclick = () => {
    setFocusToday(Number(b.dataset.f));
    invalidateModel();
    renderFocusStrip(hostId);
    if(hostId === "homeFocus" && typeof renderHome === "function") renderHome();
    if(typeof renderBrief === "function" && currentView === "insight") renderBrief();
  });
}

/* ══════════════ Home: recovery banner ══════════════ */
function renderRecoveryBanner(){
  const host = $("#homeRecovery"); if(!host) return;
  const st = recoveryState();
  if(st.active){
    const keep = recoveryQuests();
    host.innerHTML = `<div class="rec-band on">
      <b>Recovery · ${st.daysLeft} day${st.daysLeft===1?"":"s"} left</b>
      <span>The board is down to ${keep.length} quest${keep.length===1?"":"s"} and penalties are suspended. This is a plan, not a lapse.</span>
      <button class="btn sm ghost" id="recEnd">End early</button></div>`;
    const b = $("#recEnd"); if(b) b.onclick = async () => {
      if(await sysConfirm("End recovery now?", "The full board returns and penalties resume at the next rollover.", { ok:"End it" })){
        endRecovery(); renderAll();
      }
    };
  } else if(st.suggest){
    host.innerHTML = `<div class="rec-band">
      <b>${st.missed} day${st.missed===1?"":"s"} under 25% cleared</b>
      <span>A shorter board for a few days rebuilds momentum faster than trying to catch up on all of it. Penalties pause while it runs.</span>
      <button class="btn sm gold" id="recGo">Start a 3-day recovery</button></div>`;
    const b = $("#recGo"); if(b) b.onclick = () => { startRecovery(3); renderAll(); toast("Recovery started","Three days on a shorter board. Clear it and the streak survives.","gold"); };
  } else {
    host.innerHTML = "";
  }
}

/* ══════════════ Insight → Brief ══════════════ */
/* View state, deliberately not on the hunter record: how long you have tonight
   is not a fact about you, and persisting it would mean a Saturday inheriting
   Tuesday's twenty minutes. */
let _brainBudget = 0;

function renderBrief(){
  if(!$("#brBody")) return;
  const b = dailyBriefing(); if(!b) return;

  $("#brHeadline").textContent = b.headline;
  renderFocusStrip("brFocus");

  const parts = [];
  if(b.recovery) parts.push(`<div class="br-row rec"><div class="br-k">Recovery</div><div class="br-v">${b.recovery.daysLeft} day${b.recovery.daysLeft===1?"":"s"} left. Penalties suspended. Finish the short board — that is the whole objective today.</div></div>`);
  if(b.carryover) parts.push(`<div class="br-row warn"><div class="br-k">Carried over</div><div class="br-v">${esc(b.carryover.text)}<em>${b.carryover.names.map(esc).join(" · ")}</em></div></div>`);
  if(b.priority) parts.push(`<div class="br-row hi"><div class="br-k">Priority</div><div class="br-v"><b>${esc(b.priority.title)}</b><em>${esc(b.priority.because)}</em></div></div>`);
  b.secondary.forEach(r => parts.push(`<div class="br-row"><div class="br-k">Then</div><div class="br-v"><b>${esc(r.title)}</b><em>${esc(r.because)}</em></div></div>`));
  if(b.deadlines.length) parts.push(`<div class="br-row"><div class="br-k">Deadlines</div><div class="br-v">${b.deadlines.map(d => `${esc(d.name)} <span class="muted">(${d.in === 0 ? "today" : d.in + "d"})</span>`).join("<br>")}</div></div>`);
  if(!parts.length) parts.push(`<p class="muted tiny">Nothing is scheduled and nothing is owed. That is a legitimate state, not an empty screen.</p>`);
  $("#brBody").innerHTML = parts.join("");

  /* the ranked list, fitted to the time the student says they have

     18.12 added plannedRecommendations() and scheduleActionAsQuest() and wired
     neither to anything a student could press. Both were reachable only from
     their own test suite — capability that exists in the code and not in the
     product, which is the same defect as a button that does nothing, arriving
     from the other direction. */
  const budget = _brainBudget;
  const planned = budget ? plannedRecommendations(budget, { max:6 }) : null;
  const recs = planned ? planned.plan : recommendations({ max:6 });

  const box = $("#brRecs");
  box.innerHTML = recs.length ? `
    <div class="budget-row">
      <span class="tiny muted">I have</span>
      ${[0, 20, 45, 90].map(m => `<button class="btn xs ${budget === m ? "gold" : "ghost"}" data-budget="${m}">${
        m ? m + " min" : "as long as it takes"}</button>`).join("")}
    </div>
    ${planned ? `<p class="tiny muted" style="margin:6px 0 10px">${esc(planned.note)}</p>` : ""}
    ` + recs.map((r,i) => `
    <div class="rec-row ${r.tier}${r.fits === false ? " wont-fit" : ""}" data-rec="${i}">
      <span class="rec-tier">${TIER_LABEL[r.tier]}</span>
      <div class="rec-body">
        <b>${esc(r.title)}</b>
        <em>${esc(r.because)}</em>
        <span class="rec-time">${r.minutes} min${
          r.fits === false ? (r.overruns
            ? ` · will not fit, and is not optional` 
            : ` · ${r.shortfall} min more than you have`) : ""}</span>
      </div>
      <span class="rec-acts">
        <button class="btn sm ghost" data-do>${esc(r.action || "Open")}</button>
        ${r.quest ? "" : `<button class="btn sm ghost" data-quest title="Put this on the board">+ Quest</button>`}
      </span>
    </div>`).join("")
    : `<p class="muted tiny">Nothing to rank — the board is clear.</p>`;

  box.querySelectorAll("[data-budget]").forEach(el => {
    el.onclick = () => { _brainBudget = Number(el.dataset.budget) || 0; renderBrief(); };
  });
  box.querySelectorAll("[data-rec]").forEach(el => {
    const r = recs[Number(el.dataset.rec)];
    el.querySelector("[data-do]").onclick = () => {
      if(r.quest && typeof toggleQuest === "function" && r.action === "Clear it"){ toggleQuest(r.quest); renderBrief(); return; }
      if(r.go) go(r.go[0], r.go[1]);
    };
    const q = el.querySelector("[data-quest]");
    if(q) q.onclick = () => {
      const out = scheduleActionAsQuest(r);
      if(out.created) toast("On the board", `"${out.quest.name}" is now a quest. Clearing it settles the thing it came from.`, "gold");
      else toast("Not scheduled", out.reason || "That one cannot go on the board.", "blood");
      renderBrief();
    };
  });

  /* playstyle */
  const m = userModel();
  const st = $("#brStyle");
  st.innerHTML = m.playstyle.map(t => `
    <div class="ps-row">
      <div class="ps-name">${esc(t.label)} ${confPill(t.conf)}</div>
      <div class="ps-bar"><i style="width:${Math.round(t.score*100)}%"></i></div>
      <div class="ps-why">${esc(t.blurb)}</div>
    </div>`).join("");

  markBriefRead();
}

/* ══════════════ Insight → Patterns ══════════════ */
function renderPatterns(){
  const box = $("#anaPatterns"); if(!box) return;
  const ready = patternReadiness();
  if(!ready.ready){
    box.innerHTML = `<p class="muted tiny">The engine is still reading you. ${ready.have} of ${ready.need} quest-days recorded — below that, any pattern it reported would be noise wearing a confident font.</p>`;
    return;
  }
  const ps = detectPatterns({ max:8 });
  if(!ps.length){
    box.innerHTML = `<p class="muted tiny">No pattern in your record is strong enough to report. With ${ready.have} quest-days behind it, that is a real finding rather than a gap: your days are running evenly.</p>`;
    return;
  }
  box.innerHTML = ps.map((p,i) => `
    <div class="pat" data-pat="${i}">
      <div class="pat-head"><span class="pat-kind">${esc(p.kind)}</span>${confPill(p.conf)}</div>
      <div class="pat-title">${esc(p.title)}</div>
      <div class="pat-detail">${esc(p.detail)}</div>
      ${p.go ? `<button class="btn sm ghost">Go there</button>` : ""}
    </div>`).join("");
  box.querySelectorAll("[data-pat]").forEach(el => {
    const p = ps[Number(el.dataset.pat)];
    const b = el.querySelector("button");
    if(b && p.go) b.onclick = () => go(p.go[0], p.go[1]);
  });
}

/* ══════════════ Insight → Plan ══════════════ */
function renderPlan(){
  if(!$("#plProposals")) return;

  /* recovery */
  const st = recoveryState();
  const rb = $("#plRecovery");
  if(st.active){
    const keep = recoveryQuests();
    rb.innerHTML = `<p class="tiny">Active until <b>${st.plan.until}</b> · ${st.daysLeft} day${st.daysLeft===1?"":"s"} left. Penalties are suspended.</p>
      <div class="rec-keep">${keep.map(q => `<span>${esc(q.name)}</span>`).join("")}</div>
      <button class="btn sm ghost" id="plRecEnd" style="margin-top:10px">End recovery</button>`;
    $("#plRecEnd").onclick = () => { endRecovery(); renderAll(); };
  } else if(st.suggest){
    rb.innerHTML = `<p class="tiny">The last ${st.missed} scheduled day${st.missed===1?"":"s"} came in under 25% cleared. Recovery cuts the board to the ${recoveryQuests().length} cheapest mandatory quests and suspends penalties until it ends.</p>
      <div class="row" style="gap:8px;margin-top:10px">
        <button class="btn sm gold" data-rec-days="3">3 days</button>
        <button class="btn sm ghost" data-rec-days="5">5 days</button>
        <button class="btn sm ghost" data-rec-days="7">7 days</button></div>`;
    rb.querySelectorAll("[data-rec-days]").forEach(b => b.onclick = () => {
      startRecovery(Number(b.dataset.recDays)); renderAll();
      toast("Recovery started", "Short board, no penalties. Finish it and the streak holds.", "gold");
    });
  } else {
    rb.innerHTML = `<p class="muted tiny">Not needed. Recovery offers itself after two consecutive days under 25% cleared, and you are not there.</p>`;
  }

  /* proposals */
  const props = adaptiveProposals();
  const box = $("#plProposals");
  box.innerHTML = props.length ? props.map((p,i) => `
    <div class="prop ${p.severity}" data-prop="${i}">
      <div class="prop-title">${esc(p.title)}</div>
      <div class="prop-detail">${esc(p.detail)}</div>
      <div class="prop-why"><b>Why:</b> ${esc(p.why)}</div>
      <div class="prop-why"><b>If you accept:</b> ${esc(p.effect)}</div>
      <div class="prop-acts">
        <button class="btn sm gold" data-a="accept">Accept</button>
        <button class="btn sm ghost" data-a="snooze">Not now</button>
        <button class="btn sm ghost" data-a="reject">No</button>
      </div>
    </div>`).join("")
    : `<p class="muted tiny">Nothing to propose. The board and the record are in agreement.</p>`;
  box.querySelectorAll("[data-prop]").forEach(el => {
    const p = props[Number(el.dataset.prop)];
    el.querySelectorAll("[data-a]").forEach(b => b.onclick = async () => {
      const a = b.dataset.a;
      if(a === "accept"){
        if(!await sysConfirm(p.title, p.effect + "\n\nApply it now?", { ok:"Apply" })) return;
        acceptProposal(p.id); renderAll(); toast("Applied", p.title, "gold");
      } else if(a === "snooze"){
        snoozeProposal(p.id, 7); renderPlan(); toast("Snoozed", "Back in a week if the record still supports it.");
      } else {
        rejectProposal(p.id); renderPlan();
        toast("Rejected", "Noted. Twice and it stops being offered.");
      }
    });
  });

  /* ledger */
  const b = brain();
  const led = $("#plLedger");
  const rows = b && b.decisions ? b.decisions.slice(-12).reverse() : [];
  led.innerHTML = rows.length
    ? `<table><thead><tr><th>Date</th><th>Proposal</th><th>You said</th></tr></thead><tbody>${
        rows.map(d => `<tr><td>${esc(d.at)}</td><td>${esc(String(d.id).split(":")[0])}</td><td>${esc(d.verdict)}${d.note ? " · " + esc(d.note) : ""}</td></tr>`).join("")
      }</tbody></table>`
    : `<p class="muted tiny">No decisions yet. Every accept, snooze or refusal is logged here so the System can be held to what it suggested.</p>`;
}

/* ══════════════ Insight → Review ══════════════ */
function renderReview(){
  if(!$("#rvBody")) return;
  const r = weeklyReview(); if(!r) return;
  $("#rvRange").textContent = `${r.from} to ${r.to}`;

  if(!r.enough){
    $("#rvBody").innerHTML = `<p class="muted tiny">Only ${r.scheduled} scheduled quests in the last seven days — too thin to review honestly. It needs about ten.</p>`;
    $("#rvChange").textContent = r.change;
    return;
  }
  const arrow = n => n > 0.02 ? `<span class="up">▲ ${mPct(n)}pts</span>` : n < -0.02 ? `<span class="dn">▼ ${mPct(Math.abs(n))}pts</span>` : `<span class="fl">— level</span>`;
  const CATLAB = { study:"Study", body:"Training", mind:"Deep work", discipline:"Discipline", rest:"Rest" };

  $("#rvBody").innerHTML = `
    <div class="grid g3">
      <div class="kpi"><b>${r.cleared}</b><small>Quests cleared</small></div>
      <div class="kpi"><b>${mPct(r.rate)}%</b><small>Clear rate ${arrow(r.delta)}</small></div>
      <div class="kpi"><b>~${r.xp}</b><small>XP earned</small></div>
    </div>
    <div class="sep"></div>
    <div class="rv-list">
      <div><span>Perfect days</span><b>${r.perfectDays} of 7</b></div>
      <div><span>Days with nothing cleared</span><b>${r.zeroDays}</b></div>
      <div><span>Current streak</span><b>${r.streak}</b></div>
      ${r.strongest ? `<div><span>Strongest area</span><b>${esc(CATLAB[r.strongest.cat] || r.strongest.cat)} · ${mPct(r.strongest.rate)}%</b></div>` : ""}
      ${r.weakest ? `<div><span>Weakest area</span><b>${esc(CATLAB[r.weakest.cat] || r.weakest.cat)} · ${mPct(r.weakest.rate)}%</b></div>` : ""}
      <div><span>Goals with progress</span><b>${r.goalsMoved}</b></div>
      <div><span>Previous week</span><b>${mPct(r.ratePrev)}% · ${r.clearedPrev} cleared</b></div>
    </div>
    <p class="tiny muted" style="margin-top:12px">Counted from ${r.scheduled} scheduled quests across seven days. XP is derived from what was cleared, so treat it as close rather than exact.</p>
    ${r.patterns.length ? `<div class="sep"></div><div class="rv-pat">${r.patterns.map(p => `<div><b>${esc(p.title)}</b> ${confPill(p.conf)}</div>`).join("")}</div>` : ""}`;

  $("#rvChange").textContent = r.change;
  markReviewRead();
}

/* ══════════════ wiring ══════════════ */
function renderBrain(){
  renderRecoveryBanner();
  renderFocusStrip("homeFocus");
  if(currentView === "insight"){ renderBrief(); renderPatterns(); renderPlan(); renderReview(); }
}

/* ══════════════ Quests → Goals: the ladder ══════════════ */
function renderGoalLadder(){
  const box = $("#goalLadder"); if(!box) return;
  const roots = goalTree();
  if(!roots.length){
    box.innerHTML = `<p class="muted tiny">No goals yet. Start with one thing you want to be true in ninety days — that horizon is close enough to plan against and far enough to be worth planning.</p>`;
    return;
  }
  const node = (g, depth) => {
    const p = goalProgress(g);
    const H_ = HORIZON[g.horizon] || HORIZON.month;
    return `<div class="gl-node" style="margin-left:${depth * 14}px">
      <div class="gl-h">${esc(H_.label)}${p.daysLeft !== null ? ` · ${p.daysLeft >= 0 ? p.daysLeft + " days left" : "overdue"}` : ""}${p.behind ? " · behind" : ""}</div>
      <div class="gl-name">${esc(g.name)}</div>
      <div class="gl-meta">${p.done}/${p.steps} steps${p.next ? ` · next: ${esc(p.next.text)}` : " · no steps yet"}</div>
      ${g.children.map(c => node(c, depth + 1)).join("")}
    </div>`;
  };
  box.innerHTML = roots.map(g => node(g, 0)).join("");
}

/* the two buttons under the goal list */
function wireGoalButtons(){
  const plan = $("#btnPlanGoal");
  if(plan) plan.onclick = async () => {
    const name = (await sysPrompt("What are you going for?", {
      msg:"Say it the way you would say it out loud. The System reads the words to pick a plan shape — exam, skill, project, physical, money, or general.",
      placeholder:"e.g. Prepare for my IGCSE Physics exam", ok:"Next" }) || "").trim();
    if(!name) return;
    const prop = proposeBreakdown(name);
    const preview = prop.targets.map(t => `${t.name}\n  · ${t.steps.join("\n  · ")}`).join("\n\n");
    if(!await sysConfirm(`Read as: ${prop.label}`, `${prop.why}\n\n${preview}\n\nCreate this?`, { ok:"Create it" })) return;
    const g = createGoalWithPlan({ name, horizon:"quarter" });
    save(); renderAll();
    if(g) toast("Goal created", `${prop.label} · ${prop.targets.length} targets. Edit or delete any step — it is a starting point, not a contract.`, "gold");
  };
}
document.addEventListener("DOMContentLoaded", wireGoalButtons);
if(document.readyState !== "loading") wireGoalButtons();

/* fold the ladder into the existing goal render so both stay in step */
Hooks.after("renderGoals", "goal ladder", () => safeRender("goal ladder", renderGoalLadder));
