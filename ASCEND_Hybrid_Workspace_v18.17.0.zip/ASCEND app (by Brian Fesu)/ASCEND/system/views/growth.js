/* THE SYSTEM v13 — views/growth.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- Codex, Goals, Vault (v5) ---------- */
const CODEX = [
  "Discipline creates freedom.",
  "Mentality is everything.",
  "Destroy your old self. Build the next one.",
  "Your outer world mirrors your inner world.",
  "Thoughts \u2192 feelings \u2192 actions \u2192 results.",
  "Your income grows only as fast as you do.",
  "Set the thermostat higher \u2014 results follow the setting.",
  "Pay yourself first. Every single time.",
  "How you do anything is how you do everything.",
  "Mastery is a path: apprentice \u2192 practitioner \u2192 master.",
  "Choose the mentor. Steal the lesson, not the style.",
  "Boredom is the toll gate on the road to mastery.",
  "Complaining is a crap magnet. Build instead.",
  "Small daily wins beat rare heroic efforts.",
  "Fill the buckets in order: knowledge \u2192 skill \u2192 network \u2192 resources \u2192 reputation.",
  "Quitting the wrong thing is a skill, not a failure.",
  "Small details compound. Sweat them.",
  "Big pressure means you're in a big arena.",
  "Tell the story only you can tell.",
  "Leveling up takes isolation, separation, and extreme focus.",
  "Never give up \u2014 even successful people have failed many times.",
];
function renderLore(){
  const h = H(); if(!h || !$("#loreList") || typeof LORE === "undefined") return;
  const box = $("#loreList"); box.innerHTML = "";
  LORE.forEach((c,i) => {
    const open = h.level >= c.lvl;
    const row = document.createElement("div");
    row.className = "lore-row" + (open ? "" : " locked");
    row.innerHTML = `<span class="tiny">${esc(c.t)}</span>
      <button class="btn sm ${open ? "gold" : "ghost"}">${open ? "Read" : "Lv " + c.lvl}</button>`;
    row.querySelector("button").onclick = () => {
      if(!open) return toast("Sealed record","Reach Level " + c.lvl + " to unlock this chapter.","blood");
      $("#loreTitle").textContent = c.t;
      $("#loreBody").innerHTML = c.txt.split("\n").map(p => `<p>${esc(p)}</p>`).join("");
      $("#loreModal").classList.remove("hidden");
      $("#loreBody").scrollTop = 0;
    };
    box.appendChild(row);
  });
}
function renderCodex(){
  if(!$("#codexLine")) return;
  const i = Math.floor(Date.now()/86400000) % CODEX.length;
  $("#codexLine").textContent = "CODEX \u00b7 " + CODEX[i];
}
function renderGoals(){ return Hooks.dispatch("renderGoals", renderGoalsBase, this, arguments); }
function renderGoalsBase(){
  const h = H(); if(!h || !$("#goalList")) return;
  if(!Array.isArray(h.goals)) h.goals = [];
  const box = $("#goalList"); box.innerHTML = "";
  if(!h.goals.length) box.innerHTML = `<p class="muted tiny">No goals yet. A goal without targets is a wish.</p>`;
  h.goals.forEach(g => {
    const wrap = document.createElement("div");
    wrap.style.cssText = "border:1px solid rgba(56,214,255,.25);padding:10px 12px;margin-bottom:10px";
    const total = g.targets.reduce((s,t)=>s+t.steps.length,0);
    const done = g.targets.reduce((s,t)=>s+t.steps.filter(x=>x.done).length,0);
    wrap.innerHTML = `<div class="row" style="justify-content:space-between;align-items:center;margin-bottom:6px">
      <b>${esc(g.name)}</b>
      <span class="tiny" style="color:var(--gold)">[${done}/${total}]</span></div>`;
    g.targets.forEach(t => {
      const td = document.createElement("div");
      td.style.cssText = "margin:6px 0 6px 8px";
      td.innerHTML = `<div class="tiny" style="letter-spacing:.12em;text-transform:uppercase;color:var(--mana);margin-bottom:4px">${esc(t.name)}</div>`;
      t.steps.forEach((s, si) => {
        const row = document.createElement("div");
        row.className = "row"; row.style.cssText = "gap:8px;align-items:center;margin-bottom:3px";
        /* v18: a step can become a real quest on the real board. Until now the
           ladder ended in text — 8 steps and 0 quests, measured. The schedule is
           never changed silently: this asks for a time and the student confirms
           it, which is the rule for every proposal in this product. */
        const linked = typeof questsLinkedTo === "function"
          ? questsLinkedTo("goal", g.id).find(q => q.link.target === t.id && q.link.step === si)
          : null;
        row.innerHTML = `<button class="btn sm ${s.done?"gold":"ghost"}" style="min-width:34px">${s.done?"\u2713":"\u25cb"}</button>
          <span class="tiny" style="flex:1;${s.done?"text-decoration:line-through;opacity:.6":""}">${esc(s.text)}</span>
          <button class="btn sm ghost sched" title="${linked ? "Already on the board" : "Put this on the quest board"}">${linked ? "\u25c9 on board" : "\u2295 schedule"}</button>`;
        row.querySelector("button").onclick = () => {
          s.done = !s.done;
          if(s.done) grantXp(10, "Goal step cleared");
          save(); renderGoals(); renderStatus();
        };
        row.querySelector(".sched").onclick = async () => {
          if(linked){ go("quests", "q-today"); return; }
          const t0 = (await sysPrompt("Schedule this step", {
            msg: s.text, placeholder:"18:00", value:"18:00",
            ok:"Add to the board" }) || "").trim();
          if(!t0) return;
          if(!/^\d{2}:\d{2}$/.test(t0)) return toast("Use HH:MM","24-hour, like 18:00.","blood");
          const r = scheduleStepAsQuest(g.id, t.id, si, { time:t0 });
          if(!r) return toast("Could not schedule","The step could not be found.","blood");
          toast(r.created ? "On the board" : "Already scheduled",
                `${s.text} \u00b7 ${fmt12(t0)} \u00b7 clearing it ticks this step off`, "gold");
          renderGoals(); renderAll();
        };
        td.appendChild(row);
      });
      const addS = document.createElement("button");
      addS.className = "btn sm ghost"; addS.textContent = "+ step"; addS.style.marginTop = "2px";
      addS.onclick = async () => {
        const v = (await sysPrompt("Action step", {msg:"For: " + t.name, placeholder:"Something you could start in the next hour", ok:"Add step"})||"").trim().slice(0,120);
        if(!v) return; t.steps.push({id:uid(), text:v, done:false}); save(); renderGoals();
      };
      td.appendChild(addS);
      wrap.appendChild(td);
    });
    const foot = document.createElement("div");
    foot.className = "row"; foot.style.cssText = "gap:8px;margin-top:8px";
    const addT = document.createElement("button");
    addT.className = "btn sm ghost"; addT.textContent = "+ target";
    addT.onclick = async () => {
      if(g.targets.length >= 3) return toast("Three targets max","Break it into a new goal instead \u2014 focus wins.","blood");
      const v = (await sysPrompt("Target", {msg:"For: " + g.name, placeholder:"A milestone you can measure", ok:"Add target"})||"").trim().slice(0,80);
      if(!v) return; g.targets.push({id:uid(), name:v, steps:[]}); save(); renderGoals();
    };
    const del = document.createElement("button");
    del.className = "btn sm danger"; del.textContent = "\u2715";
    del.onclick = async () => { if(await sysConfirm("Delete this goal?", "The goal, its targets and every step under it are removed.", {ok:"Delete", danger:true})){ h.goals = h.goals.filter(x=>x.id!==g.id); save(); renderGoals(); } };
    foot.appendChild(addT); foot.appendChild(del);
    wrap.appendChild(foot);
    box.appendChild(wrap);
  });
}
const VAULT_JARS = [
  ["freedom","Freedom (invest only)",10],
  ["learn","Learn",10],
  ["lts","Long-term",10],
  ["play","Play",10],
  ["give","Give",10],
  ["needs","Needs",50],
];
function renderVault(){
  const h = H(); if(!h || !$("#vaultBody")) return;
  if(!h.vault) h.vault = {freedom:0,learn:0,lts:0,play:0,give:0,needs:0};
  const tb = $("#vaultBody"); tb.innerHTML = "";
  VAULT_JARS.forEach(([k,label,pct]) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${label}</td><td>${pct}%</td><td style="cursor:pointer;color:var(--mana)">GHS ${(h.vault[k]||0).toFixed(2)}</td>`;
    tr.lastElementChild.onclick = async () => {
      if(k === "freedom") return toast("The Vault refuses","The Freedom jar is never spent \u2014 only invested. That rule is the whole game.","blood");
      const v = parseFloat(await sysPrompt("Spend from " + label, {msg:"Amount in GHS. The jar decides, not the craving.", inputType:"number", placeholder:"0.00", ok:"Spend"})||"0");
      if(!(v > 0)) return;
      if(v > h.vault[k]) return toast("Not enough in that jar","Discipline means the jar decides, not the craving.","blood");
      h.vault[k] -= v;
      h.moneyLog = h.moneyLog || [];
      h.moneyLog.push({ts: Date.now(), k:"sp", jar:k, amt:v});
      if(h.moneyLog.length > 400) h.moneyLog = h.moneyLog.slice(-400);
      save(); renderVault(); renderWealthAdvice();
    };
    tb.appendChild(tr);
  });
}
