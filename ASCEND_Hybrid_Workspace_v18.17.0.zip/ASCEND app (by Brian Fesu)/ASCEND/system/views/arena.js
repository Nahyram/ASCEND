/* THE SYSTEM v13 — views/arena.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ THE ARENA — competitions & scholarships ══════════════ */
let arenaMode = "comp", arenaCat = "all";

function arenaSource(){
  if(arenaMode === "schol") return SCHOLARSHIPS;
  if(arenaMode === "saved"){
    const h = H(); const saved = (h && h.arenaSaved) || {};
    return [...COMPETITIONS, ...SCHOLARSHIPS].filter(x => saved[x.n]);
  }
  return COMPETITIONS;
}

function renderArena(){
  const h = H(); if(!h || !$("#arenaList") || typeof COMPETITIONS === "undefined") return;
  h.arenaSaved = h.arenaSaved || {};

  $$("#arenaMode button").forEach(b => {
    b.classList.toggle("on", b.dataset.am === arenaMode);
    b.onclick = () => { arenaMode = b.dataset.am; arenaCat = "all"; renderArena(); };
  });

  const src = arenaSource();
  const cats = $("#arenaCats"); cats.innerHTML = "";
  if(arenaMode !== "saved"){
    ["all", ...[...new Set(src.map(x=>x.c))]].forEach(c => {
      const b = document.createElement("button");
      b.className = "chip" + (arenaCat === c ? " on" : "");
      b.textContent = c === "all" ? "Everything" : c;
      b.onclick = () => { arenaCat = c; renderArena(); };
      cats.appendChild(b);
    });
  }

  const q = ($("#arenaSeek") && $("#arenaSeek").value || "").trim().toLowerCase();
  let list = src.filter(x => arenaCat === "all" || x.c === arenaCat);
  if(q) list = src.filter(x => (x.n+" "+x.c+" "+x.o+" "+x.d).toLowerCase().includes(q));

  const savedCount = Object.values(h.arenaSaved).filter(Boolean).length;
  $("#arenaHead").textContent = arenaMode === "comp" ? `Competitions · ${list.length}`
    : arenaMode === "schol" ? `Funded scholarships · ${list.length}`
    : `Starred · ${savedCount}`;

  const box = $("#arenaList"); box.innerHTML = "";
  if(!list.length){
    box.innerHTML = arenaMode === "saved"
      ? `<p class="muted tiny">Nothing starred. Star the ones you will actually enter — a list you never filter is a list you never use.</p>`
      : `<p class="muted tiny">Nothing matches that.</p>`;
    return;
  }
  let group = "";
  list.forEach(x => {
    if(x.c !== group && !q && arenaMode !== "saved"){
      group = x.c;
      const gh = document.createElement("div"); gh.className = "genre-head"; gh.textContent = group;
      box.appendChild(gh);
    }
    const on = !!h.arenaSaved[x.n];
    const el = document.createElement("div");
    el.className = "arena" + (on ? " star" : "");
    el.innerHTML = `<div class="ah"><div class="an">${esc(x.n)}</div></div>
      <div class="ac">${esc(x.c)}</div>
      <div class="ao">Open to: ${esc(x.o)}</div>
      <div class="ad">${esc(x.d)}</div>
      <div class="au"><a href="https://${esc(x.u)}" target="_blank" rel="noopener">${esc(x.u)}</a></div>`;
    const star = document.createElement("button");
    star.className = "starbtn" + (on ? " on" : "");
    star.textContent = on ? "★" : "☆";
    star.title = "Star this";
    star.onclick = () => {
      h.arenaSaved[x.n] = !on;
      if(!on) grantXp(5, "Target marked: " + x.n);
      save(); renderArena();
    };
    el.querySelector(".ah").appendChild(star);
    box.appendChild(el);
  });
}
if($("#arenaSeek")) $("#arenaSeek").addEventListener("input", () => renderArena());

/* ---------- wire the new panels into the render cycle ---------- */
Hooks.after("renderAll", "forge + arena", () => { renderForge(); renderArena(); });
if(!$("#app").classList.contains("hidden")){ renderForge(); renderArena(); renderLibrary(); renderScreen(); }

