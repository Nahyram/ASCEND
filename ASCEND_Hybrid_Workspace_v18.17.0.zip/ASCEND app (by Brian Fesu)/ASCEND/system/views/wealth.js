/* THE SYSTEM v13 — views/wealth.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ v8: WEALTH ACADEMY — how fortunes are actually built ══════════════ */
const WEALTH_LESSONS = [
  {t:"The Ownership Law", b:"Nobody on earth got rich from salary alone. A wage pays you once for your hours, and your hours are capped. The people at the top own things — businesses, shares, land, products, rights — and owned things earn while the owner sleeps. Hard truth: as long as 100% of your income requires 100% of your presence, you are renting your life out, not building one. The whole game, from your first cedi, is converting effort into things you OWN: a digital product, a small stake, a skill with your name on it. Employees ask \u201chow much per month?\u201d Owners ask \u201cwhat do I keep when I stop showing up?\u201d Start asking the second question now, while you are young enough for the answer to compound."},
  {t:"Pay Yourself First", b:"Most people pay everyone else first — the shop, the vendor, the data bundle — and save whatever survives. Nothing survives. It never has and never will, because spending expands to swallow whatever it can see. The rich reverse the order: the moment money arrives, a fixed cut disappears into assets BEFORE any spending happens. That is what the Vault does. 10% Freedom, untouchable. Split first, live on the rest. If you cannot save from small money, you will not save from big money — the habit is the machine, the amount is just fuel."},
  {t:"Compounding: The Quiet Monster", b:"Compounding means your money earns money, and then THAT money earns money. Early on it looks pathetic — that is why almost everyone quits. GHS 10 a week feels like nothing for two years. But growth stacks on growth, and the curve that crawled for years suddenly stands up and runs. The variable that matters most is not the amount. It is TIME — and time is the one asset where you are currently richer than every adult you know. Every year you delay is a year stolen from the steep end of your own curve. There is no catching up later. Later is more expensive. It always is."},
  {t:"Assets Eat, Liabilities Feed", b:"An asset puts money in your pocket. A liability takes money out. That is the entire test — not what the seller calls it, not how it looks on your feed. New phone: liability. Airtime for scrolling: liability. A course that raises what you can charge: asset. A laptop you use to build and sell: asset. Broke people buy liabilities that LOOK like wealth. Wealthy people buy assets that look like nothing — and let the assets buy the luxuries later. Before any purchase, one question, answered honestly: does this feed me, or does it eat me?"},
  {t:"Skills Are the First Currency", b:"Before you have capital, you have hours — and the market pays hours according to the skill inside them. Rare and useful skills command rare fees; common skills fight over scraps. You do not need to be world-class at one thing. Stack two or three good skills that combine: writing plus design, coding plus a subject you know, speaking plus organisation. The stack is rare even when each piece is ordinary. Every hour you study a paying skill, you are literally raising your own price. Every hour of empty scrolling, the price stays where it is. The market does not care which you chose. It just pays the number."},
  {t:"Leverage: Do It Once, Sell It Forever", b:"Poor leverage: one hour of work, one hour of pay, forever. Rich leverage: work that multiplies without you. There are four kinds — people working for you, capital working for you, and the two a student can grab tonight for free: CODE and MEDIA. A template, an ebook, a study pack, a video, an app — you build it once and it can sell a thousand times while you sit in class. No permission needed, no capital needed, no connections needed. This is the newest door to wealth in history and it is standing open. The only entry fee is making something."},
  {t:"Nobody Saves Their Way to Rich", b:"Saving protects money. It does not create it. A fortune needs income first — and income means selling something: your service (tutoring, design, editing), your product (digital packs, printables, this very app), or a skill applied to someone's problem. \u201cI have nothing to sell\u201d is almost never true; it usually means \u201cI have not packaged what I know.\u201d You passed an exam someone is dreading. You can make something someone needs. Package it, price it, put it in front of people, and let them say no. Ten no's cost you nothing. One yes changes what you believe you are allowed to charge."},
  {t:"The Ladder: Earn, Keep, Multiply", b:"Wealth climbs a three-rung ladder, in order. EARN: get money flowing in — skills and selling. KEEP: widen the gap between what comes in and what goes out — the Vault. MULTIPLY: put the kept money to work in boring, real instruments — in Ghana that means things like treasury bills and licensed mutual funds, not miracles. And hear this clearly: any scheme promising to \u201cdouble your money\u201d fast, any betting slip sold as a strategy, any pressure to recruit others — that is not investing, that is the machine that eats young people's savings. Real returns are boring. Boring is what compounding looks like from up close."},
  {t:"Delayed Gratification Is a Weapon", b:"Every purchase is a duel between who you are today and who you could be in five years. The crowd lets today win every time — new sneakers now, small money gone now, comfort now — and then wonders why the future keeps arriving empty. The wealthy flip the sequence: assets first, luxuries later, bought from what the assets earn. That is the entire difference, repeated ten thousand times. Wanting things is human. Buying them before your assets can pay for them is how the crowd stays the crowd. You are allowed to want everything. You are not allowed to want it first."},
  {t:"Name Your Number Calmly", b:"Money moves toward people who can talk about it without flinching. Charge for the value you create, not the time you spent — a fix that saves someone ten hours is worth more than your afternoon. Ask for more than feels comfortable; the discomfort is the tax on growing up. When you name a price, name it and stop talking — the silence after a number does the negotiating. And walk away from bad deals early: desperation is visible, and it is expensive. Nobody will ever value your work above the price you were willing to accept for it."},
  {t:"Build Systems, Not Sweat", b:"Hustle is doing the work. A system is a machine that does the work when you are not there. The billionaire question is never \u201chow hard can I work?\u201d — everyone at the top works hard, so hard work is just the entry ticket. The question is \u201cwhat runs without me?\u201d Write down how you do a thing, make it repeatable, then let a tool, a template, or eventually a person run the steps. If your income stops the moment you stop, you built a job. If it keeps moving, you built a system. Build the second thing."},
  {t:"Reputation Is Compounding Capital", b:"Deliver late once, lie once, take one shady shortcut — and you have spent trust that took years to earn and takes years to rebuild. Wealth is built in long games with people who trust you, because trust is what makes them hand you money, opportunities, and their friends' names. Every promise kept is a deposit that compounds quietly in rooms you are not in. Every cut corner is a withdrawal you cannot see, at interest you cannot afford. Play so straight it looks naive. In year one it earns nothing. In year ten it is the most valuable asset you own."},
  {t:"The Millions Equation", b:"There is no secret to a million. There is an equation: INCOME × SAVINGS RATE × TIME × RETURN. Push any variable up and the outcome grows; push several and it explodes. Run the honest numbers once and never forget them: GHS 500 a month, invested at a realistic long-term return of about 10% a year, becomes roughly GHS 100,000 in 10 years, 380,000 in 20, and about 1.1 MILLION in 30 — and most of that final number is growth, not deposits. That is a millionaire built from a modest, boring, repeated act. Now see what the crowd never sees: the equation punishes delay brutally (start 10 years late and you lose the biggest third of the curve) and it rewards income growth massively (double the monthly amount, double the outcome). So the plan writes itself — raise income with skills, protect the savings rate with the Vault, start NOW, and let time do the heavy lifting. Anyone promising you the same result faster is skipping a variable, and the variable they are skipping is always the truth. One caveat the honest keep in view: inflation shrinks what a million buys, which is exactly why the money must be invested and not parked."},
  {t:"The Four Roads to Millions", b:"Strip away the noise and there are only four real roads. ROAD 1 — HIGH-INCOME SKILL + DISCIPLINED INVESTING: become expensive (surgeon, engineer, top developer, specialist), keep a big gap between earning and spending, invest the gap for decades. Slowest headline, highest success rate. ROAD 2 — BUILD A BUSINESS THAT WORKS WITHOUT YOU: profits are uncapped where salaries are capped; a business serving thousands earns like a thousand employees. Highest failure rate, highest ceiling — survivors usually failed a few times first and kept the lessons. ROAD 3 — OWN EQUITY EARLY: shares in growing companies, whether bought on the market for decades or earned by joining or starting something young. This is how employees of successful startups quietly become millionaires — they held OWNERSHIP, not just jobs. ROAD 4 — REAL ASSETS: land and property, bought carefully, held long, rented out. Capital-heavy, slow, and it has built more quiet fortunes in Ghana than every scheme combined. Notice what is NOT on the list: betting apps, forex 'mentors' selling signals, pyramid recruiting, and anything urgent. Those are not roads. They are toll gates other people built on YOUR road. Most real fortunes travel two roads at once — a skill funding an asset. Choose your pair."},
  {t:"Trusts — How Old Money Guards Itself", b:"Rich families do not just make money. They build legal structures around it, and the oldest structure is the TRUST. How it works: the founder (called the settlor) transfers assets — money, shares, land — to a TRUSTEE, who legally holds and manages them under written rules (the trust deed) for the BENEFICIARIES, usually the family. Why the wealthy love it: 1) PROTECTION — assets in a properly built trust are no longer the settlor's personal property, so a lawsuit or business collapse cannot easily reach them. 2) CONTROL BEYOND THE GRAVE — the deed can say 'my children receive income at 25, capital at 35, nothing if they drop out', so one wild heir cannot burn three generations of work. 3) ORDERLY INHERITANCE — assets pass by the deed's rules, avoiding the court battles and family wars that scatter estates. 4) PRIVACY. Ghana recognises trusts, and licensed trust companies and lawyers set them up — this is a real tool on this soil, not just a foreign movie plot. Two honest warnings: a trust PROTECTS wealth, it does not CREATE it — structure comes after substance; and using trusts to hide money from tax authorities is evasion, which is a crime, not a strategy. Your move today costs nothing: the Freedom jar is your training trust. Principal untouchable, rules written in advance, beneficiary: future you. Practise being your own trustee now; hire the real one when there is something worth guarding."},
  {t:"The Billionaire Blueprint — Read Without Flinching", b:"First, the truth nobody sells: there is no salary on earth that makes a billionaire. Every billionaire holds massive EQUITY in something that scaled — Dangote holds Dangote Group, the tech founders hold their companies' shares. The 'net worth' headlines are ownership stakes, not bank balances. So the blueprint, honestly stated: 1) solve a problem for MILLIONS of people, because value created × people reached = wealth, and the second number is where billions hide; 2) own a serious piece of the machine that solves it — the founder's share, not the employee's wage; 3) build with LEVERAGE (code, media, capital, teams) so the machine grows without eating all your hours; 4) hold for DECADES — nearly every billionaire's curve was flat for ten-plus years before it went vertical, and the ones who sold early are the cautionary tales you never hear about. Now the statistics, without anaesthesia: the odds of billionaire are lottery-thin, and for every celebrated founder there are thousands who tried just as hard. Flinched? Good — now here is why you play anyway: the SAME blueprint, run with the same discipline, lands at millionaire far more reliably, because millionaire does not require a miracle, only the machine — skills, ownership, leverage, patience — run for enough years. Chase the billion if it burns in you. But build like someone who will be wealthy even if the lightning never strikes. That is not settling. That is strategy."},
];
function renderLessons(){
  const h = H(); if(!h || !$("#lessonList")) return;
  h.wealthDone = h.wealthDone || {};
  const box = $("#lessonList"); box.innerHTML = "";
  let prevDone = true;
  WEALTH_LESSONS.forEach((L,i) => {
    const done = !!h.wealthDone[i];
    const locked = !prevDone && !done;
    const el = document.createElement("div");
    el.className = "lesson" + (done?" done":"") + (locked?" locked":"");
    el.innerHTML = `<div class="lesson-head"><span class="ln">${pad(i+1)}</span><span class="lt">${esc(L.t)}</span>
      <span class="lstate">${done ? "STUDIED" : locked ? "LOCKED" : "OPEN"}</span></div>
      <div class="lesson-body">${esc(L.b)}\n\n</div>`;
    if(!locked){
      el.querySelector(".lesson-head").onclick = () => el.classList.toggle("open");
      const btn = document.createElement("button");
      btn.className = "btn sm " + (done ? "ghost" : "gold");
      btn.textContent = done ? "Studied ✓" : "Mark studied · +15 XP";
      btn.disabled = done;
      btn.onclick = () => { h.wealthDone[i] = true; grantXp(15, "Wealth Academy: " + L.t); grantStat("mind",1); save(); renderLessons(); };
      el.querySelector(".lesson-body").appendChild(btn);
    } else {
      el.querySelector(".lesson-head").onclick = () => toast("Locked","Study the previous lesson first. Order matters — foundations before towers.","blood");
    }
    prevDone = done;
    box.appendChild(el);
  });
}

/* ══════════════ v8: THE LEDGER SPEAKS — blunt money advisor ══════════════ */
const MONEY_TRUTHS = [
  "Money you don't track is money you don't respect — and it leaves people who don't respect it.",
  "Your data bundle is a bill. Your snacks are a bill. Small leaks sink big ships — count them.",
  "If you can't explain where last week's money went, it went against you.",
  "Broke is a bank balance. Staying broke is a set of habits. Only one of those is fixed today.",
  "Every cedi has a job. Money without a job wanders off and never comes back.",
  "Instant pleasure is the most expensive thing you will ever buy on a small income.",
  "'I'll save when I earn more' is a lie people tell at every income level. The habit starts at THIS number.",
  "Anyone promising to double your money fast is doubling THEIR money with yours.",
];
function renderWealthAdvice(){
  const h = H(); if(!h || !$("#wealthAdvice")) return;
  h.moneyLog = h.moneyLog || [];
  const now = Date.now(), d30 = now - 30*86400000;
  const recent = h.moneyLog.filter(e => e.ts >= d30);
  const inn = recent.filter(e=>e.k==="in").reduce((a,e)=>a+e.amt,0);
  const out = recent.filter(e=>e.k==="sp").reduce((a,e)=>a+e.amt,0);
  const spendBy = j => recent.filter(e=>e.k==="sp" && e.jar===j).reduce((a,e)=>a+e.amt,0);
  const lines = [];
  if(!h.moneyLog.length){
    lines.push(["ZERO RECORD","You have logged nothing. Right now your money has no supervision — and unsupervised money always finds an exit. The next cedi that touches your hand goes through the Vault. No amount is too small to count; the habit is the asset."]);
  } else {
    if(!recent.some(e=>e.k==="in"))
      lines.push(["NO INCOME · 30 DAYS","Nothing has come in for a month. Saving tips can't fix an empty pipe — the problem is earning. Open the Academy, lesson 7: package something and sell it. This week, not someday."]);
    if(inn > 0 && out > inn*0.9)
      lines.push(["YOU KEEP NOTHING","GHS " + inn.toFixed(2) + " came in, GHS " + out.toFixed(2) + " went out. You are a pipe, not a container. Rich is built from the gap between the two numbers — and your gap is nearly zero."]);
    const pl = spendBy("play"), le = spendBy("learn");
    if(pl > 0 && pl > le)
      lines.push(["PLAY OUTSPENDS LEARN","This month you spent GHS " + pl.toFixed(2) + " on Play and GHS " + le.toFixed(2) + " on Learn. Entertainment is beating education in your own ledger. That ratio is a forecast of your future income. Reverse it."]);
    if((h.vault?.freedom||0) > 0 && lines.length === 0)
      lines.push(["HOLDING THE LINE","Freedom jar: GHS " + h.vault.freedom.toFixed(2) + " and untouched. Good. Boring. Correct. When it can buy a treasury bill, do it — money in a jar keeps; money in an instrument grows."]);
  }
  const di = Math.floor(now/86400000);
  lines.push(["TRUTH OF THE DAY", MONEY_TRUTHS[di % MONEY_TRUTHS.length]]);
  lines.push(["TRUTH II", MONEY_TRUTHS[(di+3) % MONEY_TRUTHS.length]]);
  $("#wealthAdvice").innerHTML = lines.map(([t,b]) => `<div class="truth"><b>${esc(t)}</b>${esc(b)}</div>`).join("");
}

