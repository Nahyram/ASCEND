/* THE SYSTEM v14 — views/beyond.js
   Opportunities, competitions, activities and challenges.

   §49/§51 (Phase 7): a card shows only what a decision needs — name, organiser,
   deadline, eligibility state, match — and everything else lives on the detail. The
   primary action is always the official page, because that is the only source that
   can be trusted about a deadline.

   §47: no card ever says "you will get this". */
"use strict";

const OPP_KIND_LABEL = Object.fromEntries(OPP_KINDS.map(k => [k.k, k.label]));

function oppCard(x){
  const { o, m, status, verify } = x;
  const scam = scamCheck(o);
  return `<div class="opp ${status.k} ${m.blocked ? "blocked" : ""}" data-opp="${o.id}">
    <div class="opp-h">
      <b>${esc(o.name)}</b>
      <span class="opp-kind">${esc(OPP_KIND_LABEL[o.kind] || o.kind)}</span>
    </div>
    <div class="opp-meta">${esc(o.organiser || "organiser not recorded")} · ${esc(o.category)}${o.online ? " · online" : (o.region ? " · " + esc(o.region) : "")}</div>
    <div class="opp-row">
      <span class="opp-status ${status.k}">${esc(status.label)}</span>
      <span class="conf ${verify.k === "selfcheck" ? "cf-hi" : verify.k === "expired" ? "cf-lo" : "cf-md"}">${esc(verify.label)}</span>
      ${m.blocked ? "" : `<span class="opp-match">${esc(m.label)} fit</span>`}
    </div>
    ${scam.flagged ? `<div class="opp-scam"><b>Worth checking:</b> ${scam.signals.map(esc).join(" ")} ${esc(scam.advice)}</div>` : ""}
    <details class="opp-why"><summary>Why this ranking</summary>
      ${m.factors.map(f => `<div class="fac ${f.state}"><span>${esc(f.k)}</span><em>${esc(f.text)}</em></div>`).join("")}
      <p class="tiny muted" style="margin-top:8px">${esc(verify.blurb)} Last checked ${esc(o.lastChecked || "never")}.</p>
    </details>
    ${checklistBlock(o)}
    <div class="opp-acts">
      ${linkButton(o.url)}
      <button class="btn sm ghost" data-checked="${o.id}">I checked it</button>
      <button class="btn sm ghost" data-stage="${o.id}">${esc(PIPELINE_LABEL[o.stage] || o.stage)}</button>
      <button class="btn sm ghost" data-boss="${o.id}">Make it a boss</button>
      <button class="btn sm ghost" data-result="${o.id}">Record result</button>
      <button class="btn sm danger" data-del="${o.id}">\u2715</button>
    </div>
    ${o.result ? `<div class="opp-result"><b>${esc(o.result.kind)}</b> · ${esc(o.result.verification === "evidence" ? "evidence attached" : "self-reported")} · ${esc(o.result.at)}</div>` : ""}
    ${integrityWarning(o) ? `<p class="tiny muted" style="margin-top:8px">${esc(integrityWarning(o))}</p>` : ""}
  </div>`;
}

function wireOppCards(box){
  /* Ticking a step pays the XP toggleChecklistItem() has always been ready to
     pay. `once:` inside that function means unticking and reticking cannot farm
     it — the anti-farm ledger has covered this since v9 and was simply never
     reachable. */
  box.querySelectorAll("[data-chk]").forEach(cb => cb.onchange = () => {
    toggleChecklistItem(cb.dataset.chk, cb.dataset.chkitem);
    renderBeyond();
  });
  box.querySelectorAll("[data-checked]").forEach(b => b.onclick = () => {
    markChecked(b.dataset.checked); renderBeyond();
    toast("Marked as checked", "That records that *you* confirmed it on the official page today. THE SYSTEM has not checked anything.", "gold");
  });
  box.querySelectorAll("[data-stage]").forEach(b => b.onclick = async () => {
    const list = PIPELINE.map((s, i) => `${i+1}. ${PIPELINE_LABEL[s]}`).join("\n");
    const pick = await sysPrompt("Where are you with this?", { msg:list, inputType:"number", placeholder:"2", ok:"Set" });
    const st = PIPELINE[Number(pick) - 1]; if(!st) return;
    setStage(b.dataset.stage, st); renderBeyond(); renderAll();
  });
  box.querySelectorAll("[data-boss]").forEach(b => b.onclick = () => {
    const boss = bossFromOpportunity(b.dataset.boss);
    if(boss) toast("Boss summoned", `${boss.name} — the application broken into stages on your Path.`, "gold");
    renderAll();
  });
  box.querySelectorAll("[data-result]").forEach(b => b.onclick = async () => {
    const list = RESULT_KINDS.map((k, i) => `${i+1}. ${k}`).join("\n");
    const pick = await sysPrompt("What happened?", {
      msg: list + "\n\nNot placing is a result worth recording. It is evidence you entered.",
      inputType:"number", placeholder:"1", ok:"Next" });
    const kind = RESULT_KINDS[Number(pick) - 1]; if(!kind) return;
    const url = (await sysPrompt("Link to evidence (optional)", {
      msg:"A results page or certificate you can link to. Without one this stays marked self-reported, which is honest rather than weaker.",
      placeholder:"https://…", ok:"Save" }) || "").trim();
    recordResult(b.dataset.result, { kind, evidenceUrl:url, verified: !!url });
    renderBeyond(); renderAll();
  });
  box.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => {
    if(await sysConfirm("Remove this?", "It goes off your list. Nothing else is affected.", { ok:"Remove", danger:true })){
      removeOpportunity(b.dataset.del); renderBeyond();
    }
  });
}

/* 18.14 — esc() escapes HTML; it does not make a URL safe.

   `javascript:alert(1)` contains no character esc() touches, so it survived
   escaping and became a live href on a button the student clicks. Opportunity
   links come from what a student types and from imported files, so this was
   reachable. safeUrl() has been in services/integrity.js since v18, written for
   exactly this, and called by nothing. */
/* 18.15 — buildChecklist() has produced application checklists since v18 and
   toggleChecklistItem() has ticked them and paid XP for the step. Nothing ever
   rendered one. The list was built, stored on the opportunity, and invisible:
   the student could not see the steps and could not tick them, so the XP that
   step was worth could never be earned.

   Shown collapsed, because an opportunity with eleven steps should not push the
   next opportunity off the screen. */
function checklistBlock(o){
  const items = (o && o.checklist) || [];
  if(!items.length) return "";
  const done = items.filter(i => i.done).length;
  return `
    <details class="opp-check"${done && done < items.length ? " open" : ""}>
      <summary>Application steps <span>${done}/${items.length}</span></summary>
      ${items.map(i => `
        <label class="chk-row${i.done ? " on" : ""}">
          <input type="checkbox" data-chk="${esc(o.id)}" data-chkitem="${esc(i.id)}"${i.done ? " checked" : ""}>
          <span>${esc(i.text)}</span>
        </label>`).join("")}
    </details>`;
}

function linkButton(raw){
  const u = typeof safeUrl === "function" ? safeUrl(raw) : { ok:false, reason:"No link recorded" };
  if(!u.ok) return `<button class="btn sm ghost" disabled title="${esc(u.reason || "")}">${
    raw ? "Link not usable" : "No link recorded"}</button>`;
  return `<a class="btn sm gold" href="${esc(u.value)}" target="_blank" rel="noopener noreferrer">Open official page</a>`;
}

function renderBeyond(){ return Hooks.dispatch("renderBeyond", renderBeyondBase, this, arguments); }
function renderBeyondBase(){
  if(!$("#boRanked")) return;

  /* ---- deadlines ---- */
  const soon = deadlinesSoon(21);
  const sb = $("#boSoon");
  sb.innerHTML = soon.length
    ? soon.map(x => `<div class="br-row ${x.d <= 7 ? "warn" : ""}">
        <div class="br-k">${x.d === 0 ? "Today" : x.d + "d"}</div>
        <div class="br-v"><b>${esc(x.o.name)}</b><em>${esc(x.o.organiser || "")} — confirm on the official page before relying on this date.</em></div></div>`).join("")
    : `<p class="muted tiny">No deadlines inside three weeks.</p>`;

  /* ---- ranked ---- */
  const ranked = rankedOpportunities({ max:8 });
  const rb = $("#boRanked");
  rb.innerHTML = ranked.length ? ranked.map(oppCard).join("")
    : `<div class="empty"><b>Nothing tracked yet.</b>
        <p>THE SYSTEM does not ship a directory, because a stale listing is worse than none — a missed real deadline costs a student something an apology does not fix. Add the ones you find, and it will handle the deadlines, the checklist and the preparation plan.</p></div>`;
  wireOppCards(rb);

  /* ---- gaps ---- */
  const gaps = developmentGaps();
  $("#boGaps").innerHTML = gaps.length
    ? gaps.map(g => `<div class="br-row"><div class="br-k">Gap</div><div class="br-v"><b>${esc(g.text)}</b><em>${esc(g.suggest)} ${esc(g.caveat)}</em></div></div>`).join("")
    : `<p class="muted tiny">Nothing to flag. Gaps only appear once there is enough on record to see a shape.</p>`;

  /* ---- all ---- */
  const all = rankedOpportunities({ max:60 });
  const ab = $("#boAll");
  ab.innerHTML = all.length ? all.map(oppCard).join("") : `<p class="muted tiny">Nothing added yet.</p>`;
  wireOppCards(ab);

  /* ---- activities ---- */
  const o = opps();
  const acts = (o && o.activities) || [];
  $("#boActs").innerHTML = acts.length
    ? acts.map(a => {
        const d = activityDepth(a);
        return `<div class="act">
          <div class="act-h"><b>${esc(a.name)}</b><span>${esc(a.role)}${a.organisation ? " · " + esc(a.organisation) : ""}</span></div>
          <div class="ms-bar"><i style="width:${Math.round(d.depth*100)}%"></i></div>
          <div class="act-m">${d.months} month${d.months===1?"":"s"} · ${d.sessions} logged · ${d.hours}h</div>
          <div class="act-n">${esc(d.note)}</div>
          <button class="btn sm ghost" data-logact="${a.id}">Log a session</button>
        </div>`;
      }).join("")
    : `<div class="empty"><b>No activities recorded.</b><p>Clubs, teams, volunteering, a role you hold. What matters is how long and how deep, so record it once and log sessions as they happen.</p></div>`;
  $$("[data-logact]").forEach(b => b.onclick = async () => {
    const hrs = await sysPrompt("Hours", { inputType:"number", placeholder:"1", ok:"Next" });
    const note = (await sysPrompt("What did you do?", { placeholder:"optional", ok:"Log" }) || "").trim();
    logActivity(b.dataset.logact, { hours:Number(hrs) || 1, note });
    renderBeyond(); renderAll();
  });

  /* ---- challenges ---- */
  const live = activeChallenges();
  const cb = $("#boChal");
  cb.innerHTML = `
    ${live.length ? live.map(c => `<div class="chal ${c.done ? "done" : ""}">
      <div class="chal-h"><b>${esc(c.name)}</b><span>${esc(c.kind)} · +${c.xp} XP · until ${esc(c.expires)}</span></div>
      <div class="chal-b">${esc(c.blurb)}</div>
      ${c.done ? `<div class="tiny" style="color:var(--ok)">Done ${esc(c.doneAt)}</div>`
                : `<button class="btn sm gold" data-chaldone="${c.id}">I did it</button>`}
    </div>`).join("") : `<p class="muted tiny">No challenge running.</p>`}
    <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn sm ghost" data-draw="daily">Draw a daily</button>
      <button class="btn sm ghost" data-draw="weekly">Draw a weekly</button>
      <button class="btn sm ghost" data-draw="monthly">Draw a monthly</button>
    </div>
    <p class="tiny muted" style="margin-top:10px">The draw is fixed per period, so it cannot be re-rolled until it is easy.</p>`;
  cb.querySelectorAll("[data-draw]").forEach(b => b.onclick = () => {
    const c = drawChallenge(b.dataset.draw);
    renderBeyond();
    if(!c) toast("One at a time", "Finish the one you have, or let it expire.", "blood");
  });
  cb.querySelectorAll("[data-chaldone]").forEach(b => b.onclick = () => {
    completeChallenge(b.dataset.chaldone); renderBeyond(); renderAll();
  });
}

function wireBeyond(){
  const add = $("#boAdd");
  if(add) add.onclick = async () => {
    const kinds = OPP_KINDS.map((k,i) => `${i+1}. ${k.label} — ${k.blurb}`).join("\n");
    const kp = await sysPrompt("What kind?", { msg:kinds, inputType:"number", placeholder:"1", ok:"Next" });
    const kind = (OPP_KINDS[Number(kp)-1] || OPP_KINDS[0]).k;
    const name = (await sysPrompt("Name", { placeholder:"As the organiser calls it", ok:"Next" }) || "").trim();
    if(!name) return;
    const organiser = (await sysPrompt("Who runs it?", { placeholder:"Organisation", ok:"Next" }) || "").trim();
    const url = (await sysPrompt("Official page", {
      msg:"The organiser's own site. This is the only source THE SYSTEM will send you back to.",
      placeholder:"https://…", ok:"Next" }) || "").trim();
    const deadline = await sysPrompt("Deadline (optional)", { msg:"Only if it is published. Never guess one.", inputType:"date", ok:"Save" });
    const rec = addOpportunity({ kind, name, organiser, url, deadline });
    if(rec){
      buildChecklist(rec.id);
      const s = scamCheck(rec);
      renderBeyond(); renderAll();
      if(s.flagged) sysAlert("Worth a second look", s.signals.join("\n\n") + "\n\n" + s.advice);
      else toast("Added", "Checklist built. Mark it checked once you have read the official page.", "gold");
    }
  };
  const addAct = $("#boAddAct");
  if(addAct) addAct.onclick = async () => {
    const name = (await sysPrompt("Activity", { placeholder:"e.g. Robotics Club", ok:"Next" }) || "").trim();
    if(!name) return;
    const org = (await sysPrompt("Where?", { placeholder:"School, organisation…", ok:"Next" }) || "").trim();
    const roles = ACTIVITY_ROLES.map((r,i) => `${i+1}. ${r}`).join("\n");
    const rp = await sysPrompt("Your role", { msg:roles, inputType:"number", placeholder:"1", ok:"Add" });
    addActivity({ name, organisation:org, role: ACTIVITY_ROLES[Number(rp)-1] || "Member" });
    renderBeyond();
  };
}
document.addEventListener("DOMContentLoaded", wireBeyond);
if(document.readyState !== "loading") wireBeyond();
