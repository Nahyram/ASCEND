/* THE SYSTEM v13 — views/why.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ v9: THE WHY ENGINE — reminders of why you grind ══════════════ */
function whys(){ const h = H(); if(!h) return []; h.whys = Array.isArray(h.whys) ? h.whys : []; return h.whys; }
function renderWhy(){
  const h = H(); if(!h || !$("#whyList")) return;
  const list = whys();
  const box = $("#whyList"); box.innerHTML = "";
  if(!list.length){
    box.innerHTML = `<p class="muted tiny">Empty. That is a problem — a hunter without a WHY negotiates with the alarm clock every morning and loses. Write the real reasons below: who you're doing this for, what you're escaping, what you're building. The System will fire them back at you until they're carved in.</p>`;
  }
  list.forEach((w,i) => {
    const el = document.createElement("div"); el.className = "why-card";
    el.innerHTML = `<span class="wn">${pad(i+1)}</span><span class="wtxt">${esc(w)}</span><button class="btn sm ghost">✕</button>`;
    el.querySelector("button").onclick = () => { h.whys.splice(i,1); save(); renderWhy(); renderWhyLine(); };
    box.appendChild(el);
  });
  if($("#whyFreq")) $("#whyFreq").value = h.whyFreq || "off";
}
function renderWhyLine(){
  const el = $("#whyLine"); if(!el) return;
  const list = whys();
  if(!list.length){ el.textContent = ""; return; }
  const hr = Math.floor(Date.now()/3600000);
  el.textContent = "WHY YOU GRIND · " + list[hr % list.length];
}
function whyAdd(){
  const inp = $("#whyIn"); const v = (inp.value||"").trim();
  if(!v) return;
  if(v.length > 160){ toast("Too long","Keep each WHY under 160 characters — sharp enough to sting.","blood"); return; }
  const h = H(); h.whys = whys(); 
  if(h.whys.length >= 10){ toast("Ten is enough","Ten reasons. If ten don't move you, an eleventh won't.","blood"); return; }
  h.whys.push(v); inp.value = ""; save(); renderWhy(); renderWhyLine();
  toast("WHY registered","The System will remind you. That is a promise, not an offer.","gold");
}
function whyPing(manual){
  const h = H(); if(!h) return;
  const list = whys();
  if(!list.length){ if(manual) toast("No WHY on file","Write your reasons first. The System cannot remind you of nothing.","blood"); return; }
  const w = list[Math.floor(Math.random()*list.length)];
  toast("WHY YOU LEVEL UP", w, "gold");
  notify("WHY YOU LEVEL UP", w);
  if(navigator.vibrate) navigator.vibrate([160,80,160]);
  h.whyLast = Date.now(); save();
}
function whyTick(){
  const h = H(); if(!h || $("#app").classList.contains("hidden")) return;
  const freq = h.whyFreq || "off"; if(freq === "off") return;
  const hr = new Date().getHours();
  if(hr < 7 || hr >= 21) return;            // quiet hours: the grind sleeps too
  const last = h.whyLast || 0;
  const gapMin = freq === "day" ? 1440 : Number(freq);
  if(freq === "day"){
    const lastDayK = new Date(last).toDateString();
    if(lastDayK === new Date().toDateString()) return;
  } else if(Date.now() - last < gapMin*60000) return;
  whyPing(false);
}
setInterval(whyTick, 30000);

