/* THE SYSTEM v13 — views/access.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ v8: ACCESS (payment moved out of Settings) ══════════════ */
function renderAccess(){
  if(!$("#supportBlurb")) return;
  $("#supportBlurb").textContent = DB.store.blurb;
  const pay = $("#btnPay");
  if(DB.store.payLink){ pay.href = DB.store.payLink; pay.textContent = "Support / unlock full access"; }
  else { pay.removeAttribute("href"); pay.textContent = "No payment link set yet"; }
  /* The state line reads from the entitlement service, and says which authority
     answered. A student who paid deserves to know what they actually bought;
     a developer reading this later deserves to know it is not a lock. */
  const st = $("#keyState");
  if(DeviceEntitlements.unlocked()){
    const posture = entitlementPosture();
    st.textContent = posture.headline;
    st.style.color = "var(--gold)";
    st.title = posture.detail;
  } else {
    st.textContent = "";
    st.removeAttribute("title");
  }
}
$("#btnAccess").onclick = () => { renderAccess(); $("#accessModal").classList.remove("hidden"); };
$("#accessClose").onclick = () => $("#accessModal").classList.add("hidden");
$("#accessModal").onclick = e => { if(e.target.id === "accessModal") $("#accessModal").classList.add("hidden"); };

/* ══════════════ v8: HUNTER COUNT — real server, honest fallback ══════════════
   v18: this used to call fetch() directly, with no AbortController, so an
   endpoint that accepted the connection and never answered left the request
   pending for as long as the OS allowed. It now goes through Api.call like
   every other external request — same timeout, same rate limit, same isolation.
   The counter is decoration; the grind is not, and decoration must never be
   able to hold anything up. */
async function pingCount(){
  const chip = $("#huntChip");
  const showCached = () => {
    if(DB.countCache && DB.countCache.n){
      $("#huntCount").textContent = DB.countCache.n.toLocaleString();
      chip.classList.remove("hidden");
    } else chip.classList.add("hidden");
  };
  const res = await CounterService.ping(DB.installId);
  if(!res.ok) return showCached();
  const n = res.data && res.data.count;
  if(typeof n !== "number" || n < 0) return showCached();
  DB.countCache = { n, ts: Date.now() }; save();
  $("#huntCount").textContent = n.toLocaleString();
  chip.classList.remove("hidden");
}

