/* THE SYSTEM v13 — views/insight.js
   Analytics with no decoration. Every number here is counted from the record,
   and every panel says how many observations it stands on. */
"use strict";

const CATLABEL = { study:"Study", body:"Training", mind:"Deep work", discipline:"Discipline", rest:"Rest" };

function renderInsight(){
  const h = typeof H === "function" ? H() : null;
  if(!h || !$("#anaDays")) return;
  const rows = coachSample();

  if(rows.length < 12){
    const msg = `<div class="empty"><b>Not enough record yet</b>
      The System will not invent a trend out of three days. Keep clearing quests —
      the patterns below unlock at about a week of history.</div>`;
    ["#anaDays","#anaBands","#anaTrend","#anaQuests","#anaCats"].forEach(s => { const e = $(s); if(e) e.innerHTML = msg; });
    if($("#anaSummary")) $("#anaSummary").textContent = `${rows.length} quest-days recorded so far.`;
    return;
  }

  if($("#anaSummary"))
    $("#anaSummary").textContent = `${rows.length} quest-days recorded · ${pct(rate(rows))}% cleared overall`;

  /* ---- weekday bars ---- */
  const days = byDay(rows);
  if(days.length){
    const best = Math.max(...days.map(d => d.rate)), worst = Math.min(...days.map(d => d.rate));
    $("#anaDays").innerHTML =
      `<div class="bars">${days.map(d => {
        const cls = d.rate === best ? "best" : (d.rate === worst ? "worst" : "");
        return `<div class="bar ${cls}" title="${DAYNAME[d.dow]} — ${pct(d.rate)}% of ${d.n}">
          <i style="height:${Math.max(2, d.rate * 100)}%"></i><span>${DAYSHORT[d.dow]}</span></div>`;
      }).join("")}</div>
      <div class="legend"><span><i style="background:var(--gold)"></i>strongest day</span>
      <span><i style="background:var(--blood)"></i>weakest day</span>
      <span>minimum 3 observations per day</span></div>`;
  }

  /* ---- time of day ---- */
  const bands = byBand(rows);
  $("#anaBands").innerHTML = bands.length
    ? bands.map(b => `<div class="statrow"><span>Quests set ${b.lab}</span><b>${pct(b.rate)}% <span style="color:var(--ash)">of ${b.n}</span></b></div>`).join("")
    : `<p class="tiny muted">Your quests all sit in one part of the day, so there is nothing to compare yet.</p>`;

  /* ---- trend ---- */
  const w1 = windowRate(rows, 1, 7), w2 = windowRate(rows, 8, 14), w3 = windowRate(rows, 15, 21);
  const delta = w2 ? w1 - w2 : 0;
  $("#anaTrend").innerHTML =
    `<div class="statrow"><span>Last 7 days</span><b>${pct(w1)}%</b></div>
     <div class="statrow"><span>The 7 before that</span><b>${w2 ? pct(w2) + "%" : "—"}</b></div>
     <div class="statrow"><span>And the 7 before that</span><b>${w3 ? pct(w3) + "%" : "—"}</b></div>
     <p class="tiny" style="margin-top:10px;color:${delta >= 0 ? "var(--ok)" : "var(--blood)"}">
       ${!w2 ? "One more week and the System can call a direction."
             : delta >= 0.02 ? `Up ${pct(delta)} points. Keep the load where it is for another week before adding to it.`
             : delta <= -0.02 ? `Down ${pct(Math.abs(delta))} points. Cut before you collapse — a smaller list you keep beats a big one you don't.`
             : "Flat. Steady is not nothing; it is the floor everything else builds on."}</p>`;

  /* ---- per-quest reliability ---- */
  const quests = byQuest(rows).sort((a, b) => a.rate - b.rate);
  $("#anaQuests").innerHTML = quests.length
    ? quests.slice(0, 8).map(q =>
        `<div class="statrow"><span>${esc(q.name)}${q.mand ? " <b style='color:var(--gold)'>·</b>" : ""}</span>
         <b style="color:${q.rate >= .8 ? "var(--ok)" : q.rate >= .5 ? "var(--paper)" : "var(--blood)"}">${pct(q.rate)}%</b></div>`).join("")
      + `<p class="tiny muted" style="margin-top:10px">Worst first. A quest under 50% is not a discipline problem — it is a badly built quest. Change the hour, halve the size, or cut it.</p>`
    : `<p class="tiny muted">Quests need at least four scheduled appearances before they show up here.</p>`;

  /* ---- category strength ---- */
  const cats = byCat(rows).sort((a, b) => b.rate - a.rate);
  $("#anaCats").innerHTML = cats.length
    ? cats.map(c => `<div class="statrow"><span>${CATLABEL[c.cat] || c.cat}</span><b>${pct(c.rate)}% <span style="color:var(--ash)">of ${c.n}</span></b></div>`).join("")
    : `<p class="tiny muted">No category has enough history yet.</p>`;
}
