/* THE SYSTEM v14 — views/frontier.js
   Surfaces for Phases 15–18: the journey map on Home, the Circle section, and
   Studio (performance, business, launch).

   Two new sections rather than four. Phase 12 spent a whole session cutting
   thirteen destinations down to six areas, and undoing that to file four new
   panels would be the same mistake in a different coat. */
"use strict";

/* ══════════════ the loop map (Home) ══════════════ */
/* Named renderLoopMap, not renderJourney. views/build.js has owned that name since
   Phase 9 for the growth journey timeline. The collision guard caught this before
   it shipped — the fourth time in this project that a new function was about to
   silently delete an older feature by sharing its name. */
function renderLoopMap(){
  const box = $("#homeJourney"); if(!box) return;
  const j = journeyState(); if(!j){ box.innerHTML = ""; return; }
  box.innerHTML = `
    <div class="jm-head">The loop</div>
    <div class="jm-row">${j.stages.map(s => `
      <button class="jm ${s.reached ? "on" : ""} ${j.gap && j.gap.k === s.k ? "gap" : ""}" data-jm="${s.k}"
        title="${esc(s.what)}"><b>${esc(s.label)}</b><small>${s.count || "—"}</small></button>`).join("")}</div>
    <div class="jm-verdict">${esc(j.verdict)}</div>`;
  box.querySelectorAll("[data-jm]").forEach(b => b.onclick = () => {
    const s = JOURNEY.find(x => x.k === b.dataset.jm);
    if(s) go(s.go[0], s.go[1]);
  });
}

/* ══════════════ Circle (Phase 16) ══════════════ */
function renderCircle(){
  if(!$("#ciGroups")) return;
  const c = community(); if(!c) return;

  $("#ciGroups").innerHTML = (c.groups || []).length
    ? c.groups.map(g => {
        const hh = groupHealth(g);
        return `<div class="act">
          <div class="act-h"><b>${esc(g.name)}</b><span>${g.members.length} member${g.members.length===1?"":"s"}</span></div>
          <div class="act-n">${esc(hh.verdict)}</div>
          <div class="act-m">${hh.sessions} sessions · ${hh.minutes} min · ${hh.goalsDone}/${hh.goals} goals done</div>
          <div class="opp-acts">
            <button class="btn sm gold" data-cisess="${g.id}">Log a session</button>
            <button class="btn sm ghost" data-cigoal="${g.id}">+ Group goal</button>
          </div>
          ${(g.goals||[]).length ? `<div class="phase-f">${g.goals.map(x => `<span>${x.done ? "✔ " : ""}${esc(x.text)}</span>`).join("")}</div>` : ""}
        </div>`;
      }).join("")
    : `<div class="empty"><b>No study group.</b>
        <p>A group here is a shared intention, not a chat. You add first names, log the sessions you actually hold, and the System tells you honestly whether it is still meeting. Nothing is sent anywhere.</p></div>`;

  $$("[data-cisess]").forEach(b => b.onclick = async () => {
    const mins = await sysPrompt("Minutes", { inputType:"number", placeholder:"45", ok:"Next" });
    const note = (await sysPrompt("What did you cover?", { placeholder:"optional", ok:"Log" }) || "").trim();
    logGroupSession(b.dataset.cisess, { minutes:Number(mins) || 30, note });
    renderCircle(); renderAll();
  });
  $$("[data-cigoal]").forEach(b => b.onclick = async () => {
    const t = (await sysPrompt("What is the group committing to?", { placeholder:"e.g. finish chapter 6 by Friday", ok:"Add" }) || "").trim();
    if(t){ addGroupGoal(b.dataset.cigoal, { text:t }); renderCircle(); }
  });

  /* pacts */
  $("#ciPacts").innerHTML = (c.pacts || []).length
    ? c.pacts.map(p => `<div class="act">
        <div class="act-h"><b>${esc(p.commitment)}</b><span>with ${esc(p.withWhom)}</span></div>
        <div class="act-m">${(p.checkins||[]).filter(x=>x.kept).length} kept of ${(p.checkins||[]).length} check-ins</div>
        <div class="opp-acts">
          <button class="btn sm gold" data-pk="${p.id}|1">Kept it</button>
          <button class="btn sm ghost" data-pk="${p.id}|0">Missed it</button>
        </div></div>`).join("")
    : `<div class="empty"><b>No pact.</b><p>One person, one commitment, a check-in date. No scoreboard and nothing public — the only mechanism here is that somebody will ask.</p></div>`;
  $$("[data-pk]").forEach(b => b.onclick = () => {
    const [id, kept] = b.dataset.pk.split("|");
    pactCheckin(id, kept === "1"); renderCircle(); renderAll();
  });

  /* the report the student hands over */
  $("#ciReport").innerHTML = `
    <div class="rv-list">${REPORT_SECTIONS.map(s =>
      `<div><span>${esc(s.label)}</span><b>${esc(s.blurb)}</b></div>`).join("")}</div>
    <button class="btn sm gold" id="ciBuild" style="margin-top:10px">Generate it</button>
    <p class="tiny muted" style="margin-top:10px">You generate it and you hand it over. No teacher account reads your device \u2014 an adult who can see everything you track changes what you are willing to write down, and the reflections are the part worth protecting.</p>
    <pre id="ciOut" class="report-out hidden"></pre>`;
  $("#ciBuild").onclick = () => {
    const txt = reportText(buildReport());
    const out = $("#ciOut"); out.textContent = txt; out.classList.remove("hidden");
  };

  /* class work in */
  $("#ciClass").innerHTML = `
    <textarea class="in" id="ciPaste" rows="5" placeholder="Paste homework, one item per line — from the board, a group chat, wherever it came from."></textarea>
    <button class="btn sm gold" id="ciImport" style="margin-top:10px">Turn it into deadlines</button>`;
  $("#ciImport").onclick = () => {
    const r = importClassWork($("#ciPaste").value);
    $("#ciPaste").value = "";
    renderAll();
    toast(r.added ? "Added" : "Nothing to add", r.added ? `${r.added} deadline${r.added===1?"":"s"} created, due in a week by default.` : "Paste one item per line.", r.added ? "gold" : "blood");
  };

  /* the refusals, stated in the product rather than only in a comment */
  $("#ciRefused").innerHTML = COMMUNITY_REFUSED.map(x =>
    `<div class="fac fail"><span>${esc(x.k)}</span><em>${esc(x.why)}</em></div>`).join("") +
    `<p class="tiny muted" style="margin-top:10px">These are absent on purpose, not unfinished. Each one needs somebody reading reports and handling escalation, and there is one developer and no such operation. When there is, they become a build rather than a rewrite.</p>`;
}

/* ══════════════ Studio (Phases 15, 17, 18) ══════════════ */
function renderStudio(){
  if(!$("#stPerf")) return;

  /* performance */
  const p = perfReport();
  $("#stPerf").innerHTML = `
    <p class="tiny" style="line-height:1.6">${esc(p.verdict)}</p>
    ${p.views.length ? `<div class="rv-list">${p.views.slice(0,6).map(v =>
      `<div><span>${esc(v.view)}</span><b class="${v.overBudget ? "dn" : "up"}">${Math.round(v.avg)}ms avg · ${Math.round(v.worst)}ms worst</b></div>`).join("")}</div>` : ""}
    <div class="sep"></div>
    <div class="rv-list">
      <div><span>Scripts loaded</span><b>${p.bundle ? p.bundle.scripts : "—"}</b></div>
      <div><span>Stylesheets</span><b>${p.bundle ? p.bundle.styles : "—"}</b></div>
      <div><span>Record size</span><b>${(p.storage.bytes/1024).toFixed(0)} KB of ${(p.storage.budget/1024/1024).toFixed(0)} MB</b></div>
    </div>
    ${p.bundle ? `<p class="tiny muted" style="margin-top:8px">${esc(p.bundle.note)}</p>` : ""}
    ${p.storage.parts.length ? `<div class="sep"></div><div class="panel-sub">Biggest parts of your record</div>
      <div class="rv-list">${p.storage.parts.slice(0,5).map(x =>
        `<div><span>${esc(x.label)}</span><b>${(x.bytes/1024).toFixed(0)} KB</b></div>`).join("")}</div>` : ""}
    <div class="sep"></div>
    <div class="panel-sub">Panels that failed to draw</div>
    ${(() => {
      /* safeRender() tells the student details are here. If this section did not
         exist, that message would be the same kind of lie as an offline audit
         that reports "works offline" without checking. */
      const f = typeof renderFailures === "function" ? renderFailures() : [];
      return f.length
        ? f.map(x => `<div class="fac fail"><span>${esc(x.name)}</span><em>${esc(x.message)} \u00b7 ${x.count} time${x.count===1?"":"s"} this session</em></div>`).join("")
        : `<div class="fac pass"><span>None this session</span><em>Every panel that was asked to draw, drew. Failures are recorded here rather than swallowed, so an empty list means what it says.</em></div>`;
    })()}
    <div class="sep"></div>
    <div class="panel-sub">Not measured, and why</div>
    ${p.untested.map(u => `<div class="fac unknown"><span>${esc(u.k)}</span><em>${esc(u.why)}</em></div>`).join("")}
    <button class="btn sm ghost" id="stOffline" style="margin-top:10px">Check offline readiness</button>
    <div id="stOfflineOut"></div>`;
  $("#stOffline").onclick = async () => {
    const a = await offlineAudit();
    /* Three states, not two. "Unknown" is its own answer — the previous version
       had no way to say it and so said nothing, which reads as fine. */
    const cls = a.ready ? "pass" : (a.supported && a.registered ? "fail" : "unknown");
    $("#stOfflineOut").innerHTML = `
      <div class="fac ${cls}" style="margin-top:8px">
        <span>${a.ready ? "Offline verified" : "Offline NOT verified"}</span>
        <em>${esc(a.note)}</em>
      </div>
      <p class="tiny muted" style="margin-top:6px">
        worker ${a.registered ? "registered" : "absent"} \u00b7
        ${a.controlled ? "serving this page" : "not yet serving"} \u00b7
        ${a.cacheName ? esc(a.cacheName) : "no cache"} \u00b7
        ${a.cached} entries \u00b7 ${a.expected - a.missing.length}/${a.expected} required files
        ${a.extra && a.extra.length ? ` \u00b7 ${a.extra.length} old cache(s) still on disk` : ""}
      </p>`;
  };

  /* business */
  const pr = pricing(), m = revenueModel();
  $("#stBiz").innerHTML = `
    <div class="rv-list">
      <div><span>Free by policy</span><b>${pr.free} features</b></div>
      <div><span>Paid</span><b>${pr.paid} features</b></div>
      <div><span>Region</span><b>${esc(pr.region)}</b></div>
      <div><span>Price</span><b>${esc(pr.monthText)} / month · ${esc(pr.yearText)} / year</b></div>
    </div>
    <div class="sep"></div>
    <div class="panel-sub">What is paid, and why</div>
    ${Object.values(PAID_FEATURES).map(f =>
      `<div class="fac ${f.cost === "real" ? "unknown" : "pass"}"><span>${esc(f.label)}</span><em>${esc(f.why || "")}</em></div>`).join("")}
    <div class="sep"></div>
    <div class="panel-sub">Never behind a paywall</div>
    <p class="tiny" style="line-height:1.6">${NEVER_PAID.slice(0,14).map(esc).join(" · ")} … and ${NEVER_PAID.length - 14} more. <b>registerPaidFeature() refuses anything on that list</b>, so this is enforced by the build rather than by good intentions.</p>
    <div class="sep"></div>
    <p class="tiny muted">${esc(m.note)}</p>
    <p class="tiny muted">${esc(m.breakeven)}</p>
    <div class="sep"></div>
    <div class="panel-sub">Refused</div>
    ${DARK_PATTERNS_REFUSED.map(x => `<div class="fac fail"><span>${esc(x.k)}</span><em>${esc(x.why)}</em></div>`).join("")}`;

  /* launch */
  const L = launchChecklist(), a = activationFunnel(), g = growthPlan(), loc = localeStatus();
  $("#stLaunch").innerHTML = `
    <div class="gate-state ${L.ready ? "on" : "off"}"><b>${L.ready ? "Ready" : "Not ready for public launch"}</b>
      <span>${esc(L.verdict)}</span></div>
    <div class="sep"></div>
    ${L.items.map(i => `<div class="fac ${i.ok ? "pass" : "fail"}"><span>${esc(i.k)}</span><em>${esc(i.detail)}</em></div>`).join("")}
    <p class="tiny muted" style="margin-top:10px">There is no override on this list. A checklist you can tick past is decoration.</p>
    ${a ? `<div class="sep"></div>
      <div class="panel-sub">Your own activation — ${a.reached} of ${a.total} in order${a.activated ? "" : " · not activated yet"}</div>
      ${a.steps.map(s => `<div class="fac ${s.given ? "unknown" : (s.done ? "pass" : "fail")}"><span>${esc(s.k)}</span><em>${
        s.given ? "given at signup — not counted" : (s.done ? "done" : "not yet")}</em></div>`).join("")}
      <p class="tiny muted" style="margin-top:8px">${esc(a.definition)}</p>
      ${a.next ? `<p class="tiny" style="color:var(--gold)">Next: ${esc(a.next.k)}</p>` : ""}` : ""}
    <div class="sep"></div>
    <div class="panel-sub">Region</div>
    <div class="row" style="gap:6px;flex-wrap:wrap">${REGIONS.map(r =>
      `<button class="btn sm ${region().k === r.k ? "gold" : "ghost"}" data-reg="${r.k}">${esc(r.label)}</button>`).join("")}</div>
    <p class="tiny muted" style="margin-top:8px">${esc(region().note || "")}</p>
    <p class="tiny muted">${esc(loc.note)}</p>
    <div class="sep"></div>
    <div class="panel-sub">How this is meant to grow</div>
    ${g.channels.map(c => `<div class="fac pass"><span>${esc(c.k)}</span><em>${esc(c.how)}</em></div>`).join("")}
    <div class="panel-sub" style="margin-top:10px">Growth levers refused</div>
    ${g.refused.map(c => `<div class="fac fail"><span>${esc(c.k)}</span><em>${esc(c.why)}</em></div>`).join("")}
    <p class="tiny muted" style="margin-top:10px">${esc(g.note)}</p>`;
  $$("[data-reg]").forEach(b => b.onclick = () => { region(b.dataset.reg); renderStudio(); renderNetBanner && renderNetBanner(); });
}

/* ---------- wiring ---------- */
function renderFrontier(){
  safeRender("loop map", renderLoopMap);
  if($("#ciGroups")) safeRender("circle", renderCircle, { into:"#ciGroups" });
  if($("#stPerf")) safeRender("studio", renderStudio, { into:"#stPerf" });
}
Hooks.after("renderHome", "loop map", () => safeRender("loop map", renderLoopMap));

/* ---------- Circle: the two create buttons ---------- */
function wireCircle(){
  const g = $("#ciAddGroup");
  if(g) g.onclick = async () => {
    const name = (await sysPrompt("Group name", { placeholder:"e.g. Physics revision", ok:"Next" }) || "").trim();
    if(!name) return;
    const purpose = (await sysPrompt("What is it for?", { placeholder:"optional", ok:"Next" }) || "").trim();
    const who = (await sysPrompt("Who is in it?", {
      msg:"First names, separated by commas. THE SYSTEM does not look anybody up and does not contact anyone \u2014 these are labels for you.",
      placeholder:"Ama, Kwesi, Efua", ok:"Create" }) || "").trim();
    createGroup({ name, purpose, members: who ? who.split(",") : [] });
    renderCircle();
  };
  const p = $("#ciAddPact");
  if(p) p.onclick = async () => {
    const who = (await sysPrompt("Who with?", { placeholder:"First name", ok:"Next" }) || "").trim();
    if(!who) return;
    const what = (await sysPrompt("What are you committing to?", {
      msg:"One sentence, specific enough that both of you would know whether it happened.",
      placeholder:"e.g. two hours of maths every weeknight", ok:"Make it" }) || "").trim();
    if(!what) return;
    createPact({ withWhom:who, commitment:what });
    renderCircle();
  };
}
document.addEventListener("DOMContentLoaded", wireCircle);
if(document.readyState !== "loading") wireCircle();
