/* THE SYSTEM v18 — views/tutor.js
   Draws the tutor. Owns no logic and calls no network.

   Everything this file used to do — the knowledge base, the prompt builders,
   the conversation log, and a raw fetch() to the hunter's endpoint — now lives
   in services/tutor.js, which reaches the network only through services/ai.js.
   See that file for why. What is left here is DOM: subject chips, message
   bubbles, and the two event handlers that connect them. */

/* Rendering a message. The body is set with textContent, never innerHTML — an
   answer from a model is untrusted input like any other. */
function tutDraw(msg){
  const box = $("#tutLog"); if(!box) return;
  const el = document.createElement("div");
  el.className = "tmsg " + (msg.role === "user" ? "user" : "sys");
  el.innerHTML = `<div class="who"></div><div class="body ${msg.cls || ""}"></div>`;
  el.querySelector(".who").textContent = msg.role === "user" ? (H() ? H().name : "You") : "System Tutor";
  el.querySelector(".body").textContent = msg.text;
  if(msg.note){
    const n = document.createElement("div");
    n.className = "tiny muted"; n.textContent = msg.note;
    el.appendChild(n);
  }
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;
}

function renderTutor(){
  const h = H(); if(!h || !$("#tutSubs")) return;
  $("#tutCur").textContent = Tutor.curriculumLabel(h);
  $("#tutMode").textContent = Tutor.modeText();

  const subs = Tutor.subjects(h), box = $("#tutSubs");
  box.innerHTML = "";
  if(!subs.includes(Tutor.subject)) Tutor.setSubject(subs[0]);
  subs.forEach(s => {
    const b = document.createElement("button");
    b.className = "chip" + (s === Tutor.subject ? " on" : "");
    b.textContent = s;
    b.onclick = () => { Tutor.setSubject(s); renderTutor(); };
    box.appendChild(b);
  });
}

async function tutAsk(){
  const input = $("#tutIn"); if(!input) return;
  const q = input.value.trim();
  if(!q || Tutor.busy) return;
  input.value = "";
  const go = $("#tutGo");
  if(go){ go.textContent = "\u2026"; go.disabled = true; }
  try{
    const msgs = await Tutor.ask(q);
    msgs.forEach(tutDraw);
  } finally {
    /* finally, not after the await: a throw must not leave the button
       permanently disabled with the student locked out of their own tutor. */
    if(go){ go.textContent = "Ask"; go.disabled = false; }
    renderTutor();
  }
}
