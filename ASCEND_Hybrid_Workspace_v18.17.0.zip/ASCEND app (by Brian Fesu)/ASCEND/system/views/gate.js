/* THE SYSTEM v14 — views/gate.js
   The Online Gate.

   §44 asks for a simple screen and §3 asks that connection status be present but
   subtle. §54 is the one that governs the tone throughout: this must never read as
   a barrier. So the first sentence on the page says the app is fully functional
   without any of it, and the sync panel leads with "your local progress is safe"
   rather than with an error. */
"use strict";

/* Named renderOnlineGate, not renderGate. views/v9-views.js has owned that name
   since v11 for the Open Gate — the nine dropout-help lessons in Wealth. This file
   loads later, so calling mine renderGate silently replaced it: the lessons stopped
   rendering and "Mark studied" called this function instead. Nothing errored, which
   is why it survived two releases. The older name belongs to the older feature. */
function renderOnlineGate(){ return Hooks.dispatch("renderOnlineGate", renderOnlineGateBase, this, arguments); }
function renderOnlineGateBase(){
  if(!$("#gStatus")) return;
  const st = gateStatus(); if(!st) return;
  const pending = pendingChanges();

  /* ---- status ---- */
  $("#gStatus").innerHTML = `
    <div class="gate-state ${st.online ? "on" : "off"}">
      <b>${st.online ? "Connected" : "Offline"}</b>
      <span>${esc(st.text)}</span>
    </div>
    <div class="sep"></div>
    <div class="rv-list">
      <div><span>Mode</span><b>${st.mode === "account" ? "Account" : "This device only"}</b></div>
      <div><span>Server</span><b>${st.apiBase ? esc(st.apiBase) : "not set"}</b></div>
      <div><span>Transport</span><b>${esc(st.driver)}</b></div>
      <div><span>Account</span><b>${st.account ? esc(st.account.displayName) : "none"}</b></div>
      <div><span>Connection</span><b>${st.metered === true ? "Mobile data" : st.metered === false ? "Wi-Fi" : "not reported"}</b></div>
      <div><span>Waiting to sync</span><b>${pending.length}</b></div>
      <div><span>Last sync</span><b>${st.lastSync ? new Date(st.lastSync).toLocaleString() : "never"}</b></div>
    </div>
    <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn sm ghost" id="gServer">${st.apiBase ? "Change server" : "Set server"}</button>
      ${st.mode === "account"
        ? `<button class="btn sm gold" id="gSyncNow">Sync now</button><button class="btn sm ghost" id="gOut">Sign out</button>`
        : st.apiBase
          ? `<button class="btn sm gold" id="gIn">Create an account</button><button class="btn sm ghost" id="gSignIn">Sign in</button><button class="btn sm ghost" id="gForgot">Forgot password</button>`
          : `<button class="btn sm ghost" id="gDemo">Try it without a server</button>`}
    </div>
    <p class="tiny muted" style="margin-top:12px">${st.apiBase
      ? "An account adds backup, other devices and the AI tutor. It adds nothing to the learning itself \u2014 every quest, subject and record on this screen works with no account and no connection."
      : "ASCEND works with no server at all, and that is not a degraded mode. Setting one adds backup, sync across devices and the tutor. The demo transport below is an in-memory server for trying the sync behaviour without one."}</p>`;

  const srv = $("#gServer");
  if(srv) srv.onclick = async () => {
    const v = await sysPrompt("ASCEND server address", {
      msg:"The address of the ASCEND backend \u2014 yours, or your school's. Leave it empty to disconnect.",
      value: st.apiBase || "", placeholder:"https://ascend.example.com", ok:"Check" });
    if(v === null) return;
    if(!v.trim()){ cloudApiBase(null); setCloudDriver("local"); renderOnlineGate(); return; }
    const problem = cloudApiProblem(v);
    if(problem){ sysAlert("That address will not work", problem); return; }
    srv.textContent = "Checking\u2026";
    const h = await cloudHealth(v);
    if(!h.ok){ renderOnlineGate(); sysAlert("Could not use that server", h.text); return; }
    cloudApiBase(v); setCloudDriver("rest");
    renderOnlineGate();
    toast("Server set", h.text, "gold");
  };

  /* One flow for both buttons: the only difference is whether the account is
     created first. Two near-identical handlers is how they drift apart. */
  async function accountFlow(register){
    const email = (await sysPrompt(register ? "Email for the new account" : "Email", {
      msg: register
        ? "Used to sign in and to recover the account. Nothing is sent to it \u2014 there is no mailing list."
        : "The email on the account.",
      inputType:"email", placeholder:"you@example.com", ok:"Next" }) || "").trim();
    if(!email) return;
    const password = await sysPrompt("Password", {
      msg: register
        ? "Twelve characters or more. Write it somewhere safe \u2014 password reset is not built yet, so a forgotten password means a new account."
        : "Your ASCEND password.",
      inputType:"password", ok: register ? "Create account" : "Sign in" });
    if(!password) return;

    setCloudDriver("rest");
    const acct = await signIn({ email, password, register, displayName: (H() || {}).name });
    const status = gateStatus();
    renderOnlineGate();
    if(!acct){
      sysAlert(register ? "Could not create the account" : "Could not sign in",
        (status && status.lastError) || "The server refused the request.");
      return;
    }
    toast(register ? "Account created" : "Signed in",
      "Everything already on this device is queued for upload. Nothing was replaced.", "gold");
    await refreshEntitlements();
    const r = await syncNow({ force:true });
    renderOnlineGate();
    if(!r.ok && r.reason === "error") toast("Sync will retry", "Your local progress is safe.", "blood");
  }
  const forgot = $("#gForgot");
  if(forgot) forgot.onclick = async () => {
    const email = (await sysPrompt("Email on the account", {
      msg:"A reset link goes to this address. Your quests, progress and records are untouched either way \u2014 a reset only affects signing in.",
      inputType:"email", placeholder:"you@example.com", ok:"Send" }) || "").trim();
    if(!email) return;
    const r = await requestPasswordReset(email);
    if(!r.ok){ sysAlert("Could not send it", r.error); return; }

    const token = (await sysPrompt("Paste the code", {
      msg: r.message + "\n\nOpen the email and paste the code here. It lasts an hour and works once.",
      ok:"Next" }) || "").trim();
    if(!token) return;
    const pw = await sysPrompt("New password", {
      msg:"Twelve characters or more. Every device signed into this account will be signed out \u2014 including any you have lost.",
      inputType:"password", ok:"Change it" });
    if(!pw) return;

    const done = await confirmPasswordReset(token, pw);
    renderOnlineGate();
    if(done.ok) toast("Password changed", done.message, "gold");
    else sysAlert("That did not work", done.error);
  };

  const inb = $("#gIn");     if(inb) inb.onclick = () => accountFlow(true);
  const sib = $("#gSignIn"); if(sib) sib.onclick = () => accountFlow(false);

  const demo = $("#gDemo");
  if(demo) demo.onclick = async () => {
    const name = (await sysPrompt("Display name", {
      msg:"A name, a nickname, anything. Never your full legal name \u2014 nothing here needs it. This runs against an in-memory server on this device: the sync, the queue and the conflict rules are real, but nothing leaves the tab and nothing survives a reinstall.",
      placeholder:"e.g. Kael", ok:"Start" }) || "").trim();
    if(!name) return;
    setCloudDriver("loopback");
    const acct = await signIn({ displayName:name });
    renderOnlineGate();
    if(acct) toast("Demo account", "In-memory only \u2014 set a server for real backup.", "gold");
  };

  const outb = $("#gOut");
  if(outb) outb.onclick = async () => {
    if(await sysConfirm("Sign out?", "Every quest, note, project and record stays exactly where it is on this device. Signing out only stops syncing, and revokes this device's session on the server.", { ok:"Sign out" })){
      await signOut(); renderOnlineGate();
    }
  };
  const sn = $("#gSyncNow");
  if(sn) sn.onclick = async () => {
    sn.textContent = "Syncing…";
    const r = await syncNow({ force:true });
    renderOnlineGate(); renderAll();
    if(r.ok && r.conflicts && r.conflicts.length){
      sysAlert("Two devices changed the same thing",
        "Both versions were kept and merged rather than one overwriting the other. Affected: " +
        r.conflicts.map(c => `${c.scope} (${c.ids.length})`).join(", ") +
        ".\n\nNothing was discarded. If something looks wrong, your export is still the authoritative copy.");
    } else if(!r.ok && r.reason === "error"){
      toast("Sync paused", "Your local progress is safe. It will retry on its own.", "blood");
    }
  };

  /* ---- sync settings (§46) ---- */
  const cs = cloudSettings();
  $("#gSync").innerHTML = `
    <div class="rv-list">
      <div><span>Sync automatically</span><b><button class="btn sm ghost" data-t="auto">${cs.auto ? "On" : "Off"}</button></b></div>
      <div><span>Wi-Fi only</span><b><button class="btn sm ghost" data-t="wifiOnly">${cs.wifiOnly ? "On" : "Off"}</button></b></div>
      <div><span>Include progress</span><b><button class="btn sm ghost" data-i="progress">${cs.include.progress !== false ? "Yes" : "No"}</button></b></div>
      <div><span>Include Academy</span><b><button class="btn sm ghost" data-i="academy">${cs.include.academy !== false ? "Yes" : "No"}</button></b></div>
      <div><span>Include projects</span><b><button class="btn sm ghost" data-i="projects">${cs.include.projects !== false ? "Yes" : "No"}</button></b></div>
    </div>
    <p class="tiny muted" style="margin-top:12px">Anything switched off is not collected at all, rather than collected and filtered later.</p>
    ${pending.length ? `<div class="sep"></div><div class="panel-sub">Waiting</div>${
      pending.slice(0,8).map(q => `<div class="tiny" style="padding:4px 0">${esc(q.scope)} \u00b7 ${q.n} change${q.n===1?"":"s"} \u00b7 ${new Date(q.at).toLocaleTimeString()}</div>`).join("")
    }` : ""}`;
  $$("[data-t]").forEach(b => b.onclick = () => { const k = b.dataset.t; cloudSettings({ [k]: !cs[k] }); renderOnlineGate(); });
  $$("[data-i]").forEach(b => b.onclick = () => { const k = b.dataset.i; cloudSettings({ include:{ [k]: cs.include[k] === false } }); renderOnlineGate(); });

  /* ---- services (§53) ---- */
  $("#gServices").innerHTML = Api.status().map(s => `
    <div class="svc ${s.state}">
      <div class="svc-h"><b>${esc(s.label)}</b><span>${esc(s.state)}</span></div>
      <div class="svc-b">${esc(s.advice.text)}</div>
    </div>`).join("") + `
    <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn sm ghost" id="gProxy">Set a proxy URL</button>
      <button class="btn sm ghost" id="gClearCache">Clear cache (${Api.cacheSize})</button>
    </div>
    <p class="tiny muted" style="margin-top:10px">THE SYSTEM ships no API key of its own. If any of these fail, only that feature stops \u2014 the rest of the app does not notice.</p>`;
  const px = $("#gProxy");
  if(px) px.onclick = async () => {
    const cur = (apiConfig() || {}).proxyBase || "";
    const v = await sysPrompt("Proxy base URL", {
      msg:"A small endpoint you control that holds the API keys and forwards the request. This is the correct arrangement \u2014 a key in a browser is a public key, whoever owns it.",
      value:cur, placeholder:"https://your-worker.example.workers.dev", ok:"Save" });
    if(v !== null){ apiConfig({ proxyBase:v }); renderOnlineGate(); }
  };
  const cc = $("#gClearCache");
  if(cc) cc.onclick = () => { Api.clearCache(); renderOnlineGate(); toast("Cache cleared","","gold"); };

  /* ---- data ownership (§10) ---- */
  $("#gData").innerHTML = `
    <div class="rv-list">
      <div><span>Storage driver</span><b>${esc(Store.driver)}${Store.durable ? "" : " (not durable)"}</b></div>
      <div><span>Approximate size</span><b>${(Store.bytes()/1024).toFixed(1)} KB</b></div>
      <div><span>Release</span><b>${esc(typeof SYSTEM_VERSION === "string" ? SYSTEM_VERSION : "unknown")}</b></div>
      <div><span>Schema version</span><b>${SCHEMA}</b></div>
      <div><span>Device</span><b>${esc(deviceId().slice(0,8))}</b></div>
    </div>
    <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn sm ghost" id="gExport">Export everything</button>
      <button class="btn sm danger" id="gWipeCloud">Delete the cloud copy</button>
    </div>
    <p class="tiny muted" style="margin-top:12px">Deleting the cloud copy leaves this device untouched \u2014 that is the point of an export. ${Store.durable ? "" : "<b>This browser is not storing data durably.</b> Export now; a reload may lose everything."}</p>`;
  const ex = $("#gExport");
  /* This used to be guarded with a typeof check that fell through to go("set").
     exportHunter() did not exist, so the guard was always false and the button
     quietly navigated instead of exporting — under a paragraph telling people
     with non-durable storage to export now or lose everything. No fallback: if
     the export ever goes missing again, this should fail loudly. */
  if(ex) ex.onclick = () => exportHunter();
  const wc = $("#gWipeCloud");
  if(wc) wc.onclick = async () => {
    if(await sysConfirm("Delete the cloud copy?", "Everything on this device stays. Only the server-side copy goes, and it goes immediately.", { ok:"Delete", danger:true })){
      const ok = await deleteCloudData();
      renderOnlineGate();
      toast(ok ? "Cloud copy deleted" : "Could not delete", ok ? "This device is unaffected." : "Nothing was changed.", ok ? "gold" : "blood");
    }
  };
}

/* start listening for connection changes once the app is up */
if(typeof watchConnection === "function") watchConnection();
