/* THE SYSTEM v13 — views/forge.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ THE FORGE — 50 hobbies, pick exactly 4 ══════════════ */
let forgeCat = "all";

function forgeCats(){ return ["all", ...[...new Set(HOBBIES.map(x=>x.c))]]; }

function renderForge(){
  const h = H(); if(!h || !$("#forgeList") || typeof HOBBIES === "undefined") return;
  h.hobbies = Array.isArray(h.hobbies) ? h.hobbies : [];
  h.hobbyLog = h.hobbyLog || {};

  /* category chips */
  const cats = $("#forgeCats"); cats.innerHTML = "";
  forgeCats().forEach(c => {
    const b = document.createElement("button");
    b.className = "chip" + (forgeCat === c ? " on" : "");
    b.textContent = c === "all" ? "All 50" : c;
    b.onclick = () => { forgeCat = c; renderForge(); };
    cats.appendChild(b);
  });

  const n = h.hobbies.length;
  const cnt = $("#forgeCount");
  cnt.className = "forge-count" + (n === 4 ? " full" : "");
  cnt.textContent = n === 4 ? "FOUR CHOSEN — THE FORGE IS SEALED. UNPICK ONE TO SWAP."
    : `${n} OF 4 CHOSEN — ${4-n} SLOT${4-n===1?"":"S"} REMAIN`;

  /* chosen block, with a daily practice log */
  const chosenBox = $("#forgeChosen"); chosenBox.innerHTML = "";
  if(!n){
    chosenBox.innerHTML = `<p class="muted tiny">Nothing chosen yet. Scroll the forge below and pick four. Skills you already do count — claim them.</p>`;
  } else {
    const today = todayKey();
    h.hobbies.forEach(k => {
      const x = HOBBIES.find(y=>y.k===k); if(!x) return;
      const logged = (h.hobbyLog[today]||{})[k];
      const el = document.createElement("div");
      el.className = "hob sel";
      el.innerHTML = `<div style="flex:1"><div class="hn">${esc(x.n)}</div><div class="hc">${esc(x.c)}</div>
        <div class="hs"><b>THIS WEEK</b>${esc(x.s)}</div></div>`;
      const btn = document.createElement("button");
      btn.className = "btn sm hpick " + (logged ? "ghost" : "gold");
      btn.textContent = logged ? "Logged ✓" : "Practised · +15 XP";
      btn.disabled = !!logged;
      btn.onclick = () => {
        h.hobbyLog[today] = h.hobbyLog[today] || {};
        h.hobbyLog[today][k] = true;
        grantXp(15, "Forge: " + x.n, "hobby"); save(); renderForge();
      };
      el.appendChild(btn);
      chosenBox.appendChild(el);
    });
    if(n === 4){
      const note = document.createElement("div"); note.className = "build-step";
      note.innerHTML = `<b>WHY FOUR</b>Nobody is short of interests. People are short of finished ones. Four skills practised for two years each beats twenty tried for a fortnight — and four is small enough that you cannot hide behind "I was busy with the others". Log each one on the day you actually touch it. Empty weeks are data, not failure: if a slot stays empty a month, it was never your skill. Swap it.`;
      chosenBox.appendChild(note);
    }
  }

  /* the full list */
  const q = ($("#forgeSeek") && $("#forgeSeek").value || "").trim().toLowerCase();
  const box = $("#forgeList"); box.innerHTML = "";
  let list = HOBBIES.filter(x => forgeCat === "all" || x.c === forgeCat);
  if(q) list = HOBBIES.filter(x => (x.n+" "+x.c+" "+x.w).toLowerCase().includes(q));
  let group = "";
  list.forEach(x => {
    if(x.c !== group && !q){
      group = x.c;
      const gh = document.createElement("div"); gh.className = "genre-head"; gh.textContent = group;
      box.appendChild(gh);
    }
    const on = h.hobbies.includes(x.k);
    const el = document.createElement("div");
    el.className = "hob" + (on ? " sel" : "");
    el.innerHTML = `<div style="flex:1"><div class="hn">${esc(x.n)}</div><div class="hc">${esc(x.c)}</div>
      <div class="hw">${esc(x.w)}</div><div class="hs"><b>START</b>${esc(x.s)}</div></div>`;
    const btn = document.createElement("button");
    btn.className = "btn sm hpick " + (on ? "gold" : "ghost");
    btn.textContent = on ? "Chosen ✓" : "Choose";
    btn.onclick = () => {
      if(on){ h.hobbies = h.hobbies.filter(y=>y!==x.k); save(); renderForge(); return; }
      if(h.hobbies.length >= 4){
        toast("Four is the limit", "Drop one first. The System will not let you collect intentions you have no hours for.", "blood");
        return;
      }
      h.hobbies = [...h.hobbies, x.k];
      grantXp(10, "Forge slot filled: " + x.n);
      save(); renderForge();
    };
    el.appendChild(btn);
    box.appendChild(el);
  });
  if(!list.length) box.innerHTML = `<p class="muted tiny">Nothing matches that.</p>`;
}
if($("#forgeSeek")) $("#forgeSeek").addEventListener("input", () => renderForge());

