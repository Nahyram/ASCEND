/* THE SYSTEM v14 — views/build.js
   Projects, the portfolio, and the journey they add up to.

   §83/§84: a project card shows title, category, stage, progress and next
   milestone. Not every field. §85: empty states teach.

   The publish flow is the part worth reading. §36 and §48 say a project must be
   reviewed and then deliberately selected, so the button does not toggle a flag —
   it runs a readiness check and, if the project is not ready, refuses and says
   exactly what is missing. */
"use strict";

function projectCard(p){
  const prog = projectProgress(p);
  const stage = PROJECT_STAGES.find(s => s.k === p.stage) || PROJECT_STAGES[0];
  return `<div class="proj ${p.stage}" data-p="${p.id}">
    <div class="proj-h">
      <b>${esc(p.title)}</b>
      <span class="proj-stage">${esc(stage.label)}</span>
      ${p.featured ? `<span class="proj-feat">in portfolio</span>` : ""}
    </div>
    <div class="proj-m">${esc(p.category)}${p.description ? " · " + esc(p.description) : ""}</div>
    <div class="ms-bar"><i style="width:${Math.round(prog.pct*100)}%"></i></div>
    <div class="proj-next">${prog.done}/${prog.n} milestones${prog.next ? ` · next: ${esc(prog.next.name)}` : " · all done"}</div>
    <div class="proj-ms">
      ${(p.milestones||[]).map(m => `<div class="boss-st ${m.done ? "on" : ""}" data-ms="${p.id}|${m.id}" role="button" tabindex="0">
        <span class="tick">${m.done ? "✔" : "○"}</span><span>${esc(m.name)}</span></div>`).join("")}
    </div>
    <div class="opp-acts">
      <button class="btn sm ghost" data-pstage="${p.id}">Change stage</button>
      <button class="btn sm ghost" data-pev="${p.id}">+ Evidence (${(p.evidence||[]).length})</button>
      <button class="btn sm ghost" data-pskill="${p.id}">+ Skill</button>
      <button class="btn sm ghost" data-pref="${p.id}">${p.reflection ? "Reflection ✔" : "Reflect"}</button>
      <button class="btn sm ${p.featured ? "ghost" : "gold"}" data-pfeat="${p.id}">${p.featured ? "Remove from portfolio" : "Add to portfolio"}</button>
      <button class="btn sm danger" data-parch="${p.id}">Archive</button>
    </div>
    <details class="opp-why"><summary>What this project demonstrates</summary>
      ${(() => { const d = projectDimensions(p);
        return `<div class="dims">${d.dims.map(x => `<div class="fac ${x.have ? "pass" : "unknown"}"><span>${esc(x.label)}</span><em>${esc(x.note)}</em></div>`).join("")}</div>
        <p class="tiny muted" style="margin-top:8px">${d.met} of ${d.total}. These are dimensions rather than a score, deliberately — one number just invites optimising the number.</p>`; })()}
      ${(p.skills||[]).length ? `<div class="sep"></div>${p.skills.map(s => `<div class="fac pass"><span>${esc(s.name)}</span><em>${esc(s.evidence)}</em></div>`).join("")}` : ""}
      ${(p.evidence||[]).length ? `<div class="sep"></div>${p.evidence.map(e => `<div class="fac ${e.visibility === "private" ? "unknown" : "pass"}"><span>${esc(e.name)}</span><em>${esc(e.visibility)}${e.url ? " · " + esc(e.url) : ""}</em></div>`).join("")}` : ""}
    </details>
  </div>`;
}

function renderBuildProjects(){
  const box = $("#bProjects"); if(!box) return;
  const list = projects().filter(p => !p.archived);
  box.innerHTML = list.length ? list.map(projectCard).join("")
    : `<div class="empty"><b>No projects yet.</b>
        <p>A project is where studying stops being private. The smallest real thing you could show somebody in two weeks beats the best-planned imaginary one \u2014 and it is the only kind that ever gets finished.</p></div>`;

  box.querySelectorAll("[data-ms]").forEach(el => {
    const [pid, mid] = el.dataset.ms.split("|");
    const act = () => { toggleMilestone(pid, mid); renderBuild(); renderAll(); };
    el.onclick = act;
    el.onkeydown = e => { if(e.key === "Enter" || e.key === " "){ e.preventDefault(); act(); } };
  });
  box.querySelectorAll("[data-pstage]").forEach(b => b.onclick = async () => {
    const list_ = PROJECT_STAGES.map((s,i) => `${i+1}. ${s.label} — ${s.blurb}`).join("\n");
    const pick = await sysPrompt("Stage", { msg:list_, inputType:"number", placeholder:"3", ok:"Set" });
    const s = PROJECT_STAGES[Number(pick)-1]; if(!s) return;
    setProjectStage(b.dataset.pstage, s.k); renderBuild(); renderAll();
  });
  box.querySelectorAll("[data-pev]").forEach(b => b.onclick = async () => {
    const name = (await sysPrompt("What is the evidence?", {
      msg:"A repository, a document, a photo, a results page. THE SYSTEM stores a description and a link \u2014 it does not hold your files, and it should never hold your identity documents.",
      placeholder:"e.g. GitHub repository", ok:"Next" }) || "").trim();
    if(!name) return;
    const warn = evidenceWarning(name);
    if(warn){ await sysAlert("Do not attach that", warn); return; }
    const url = (await sysPrompt("Link (optional)", { placeholder:"https://…", ok:"Add" }) || "").trim();
    addEvidence(b.dataset.pev, { name, url });
    renderBuild();
  });
  box.querySelectorAll("[data-pskill]").forEach(b => b.onclick = async () => {
    const name = (await sysPrompt("Which skill?", { placeholder:"e.g. Programming", ok:"Next" }) || "").trim();
    if(!name) return;
    const ev = (await sysPrompt("What did you do that shows it?", {
      msg:"One sentence. \u201cProgramming +50\u201d means nothing to anybody; \u201cwrote the sensor logic and debugged the navigation\u201d means something.",
      placeholder:"e.g. built the control software", ok:"Add" }) || "").trim();
    if(!ev) return toast("Evidence required","A skill claim without evidence does not go on a portfolio.","blood");
    attachSkill(b.dataset.pskill, { name, evidence:ev }); renderBuild();
  });
  box.querySelectorAll("[data-pref]").forEach(b => b.onclick = async () => {
    const answers = {};
    for(const q of REFLECTION_PROMPTS){
      const a = (await sysPrompt(q.q, { msg:"Short is fine. Skip any that do not apply.", ok:"Next" }) || "").trim();
      if(a) answers[q.k] = a;
    }
    if(Object.keys(answers).length){ saveReflection(b.dataset.pref, answers); renderBuild(); renderAll(); }
  });
  box.querySelectorAll("[data-pfeat]").forEach(b => b.onclick = async () => {
    const p = getProject(b.dataset.pfeat);
    if(p.featured){ featureProject(p.id, false); renderBuild(); return; }
    const r = featureProject(p.id, true);
    if(!r.ok){
      await sysAlert("Not ready for the portfolio",
        "A portfolio entry is a claim somebody might check. Before this one goes up:\n\n• " + r.blockers.join("\n• "));
      return;
    }
    renderBuild(); toast("Added to your portfolio", "Only the evidence you marked non-private will show.", "gold");
  });
  box.querySelectorAll("[data-parch]").forEach(b => b.onclick = async () => {
    if(await sysConfirm("Archive this project?", "It stays in your record and can be restored. Nothing is deleted.", { ok:"Archive" })){
      archiveProject(b.dataset.parch, true); renderBuild();
    }
  });

  const sg = $("#bSuggest");
  const sug = projectSuggestions();
  sg.innerHTML = sug.length
    ? sug.map(s => `<div class="br-row"><div class="br-k">Next</div><div class="br-v"><b>${esc(s.text)}</b><em>${esc(s.why)}</em></div></div>`).join("")
    : `<p class="muted tiny">Nothing missing. Every project you have finished is documented, evidenced and reflected on — which is rarer than it sounds.</p>`;
}

function renderPortfolio(){
  const box = $("#bPortfolio"); if(!box) return;
  const pf = portfolio(); if(!pf) return;
  const featured = projects().filter(p => p.featured && !p.archived);
  box.innerHTML = `
    <label class="tiny muted">Headline</label>
    <input class="in" id="pfHead" value="${esc(pf.headline || "")}" placeholder="e.g. Student · robotics and code">
    <label class="tiny muted" style="margin-top:10px;display:block">About</label>
    <textarea class="in" id="pfAbout" rows="4" placeholder="A few lines. No school name, no address, no phone number — a portfolio never needs them.">${esc(pf.about || "")}</textarea>
    <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn sm gold" id="pfSave">Save</button>
      <button class="btn sm ghost" id="pfVis">Visibility: ${esc(pf.visibility)}</button>
    </div>
    <div class="sep"></div>
    <div class="rv-list">
      <div><span>Featured projects</span><b>${featured.length}</b></div>
      <div><span>Eligible but not featured</span><b>${projects().filter(p => !p.featured && !p.archived && publishReadiness(p.id).ready).length}</b></div>
    </div>
    <p class="tiny muted" style="margin-top:10px">Nothing is featured automatically. A finished project is not the same as a project you want to be judged on.</p>`;

  $("#pfSave").onclick = () => {
    updatePortfolio({ headline:$("#pfHead").value, about:$("#pfAbout").value });
    renderBuild(); toast("Saved","","gold");
  };
  $("#pfVis").onclick = async () => {
    const opts = ["private","link","public"];
    const pick = await sysPrompt("Who can see this portfolio?", {
      msg: portfolioPublishWarning().map((w,i) => `${i+1===1?"":""}• ${w}`).join("\n") + "\n\n1. Private\n2. Anyone with the link\n3. Public",
      inputType:"number", placeholder:"1", ok:"Set" });
    const v = opts[Number(pick)-1]; if(!v) return;
    if(v !== "private"){
      const ok = await sysConfirm("Make it visible?",
        "Check your About text first. No school name, no address, no phone number, no exact location. You can revoke this at any time and it takes effect immediately.",
        { ok:"I have checked" });
      if(!ok) return;
    }
    updatePortfolio({ visibility:v }); renderBuild();
  };

  /* preview (§42) */
  const pv = $("#bPreview"); if(!pv) return;
  const p = portfolioPreview();
  pv.innerHTML = `<div class="pfview">
    <div class="pf-name">${esc(p.name)}</div>
    ${p.headline ? `<div class="pf-head">${esc(p.headline)}</div>` : ""}
    ${p.about ? `<p class="pf-about">${esc(p.about)}</p>` : ""}
    ${p.projects.length ? `<div class="pf-sec">Projects</div>${p.projects.map(x => `
      <div class="pf-card"><b>${esc(x.title)}</b><span>${esc(x.category)}</span>
        <p>${esc(x.description || "")}</p>
        ${x.skills.length ? `<div class="pf-skills">${x.skills.map(s => `<span title="${esc(s.evidence)}">${esc(s.name)}</span>`).join("")}</div>` : ""}
        ${x.evidence.length ? `<div class="tiny muted">${x.evidence.length} evidence item${x.evidence.length===1?"":"s"} shown</div>` : ""}
      </div>`).join("")}` : `<p class="muted tiny">No projects featured yet.</p>`}
    ${p.competitions.length ? `<div class="pf-sec">Competitions</div>${p.competitions.map(c => `
      <div class="pf-card"><b>${esc(c.name)}</b><span>${esc(c.result)} · ${esc(c.verification === "evidence" ? "evidence attached" : "self-reported")}</span></div>`).join("")}` : ""}
    ${p.activities.length ? `<div class="pf-sec">Activities</div>${p.activities.map(a => `
      <div class="pf-card"><b>${esc(a.name)}</b><span>${esc(a.role)} · ${a.months} months</span></div>`).join("")}` : ""}
    <div class="sep"></div>
    <p class="tiny muted">Never shown: ${p.excluded.map(esc).join(" · ")}.</p>
  </div>`;
}

function renderJourney(){
  const box = $("#bJourney"); if(!box) return;
  const ev = growthTimeline();
  box.innerHTML = ev.length
    ? ev.map(e => `<div class="jrn"><div class="jrn-d">${esc(e.at)}</div><div class="jrn-k">${esc(e.kind)}</div><div class="jrn-t">${esc(e.text)}</div></div>`).join("")
    : `<p class="muted tiny">Nothing on the timeline yet. It fills itself from projects finished, results recorded, achievements earned and bosses put down — you never write it by hand.</p>`;
}

function renderBuild(){
  if(!$("#bProjects")) return;
  /* Three renders, three isolations. They used to share one try block, so a
     throw in the first silently skipped the other two as well. */
  safeRender("build projects", renderBuildProjects);
  safeRender("portfolio", renderPortfolio);
  safeRender("journey", renderJourney);
}

function wireBuild(){
  const b = $("#bAddProject");
  if(b) b.onclick = async () => {
    const title = (await sysPrompt("What are you building?", { placeholder:"e.g. Line-following robot", ok:"Next" }) || "").trim();
    if(!title) return;
    const desc = (await sysPrompt("In one line", { placeholder:"What it is and who it is for", ok:"Next" }) || "").trim();
    const keys = Object.keys(PROJECT_TEMPLATES);
    const tl = keys.map((k,i) => `${i+1}. ${PROJECT_TEMPLATES[k].label}`).join("\n");
    const pick = await sysPrompt("Shape", { msg:tl, inputType:"number", placeholder:"1", ok:"Create" });
    const template = keys[Number(pick)-1] || "blank";
    const p = createProject({ title, description:desc, template });
    renderBuild(); renderAll();
    if(p) toast("Project started", `${p.milestones.length} milestones to edit or ignore. The first one is the only one that matters today.`, "gold");
  };
}
document.addEventListener("DOMContentLoaded", wireBuild);
if(document.readyState !== "loading") wireBuild();
