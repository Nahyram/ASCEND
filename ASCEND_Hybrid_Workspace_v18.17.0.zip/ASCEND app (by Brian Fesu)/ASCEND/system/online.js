/* ══════════════════════════════════════════════════════════════════
   THE SYSTEM — v11 · THE ONLINE GATE

   The app stays offline-first. Nothing here runs unless the hunter
   opens the Gate in Settings. When it is open, the System may pull
   REAL titles from public catalogues and cache them permanently, so a
   shelf that shipped with 30 books can grow to 450 without a single
   invented title.

   SOURCES  (all public, all read-only, no account, no key)
     Open Library  openlibrary.org   — books by subject, ranked by how
                                       many editions exist (a fair proxy
                                       for reach). Internet Archive.
     TVMaze        api.tvmaze.com    — series and TV shows with genres,
                                       ranked by their popularity weight.
     Jikan         api.jikan.moe     — anime by genre, ranked by MyAnimeList
                                       popularity. Rate limited: 3 req/sec.
     TMDB          api.themoviedb.org— FILMS. This one needs a free key the
                                       hunter creates themselves and pastes
                                       into Settings. Without it, films fall
                                       back to the shelves that ship offline.

   SECURITY POSTURE
     · Hard allowlist. A request to any other host is refused before
       fetch() is called, even if something in the app asks for it.
     · GET only. No credentials, no cookies, referrer stripped.
     · Every field that comes back is treated as hostile text: trimmed,
       length-capped, control characters stripped. It is rendered with
       the app's escaper, never as HTML.
     · Timeouts and a global request budget, so a bad network cannot
       burn a phone's data plan silently.
     · Responses are never handed to the service worker cache.
   ══════════════════════════════════════════════════════════════════ */

window.Net = (function(){
"use strict";

const ALLOW = [
  "openlibrary.org",
  "covers.openlibrary.org",
  "api.tvmaze.com",
  "api.jikan.moe",
  "api.themoviedb.org"
];

let budget = { used:0, cap:600, resetAt: Date.now() + 3600000 };

function hostOf(u){ try{ return new URL(u).host.toLowerCase(); }catch(e){ return ""; } }
function allowed(u){
  try{
    const url = new URL(u);
    if(url.protocol !== "https:") return false;
    const h = url.host.toLowerCase();
    return ALLOW.some(a => h === a || h.endsWith("." + a));
  }catch(e){ return false; }
}

function online(){ return navigator.onLine !== false; }

/* ── connection shape: whose data bundle is this? ──
   Save-Data is the owner of the device telling every app to use less of
   their bundle. The System obeys it in every mode. `metered` is a
   best-effort read; some browsers report nothing at all, in which case we
   assume unmetered and lean on the hourly budget above to cap the damage. */
function conn(){
  const c = navigator.connection || navigator.mozConnection || navigator.webkitConnection || null;
  const type = (c && c.type) || "";
  const eff  = (c && c.effectiveType) || "";
  return {
    saveData: !!(c && c.saveData),
    type, effective: eff,
    metered: type === "cellular" || /^(slow-2g|2g)$/.test(eff),
    known: !!c
  };
}
function onConnChange(fn){
  const c = navigator.connection;
  if(c && typeof c.addEventListener === "function"){ try{ c.addEventListener("change", fn); }catch(e){} }
}

/* ── shelves the Gate will never fetch for ──
   A shelf flagged adult:true in data.js is 18+ by design, and the app's
   stated audience is 14–18. So: no catalogue mapping is wired to those
   shelves, the shelf picker leaves them out, the background sync skips
   them, and this refuses them even if a caller asks directly. Four locks
   on one door, deliberately. Automatic connection changes none of it. */
const NEVER_FETCH = ["darkromance", "s_dark"];
function adultShelf(kind, key){
  if(NEVER_FETCH.indexOf(key) !== -1) return true;
  /* GENRES and SCREEN are `const` in the page script, so they are global
     lexical bindings and never appear on window. Read them by name, late,
     and treat "not loaded yet" as "do not fetch". */
  let src = null;
  try{ src = (kind === "book") ? GENRES : SCREEN; }catch(e){ return true; }
  const g = src && src[key];
  return !!(g && g.adult);
}
function guardShelf(kind, key){
  if(adultShelf(kind, key)) throw new Error("The Gate does not fetch for 18+ shelves. Those stay exactly as they shipped.");
}

/* Guarded fetch: allowlist → budget → timeout → JSON */
async function get(url, ms){
  if(!online()) throw new Error("offline");
  if(!allowed(url)) throw new Error("The Gate refused a request to an address that is not on its allowlist.");
  if(Date.now() > budget.resetAt){ budget.used = 0; budget.resetAt = Date.now() + 3600000; }
  if(budget.used >= budget.cap) throw new Error("Request budget spent for this hour. The Gate is protecting your data bundle.");
  budget.used++;

  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms || 15000);
  try{
    const r = await fetch(url, {
      signal: ac.signal, method:"GET", mode:"cors",
      credentials:"omit", cache:"no-store", referrerPolicy:"no-referrer",
      headers:{ "Accept":"application/json" }
    });
    if(r.status === 429) throw new Error("rate");
    if(!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ── sanitising anything that comes off the wire ── */
const clean = (s, cap) => String(s == null ? "" : s)
  .replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "")
  .replace(/\s+/g, " ")
  .trim()
  .slice(0, cap || 120);

const titleOK = t => t && t.length > 1 && t.length < 110 && !/^\W+$/.test(t);

/* ═══════════════ BOOKS — Open Library ═══════════════ */

/* Every shelf key in the app mapped to Open Library subject slugs.
   Order matters: the first slug is the truest match. */
const OL_SUBJECTS = {
  discipline:["self-help","habit","time_management","personal_development","success"],
  money:["personal_finance","finance","investments","money","wealth"],
  strategy:["strategy","negotiation","military_art_and_science","decision_making"],
  psychology:["psychology","cognitive_psychology","behavioral_economics","social_psychology"],
  biography:["biography","autobiography","memoirs","businesspeople"],
  business:["business","entrepreneurship","management","marketing","startups"],
  fantasy:["fantasy","epic_fantasy","magic","dragons","wizards"],
  scifi:["science_fiction","space_opera","cyberpunk","time_travel"],
  mystery:["detective_and_mystery_stories","mystery","noir","private_investigators"],
  classics:["classic_literature","english_literature","literature","fiction"],
  history:["history","world_war_two","ancient_history","african_history"],
  philosophy:["philosophy","ethics","stoicism","logic"],
  manga:["comics_and_graphic_novels","manga","graphic_novels"],
  adventure:["adventure","adventure_stories","survival","exploration"],
  african:["african_literature","africa","nigeria","ghana","south_africa"],
  science:["science","physics","mathematics","astronomy","biology"],
  tech:["computer_science","programming","artificial_intelligence","software_engineering"],
  sports:["sports","athletes","football","basketball","olympics"],
  poetry:["poetry","african_poetry","love_poetry","english_poetry"],
  romance:["love_stories","romance","contemporary_romance"],
  yaromance:["young_adult_fiction","teenage_romance","coming_of_age","first_love"],
  horror:["horror","ghost_stories","monsters","supernatural"],
  dystopian:["dystopia","dystopian_fiction","totalitarianism","apocalyptic_fiction"],
  crime:["crime","true_crime","criminal_investigation","thrillers"],
  health:["health","nutrition","exercise","sleep","mental_health"],
  faith:["religion","christianity","islam","spirituality","prayer"],
  creativity:["creative_writing","art","design","drawing","photography"],
  war:["war","military_history","world_war_one","military_science"],
  econ:["economics","macroeconomics","development_economics","international_trade"],
  exams:["study_skills","examinations","study_guides","test_preparation"],
  contemp:["contemporary_fiction","domestic_fiction","family_life"],
  comedy:["humor","comedy","satire","wit_and_humor"],
  leadership:["leadership","management","organizational_behavior","teams"]
};

/* Fetch one page of a subject. Open Library caps limit at 1000; 100 is polite. */
async function olPage(subject, offset, limit){
  const u = "https://openlibrary.org/subjects/" + encodeURIComponent(subject) +
            ".json?limit=" + (limit || 100) + "&offset=" + (offset || 0);
  const j = await get(u, 20000);
  const works = (j && j.works) || [];
  return works.map(w => {
    const t = clean(w.title, 100);
    const a = clean((w.authors && w.authors[0] && w.authors[0].name) || "", 70);
    const ed = Number(w.edition_count) || 0;
    const yr = Number(w.first_publish_year) || 0;
    return titleOK(t) && a ? { t, a, ed, yr } : null;
  }).filter(Boolean);
}

/* Grow one shelf toward `target`. Returns new rows only (not the existing ones). */
async function fetchBooks(genreKey, existing, target, onProgress){
  guardShelf("book", genreKey);
  const subs = OL_SUBJECTS[genreKey];
  if(!subs) throw new Error("No catalogue mapping for that shelf yet. Add one in online.js → OL_SUBJECTS.");
  const seen = new Set((existing || []).map(r => norm(r[0])));
  const found = [];

  outer:
  for(const s of subs){
    for(let off = 0; off < 600; off += 100){
      let page;
      try{ page = await olPage(s, off, 100); }
      catch(e){ if(String(e.message) === "rate"){ await sleep(2500); continue; } break; }
      if(!page.length) break;
      page.forEach(b => {
        const k = norm(b.t);
        if(seen.has(k)) return;
        seen.add(k);
        found.push(b);
      });
      if(onProgress) onProgress((existing||[]).length + found.length, target);
      if((existing||[]).length + found.length >= target) break outer;
      await sleep(220);
    }
  }
  /* most editions first — the closest honest proxy for "most read" */
  found.sort((a,b) => b.ed - a.ed);
  return found.map(b => [b.t, b.a, b.yr ? ("First published " + b.yr + " · " + b.ed + " editions in print.") : null])
              .map(r => r[2] ? r : [r[0], r[1]]);
}

const norm = s => String(s).toLowerCase().replace(/[^a-z0-9]/g, "");

/* ═══════════════ SERIES — TVMaze ═══════════════ */

const TVMAZE_GENRE = {
  s_drama:["Drama"], s_thriller:["Thriller","Suspense"], s_action:["Action","Adventure"],
  s_scifi:["Science-Fiction"], s_fantasy:["Fantasy"], s_crime:["Crime"], s_horror:["Horror"],
  s_romance:["Romance"], s_comedy:["Comedy"], s_mystery:["Mystery"], s_war:["War"],
  s_family:["Family","Children"], s_sport:["Sports"], s_music:["Music"], s_history:["History"],
  s_medical:["Medical"], s_legal:["Legal"], s_espionage:["Espionage"], s_kdrama:["Romance","Drama"],
  s_reality:["Food","Travel","Nature"], s_docs:["Nature","Travel"],
  /* s_dark is 18+ and is deliberately absent — see NEVER_FETCH below. */
  s_animation:["Anime","Children"], s_africa:["Drama"]
};

let tvCache = null;
async function tvAll(onProgress){
  if(tvCache) return tvCache;
  const rows = [];
  for(let p = 0; p < 24; p++){
    let j;
    try{ j = await get("https://api.tvmaze.com/shows?page=" + p, 20000); }
    catch(e){ break; }
    if(!Array.isArray(j) || !j.length) break;
    j.forEach(s => {
      const t = clean(s.name, 90);
      if(!titleOK(t)) return;
      rows.push({
        t, genres:(s.genres||[]).map(g => clean(g, 30)),
        w: Number(s.weight) || 0,
        yr: (s.premiered || "").slice(0,4),
        sum: clean(String(s.summary||"").replace(/<[^>]*>/g," "), 150),
        country: clean((s.network && s.network.country && s.network.country.code) || "", 4)
      });
    });
    if(onProgress) onProgress(rows.length);
    await sleep(180);
  }
  tvCache = rows;
  return rows;
}

async function fetchSeries(genreKey, existing, target, onProgress){
  guardShelf("screen", genreKey);
  const want = TVMAZE_GENRE[genreKey];
  if(!want) throw new Error("No series mapping for that genre.");
  const all = await tvAll(onProgress);
  const seen = new Set((existing || []).map(r => norm(r[0])));
  const kr = genreKey === "s_kdrama";
  return all
    .filter(s => want.some(g => s.genres.includes(g)))
    .filter(s => !kr || s.country === "KR")
    .filter(s => !seen.has(norm(s.t)))
    .sort((a,b) => b.w - a.w)
    .slice(0, Math.max(0, target - (existing||[]).length))
    .map(s => [s.t, "series", s.sum ? (s.sum + (s.yr ? " (" + s.yr + ")" : "")) : (s.yr || null)])
    .map(r => r[2] ? r : [r[0], r[1]]);
}

/* ═══════════════ ANIME — Jikan / MyAnimeList ═══════════════ */

const MAL_GENRE = {
  s_anime_act:[1,2],        /* Action, Adventure */
  s_anime_dark:[41,37],     /* Suspense, Supernatural */
  s_anime_life:[36,8],      /* Slice of Life, Drama */
  s_anime_mind:[7,40]       /* Mystery, Psychological */
};

async function fetchAnime(genreKey, existing, target, onProgress){
  guardShelf("screen", genreKey);
  const ids = MAL_GENRE[genreKey];
  if(!ids) throw new Error("No anime mapping for that genre.");
  const seen = new Set((existing || []).map(r => norm(r[0])));
  const out = [];
  for(let page = 1; page <= 12; page++){
    let j;
    try{
      j = await get("https://api.jikan.moe/v4/anime?genres=" + ids.join(",") +
                    "&order_by=popularity&sort=asc&sfw=true&limit=25&page=" + page, 20000);
    }catch(e){
      if(String(e.message) === "rate"){ await sleep(3000); page--; continue; }
      break;
    }
    const list = (j && j.data) || [];
    if(!list.length) break;
    list.forEach(a => {
      const t = clean(a.title_english || a.title, 90);
      if(!titleOK(t) || seen.has(norm(t))) return;
      seen.add(norm(t));
      const yr = a.year || (a.aired && a.aired.prop && a.aired.prop.from && a.aired.prop.from.year) || "";
      const ep = a.episodes ? a.episodes + " eps" : "";
      const sc = a.score ? "MAL " + a.score : "";
      const note = [ep, sc, yr].filter(Boolean).join(" · ");
      out.push(note ? [t, "anime", note] : [t, "anime"]);
    });
    if(onProgress) onProgress((existing||[]).length + out.length, target);
    if((existing||[]).length + out.length >= target) break;
    await sleep(1100);                       /* Jikan: 3/sec, 60/min — stay well under */
  }
  return out;
}

/* ═══════════════ FILMS — TMDB (hunter's own free key) ═══════════════ */

const TMDB_GENRE = {
  s_action:[28,12], s_scifi:[878], s_fantasy:[14], s_crime:[80], s_horror:[27],
  s_romance:[10749], s_comedy:[35], s_war:[10752], s_history:[36], s_mystery:[9648],
  s_animation:[16], s_family:[10751], s_docs:[99], s_music:[10402], s_thriller:[53],
  s_drama:[18], s_sport:[28], s_true:[80,99], s_biz:[18,99],
  s_medical:[18], s_legal:[18,80], s_espionage:[53,28], s_africa:[18]
};

async function fetchFilms(genreKey, existing, target, key, onProgress){
  guardShelf("screen", genreKey);
  if(!key) throw new Error("Films need a free TMDB key. Settings → Online Gate explains how to get one in about two minutes.");
  const ids = TMDB_GENRE[genreKey];
  if(!ids) throw new Error("No film mapping for that genre.");
  const seen = new Set((existing || []).map(r => norm(r[0])));
  const out = [];
  for(let page = 1; page <= 25; page++){
    let j;
    try{
      j = await get("https://api.themoviedb.org/3/discover/movie?api_key=" + encodeURIComponent(key) +
                    "&with_genres=" + ids.join(",") + "&sort_by=popularity.desc&include_adult=false" +
                    "&vote_count.gte=200&page=" + page, 20000);
    }catch(e){ break; }
    const list = (j && j.results) || [];
    if(!list.length) break;
    list.forEach(m => {
      const t = clean(m.title, 90);
      if(!titleOK(t) || seen.has(norm(t))) return;
      seen.add(norm(t));
      const yr = (m.release_date || "").slice(0,4);
      const note = [yr, m.vote_average ? ("TMDB " + Number(m.vote_average).toFixed(1)) : ""].filter(Boolean).join(" · ");
      out.push(note ? [t, "film", note] : [t, "film"]);
    });
    if(onProgress) onProgress((existing||[]).length + out.length, target);
    if((existing||[]).length + out.length >= target) break;
    await sleep(260);
  }
  return out;
}

/* ═══════════════ CACHE — IndexedDB, survives forever ═══════════════ */

const DBN = "system-codex", STORE = "shelves";
function idb(){
  return new Promise((res, rej) => {
    const rq = indexedDB.open(DBN, 1);
    rq.onupgradeneeded = () => { rq.result.createObjectStore(STORE); };
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}
async function cacheSet(k, v){
  const d = await idb();
  return new Promise((res, rej) => {
    const tx = d.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put({ rows:v, at:Date.now() }, k);
    tx.oncomplete = () => res(true); tx.onerror = () => rej(tx.error);
  });
}
async function cacheGet(k){
  const d = await idb();
  return new Promise((res, rej) => {
    const tx = d.transaction(STORE, "readonly");
    const rq = tx.objectStore(STORE).get(k);
    rq.onsuccess = () => res(rq.result || null); rq.onerror = () => rej(rq.error);
  });
}
async function cacheKeys(){
  const d = await idb();
  return new Promise((res, rej) => {
    const tx = d.transaction(STORE, "readonly");
    const rq = tx.objectStore(STORE).getAllKeys();
    rq.onsuccess = () => res(rq.result || []); rq.onerror = () => rej(rq.error);
  });
}
async function cacheClear(){
  const d = await idb();
  return new Promise((res, rej) => {
    const tx = d.transaction(STORE, "readwrite");
    tx.objectStore(STORE).clear();
    tx.oncomplete = () => res(true); tx.onerror = () => rej(tx.error);
  });
}

/* quick reachability probe — one tiny request */
async function probe(){
  const t0 = performance.now();
  await get("https://openlibrary.org/subjects/self-help.json?limit=1", 8000);
  return Math.round(performance.now() - t0);
}

return {
  online, allowed, get, probe, conn, onConnChange, adultShelf, NEVER_FETCH,
  fetchBooks, fetchSeries, fetchAnime, fetchFilms,
  cacheSet, cacheGet, cacheKeys, cacheClear,
  OL_SUBJECTS, TVMAZE_GENRE, MAL_GENRE, TMDB_GENRE, ALLOW,
  budget: () => ({ ...budget })
};
})();
