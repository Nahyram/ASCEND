/* ASCEND — content/tools.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ v9: THE ARSENAL — best learning tools online ══════════════ */
const TOOLS = [
  ["Exam Prep — your curriculum, mastered", [
    ["Khan Academy","khanacademy.org","Free, world-class lessons in maths and sciences. The default answer to 'I don't get this topic'."],
    ["Save My Exams","savemyexams.com","IGCSE/GCSE/A-Level revision notes and past-paper questions by topic. Built for your exact syllabus."],
    ["Physics & Maths Tutor","physicsandmathstutor.com","Free past papers and topic questions for IGCSE through A-Level. The paper-grinding site."],
    ["Seneca Learning","senecalearning.com","Free smart-repetition courses mapped to GCSE/A-Level specs."],
    ["BBC Bitesize","bbc.co.uk/bitesize","Clean, free study notes for core subjects."],
    ["Quizlet","quizlet.com","Flashcards for everything, made by millions of students before you."],
    ["Anki","apps.ankiweb.net","The serious flashcard app. Spaced repetition — how med students memorise oceans."]]],
  ["University-Level, Free", [
    ["Harvard CS50","cs50.harvard.edu/x","Harvard's legendary intro to computer science. Free, with a certificate path."],
    ["MIT OpenCourseWare","ocw.mit.edu","Actual MIT courses — lectures, notes, exams — free."],
    ["edX","edx.org","University courses from Harvard, MIT and more. Audit free."],
    ["Coursera","coursera.org","University and industry courses. Financial aid can make certificates free — apply, it works."],
    ["OpenLearn","open.edu/openlearn","The Open University's free course library."],
    ["CrashCourse","youtube.com/@crashcourse","Every school subject, explained fast and well."]]],
  ["Code & Build", [
    ["freeCodeCamp","freecodecamp.org","Zero to certified developer, completely free. The dropout's university."],
    ["The Odin Project","theodinproject.com","A full free web-development curriculum that makes you build."],
    ["Codecademy","codecademy.com","Interactive coding in the browser. Free tier is plenty to start."],
    ["W3Schools","w3schools.com","The reference — try every web technology in the browser."],
    ["Scrimba","scrimba.com","Interactive screencasts where you pause and edit the teacher's code."],
    ["Kaggle Learn","kaggle.com/learn","Free micro-courses in Python, data and machine learning, plus real competitions."],
    ["Replit","replit.com","Code anything from a browser — no laptop setup needed."]]],
  ["Skills That Pay", [
    ["Google Skillshop & Digital Garage","skillshop.withgoogle.com","Free Google certifications in ads, analytics and digital marketing. Real CV weight."],
    ["HubSpot Academy","academy.hubspot.com","Free certified courses in marketing, sales and content."],
    ["Canva Design School","canva.com/learn","Design fundamentals on the tool half of Ghana's flyers are made with."],
    ["ALX Africa","alxafrica.com","Serious tech and professional programmes built for African students. Scholarships exist."],
    ["Duolingo","duolingo.com","A second language, five minutes at a time."],
    ["3Blue1Brown","youtube.com/@3blue1brown","Maths made visual and beautiful. Watch one video and you'll understand."],
    ["Veritasium","youtube.com/@veritasium","Physics and engineering stories that make you smarter by accident."],
    ["The Organic Chemistry Tutor","youtube.com/@TheOrganicChemistryTutor","Every maths, physics and chemistry topic, worked calmly on a black screen."]]],
];


export { TOOLS };
