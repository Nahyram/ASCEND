/* ASCEND — content/balance.js
   Phase 4 §40: every number that decides how fast someone progresses lives here,
   in one file, so the game can be rebalanced without touching application logic.

   This matters more than it sounds. v12 scattered XP values across seed data,
   quest editors, skill effects and view files, which meant "make levelling
   slightly slower" was a fifteen-file change nobody would risk. Now it is an edit
   to a table.

   Nothing in this file executes. It is data. */

const BALANCE = {

  /* ---------- XP awards ----------
     §3: reward meaningful action, never app usage. There is deliberately no
     "opened the app", "checked your stats" or "logged in today" entry. */
  xp: {
    questBase:      15,   /* an optional quest, before its own xp overrides this */
    questMandatory: 25,
    goalStep:       10,
    goalTarget:     60,   /* every step under a target cleared */
    goalComplete:  200,
    bookFinished:   80,
    hobbySession:   12,
    focusSession:   20,
    reflection:     15,
    bossStage:      50,
    bossComplete:  400,
    milestone:     250,
  },

  /* ---------- the level curve ----------
     §4: early levels reachable, later ones meaningful, and never the exponential
     nonsense that makes level 60 a theoretical object. The v12 curve was
     100·level^1.35, which is kept — it is a good curve — but the constant is now
     visible and adjustable rather than buried in progression.js. */
  level: {
    base: 100,
    exponent: 1.35,
    /* §5: titles per band. The existing lore is Solo-Leveling-adjacent hunter
       fiction, so these follow it rather than importing a generic ladder. */
    titles: [
      { at:1,   name:"Awakened" },
      { at:5,   name:"Initiate" },
      { at:10,  name:"Adept" },
      { at:20,  name:"Specialist" },
      { at:30,  name:"Elite" },
      { at:45,  name:"Veteran" },
      { at:60,  name:"Master" },
      { at:80,  name:"Grandmaster" },
      { at:100, name:"Monarch" },
    ],
  },

  /* ---------- ranks ----------
     §6: level measures progression, rank measures demonstrated mastery. v12 tied
     rank purely to level, which meant a hunter could reach S-Rank by clearing
     easy quests for long enough. Rank now requires evidence as well as level. */
  ranks: [
    { r:"E", level:1,  need:{} },
    { r:"D", level:10, need:{ cleared:150,  streak:5,  achievements:3 } },
    { r:"C", level:20, need:{ cleared:400,  streak:10, achievements:8,  bosses:1 } },
    { r:"B", level:35, need:{ cleared:900,  streak:20, achievements:14, bosses:3 } },
    { r:"A", level:50, need:{ cleared:1800, streak:30, achievements:22, bosses:6 } },
    { r:"S", level:70, need:{ cleared:3200, streak:45, achievements:32, bosses:10 } },
    { r:"N", level:90, need:{ cleared:5000, streak:60, achievements:44, bosses:16 } },
  ],
  rankNames: {
    E:"E-Rank", D:"D-Rank", C:"C-Rank", B:"B-Rank",
    A:"A-Rank", S:"S-Rank", N:"National Level Hunter",
  },

  /* ---------- stats: what counts as evidence (§7) ----------
     "Do not automatically claim a student has increased a stat merely because
     they clicked complete. Stats should be derived from evidence and activity
     patterns where possible."

     The split below is the whole rule, and it falls out of what a category
     actually measures:

       selfEvident   the act IS the measurement. Waking at 05:20 or finishing a
                     workout is not a claim about capability — it is a claim
                     about turning up, and ticking it is an honest record of
                     exactly that. Consistency here is the "activity pattern"
                     §7 explicitly allows.

       needsEvidence the act is EFFORT, not capability. Sitting with a Physics
                     book for an hour is real and earns XP, but it is not proof
                     that any Physics was learnt. Intellect and Perception are
                     paid from demonstrated mastery movement instead — see
                     recordAnswer() in services/practice.js.

     XP is unaffected in both cases. Effort is real and is still paid for; what
     is withheld is the capability claim. */
  stats: {
    selfEvident:   ["discipline", "body", "rest"],
    needsEvidence: ["study", "mind"],
    evidenceHint:  "Answer practice questions in Academy — accuracy is the evidence.",
  },

  /* ---------- quest difficulty (§13) ----------
     Difficulty is estimated effort, not decoration: the multiplier is what makes
     a Legendary quest worth attempting instead of five Trivial ones. */
  difficulty: [
    { k:"trivial",   label:"Trivial",   mins:5,   mult:0.5 },
    { k:"easy",      label:"Easy",      mins:15,  mult:0.8 },
    { k:"moderate",  label:"Moderate",  mins:30,  mult:1.0 },
    { k:"hard",      label:"Hard",      mins:60,  mult:1.5 },
    { k:"epic",      label:"Epic",      mins:120, mult:2.2 },
    { k:"legendary", label:"Legendary", mins:240, mult:3.0 },
  ],

  /* ---------- quest hierarchy (§11) ---------- */
  questTypes: [
    { k:"daily",     label:"Daily",     blurb:"A small action, today." },
    { k:"weekly",    label:"Weekly",    blurb:"A short-term objective." },
    { k:"main",      label:"Main",      blurb:"Something you actually want." },
    { k:"boss",      label:"Boss",      blurb:"A milestone built from smaller quests." },
    { k:"story",     label:"Story",     blurb:"The Archive opens as you progress." },
    { k:"milestone", label:"Milestone", blurb:"A real-world achievement, recorded." },
    { k:"recovery",  label:"Recovery",  blurb:"Getting back on the board." },
  ],

  /* ---------- anti-exploitation (§41) ----------
     Repeatedly clearing and un-clearing the same quest must not print XP. */
  antiFarm: {
    sameQuestPerDay: 1,      /* XP paid once per quest per day, re-ticks are free */
    dailyXpCap: 900,         /* generous for a real day, absurd for a farmer */
    minSecondsBetweenClaims: 3,
  },

  /* ---------- the world (§29, §30, §31) ----------
     Areas represent categories of growth, and each maps onto a part of the app
     that already exists. Unlocking an area is not a new feature — it is the
     moment the System explains what a part of itself is for. Nothing essential
     is ever locked: everything below is already reachable from navigation. */
  world: [
    { k:"gate",        name:"The Gate",        maps:"Home & quests",  at:{ level:1 },
      blurb:"Where every hunter starts. The board, the day, the directive." },
    { k:"academy",     name:"The Academy",     maps:"Learn",          at:{ level:3, cleared:20 },
      blurb:"Books, the tutor, the Archive. Knowledge you choose rather than knowledge assigned." },
    { k:"forge",       name:"The Forge",       maps:"Grow · Forge",   at:{ level:6, cleared:60 },
      blurb:"Four crafts, defended daily. This is where skill stops being a plan." },
    { k:"arena",       name:"The Arena",       maps:"Wealth · Arena", at:{ level:10, bosses:1 },
      blurb:"Competitions and scholarships. Where the work meets other people's standards." },
    { k:"observatory", name:"The Observatory", maps:"Insight",        at:{ level:12, cleared:200 },
      blurb:"The record read back to you — patterns, proposals, the weekly review." },
    { k:"vault",       name:"The Vault",       maps:"Wealth",         at:{ level:16, cleared:350 },
      blurb:"Money handled deliberately. The Freedom jar that is never spent." },
    { k:"citadel",     name:"The Citadel",     maps:"Progression",    at:{ level:25, achievements:12 },
      blurb:"Everything you have built, in one place. Titles, records, milestones." },
    { k:"frontier",    name:"The Frontier",    maps:"Goals & projects", at:{ level:40, bosses:5 },
      blurb:"Beyond the syllabus. The things nobody set for you." },
  ],

  /* ---------- achievements (§18) ----------
     Categories per the phase doc. `check` is a key the engine knows how to
     evaluate; the numbers are here so they can be tuned without code edits. */
  achievements: [
    /* PROGRESSION */
    { id:"lvl5",    cat:"progression", name:"Awakened",        need:{ level:5 },    blurb:"Reach level 5." },
    { id:"lvl10",   cat:"progression", name:"Adept",           need:{ level:10 },   blurb:"Reach level 10." },
    { id:"lvl25",   cat:"progression", name:"Specialist",      need:{ level:25 },   blurb:"Reach level 25." },
    { id:"lvl50",   cat:"progression", name:"Elite",           need:{ level:50 },   blurb:"Reach level 50." },
    { id:"rankC",   cat:"progression", name:"C-Rank Hunter",   need:{ rank:"C" },   blurb:"Earn C-Rank — level and evidence." },
    { id:"rankA",   cat:"progression", name:"A-Rank Hunter",   need:{ rank:"A" },   blurb:"Earn A-Rank." },

    /* CONSISTENCY */
    { id:"streak7",  cat:"consistency", name:"One Week Held",   need:{ streak:7 },   blurb:"A seven-day streak." },
    { id:"streak30", cat:"consistency", name:"The Month",       need:{ streak:30 },  blurb:"Thirty days without breaking." },
    { id:"streak100",cat:"consistency", name:"Hundred",         need:{ streak:100 }, blurb:"One hundred consecutive days." },
    { id:"perfect",  cat:"consistency", name:"Clean Sweep",     need:{ perfectDays:1 },  blurb:"Clear every quest scheduled in a day." },
    { id:"perfect10",cat:"consistency", name:"Ten Clean Days",  need:{ perfectDays:10 }, blurb:"Ten perfect days." },
    { id:"cleared500",cat:"consistency",name:"Five Hundred",    need:{ cleared:500 },blurb:"Five hundred quests cleared." },

    /* LEARNING */
    { id:"book1",   cat:"learning", name:"First Finish",      need:{ books:1 },   blurb:"Finish a book." },
    { id:"book10",  cat:"learning", name:"Ten Volumes",       need:{ books:10 },  blurb:"Finish ten books." },
    { id:"study100",cat:"learning", name:"Hundred Sessions",  need:{ catCleared:{ cat:"study", n:100 } }, blurb:"Clear 100 study quests." },
    { id:"hobby30", cat:"learning", name:"Craftsman",         need:{ hobbyDays:30 }, blurb:"Practise a craft on thirty separate days." },

    /* MILESTONES */
    { id:"boss1",   cat:"milestone", name:"First Fall",       need:{ bosses:1 },  blurb:"Complete a boss quest." },
    { id:"boss5",   cat:"milestone", name:"Five Fallen",      need:{ bosses:5 },  blurb:"Complete five boss quests." },
    { id:"goal1",   cat:"milestone", name:"Finished It",      need:{ goalsDone:1 },blurb:"Complete a goal, every step." },
    { id:"goal5",   cat:"milestone", name:"Serial Finisher",  need:{ goalsDone:5 },blurb:"Complete five goals." },

    /* EXPLORATION */
    { id:"world3",  cat:"exploration", name:"Cartographer",   need:{ areas:3 },   blurb:"Unlock three areas of the world." },
    { id:"world6",  cat:"exploration", name:"Far Traveller",  need:{ areas:6 },   blurb:"Unlock six areas." },
    { id:"skills5", cat:"exploration", name:"Branching Out",  need:{ skills:5 },  blurb:"Learn five skills." },

    /* RECOVERY — deliberately an achievement, not a mark against you.
       §24: one missed day must not read as failure. Coming back is the skill. */
    { id:"return",  cat:"consistency", name:"The Return",     need:{ recoveries:1 },
      blurb:"Complete a recovery after a collapsed week. Getting back is the harder skill." },

    /* SECRET (§18) — discoverable, not listed until earned */
    { id:"dawn",    cat:"secret", name:"Before Dawn",  secret:true, need:{ clearedBefore:6 },
      blurb:"Cleared a quest before 6 AM." },
    { id:"nightowl",cat:"secret", name:"Late Shift",   secret:true, need:{ clearedAfter:23 },
      blurb:"Cleared a quest after 11 PM." },
    { id:"comeback",cat:"secret", name:"From Zero",    secret:true, need:{ zeroToPerfect:true },
      blurb:"A perfect day directly after a day with nothing cleared." },
  ],

  /* ---------- titles (§19) ----------
     Earned from achievements, equipped by choice, purely cosmetic. */
  titles: [
    { id:"t_scholar",   name:"The Scholar",    from:"book10",    blurb:"Ten books finished." },
    { id:"t_relentless",name:"The Relentless", from:"streak30",  blurb:"Thirty days unbroken." },
    { id:"t_builder",   name:"The Builder",    from:"hobby30",   blurb:"Thirty days at a craft." },
    { id:"t_strategist",name:"The Strategist", from:"goal5",     blurb:"Five goals seen through." },
    { id:"t_slayer",    name:"The Slayer",     from:"boss5",     blurb:"Five bosses down." },
    { id:"t_explorer",  name:"The Explorer",   from:"world6",    blurb:"Six areas unlocked." },
    { id:"t_returned",  name:"The Returned",   from:"return",    blurb:"Came back from a collapsed week." },
    { id:"t_elite",     name:"The Elite",      from:"lvl50",     blurb:"Level fifty." },
  ],

  /* ---------- seasons (§27) ----------
     Optional. Nothing a student needs is ever seasonal — these only re-zero the
     comparison window so a bad November is not carried forever. */
  seasons: [
    { k:"s1", name:"Awakening", from:"09-01", to:"12-31" },
    { k:"s2", name:"Ascension", from:"01-01", to:"04-30" },
    { k:"s3", name:"Mastery",   from:"05-01", to:"08-31" },
  ],
};

export { BALANCE };
