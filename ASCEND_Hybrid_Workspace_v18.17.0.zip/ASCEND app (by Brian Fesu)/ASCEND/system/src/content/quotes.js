import { $ } from "../core/kernel.js";

/* ASCEND — content/quotes.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ v8: DAILY TRANSMISSION — quotes from masterminds ══════════════ */
const QUOTES = [
  {q:"Victorious warriors win first and then go to war.", by:"Sun Tzu", src:"The Art of War"},
  {q:"The impediment to action advances action. What stands in the way becomes the way.", by:"Marcus Aurelius", src:"Meditations"},
  {q:"There is more than one path to the top of the mountain.", by:"Miyamoto Musashi", src:"The Book of Five Rings"},
  {q:"Never was anything great achieved without danger.", by:"Niccolò Machiavelli", src:"The Prince"},
  {q:"Luck is what happens when preparation meets opportunity.", by:"Seneca", src:"Stoic philosopher"},
  {q:"There is nothing more deceptive than an obvious fact.", by:"Sherlock Holmes", src:"Arthur Conan Doyle"},
  {q:"A lesson without pain is meaningless.", by:"Edward Elric", src:"Fullmetal Alchemist"},
  {q:"If you don't take risks, you can't create a future.", by:"Monkey D. Luffy", src:"One Piece"},
  {q:"If the king does not move, his subjects will not follow.", by:"Lelouch vi Britannia", src:"Code Geass"},
  {q:"A person who cannot sacrifice anything can never change anything.", by:"Armin Arlert", src:"Attack on Titan"},
  {q:"Fear is not evil. It tells you what your weakness is.", by:"Gildarts Clive", src:"Fairy Tail"},
  {q:"If heroes run and hide, who will stay and fight?", by:"Saitama", src:"One-Punch Man"},
  {q:"Do, or do not. There is no try.", by:"Yoda", src:"Star Wars"},
  {q:"Why do we fall? So we can learn to pick ourselves up.", by:"Alfred Pennyworth", src:"Batman Begins"},
  {q:"Great men are not born great, they grow great.", by:"Don Vito Corleone", src:"The Godfather"},
  {q:"Every man dies. Not every man really lives.", by:"William Wallace", src:"Braveheart"},
  {q:"It's about how hard you can get hit and keep moving forward.", by:"Rocky Balboa", src:"Rocky Balboa"},
  {q:"Get busy living, or get busy dying.", by:"Andy Dufresne", src:"The Shawshank Redemption"},
  {q:"It is our choices that show what we truly are.", by:"Albus Dumbledore", src:"Harry Potter"},
  {q:"All we have to decide is what to do with the time given us.", by:"Gandalf", src:"The Lord of the Rings"},
  {q:"You fall to the level of your systems.", by:"James Clear", src:"Atomic Habits"},
  {q:"Hard choices, easy life. Easy choices, hard life.", by:"Jerzy Gregorek", src:"champion weightlifter"},
  {q:"Discipline equals freedom.", by:"Jocko Willink", src:"Discipline Equals Freedom"},
  {q:"Whether you think you can or you can't, you're right.", by:"Henry Ford", src:"industrialist"},
  {q:"Winter does not negotiate. Neither should your standards.", by:"Kael Orion", src:"The Mastermind's Winter Arc"},
  {q:"The System does not grade effort. It grades what got done.", by:"THE SYSTEM", src:"daily directive"},
  {q:"Nobody is coming to save the day you are wasting.", by:"THE SYSTEM", src:"daily directive"},
  {q:"You are always training something. Today it was either focus or distraction.", by:"THE SYSTEM", src:"daily directive"},
];
function renderQuote(){
  if(!$("#quoteText")) return;
  const i = Math.floor(Date.now()/86400000) % QUOTES.length, x = QUOTES[i];
  $("#quoteText").textContent = "\u201c" + x.q + "\u201d";
  $("#quoteBy").textContent = "— " + x.by;
  $("#quoteSrc").textContent = x.src;
}


export { QUOTES, renderQuote };
