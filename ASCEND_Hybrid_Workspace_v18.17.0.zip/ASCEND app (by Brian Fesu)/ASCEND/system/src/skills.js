/* ══════════════════════════════════════════════════════════════════
   THE SYSTEM — v11 · SKILL TREE
   Skills unlock at levels. Unlocking is automatic; LEARNING one costs
   skill points, so you cannot own everything. Choose a build.

   SHAPE
     id      unique key, stored on the hunter
     name    display name
     lvl     level at which it becomes available
     cost    skill points to learn
     branch  scholar | warrior | monarch | craft
     type    passive | active | unlock
     desc    what it actually does, in plain words
     eff     machine-readable effect (read by the engine in index.html)

   EFFECT KEYS
     xp:{all|study|body|mind|discipline|rest|book|focus|hobby, mult}
     penaltyCut  0..1  — fraction of the XP penalty cancelled
     shield      n     — free missed days per week before the streak dies
     slots       n     — extra skill points granted per level from here up
     feature     str   — unlocks an app capability
     active:{charges, cooldownDays, action}
   ══════════════════════════════════════════════════════════════════ */

const SKILLS = [
  /* ───────────── TIER I — levels 2-9 ───────────── */
  { id:"sprint", name:"Sprint", lvl:2, cost:1, branch:"warrior", type:"passive",
    desc:"Every quest you clear pays 5% more XP. Small edge, applied a thousand times.",
    eff:{ xp:{ all:1.05 } } },

  { id:"iron_will", name:"Iron Will", lvl:3, cost:1, branch:"warrior", type:"passive",
    desc:"Penalty XP losses are cut by 25%. The penalty quest still lands — you just bleed less.",
    eff:{ penaltyCut:0.25 } },

  { id:"bookworm", name:"Bookworm", lvl:4, cost:1, branch:"scholar", type:"passive",
    desc:"Finishing a book pays 50% more. Reading is the cheapest advantage on earth.",
    eff:{ xp:{ book:1.5 } } },

  { id:"gate_open", name:"Gate Sense", lvl:5, cost:1, branch:"monarch", type:"unlock",
    desc:"The link is automatic from level 1. This widens it: instead of one shelf topped up per session, the System sweeps every shelf you have chosen, in one go.",
    eff:{ feature:"online" } },

  { id:"early_riser", name:"Dawn Strike", lvl:6, cost:1, branch:"warrior", type:"passive",
    desc:"Any quest cleared before 08:00 pays 20% more. The morning is where the gap opens.",
    eff:{ xpBefore:{ hour:8, mult:1.2 } } },

  { id:"rewind", name:"Rewind", lvl:8, cost:2, branch:"monarch", type:"active",
    desc:"Restore a streak the System terminated. Once every 14 days — it is mercy, not a loophole.",
    eff:{ active:{ cooldownDays:14, action:"restoreStreak" } } },

  /* ───────────── TIER II — levels 10-19 ───────────── */
  { id:"mana_flow", name:"Mana Flow", lvl:10, cost:2, branch:"monarch", type:"passive",
    desc:"All XP up 10%. The tide lifts everything.",
    eff:{ xp:{ all:1.10 } } },

  { id:"night_owl", name:"Night Vigil", lvl:11, cost:1, branch:"scholar", type:"passive",
    desc:"Quests cleared after 20:00 pay 15% more. For the ones who study when the house goes quiet.",
    eff:{ xpAfter:{ hour:20, mult:1.15 } } },

  { id:"ward_deep", name:"Ward Protocol", lvl:12, cost:1, branch:"craft", type:"unlock",
    desc:"Unlocks deep inspection in the Ward — byte-level file checks, archive-bomb detection and quarantine controls.",
    eff:{ feature:"warddeep" } },

  { id:"scholar", name:"Scholar", lvl:14, cost:2, branch:"scholar", type:"passive",
    desc:"Study quests pay 25% more. The System rewards the work that compounds.",
    eff:{ xp:{ study:1.25 } } },

  { id:"overdrive", name:"Overdrive", lvl:15, cost:2, branch:"warrior", type:"active",
    desc:"Double XP for the next three hours. Once every 3 days. Fire it on a day you intend to destroy.",
    eff:{ active:{ cooldownDays:3, action:"overdrive", hours:3, mult:2 } } },

  { id:"forge_master", name:"Forge Master", lvl:16, cost:1, branch:"craft", type:"passive",
    desc:"Hobby practice in the Forge pays 50% more. Skills you build for fun still make you dangerous.",
    eff:{ xp:{ hobby:1.5 } } },

  { id:"steady_hand", name:"Steady Hand", lvl:18, cost:1, branch:"warrior", type:"passive",
    desc:"Training quests pay 20% more. The body carries the mind.",
    eff:{ xp:{ body:1.2 } } },

  /* ───────────── TIER III — levels 20-39 ───────────── */
  { id:"ironclad", name:"Ironclad", lvl:20, cost:3, branch:"warrior", type:"passive",
    desc:"Your streak survives one missed day per week. One. Do not build a life on it.",
    eff:{ shield:1 } },

  { id:"archivist", name:"Archivist", lvl:22, cost:2, branch:"craft", type:"unlock",
    desc:"Unlocks Armory auto-sorting profiles: save a subject map, re-sort any new drop in seconds.",
    eff:{ feature:"armoryprofiles" } },

  { id:"sanctuary", name:"Sanctuary", lvl:24, cost:3, branch:"monarch", type:"active",
    desc:"Clear every pending penalty at once. Once every 10 days. Use it to restart, not to escape.",
    eff:{ active:{ cooldownDays:10, action:"clearPenalties" } } },

  { id:"deep_diver", name:"Deep Dive", lvl:26, cost:2, branch:"scholar", type:"passive",
    desc:"Completed focus sessions pay 30% more. Depth beats duration.",
    eff:{ xp:{ focus:1.3 } } },

  { id:"domain", name:"Domain Expansion", lvl:28, cost:3, branch:"scholar", type:"active",
    desc:"For 60 minutes, focus-session XP is tripled. Once every 5 days.",
    eff:{ active:{ cooldownDays:5, action:"domain", hours:1, mult:3 } } },

  { id:"polymath", name:"Polymath", lvl:30, cost:3, branch:"monarch", type:"passive",
    desc:"All XP up a further 15%. You are no longer specialising — you are stacking.",
    eff:{ xp:{ all:1.15 } } },

  { id:"unbroken", name:"Unbroken", lvl:34, cost:3, branch:"warrior", type:"passive",
    desc:"Penalty XP losses cut by half. Failure costs you less because you fail less.",
    eff:{ penaltyCut:0.5 } },

  { id:"librarian", name:"Grand Librarian", lvl:36, cost:2, branch:"craft", type:"unlock",
    desc:"Raises the Online Gate fetch ceiling from 150 to 450 titles per shelf.",
    eff:{ feature:"shelf450" } },

  /* ───────────── TIER IV — levels 40+ ───────────── */
  { id:"ruler", name:"Ruler's Authority", lvl:40, cost:4, branch:"monarch", type:"passive",
    desc:"All XP up a further 25%.",
    eff:{ xp:{ all:1.25 } } },

  { id:"strategist", name:"Strategist", lvl:45, cost:3, branch:"scholar", type:"passive",
    desc:"Mind quests — planning, building, learning — pay 40% more.",
    eff:{ xp:{ mind:1.4 } } },

  { id:"monarch", name:"Shadow Monarch", lvl:50, cost:5, branch:"monarch", type:"passive",
    desc:"All XP up a further 40%, and every level from here grants 2 skill points instead of 1.",
    eff:{ xp:{ all:1.40 }, slots:1 } },

  { id:"relentless", name:"Relentless", lvl:60, cost:4, branch:"warrior", type:"passive",
    desc:"Discipline quests pay 50% more. At this level the habit is the identity.",
    eff:{ xp:{ discipline:1.5 } } },

  { id:"sovereign", name:"Sovereign", lvl:70, cost:5, branch:"monarch", type:"passive",
    desc:"All XP up a further 60%.",
    eff:{ xp:{ all:1.60 } } },

  { id:"architect", name:"Architect", lvl:80, cost:5, branch:"craft", type:"passive",
    desc:"Hobby and focus XP doubled. You build things now, not just habits.",
    eff:{ xp:{ hobby:2, focus:2 } } },

  { id:"army", name:"Army of Shadows", lvl:90, cost:6, branch:"monarch", type:"passive",
    desc:"All XP doubled. The final passive. Nothing you do is small any more.",
    eff:{ xp:{ all:2 } } }
];

/* ── branch presentation ── */
const BRANCHES = {
  scholar:{ label:"Scholar", glyph:"✦", blurb:"Study, reading, focus." },
  warrior:{ label:"Warrior", glyph:"⚔", blurb:"Training, streaks, resistance." },
  monarch:{ label:"Monarch", glyph:"◈", blurb:"Raw XP, mercy skills, the gate." },
  craft:{   label:"Craft",   glyph:"⛭", blurb:"Hobbies, the Armory, the Ward." }
};

/* ── pure helpers (no DOM, no state writes) ── */
function skillById(id){ return SKILLS.find(s => s.id === id) || null; }
function skillsAtOrBelow(lvl){ return SKILLS.filter(s => s.lvl <= lvl); }
function nextSkillAfter(lvl){ return SKILLS.filter(s => s.lvl > lvl).sort((a,b)=>a.lvl-b.lvl)[0] || null; }

/* Points earned by a hunter who has reached `lvl`, given which skills are learned.
   1 per level from 2 upward, +1 more per level once a slots skill is learned. */
function pointsEarned(lvl, learned){
  let pts = Math.max(0, lvl - 1);
  (learned || []).forEach(id => {
    const s = skillById(id);
    if(s && s.eff && s.eff.slots) pts += Math.max(0, lvl - s.lvl) * s.eff.slots;
  });
  return pts;
}
function pointsSpent(learned){
  return (learned || []).reduce((n,id) => n + ((skillById(id) || {}).cost || 0), 0);
}

export { SKILLS, BRANCHES, skillById, skillsAtOrBelow, nextSkillAfter, pointsEarned, pointsSpent };
