/* ══════════════════════════════════════════════════════════════════
   THE SYSTEM — v11 · THE ARMORY  (study-material intake engine)

   WHAT THIS DOES
     · Reads a .zip WITHOUT unpacking it. It seeks to the end of the
       archive, parses the central directory (Zip64 aware) and builds an
       index of every entry. A 7 GB zip is read as a few hundred kilobytes
       of directory data. Nothing is decompressed until you open one file.
     · Or walks a whole folder you pick, using the File System Access API,
       keeping a handle so the material stays reachable next session
       without re-uploading a byte.
     · Classifies every file: subject → material type → year/session/paper.
     · Runs THE WARD over the index before anything is shown.

   HONEST LIMIT ON THE WARD
     This is a file-hygiene scanner, not an antivirus. It has no virus
     signature database and cannot detect novel malware. It checks
     extensions, magic bytes, extension/content mismatch, disguised
     names, archive bombs, path-traversal entries, macro-bearing office
     files and active content in PDFs/HTML/SVG — the tricks that actually
     travel in shared "past papers" folders. Keep real antivirus on the
     device. See README.

   Everything here is pure engine. The UI lives in index.html.
   ══════════════════════════════════════════════════════════════════ */

/* 18.16 — exported rather than assigned to window.

   As a classic script this was the only way to expose itself. As a module it is
   an export, and src/entry.js is the single place anything reaches global scope.
   Two publishers is how a bridge becomes permanent: one of them is written down
   and shrinking, the other is invisible. */
const Armory = (function(){

/* ─────────────────────────── small helpers ─────────────────────────── */
const dv = b => new DataView(b);
const u16 = (v,o) => v.getUint16(o, true);
const u32 = (v,o) => v.getUint32(o, true);
const u64 = (v,o) => { const lo = v.getUint32(o,true), hi = v.getUint32(o+4,true); return hi * 4294967296 + lo; };
const dec = (buf, utf8) => new TextDecoder(utf8 ? "utf-8" : "windows-1252", {fatal:false}).decode(buf);
const baseName = p => String(p).split("/").pop();
const extOf = p => { const n = baseName(p); const i = n.lastIndexOf("."); return i > 0 ? n.slice(i+1).toLowerCase() : ""; };
const fmtBytes = n => {
  if(!n && n !== 0) return "—";
  const u = ["B","KB","MB","GB","TB"]; let i = 0, x = n;
  while(x >= 1024 && i < u.length-1){ x /= 1024; i++; }
  return (x >= 10 || i === 0 ? Math.round(x) : x.toFixed(1)) + " " + u[i];
};

/* ═══════════════════════ 1 · ZIP CENTRAL DIRECTORY ═══════════════════════ */

const SIG_EOCD    = 0x06054b50;
const SIG_Z64_LOC = 0x07064b50;
const SIG_Z64_EOD = 0x06064b50;
const SIG_CDH     = 0x02014b50;
const SIG_LFH     = 0x04034b50;

async function slice(file, start, end){
  return new Uint8Array(await file.slice(start, end).arrayBuffer());
}

/* Locate the End Of Central Directory record by scanning backwards. */
async function findEOCD(file){
  const maxTail = Math.min(file.size, 65557 + 64);
  const tail = await slice(file, file.size - maxTail, file.size);
  const v = dv(tail.buffer);
  for(let i = tail.length - 22; i >= 0; i--){
    if(u32(v, i) === SIG_EOCD){
      return { buf: tail, off: i, base: file.size - maxTail };
    }
  }
  return null;
}

/* Read the archive index. Returns { entries, zip64, comment } or throws. */
async function readZipIndex(file, onProgress){
  if(file.size < 22) throw new Error("File is too small to be a zip archive.");
  const eocd = await findEOCD(file);
  if(!eocd) throw new Error("No zip directory found. If this is a .rar or .7z, unzip it first — the browser can only read .zip.");

  const v = dv(eocd.buf.buffer);
  let count   = u16(v, eocd.off + 10);
  let cdSize  = u32(v, eocd.off + 12);
  let cdStart = u32(v, eocd.off + 16);

  /* Zip64 — required for archives over 4 GB or with 65 535+ entries */
  let zip64 = false;
  const locAbs = eocd.base + eocd.off - 20;
  if(locAbs >= 0 && (count === 0xFFFF || cdSize === 0xFFFFFFFF || cdStart === 0xFFFFFFFF)){
    const loc = await slice(file, locAbs, locAbs + 20);
    const lv = dv(loc.buffer);
    if(u32(lv, 0) === SIG_Z64_LOC){
      const eodOff = u64(lv, 8);
      const eod = await slice(file, eodOff, eodOff + 56);
      const ev = dv(eod.buffer);
      if(u32(ev, 0) === SIG_Z64_EOD){
        zip64  = true;
        count  = u64(ev, 32);
        cdSize = u64(ev, 40);
        cdStart= u64(ev, 48);
      }
    }
  }
  if(!isFinite(cdStart) || cdStart < 0 || cdStart > file.size) throw new Error("The zip directory points outside the file. The archive looks truncated or corrupt.");
  if(cdSize > 256 * 1024 * 1024) throw new Error("This archive's directory alone is over 256 MB. That is far past anything a browser should hold.");

  const cd = await slice(file, cdStart, cdStart + cdSize);
  const cv = dv(cd.buffer);
  const entries = [];
  let p = 0, n = 0;

  while(p + 46 <= cd.length){
    if(u32(cv, p) !== SIG_CDH) break;
    const flags  = u16(cv, p + 8);
    const method = u16(cv, p + 10);
    const mtime  = u16(cv, p + 12), mdate = u16(cv, p + 14);
    const crc    = u32(cv, p + 16);
    let   csize  = u32(cv, p + 20);
    let   usize  = u32(cv, p + 24);
    const nLen   = u16(cv, p + 28);
    const eLen   = u16(cv, p + 30);
    const cLen   = u16(cv, p + 32);
    const attrs  = u32(cv, p + 38);
    let   lho    = u32(cv, p + 42);

    const nameBuf = cd.subarray(p + 46, p + 46 + nLen);
    const name = dec(nameBuf, (flags & 0x800) !== 0);

    /* Zip64 extended information extra field (0x0001) */
    let ep = p + 46 + nLen;
    const eEnd = ep + eLen;
    while(ep + 4 <= eEnd){
      const hid = u16(cv, ep), hsz = u16(cv, ep + 2);
      if(hid === 0x0001){
        let q = ep + 4;
        if(usize === 0xFFFFFFFF && q + 8 <= eEnd){ usize = u64(cv, q); q += 8; }
        if(csize === 0xFFFFFFFF && q + 8 <= eEnd){ csize = u64(cv, q); q += 8; }
        if(lho   === 0xFFFFFFFF && q + 8 <= eEnd){ lho   = u64(cv, q); q += 8; }
      }
      ep += 4 + hsz;
    }

    const isDir = name.endsWith("/") || ((attrs & 0x10) !== 0 && usize === 0);
    if(!isDir && name){
      entries.push({
        name, size: usize, csize, method, crc, off: lho,
        enc: (flags & 0x0001) !== 0,           /* entry is password-protected */
        date: dosDate(mdate, mtime)
      });
    }
    p = ep + cLen;
    n++;
    if(onProgress && (n % 2000 === 0)) onProgress(n, count);
    if(n > 400000) break;                       /* sanity ceiling */
  }
  return { entries, zip64, declared: count, cdSize };
}

function dosDate(d, t){
  try{
    const y = 1980 + ((d >> 9) & 0x7f), mo = ((d >> 5) & 0x0f), da = (d & 0x1f);
    return new Date(y, Math.max(0, mo-1), Math.max(1, da), (t >> 11) & 0x1f, (t >> 5) & 0x3f).getTime();
  }catch(e){ return 0; }
}

/* Pull ONE entry out of the zip on demand. Small files only — this is for
   opening a note, not for extracting the whole archive. */
async function extractEntry(file, entry, capBytes){
  const cap = capBytes || 64 * 1024 * 1024;
  if(entry.size > cap) throw new Error("That file is " + fmtBytes(entry.size) + ". Open it from the original archive on your device instead — the browser should not hold it in memory.");
  if(entry.enc) throw new Error("That entry is password-protected inside the zip. The System cannot open it.");
  const head = await slice(file, entry.off, entry.off + 30);
  const hv = dv(head.buffer);
  if(u32(hv, 0) !== SIG_LFH) throw new Error("Local header missing — the archive may be damaged.");
  const nLen = u16(hv, 26), eLen = u16(hv, 28);
  const start = entry.off + 30 + nLen + eLen;
  const raw = await slice(file, start, start + entry.csize);
  if(entry.method === 0) return raw;
  if(entry.method === 8){
    if(typeof DecompressionStream === "undefined") throw new Error("This browser cannot decompress zip entries. Chrome, Edge or Safari 16.4+ can.");
    const ds = new DecompressionStream("deflate-raw");
    const out = new Response(new Blob([raw]).stream().pipeThrough(ds));
    return new Uint8Array(await out.arrayBuffer());
  }
  throw new Error("Compression method " + entry.method + " is not supported (only store and deflate are).");
}

/* ═══════════════════════ 2 · FOLDER WALK ═══════════════════════ */

/* File System Access API — the right tool for 7 GB of material.
   Nothing is copied. The System keeps a handle and reads on demand. */
async function pickDirectory(){
  if(!window.showDirectoryPicker) throw new Error("This browser has no folder picker. Use Chrome or Edge on desktop or Android — or drop a .zip instead, which works everywhere.");
  return await window.showDirectoryPicker({ id:"system-armory", mode:"read" });
}

async function walkDirectory(dirHandle, onProgress, limit){
  const cap = limit || 60000;
  const out = [];
  async function rec(handle, path, depth){
    if(out.length >= cap || depth > 12) return;
    for await (const [name, h] of handle.entries()){
      if(out.length >= cap) return;
      const p = path ? path + "/" + name : name;
      if(h.kind === "directory"){ await rec(h, p, depth + 1); }
      else {
        let size = 0, date = 0;
        try{ const f = await h.getFile(); size = f.size; date = f.lastModified; }catch(e){}
        out.push({ name:p, size, date, handleName:name, dirPath:path });
        if(onProgress && out.length % 250 === 0) onProgress(out.length);
      }
    }
  }
  await rec(dirHandle, "", 0);
  return out;
}

/* <input webkitdirectory> / multi-file fallback — works everywhere, but the
   browser must enumerate every File object up front. Fine to a few thousand. */
function fromFileList(list){
  return [...list].map(f => ({
    name: f.webkitRelativePath || f.name,
    size: f.size, date: f.lastModified, file: f
  }));
}

/* ═══════════════════════ 3 · SUBJECT CLASSIFIER ═══════════════════════ */

/* Each subject: [key, label, [match terms], [exam board codes]]
   Matching runs longest-term-first so "further mathematics" wins over "mathematics". */
const SUBJECTS = [
  ["further_maths","Further Mathematics",["further mathematics","further maths","further math","f-maths","fmaths"],["9231","0606","4037"]],
  ["maths","Mathematics",["mathematics","maths","math","algebra","calculus","trigonometry","geometry","statistics","core math","elective math","additional math","add maths","pure math","mechanics"],["0580","0581","4024","9709","0607"]],
  ["physics","Physics",["physics","phy"],["0625","0972","9702","5054"]],
  ["chemistry","Chemistry",["chemistry","chem"],["0620","0971","9701","5070"]],
  ["biology","Biology",["biology","bio"],["0610","0970","9700","5090"]],
  ["science","Combined / Integrated Science",["combined science","coordinated science","integrated science","general science","physical science"],["0653","0654","0973"]],
  ["eng_lang","English Language",["english language","english lang","use of english","first language english","esl","english as a second"],["0500","0510","0511","1123","8021"]],
  ["eng_lit","English Literature",["english literature","literature in english","lit in english","literature"],["0475","0486","0992","9695"]],
  ["ict","ICT & Computing",["information and communication","information technology","computer science","computing","ict","programming","python","coding"],["0417","0418","0478","2210","9618","9608"]],
  ["econ","Economics",["economics","econ","microeconomics","macroeconomics"],["0455","2281","9708"]],
  ["business","Business Studies",["business studies","business management","business","entrepreneurship"],["0450","0986","7115","9609"]],
  ["accounting","Accounting",["accounting","accounts","financial accounting","cost accounting","principles of accounts"],["0452","7110","9706"]],
  ["geography","Geography",["geography","geog"],["0460","0976","2217","9696"]],
  ["history","History",["history","hist"],["0470","0977","2147","9489"]],
  ["government","Government & Politics",["government","politics","civic education","civics"],["9787"]],
  ["social","Social Studies",["social studies","sociology"],["0495","9699"]],
  ["religion","Religious Studies",["religious studies","religious education","christian religious","islamic studies","rme","crs","ire","bible knowledge"],["0490","2058","9011"]],
  ["french","French",["french","francais","français"],["0520","7156","9716"]],
  ["spanish","Spanish",["spanish","espanol","español"],["0530","7160","9719"]],
  ["german","German",["german","deutsch"],["0525","7159"]],
  ["chinese","Chinese",["chinese","mandarin"],["0547","0509"]],
  ["ghana_lang","Ghanaian Language",["twi","asante twi","akuapem","fante","ewe","ga ","dagbani","dagaare","nzema","gonja","kasem"],[]],
  ["art","Art & Design",["art and design","art & design","fine art","visual art","graphic design","drawing"],["0400","0989","9479"]],
  ["music","Music",["music","theory of music"],["0410","0978","9483"]],
  ["drama","Drama & Theatre",["drama","theatre","theater","performing art"],["0411","9482"]],
  ["pe","Physical Education",["physical education","p.e.","sport science"],["0413","9396"]],
  ["psych","Psychology",["psychology","psych"],["0500p","9990"]],
  ["food","Food & Nutrition",["food and nutrition","food & nutrition","home economics","catering","management in living"],["0648","6065"]],
  ["design_tech","Design & Technology",["design and technology","technical drawing","engineering drawing","woodwork","metalwork","building construction","applied electricity"],["0445","0979","9705"]],
  ["global","Global Perspectives",["global perspectives","global perspective","world issues"],["0457","9239"]],
  ["agric","Agricultural Science",["agricultural science","agriculture","agric","general agriculture"],["0600","5038"]],
  ["env","Environmental Management",["environmental management","environmental science"],["0680","8291"]],
  ["sat","SAT / Standardised Tests",["sat ","digital sat","psat","act ","gre ","ielts","toefl"],[]]
];

/* Longest terms first so specific beats general */
const SUBJ_TERMS = (() => {
  const rows = [];
  SUBJECTS.forEach(([key,, terms, codes]) => {
    terms.forEach(t => rows.push([t, key, t.length + 100]));
    (codes||[]).forEach(c => rows.push([c, key, c.length + 300]));   /* board codes are strongest evidence */
  });
  return rows.sort((a,b) => b[2] - a[2]);
})();

const SUBJ_LABEL = Object.fromEntries(SUBJECTS.map(([k,l]) => [k, l]));
SUBJ_LABEL.unsorted = "Unsorted";

function detectSubject(path){
  const hay = " " + String(path).toLowerCase().replace(/[_\-.]/g, " ").replace(/\s+/g, " ") + " ";
  for(const [term, key] of SUBJ_TERMS){
    if(/^\d{4}$/.test(term)){
      if(new RegExp("(^|[^0-9])" + term + "([^0-9]|$)").test(hay)) return key;
    } else if(hay.includes(" " + term.trim() + " ") || hay.includes(term)){
      return key;
    }
  }
  return "unsorted";
}

/* ── material type ── */
const VIDEO_EXT = ["mp4","mkv","avi","mov","webm","m4v","flv","wmv","mpg","mpeg","3gp","ts","ogv"];
const AUDIO_EXT = ["mp3","m4a","wav","ogg","aac","flac","opus","wma"];
const DOC_EXT   = ["pdf","doc","docx","odt","rtf","txt","md","ppt","pptx","odp","xls","xlsx","csv","epub","mobi","djvu","pages","key","numbers"];
const IMG_EXT   = ["jpg","jpeg","png","gif","webp","bmp","heic","tif","tiff","svg"];

/* Cambridge/Edexcel/WAEC paper-code grammar:
   0580_s21_qp_42   9702_w19_ms_11   4024_m22_qp_12  */
const CIE_RE = /\b(\d{4})[_\- ]?([wsm])(\d{2})[_\- ]?(qp|ms|in|ci|er|gt|sy|sf|sm|sp|rp|tn|pm)[_\- ]?(\d{1,2})?\b/i;
const PAPER_KIND = { qp:"Question paper", ms:"Mark scheme", in:"Insert", ci:"Confidential instructions",
  er:"Examiner report", gt:"Grade thresholds", sy:"Syllabus", sf:"Source", sm:"Specimen",
  sp:"Specimen paper", rp:"Resource", tn:"Teacher notes", pm:"Mark scheme" };
const SESSION = { m:"Feb/March", s:"May/June", w:"Oct/Nov" };
const SESSION_ORDER = { m:1, s:2, w:3 };

function detectType(path){
  const p = String(path).toLowerCase();
  const e = extOf(p);
  if(VIDEO_EXT.includes(e)) return "video";
  if(AUDIO_EXT.includes(e)) return "audio";

  const cie = p.match(CIE_RE);
  if(cie) return cie[4].toLowerCase() === "sy" ? "syllabus" : "past";
  if(/\b(past ?papers?|question ?papers?|mark ?scheme|marking ?scheme|examiner ?report|exam ?paper|pastq|past q|wassce|waec|neco|jamb|may ?june|oct ?nov|november \d{4}|june \d{4})\b/.test(p)) return "past";
  if(/\b(syllabus|specification|scheme of work|curriculum|course outline)\b/.test(p)) return "syllabus";
  if(/\b(textbook|coursebook|course book|student book|students book|workbook|revision guide|study guide|endorsed|edition)\b/.test(p) || e === "epub" || e === "mobi" || e === "djvu") return "book";
  if(/\b(flash ?cards?|anki|quizlet|mcq|quiz|test yourself)\b/.test(p)) return "flash";
  if(DOC_EXT.includes(e) || IMG_EXT.includes(e)) return "notes";
  return "other";
}

const TYPE_LABEL = { notes:"Notes", past:"Past papers", video:"Videos", audio:"Audio",
  book:"Textbooks", syllabus:"Syllabus", flash:"Flashcards & quizzes", other:"Other files" };
const TYPE_ORDER = ["notes","past","video","audio","book","syllabus","flash","other"];

/* ── year / session / paper number ── */
function detectPaperMeta(path){
  const p = String(path);
  const m = p.match(CIE_RE);
  if(m){
    const yy = parseInt(m[3], 10);
    return {
      code: m[1],
      year: yy + (yy > 60 ? 1900 : 2000),
      session: m[2].toLowerCase(),
      kind: (m[4] || "").toLowerCase(),
      paper: m[5] ? parseInt(m[5], 10) : null
    };
  }
  const out = { code:null, year:null, session:null, kind:null, paper:null };
  const y = p.match(/\b(19[89]\d|20[0-4]\d)\b/);
  if(y) out.year = parseInt(y[1], 10);
  const low = p.toLowerCase();
  if(/\b(may|june|jun|summer)\b/.test(low)) out.session = "s";
  else if(/\b(oct|nov|winter)\b/.test(low)) out.session = "w";
  else if(/\b(feb|mar|march)\b/.test(low)) out.session = "m";
  if(/\bmark ?scheme|\bms\b|answers?\b/.test(low)) out.kind = "ms";
  else if(/\bquestion ?paper|\bqp\b/.test(low)) out.kind = "qp";
  const pn = low.match(/\bpaper ?(\d{1,2})\b/);
  if(pn) out.paper = parseInt(pn[1], 10);
  return out;
}

/* Newest first inside past-paper groups, question paper before mark scheme. */
function sortPapers(rows, oldestFirst){
  const dir = oldestFirst ? 1 : -1;
  return rows.slice().sort((a,b) => {
    const ay = a.meta.year || 0, by = b.meta.year || 0;
    if(ay !== by) return (ay - by) * dir;
    const as = SESSION_ORDER[a.meta.session] || 0, bs = SESSION_ORDER[b.meta.session] || 0;
    if(as !== bs) return (as - bs) * dir;
    const ap = a.meta.paper || 99, bp = b.meta.paper || 99;
    if(ap !== bp) return ap - bp;
    const rank = k => k === "qp" ? 0 : k === "in" ? 1 : k === "ms" ? 2 : k === "er" ? 3 : 4;
    const ar = rank(a.meta.kind), br = rank(b.meta.kind);
    if(ar !== br) return ar - br;
    return a.name.localeCompare(b.name);
  });
}

/* ═══════════════════════ 4 · THE WARD ═══════════════════════ */

/* Extensions that can execute. Never opened, never previewed, quarantined. */
const EXEC_EXT = ["exe","msi","bat","cmd","com","scr","pif","cpl","vbs","vbe","js","jse","wsf","wsh",
  "ps1","psm1","psd1","sh","bash","jar","apk","app","dmg","deb","rpm","dll","sys","lnk","reg","hta",
  "gadget","inf","ade","adp","chm","msc","msp","mst","ocx","paf","pol","scf","vb","vxd","ws"];
/* Office formats that can carry macros */
const MACRO_EXT = ["docm","xlsm","pptm","dotm","xltm","potm","xlam","ppam","xll","xlsb"];
/* Archives nested inside the drop — can hide anything, so they're flagged for review */
const ARCH_EXT  = ["zip","rar","7z","tar","gz","bz2","xz","iso","cab","tgz","z","arj","ace","img"];
/* Right-to-left override and friends — the classic "gpj.exe" filename trick */
const RTL_RE = /[\u202A-\u202E\u2066-\u2069\u200E\u200F]/;

function wardCheck(entry){
  const flags = [];
  const name = baseName(entry.name);
  const low  = name.toLowerCase();
  const e    = extOf(name);
  const path = String(entry.name);

  if(EXEC_EXT.includes(e))
    flags.push({ sev:"block", code:"executable", msg:"Executable or script file (." + e + "). Study material is never an executable." });

  if(MACRO_EXT.includes(e))
    flags.push({ sev:"warn", code:"macro", msg:"Macro-enabled Office file. Open with macros disabled, or ask for a plain ." + e.replace("m","x") + "." });

  /* double extension: notes.pdf.exe, paper.docx.js */
  const parts = low.split(".");
  if(parts.length > 2){
    const inner = parts[parts.length - 2];
    if([...DOC_EXT, ...IMG_EXT, ...VIDEO_EXT].includes(inner) && (EXEC_EXT.includes(e) || ARCH_EXT.includes(e)))
      flags.push({ sev:"block", code:"double-ext", msg:"Disguised name: looks like a ." + inner + " but is actually a ." + e + "." });
  }

  if(RTL_RE.test(name))
    flags.push({ sev:"block", code:"rtl", msg:"Filename contains direction-override characters — used to hide a real extension." });

  if(path.includes("../") || path.includes("..\\") || /^([a-z]:[\\/]|[\\/])/i.test(path))
    flags.push({ sev:"block", code:"traversal", msg:"Entry path escapes the archive folder (zip-slip). Malformed or hostile archive." });

  if(ARCH_EXT.includes(e))
    flags.push({ sev:"note", code:"nested", msg:"Nested archive — the Ward cannot see inside it. Unpack and re-scan if you need it." });

  if(entry.enc)
    flags.push({ sev:"warn", code:"encrypted", msg:"Password-protected entry. Encrypted contents cannot be inspected." });

  /* archive bomb: absurd compression ratio on a large entry */
  if(entry.csize > 0 && entry.size > 50 * 1024 * 1024){
    const ratio = entry.size / entry.csize;
    if(ratio > 200)
      flags.push({ sev:"block", code:"bomb", msg:"Compression ratio " + Math.round(ratio) + ":1 on " + fmtBytes(entry.size) + " — the signature of a decompression bomb." });
  }

  if(entry.size === 0)
    flags.push({ sev:"note", code:"empty", msg:"Empty file." });

  const sev = flags.some(f => f.sev === "block") ? "block"
            : flags.some(f => f.sev === "warn")  ? "warn"
            : flags.length ? "note" : "clean";
  return { sev, flags };
}

/* Deep pass — reads the first bytes of a file and compares them to the
   extension. Requires the Ward Protocol skill; only run on demand. */
const MAGIC = [
  [[0x25,0x50,0x44,0x46], "pdf"],
  [[0x50,0x4b,0x03,0x04], "zip"],            /* also docx/xlsx/pptx/epub */
  [[0xff,0xd8,0xff],      "jpg"],
  [[0x89,0x50,0x4e,0x47], "png"],
  [[0x47,0x49,0x46,0x38], "gif"],
  [[0x52,0x49,0x46,0x46], "riff"],
  [[0x1a,0x45,0xdf,0xa3], "mkv"],
  [[0xd0,0xcf,0x11,0xe0], "ole"],            /* legacy doc/xls/ppt */
  [[0x4d,0x5a],           "exe"],            /* MZ — Windows PE */
  [[0x7f,0x45,0x4c,0x46], "elf"],            /* Linux binary */
  [[0xca,0xfe,0xba,0xbe], "macho"],
  [[0x23,0x21],           "shebang"]
];
const ZIP_FAMILY = ["zip","docx","xlsx","pptx","docm","xlsm","pptm","epub","odt","ods","odp","apk","jar","kmz"];
const OLE_FAMILY = ["doc","xls","ppt","msi","msg"];
const EICAR = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*";

function sniff(bytes){
  for(const [sig, kind] of MAGIC){
    if(sig.every((b, i) => bytes[i] === b)) return kind;
  }
  const head = new TextDecoder("utf-8", {fatal:false}).decode(bytes.subarray(0, 512)).toLowerCase();
  if(head.includes("<?xml") && head.includes("<svg")) return "svg";
  if(head.includes("<!doctype html") || head.includes("<html")) return "html";
  return "unknown";
}

/* head: first ~8 KB of the file. Returns extra flags. */
function deepCheck(name, head){
  const flags = [];
  const e = extOf(name);
  const kind = sniff(head);
  const text = new TextDecoder("utf-8", {fatal:false}).decode(head);
  const low = text.toLowerCase();

  const expect =
    ZIP_FAMILY.includes(e) ? "zip" :
    OLE_FAMILY.includes(e) ? "ole" :
    e === "jpeg" ? "jpg" : e;

  if(kind === "exe" || kind === "elf" || kind === "macho" || kind === "shebang"){
    if(!EXEC_EXT.includes(e))
      flags.push({ sev:"block", code:"masquerade", msg:"File is a compiled program or script, not a ." + e + ". Do not open it." });
  } else if(kind !== "unknown" && expect && kind !== expect && !(kind === "riff" && ["wav","avi","webp"].includes(e))){
    flags.push({ sev:"warn", code:"mismatch", msg:"Contents look like " + kind.toUpperCase() + " but the name says ." + e + "." });
  }

  if(e === "pdf" || kind === "pdf"){
    if(/\/javascript|\/js\b/i.test(text)) flags.push({ sev:"warn", code:"pdf-js", msg:"PDF contains embedded JavaScript." });
    if(/\/openaction/i.test(text))        flags.push({ sev:"warn", code:"pdf-auto", msg:"PDF runs an action on open." });
    if(/\/launch|\/embeddedfile/i.test(text)) flags.push({ sev:"warn", code:"pdf-launch", msg:"PDF can launch a file or carries an attachment." });
  }
  if(kind === "svg" || kind === "html" || ["svg","html","htm","xhtml"].includes(e)){
    if(low.includes("<script") || /on(load|error|click)\s*=/.test(low))
      flags.push({ sev:"warn", code:"active-html", msg:"Page contains scripts. The System renders it as plain text only." });
  }
  if(text.includes(EICAR))
    flags.push({ sev:"block", code:"eicar", msg:"EICAR antivirus test file detected. Harmless by design — and proof the Ward is reading bytes." });

  return { kind, flags };
}

/* ═══════════════════════ 5 · INDEX BUILDER ═══════════════════════ */

/* rows: [{name, size, date, ...}] → sorted, classified, Ward-checked index */
function buildIndex(rows, source){
  const files = [];
  let blocked = 0, warned = 0;

  rows.forEach((r, i) => {
    const w = wardCheck(r);
    const rec = {
      i,
      name: r.name,
      base: baseName(r.name),
      ext: extOf(r.name),
      size: r.size || 0,
      date: r.date || 0,
      subject: detectSubject(r.name),
      type: detectType(r.name),
      meta: detectPaperMeta(r.name),
      ward: w.sev,
      flags: w.flags,
      off: r.off, csize: r.csize, method: r.method, enc: r.enc,
      dirPath: r.dirPath
    };
    if(w.sev === "block"){ blocked++; rec.quarantine = true; }
    else if(w.sev === "warn") warned++;
    files.push(rec);
  });

  /* subject → type → sorted rows */
  const bySubject = {};
  files.forEach(f => {
    if(f.quarantine) return;
    const s = (bySubject[f.subject] = bySubject[f.subject] || {});
    (s[f.type] = s[f.type] || []).push(f);
  });
  Object.values(bySubject).forEach(groups => {
    Object.keys(groups).forEach(t => {
      groups[t] = t === "past"
        ? sortPapers(groups[t], false)
        : groups[t].sort((a,b) => a.base.localeCompare(b.base, undefined, {numeric:true}));
    });
  });

  const totalBytes = files.reduce((n,f) => n + (f.size || 0), 0);
  return {
    source, created: Date.now(),
    files, bySubject,
    stats: { count: files.length, bytes: totalBytes, blocked, warned,
             subjects: Object.keys(bySubject).length }
  };
}

/* ═══════════════════════ 6 · INDEXEDDB ═══════════════════════ */

const DBN = "system-armory", STORE = "kv";
function idb(){
  return new Promise((res, rej) => {
    const rq = indexedDB.open(DBN, 1);
    rq.onupgradeneeded = () => { rq.result.createObjectStore(STORE); };
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}
async function kvSet(k, v){
  const d = await idb();
  return new Promise((res, rej) => {
    const tx = d.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(v, k);
    tx.oncomplete = () => res(true); tx.onerror = () => rej(tx.error);
  });
}
async function kvGet(k){
  const d = await idb();
  return new Promise((res, rej) => {
    const tx = d.transaction(STORE, "readonly");
    const rq = tx.objectStore(STORE).get(k);
    rq.onsuccess = () => res(rq.result); rq.onerror = () => rej(rq.error);
  });
}
async function kvDel(k){
  const d = await idb();
  return new Promise((res, rej) => {
    const tx = d.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(k);
    tx.oncomplete = () => res(true); tx.onerror = () => rej(tx.error);
  });
}

/* ═══════════════════════ exports ═══════════════════════ */
return {
  readZipIndex, extractEntry,
  pickDirectory, walkDirectory, fromFileList,
  detectSubject, detectType, detectPaperMeta, sortPapers,
  wardCheck, deepCheck, sniff, buildIndex,
  kvSet, kvGet, kvDel,
  SUBJECTS, SUBJ_LABEL, TYPE_LABEL, TYPE_ORDER, PAPER_KIND, SESSION,
  VIDEO_EXT, EXEC_EXT, fmtBytes, baseName, extOf
};
})();

export { Armory };
