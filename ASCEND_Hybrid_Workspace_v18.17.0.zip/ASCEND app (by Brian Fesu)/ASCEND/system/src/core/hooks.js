/* ASCEND — core/hooks.js
   The seam that makes the module conversion possible.

   ## What this replaces

   Twenty-two places in this codebase reassigned a function that another file
   had declared:

       const __renderAllV12 = renderAll;
       renderAll = function(){ __renderAllV12(); renderHome(); refreshTally(); };

   renderAll was wrapped six deep this way — core-views declares it, then
   v9-views, arena, ui-v11, router and wiring each replace it with a wrapper
   around the previous one. The composition order is the <script> order in
   index.html and nothing else. Three consequences, all of which have cost this
   project a release:

     · It is undiscoverable. Reading views/home.js you cannot tell that
       renderAll will call renderHome, because home.js never says so — router.js
       does, three hundred lines away in a different directory.

     · It is load-order-fragile. Move one <script> tag and the chain silently
       reorders. Five function-name collisions have shipped in this project's
       history for the neighbouring reason.

     · It cannot survive ES modules. An imported binding is read-only, so all
       twenty-two are compile errors. This is the concrete thing that has kept
       P1-01 outstanding for four releases — not the 88 files, and not the
       cycles. (The dependency graph has 140 cycles but zero LOAD-TIME cycles:
       every one is a call-time cycle between hoisted function declarations,
       which ES modules resolve exactly as classic scripts do.)

   ## What replaces it

   The declaring file keeps the base implementation private and exposes a
   dispatcher:

       function renderAllBase(){ ...the original body... }
       function renderAll(){ return Hooks.dispatch("renderAll", renderAllBase, this, arguments); }

   Other files register instead of reassigning:

       Hooks.after("renderAll", "shell chrome", () => { renderHome(); refreshTally(); });

   renderAll is never reassigned, so the binding can be `const` and can be an
   ES module export. The composition is now a list you can print.

   ## Ordering

   One ordered list per name. Registration order is preserved, and the LAST
   registered is the OUTERMOST — which is what the reassignment idiom did, since
   each file wrapped whatever it found. Load order therefore still determines
   composition, but it is now recorded rather than implied, and Hooks.list()
   will tell you what it ended up as.

   ## Errors

   dispatch does NOT catch. A wrapper that throws propagates exactly as it does
   today — changing that here would alter behaviour in twelve view files at
   once, which is not what a refactor should do. What is new is that the failure
   is RECORDED before it propagates, so a hook that breaks a render is
   attributable to a named registration instead of appearing as an anonymous
   stack in the middle of renderAll. Files that want isolation keep using
   safeRender(), which is unchanged.

   ## Contract

     Hooks.wrap(name, label, fn)     fn(next, ...args) — full control
     Hooks.before(name, label, fn)   fn(...args) runs first, return ignored
     Hooks.after(name, label, fn)    fn(result, ...args) runs last, return ignored
     Hooks.replace(name, label, fn)  fn(...args) — base is not called
     Hooks.dispatch(name, base, thisArg, args)
     Hooks.list(name)                the composition, outermost last
     Hooks.names()                   every dispatched name
     Hooks.failures(n)               recent hook errors, for diagnostics
*/

const Hooks = (() => {
  const reg = new Map();          /* name -> [{ kind, label, fn }] */
  const failures = [];
  const MAX_FAILURES = 40;

  function add(name, kind, label, fn) {
    if (typeof fn !== "function") return () => {};
    if (typeof name !== "string" || !name) return () => {};
    if (!reg.has(name)) reg.set(name, []);
    const list = reg.get(name);
    const entry = { kind, label: String(label || "unlabelled"), fn };
    list.push(entry);
    return () => { const i = list.indexOf(entry); if (i >= 0) list.splice(i, 1); };
  }

  function note(name, label, kind, err) {
    failures.push({
      name, label, kind,
      message: (err && err.message) || String(err),
      at: Date.now(),
    });
    if (failures.length > MAX_FAILURES) failures.shift();
    if (typeof console !== "undefined" && console.warn) {
      console.warn("[hooks] " + name + " · " + kind + " \"" + label + "\" threw: " + ((err && err.message) || err));
    }
  }

  /* Compose the registered entries around `base` and call the result.
     Built fresh on each dispatch rather than cached: a registration can arrive
     at any time (a lazily-loaded feature registering a render hook), and a
     cached chain would silently ignore it. The lists are short — the longest in
     this app is six — so the allocation is not worth a cache-invalidation bug. */
  function dispatch(name, base, thisArg, args) {
    const list = reg.get(name);
    const argv = Array.prototype.slice.call(args || []);
    if (!list || !list.length) return base.apply(thisArg, argv);

    let call = function (...a) { return base.apply(thisArg, a); };

    for (const entry of list) {
      const next = call;
      const { kind, label, fn } = entry;
      if (kind === "wrap") {
        call = function (...a) {
          try { return fn.call(thisArg, next, ...a); }
          catch (e) { note(name, label, kind, e); throw e; }
        };
      } else if (kind === "before") {
        call = function (...a) {
          try { fn.apply(thisArg, a); }
          catch (e) { note(name, label, kind, e); throw e; }
          return next(...a);
        };
      } else if (kind === "after") {
        call = function (...a) {
          const r = next(...a);
          try { fn.call(thisArg, r, ...a); }
          catch (e) { note(name, label, kind, e); throw e; }
          return r;
        };
      } else if (kind === "replace") {
        call = function (...a) {
          try { return fn.apply(thisArg, a); }
          catch (e) { note(name, label, kind, e); throw e; }
        };
      }
    }
    return call(...argv);
  }

  return {
    wrap:    (name, label, fn) => add(name, "wrap", label, fn),
    before:  (name, label, fn) => add(name, "before", label, fn),
    after:   (name, label, fn) => add(name, "after", label, fn),
    replace: (name, label, fn) => add(name, "replace", label, fn),
    dispatch,
    list(name) { return (reg.get(name) || []).map(e => ({ kind: e.kind, label: e.label })); },
    names() { return [...reg.keys()].sort(); },
    count(name) { return (reg.get(name) || []).length; },
    failures(n = 20) { return failures.slice(-n); },
    /* test seam only — never called by the app */
    _reset() { reg.clear(); failures.length = 0; },
  };
})();

export { Hooks };
