import { SCHEMA, Store } from "./store.js";

/* ASCEND — core/kernel.js
   v12 logic, unchanged, except that persistence goes through core/store.js
   instead of touching localStorage directly. Same key, same shape, same saves. */
/* ══════════════════════════════════════════════════════════
   THE SYSTEM — offline core. No server, no network, no tracking.
   All state in localStorage under key "system.v1".
   ══════════════════════════════════════════════════════════ */

const LS = "system.v1";
const $  = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const pad = n => String(n).padStart(2,"0");
const todayKey = (d=new Date()) => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
/* The inverse of todayKey(). new Date("2026-08-18") is parsed as UTC midnight,
   which is the previous day everywhere west of Greenwich — so a key written in
   local time came back as the wrong date, and getDay() as the wrong weekday.
   Splitting the parts and using the local constructor keeps the round trip
   honest in every timezone. Noon, not midnight, so a DST shift cannot move it. */
const dateFromKey = k => {
  const [y,m,d] = String(k).split("-").map(Number);
  return (y && m && d) ? new Date(y, m-1, d, 12, 0, 0) : new Date(NaN);
};
const DEFAULT_AVATAR = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' fill='%230a1424'/><text x='50' y='64' font-size='42' text-anchor='middle' fill='%2338d6ff' font-family='monospace'>?</text></svg>";

/* ---------- persistence ---------- */
let DB = load();   /* replaced once SYSTEM_READY settles — see below */
function load(){
  try{ const r = Store.readJSON(LS); if(r && r.hunters){
    r.store = r.store || {};
    if(typeof r.store.countEndpoint !== "string") r.store.countEndpoint = "";
    r.sec = r.sec || { fails:{}, until:{} };
    if(!r.installId) r.installId = [...crypto.getRandomValues(new Uint8Array(12))].map(b=>b.toString(16).padStart(2,"0")).join("");
    return Store.migrate(r);
  } }catch(e){}
  return Store.migrate({ schema: SCHEMA, hunters:{}, active:null,
    store:{ payLink:"", blurb:"The System is built by an independent creator. If it's changing how your day runs, you can back it.", countEndpoint:"" },
    sec:{ fails:{}, until:{} },
    installId: [...crypto.getRandomValues(new Uint8Array(12))].map(b=>b.toString(16).padStart(2,"0")).join("")
  });
}
function save(){
  /* 18.14 — guardedSave() has existed in services/integrity.js since v18 and was
     called by nothing. It is the difference between a failed write that tells
     the student "storage is full" after their form has cleared, and one that
     holds a copy of what they were writing so it can be handed back.

     186 call sites route through here, so wiring it once wires all of them.
     The typeof guard is load order, not doubt: kernel.js runs before
     services/integrity.js, and a save during boot must still work. */
  if(typeof guardedSave === "function"){
    const g = guardedSave(DB);
    if(!g.ok && typeof toast === "function") toast("Could not save", g.message, "blood");
    return g.ok;
  }
  const r = Store.writeJSON(LS, DB);
  if(!r.ok && typeof toast === "function") toast("Storage full","Free up space or export your hunter file.","blood");
  return r.ok;
}
const H = () => DB.hunters[DB.active];

/* ---------- boot is asynchronous as of 18.9 ----------
   The store's IndexedDB driver cannot answer synchronously until it has been
   hydrated, so the load() above returns an empty record on an IndexedDB-backed
   device and this re-reads once the real bytes are in.

   That is only safe because nothing outside this file touches DB or H() at
   script-load time — measured across all 76 classic scripts, not assumed, and
   asserted in store-test.js so it stays true. Every other reader runs from a
   callback that fires well after this settles. Writes are protected from the
   other side: the driver refuses to flush before it is hydrated, so a save()
   racing boot cannot put an empty record over a real one. */
const SYSTEM_READY = (typeof Store !== "undefined" && Store.hydrate
  ? Store.hydrate()
  : Promise.resolve({ driver:"local" })
).then(info => {
  /* Re-read ONLY when the driver could not answer synchronously at load.

     localStorage and memory both could, so DB already holds the real record by
     the time this resolves — and it may already hold changes that have not been
     saved yet. Re-reading there discards them. That is not hypothetical: it
     broke five cloud checks in brain-test the first time this shipped, because
     the suite builds a hunter and syncs it inside one tick. */
  if(info && info.driver === "idb" && !info.fellBack) DB = load();
  return info;
}).catch(() => ({ driver:"unknown", error:true }));


/* DB is the one export here that is REASSIGNED after this module runs — load()
   is called again once the store hydrates. Named exports are live bindings, so
   an importing module sees the new value; a name copied onto globalThis does
   not, which is why src/entry.js publishes DB through a getter rather than by
   assignment. Nothing outside this file writes it — that was measured across all
   76 classic scripts before this conversion, and reachability-test.js keeps it
   true. */
export { LS, $, $$, pad, todayKey, dateFromKey, DEFAULT_AVATAR, DB, load, save, H, SYSTEM_READY };
