/* ASCEND — core/store.js
   The one seam between the application and where its bytes live.

   v13 called localStorage directly from kernel.js. That was fine while there was
   exactly one place data could go. Phase 6 needs a second (cloud), Phase 13 needs
   a third (IndexedDB for bulk), and neither should require touching 40 view files.
   So everything now passes through here.

   Contract, deliberately small:
     Store.readJSON(key)         → parsed value or null
     Store.writeJSON(key, value) → { ok, error }
     Store.remove(key)           → void
     Store.migrate(record)       → record, brought up to CURRENT schema
     Store.subscribe(fn)         → unsubscribe; fires on every successful write
     Store.driver                → the active driver's name

   Drivers implement get/set/del/keys synchronously, and 18.9 adds the IndexedDB
   one the registry was built for. IndexedDB is asynchronous and the contract is
   not, so `idb` is a synchronous facade over an in-memory cache that is hydrated
   once at boot and flushed asynchronously after every write. That is what keeps
   186 existing save() call sites working unchanged: the caller sees the same
   synchronous function it always did.

   Two consequences are worth stating out loud rather than discovering later.

   · Boot is now genuinely asynchronous. Store.hydrate() must resolve before the
     record is readable, so kernel.js re-reads once it does and boot-auth.js
     waits. Nothing outside kernel.js touched DB at load time — that was measured
     before this change, not assumed.

   · A write can be lost if the tab is killed in the ~0 to 40 ms between a save()
     and its flush. localStorage could not lose that write because it was
     synchronous. The flush is therefore eager rather than idle-scheduled, and
     pagehide forces one; the residual window is small but it is not zero, and it
     is the reason the localStorage copy is kept rather than deleted. */

const SCHEMA = 6;          /* 1 = v12/v13 · 2 = intelligence · 3 = Academy · 4 = Gate/opportunities/projects · 5 = Circle & Studio · 6 = the student graph (quest links) */

const StoreDrivers = {
  local: {
    name: "local",
    available(){ try{ localStorage.setItem("__t","1"); localStorage.removeItem("__t"); return true; }catch(e){ return false; } },
    get(k){ return localStorage.getItem(k); },
    set(k,v){ localStorage.setItem(k,v); },
    del(k){ localStorage.removeItem(k); },
    keys(){ return Object.keys(localStorage); },
  },
  /* ---------- IndexedDB ----------
     The reason to move: localStorage is capped near 5 MB per origin and, more
     importantly, every write is synchronous and serialises the entire record on
     the main thread. A fresh record is 5.8 KB, so the cap is not the pressure —
     two years of daily practice logs on a mid-range Android phone is.

     What this is NOT yet: the whole record is still one key, so a write is still
     all-or-nothing. Splitting it per domain is what actually fixes corruption
     granularity, and it belongs with the event log rather than here, where it
     would be a second risky change in the same release. */
  idb: {
    name: "idb",
    DB_NAME: "ascend.store",
    STORE: "kv",
    VERSION: 1,
    _cache: new Map(),
    _db: null,
    _hydrated: false,
    _pending: new Map(),
    _flushing: null,
    _timer: null,
    _onError: null,

    available(){
      try{ return typeof indexedDB !== "undefined" && indexedDB !== null; }
      catch(e){ return false; }
    },

    _open(){
      if(this._db) return Promise.resolve(this._db);
      return new Promise((resolve, reject) => {
        let rq;
        try{ rq = indexedDB.open(this.DB_NAME, this.VERSION); }
        catch(e){ return reject(e); }
        rq.onupgradeneeded = () => {
          const db = rq.result;
          if(!db.objectStoreNames.contains(this.STORE)) db.createObjectStore(this.STORE);
        };
        rq.onsuccess = () => { this._db = rq.result; resolve(this._db); };
        rq.onerror = () => reject(rq.error || new Error("indexedDB.open failed"));
        rq.onblocked = () => reject(new Error("indexedDB is blocked by another tab"));
      });
    },

    /* Reads every key into the synchronous cache. Until this resolves the driver
       reports nothing and refuses to flush, so a save() that races the boot
       cannot write an empty record over a real one. */
    async hydrate(){
      const db = await this._open();
      const all = await new Promise((resolve, reject) => {
        const tx = db.transaction(this.STORE, "readonly");
        const os = tx.objectStore(this.STORE);
        const out = new Map();
        const rq = os.openCursor();
        rq.onsuccess = () => {
          const c = rq.result;
          if(!c) return resolve(out);
          out.set(String(c.key), c.value);
          c.continue();
        };
        rq.onerror = () => reject(rq.error || new Error("cursor failed"));
      });
      this._cache = all;
      this._hydrated = true;
      return all.size;
    },

    get(k){ return this._cache.has(k) ? this._cache.get(k) : null; },
    set(k, v){ this._cache.set(k, v); this._queue(k); },
    del(k){ this._cache.delete(k); this._queue(k); },
    keys(){ return [...this._cache.keys()]; },

    _queue(k){
      this._pending.set(k, this._cache.has(k) ? this._cache.get(k) : undefined);
      if(!this._hydrated) return;          /* the guard that protects a real record */
      if(this._timer) return;
      /* Eager, not idle: the gap between a save() and its flush is the only
         window in which a killed tab loses a write. */
      this._timer = setTimeout(() => { this._timer = null; this.flush(); }, 0);
    },

    flush(){
      if(this._flushing) return this._flushing.then(() => this.flush());
      if(!this._hydrated || !this._pending.size) return Promise.resolve();
      const batch = this._pending; this._pending = new Map();
      this._flushing = this._open().then(db => new Promise((resolve, reject) => {
        const tx = db.transaction(this.STORE, "readwrite");
        const os = tx.objectStore(this.STORE);
        for(const [k, v] of batch){
          if(v === undefined) os.delete(k); else os.put(v, k);
        }
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error || new Error("write failed"));
        tx.onabort = () => reject(tx.error || new Error("write aborted"));
      })).catch(e => {
        /* Put the batch back so the next flush retries it, and tell the app —
           a storage failure the student never sees is a storage failure that
           looks like their work vanished. */
        for(const [k, v] of batch) if(!this._pending.has(k)) this._pending.set(k, v);
        if(typeof this._onError === "function") this._onError(e);
      }).finally(() => { this._flushing = null; });
      return this._flushing;
    },
  },

  /* Last resort so the app still runs in a locked-down browser. Nothing survives
     a reload, and the UI is told so rather than silently losing the hunter. */
  memory: {
    name: "memory",
    _m: new Map(),
    available(){ return true; },
    get(k){ return this._m.has(k) ? this._m.get(k) : null; },
    set(k,v){ this._m.set(k,v); },
    del(k){ this._m.delete(k); },
    keys(){ return [...this._m.keys()]; },
  },
};

const Store = (() => {
  /* Order matters and is deliberate. idb first because it is the durable one
     with room to grow; local next because it works everywhere including
     file:// and private windows where IndexedDB is refused; memory last so the
     app still runs in a locked-down browser and says so. */
  const driver =
    StoreDrivers.idb.available()   ? StoreDrivers.idb   :
    StoreDrivers.local.available() ? StoreDrivers.local : StoreDrivers.memory;
  const listeners = new Set();
  let lastError = null;
  let hydrating = null;
  let migratedFrom = null;

  /* ---------- moving an existing student onto IndexedDB ----------
     This is the highest-stakes code in the app: on the other side of it is a
     student's entire record. Three rules, and the third is the one people skip:

       1. copy, never move
       2. verify the copy by reading it back and comparing the bytes
       3. do not delete the source — not in this release, not in the next one

     A migration that deletes on the strength of a successful write is a
     migration that trusts a write it has not read. localStorage keeps its copy;
     it costs 6 KB and it is the difference between a bad release and a lost
     term of work. */
  const MIGRATED_KEY = "ascend.migrated.from.local";

  async function migrateFromLocal(){
    if(driver !== StoreDrivers.idb) return null;
    if(driver.get(MIGRATED_KEY)) return "already";
    if(!StoreDrivers.local.available()) return null;

    let keys = [];
    try{ keys = StoreDrivers.local.keys().filter(k => k.startsWith("system.") || k.startsWith("ascend.")); }
    catch(e){ return null; }
    if(!keys.length) return null;

    /* Anything already in IndexedDB wins. Arriving here with both populated
       means a rollback happened, and overwriting the newer copy with the older
       one is the worst available outcome. */
    const collisions = keys.filter(k => driver.get(k) != null);
    if(collisions.length) return "skipped-existing";

    for(const k of keys) driver.set(k, StoreDrivers.local.get(k));
    driver.set(MIGRATED_KEY, new Date().toISOString());
    await driver.flush();

    /* Rule 2: read the written bytes back out of IndexedDB itself, not out of
       the cache that was just written from — comparing a value to itself proves
       nothing. */
    const written = await driver.hydrate();
    for(const k of keys){
      if(driver.get(k) !== StoreDrivers.local.get(k)){
        driver.del(MIGRATED_KEY);
        await driver.flush();
        throw new Error("migration verification failed for " + k);
      }
    }
    void written;
    return "migrated:" + keys.length;
  }

  /* Idempotent: every caller gets the same promise, so a second await during
     boot costs nothing and cannot start a second migration. */
  function hydrate(){
    if(hydrating) return hydrating;
    hydrating = (async () => {
      if(driver !== StoreDrivers.idb) return { driver: driver.name, keys: driver.keys().length };
      try{
        await driver.hydrate();
        migratedFrom = await migrateFromLocal();
        return { driver: driver.name, keys: driver.keys().length, migratedFrom };
      }catch(e){
        /* IndexedDB refused. Fall back rather than boot an empty app: Safari in
           a private window and some school-managed browsers do exactly this. */
        lastError = e;
        return { driver: driver.name, keys: 0, error: e.message, fellBack: true };
      }
    })();
    return hydrating;
  }

  function readJSON(key){
    try{
      const raw = driver.get(key);
      return raw == null ? null : JSON.parse(raw);
    }catch(e){ lastError = e; return null; }
  }

  function writeJSON(key, value){
    try{
      driver.set(key, JSON.stringify(value));
      lastError = null;
      listeners.forEach(fn => { try{ fn(key, value); }catch(e){} });
      return { ok:true };
    }catch(e){
      lastError = e;
      return { ok:false, error:e };
    }
  }

  /* ---------- migrations ----------
     Each entry takes a record at version n and returns it at n+1. They run in
     order on load and must be safe to run on a record that already looks modern —
     a half-applied migration from an interrupted session must not corrupt data.
     Nothing here deletes a field. v14 only adds. */
  const MIGRATIONS = {
    1: rec => {
      /* v14: every hunter gains an intelligence container and a focus log.
         Both are optional everywhere they are read, so a record that skips this
         migration still works — it just has no history to reason over. */
      for(const h of Object.values(rec.hunters || {})){
        if(!h.brain) h.brain = { decisions:[], snoozed:{}, recovery:null, lastBrief:null, lastReview:null };
        if(!h.focusLog) h.focusLog = {};
        if(Array.isArray(h.goals)){
          for(const g of h.goals){
            if(!g.horizon) g.horizon = "month";   /* the only sane default for an undated goal */
            if(!("due" in g)) g.due = null;
            if(!("parent" in g)) g.parent = null;
          }
        }
      }
      return rec;
    },
    2: rec => {
      /* v14 Phase 5: the Academy container. Empty is a valid state — a hunter who
         never opens the Academy is unaffected by its existence. */
      for(const h of Object.values(rec.hunters || {})){
        if(!h.academy) h.academy = {
          qualification: h.curriculum || "",
          subjects:[], questions:[], cards:[], errors:[], sessions:[], exams:[], grades:[],
        };
      }
      return rec;
    },
    3: rec => {
      /* v14 Phases 6–9. Every container is optional at read time, so a hunter who
         never opens these sections carries three empty objects and nothing else
         changes for them. */
      for(const h of Object.values(rec.hunters || {})){
        if(!h.cloud) h.cloud = { mode:"local", account:null, token:null, queue:[], rev:0, serverRev:0,
          lastSync:null, lastError:null,
          settings:{ auto:true, wifiOnly:false, include:{ progress:true, academy:true, projects:true } } };
        if(!h.opportunities) h.opportunities = { items:[], activities:[], challenges:[], ignored:[] };
        if(!h.projects) h.projects = { items:[], portfolio:{ about:"", headline:"", sections:[], theme:"minimal", visibility:"private" } };
        if(!h.apiCfg) h.apiCfg = { proxyBase:"", keys:{} };
      }
      return rec;
    },
    4: rec => {
      /* v14 Phases 15–18. One container, and prefs for region and data saver.
         A hunter who never opens Circle or Studio carries an empty object. */
      for(const h of Object.values(rec.hunters || {})){
        if(!h.circle) h.circle = { groups:[], pacts:[], reports:[] };
        if(!h.prefs) h.prefs = {};
      }
      return rec;
    },
    5: rec => {
      /* v18: the student graph. A quest may carry an optional `link` naming the
         goal step, topic, project or milestone it serves. There is nothing to
         backfill — a v17 quest has no link and behaves exactly as it did — so
         this only discards a malformed value rather than inventing one. Guessing
         which goal an existing quest "really" belonged to would be fabrication,
         and a wrong link silently ticks off work the student never did. */
      for(const h of Object.values(rec.hunters || {})){
        if(!Array.isArray(h.quests)) continue;
        for(const q of h.quests) if(q.link && typeof q.link !== "object") delete q.link;
      }
      return rec;
    },
  };

  function migrate(rec){
    if(!rec || typeof rec !== "object") return rec;
    let v = Number(rec.schema) || 1;
    while(v < SCHEMA && MIGRATIONS[v]){
      try{ rec = MIGRATIONS[v](rec) || rec; }catch(e){ break; }
      v++;
    }
    rec.schema = Math.max(v, Number(rec.schema) || 1);
    return rec;
  }

  /* A killed tab loses whatever has not flushed. This does not close the window
     — nothing synchronous can, once the backend is asynchronous — but it turns
     the common case (switching apps, closing a tab) into a flushed one. */
  if(typeof addEventListener === "function" && driver === StoreDrivers.idb){
    addEventListener("pagehide", () => { try{ driver.flush(); }catch(e){} });
    addEventListener("visibilitychange", () => {
      try{ if(document.visibilityState === "hidden") driver.flush(); }catch(e){}
    });
  }
  if(driver === StoreDrivers.idb){
    driver._onError = e => {
      lastError = e;
      if(typeof toast === "function") toast("Could not save", "Your work is still on screen. ASCEND will keep retrying.", "blood");
    };
  }

  return {
    get driver(){ return driver.name; },
    get durable(){ return driver.name !== "memory"; },
    get lastError(){ return lastError; },
    get ready(){ return driver !== StoreDrivers.idb || driver._hydrated; },
    get migratedFrom(){ return migratedFrom; },
    hydrate,
    flush: () => (driver === StoreDrivers.idb ? driver.flush() : Promise.resolve()),
    readJSON, writeJSON, migrate,
    remove: k => { try{ driver.del(k); }catch(e){} },
    keys: () => { try{ return driver.keys(); }catch(e){ return []; } },
    subscribe(fn){ listeners.add(fn); return () => listeners.delete(fn); },
    /* rough usage figure for Settings — localStorage has no quota API */
    bytes(){
      try{ return driver.keys().reduce((n,k) => n + (driver.get(k) || "").length + k.length, 0); }
      catch(e){ return 0; }
    },
  };
})();

export { SCHEMA, StoreDrivers, Store };
