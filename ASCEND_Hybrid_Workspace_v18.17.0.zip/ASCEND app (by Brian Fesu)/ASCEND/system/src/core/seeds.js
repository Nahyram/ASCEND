import { todayKey } from "./kernel.js";

/* ASCEND — core/seeds.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- the timetable, as shipped ---------- */
const WD = [1,2,3,4,5]; // Mon..Fri
const ALLD = [0,1,2,3,4,5,6]; // every day, weekends included
function founderSeed(){
  const q = (time,name,cat,days,mand=false,xp=null) => ({id:uid(),time,name,cat,days,mand,xp: xp ?? (mand?25:15)});
  return [
    q("06:00","Wake Up — the grind claims the morning","discipline",ALLD,true,30),
    q("06:20","Exercise — a founder needs a body that keeps up","body",ALLD,false,20),
    q("10:00","Deep Build — weekend product sprint (2 hrs)","mind",[0,6],false,35),
    q("16:00","Learn — programming · AI · marketing (1 hr)","mind",ALLD,true,25),
    q("17:15","Build — create or improve one product (1 hr)","mind",ALLD,true,30),
    q("18:30","Share — post one useful thing online (30 min)","discipline",ALLD,true,20),
    q("19:15","Listen — talk to or observe one student customer","mind",[2,4,6],false,20),
    q("20:30","Ship Log — journal what moved the business today","discipline",ALLD,false,15),
    q("21:45","Bedtime — founders who sleep outbuild founders who don't","rest",ALLD,true,20),
  ];
}
function founderDeadlines(){
  const dl = (name,inDays,weight) => { const d = new Date(); d.setDate(d.getDate()+inDays); return {id:uid(), name, date:todayKey(d), weight:String(weight)}; };
  return [
    dl("Foundation: brand name chosen",3,2),
    dl("Foundation: mission written in one sentence",3,2),
    dl("Foundation: target customer defined",5,2),
    dl("Foundation: product ladder mapped (free → paid → premium)",7,3),
    dl("Foundation: content strategy — one channel picked",9,2),
    dl("Foundation: sales system — payment link live",12,3),
    dl("Foundation: growth system — weekly review slot set",14,1),
    dl("90-Day: tools mastered — AI chat · Canva · Docs",14,1),
    dl("90-Day: store live (Selar / Payhip / Gumroad) with adult payout set up",21,3),
    dl("90-Day: first 10 products listed",28,3),
    dl("90-Day: Exam Success Bundle launched",45,2),
    dl("90-Day: catalog at 25 quality products",60,2),
    dl("90-Day: 12 short videos posted (TikTok / Shorts / Reels)",75,2),
    dl("90-Day: first 10 sales — review what worked",90,3),
  ];
}
const CURRICULA = {
  igcse: { label:"IGCSE",
    a:["Extended Math","Add Math","Physics","ICT","Extended Math"],
    b:["English Language","French","Business","English Language","French"],
    c:["Physics","ICT","Extended Math","Add Math","Business"],
    revise:"Revise / Past Papers / Notes" },
  gcse: { label:"GCSE",
    a:["GCSE Maths","GCSE English Language","GCSE Sciences","GCSE Maths","GCSE Sciences"],
    b:["GCSE English Literature","GCSE Sciences","GCSE Maths","GCSE Option Subject","GCSE English Language"],
    c:["GCSE Option Subject","GCSE Option Subject","GCSE English Literature","GCSE Sciences","GCSE Maths — Past Papers"],
    revise:"GCSE past papers & mark schemes" },
  alevel: { label:"A-Level",
    a:["A-Level Subject 1 — New Topic","A-Level Subject 2 — New Topic","A-Level Subject 3 — New Topic","A-Level Subject 1 — New Topic","A-Level Subject 2 — New Topic"],
    b:["A-Level Subject 2 — Notes & Flashcards","A-Level Subject 3 — Notes & Flashcards","A-Level Subject 1 — Notes & Flashcards","A-Level Subject 2 — Notes & Flashcards","A-Level Subject 3 — Notes & Flashcards"],
    c:["A-Level Subject 3 — Past Questions","A-Level Subject 1 — Past Questions","A-Level Subject 2 — Past Questions","A-Level Subject 3 — Past Questions","A-Level Subject 1 — Past Questions"],
    revise:"A-Level past papers & mark schemes" },
  wassce: { label:"WASSCE",
    a:["Core Mathematics","Integrated Science","Core Mathematics","Elective 1","Integrated Science"],
    b:["English Language","Elective 1","Elective 2","English Language","Elective 2"],
    c:["Social Studies","Elective 3","Elective 1 — Past Questions","Elective 3","Core Maths — Past Questions"],
    revise:"WASSCE past questions (WAEC)" },
  sat: { label:"SAT",
    a:["SAT Math — Algebra & Problem Solving","SAT Reading & Writing Drills","SAT Math — Advanced Topics","SAT Reading & Writing Drills","SAT Math — Timed Section"],
    b:["SAT Vocabulary & Grammar Rules","SAT Math Practice Set","SAT Reading Passages","SAT Math Practice Set","SAT Writing — Rhetoric Questions"],
    c:["SAT Timed Practice Section","Error Log Review","SAT Timed Practice Section","Error Log Review","Full-Length Practice Block"],
    revise:"Review error log & flashcards" },
  ib: { label:"IB Diploma",
    a:["IB HL Subject 1","IB HL Subject 2","IB HL Subject 3","IB HL Subject 1","IB HL Subject 2"],
    b:["IB SL Subject 4","IB SL Subject 5","IB SL Subject 6","IB SL Subject 4","IB SL Subject 5"],
    c:["TOK / Extended Essay Work","IB HL Subject 3","Internal Assessment Work","IB SL Subject 6","TOK / Extended Essay Work"],
    revise:"IB past papers & IA/EE progress" },
  custom: { label:"Custom",
    a:["Study Block 1 — Your Subject","Study Block 1 — Your Subject","Study Block 1 — Your Subject","Study Block 1 — Your Subject","Study Block 1 — Your Subject"],
    b:["Study Block 2 — Your Subject","Study Block 2 — Your Subject","Study Block 2 — Your Subject","Study Block 2 — Your Subject","Study Block 2 — Your Subject"],
    c:["Study Block 3 — Your Subject","Study Block 3 — Your Subject","Study Block 3 — Your Subject","Study Block 3 — Your Subject","Study Block 3 — Your Subject"],
    revise:"Revise / past questions / notes" },
};
function seedQuests(cur){
  const C = CURRICULA[cur] || CURRICULA.igcse;
  const q = (time,name,cat,days,mand=false,xp=null) => ({id:uid(),time,name,cat,days,mand,xp: xp ?? (mand?25:15)});
  const out = [
    q("05:20","Wake Up — time to level up","discipline",WD,true,30),
    q("05:50","Wash Car","discipline",[1,2,4,5],false,10),
    q("05:50","Speech Writing & Oratory","mind",[3],false,20),
    q("07:00","Cleaning","discipline",WD,false,10),
    q("08:45","Exercise / Martial Arts","body",WD,true,25),
    q("09:05","Cold Bath (cold focus)","body",WD,false,15),
  ];
  [["09:30",C.a],["11:30",C.b],["12:45",C.c]].forEach(([time,names],si)=>{
    names.forEach((name,i)=> out.push(q(time,name,"study",[i+1],true,25)));
    if(si===0) out.push(q("10:45","Breakfast","rest",WD,false,5));
    if(si===1) out.push(q("12:30","Break","rest",WD,false,5));
  });
  out.push(
    q("13:45",C.revise,"study",WD,true,25),
    q("14:00","Learn Japanese","mind",WD,false,20),
    q("14:45","Programming & Robotics","mind",WD,false,20),
    q("15:30","Chess Practice","mind",WD,false,15),
    q("16:15","Piano Practice","mind",WD,false,15),
    q("17:00","Exercise / Martial Arts","body",WD,true,25),
    q("18:00","Hot Bath","rest",WD,false,5),
    q("18:30","Dinner","rest",WD,false,5),
    q("19:15","Deep Study / Weak Areas","study",WD,true,30),
    q("20:00","Read / Documentaries / Self-Improvement","mind",WD,false,15),
    q("20:45","Plan Tomorrow / Journal / Reflection","discipline",WD,true,20),
    q("21:30","Bedtime — rest to perform best","rest",WD,true,20)
  );
  return out;
}
function uid(){ return Math.random().toString(36).slice(2,9); }


export { WD, ALLD, founderSeed, founderDeadlines, CURRICULA, seedQuests, uid };
