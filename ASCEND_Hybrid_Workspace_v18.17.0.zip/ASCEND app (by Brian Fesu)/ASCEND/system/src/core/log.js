/* ASCEND — core/log.js
   The append-only event log, on the client.

   ## What this is for

   Everything the student does that changes progression gets recorded here as a
   fact, in order, and state is derived by replaying it. The log is the record;
   the hunter's `level` field becomes a cache of it.

   In 18.10 that is deliberately still a claim under test rather than the truth:
   events are emitted alongside the existing writes and replayed in parallel, and
   the two are compared. Flipping authority before the comparison agrees over a
   year of real usage would be the same mistake as 18.6's server — complete,
   plausible, never actually run against the thing it replaces.

   ## Per-hunter keys

   This is also the first thing in ASCEND that does not live inside the one giant
   `system.v1` blob. Each hunter's log is its own Store key, so appending an event
   rewrites the log rather than the entire record. That is the beginning of the
   fix for all-or-nothing writes; the rest of the record follows once the domains
   move across.

   ## Sequence numbers

   `seq` is per device and monotonic, and it is persisted with the log rather than
   derived from its length. Deriving it from length would restart numbering after
   a compaction and mint duplicate ids for genuinely different events — and since
   dedupe is by id, the second one would be silently dropped. That is invisible
   lost XP, which is the worst kind. */

import { makeEvent, canonical, merge, isEvent, EVENT_TYPES, LOG_VERSION } from "../../../shared/events.js";
import { replayProgression, compareProgression, INITIAL } from "../../../shared/domain/progression.js";

const LOG_KEY = id => "ascend.log.v1." + id;

/* Compaction keeps the log bounded. A student clearing eight quests a day for
   three years is roughly 9,000 events; well within reach, but there is no reason
   to replay all of it on every boot. Above the threshold the oldest events are
   folded into the snapshot and dropped. */
const COMPACT_ABOVE = 2000;
const KEEP_AFTER_COMPACT = 500;

function emptyLog(device) {
  return { v: LOG_VERSION, device, seq: 0, base: { ...INITIAL }, events: [], acked: 0 };
}

const Log = (() => {
  let cache = null;      /* { hunterId, log } — one hunter is active at a time */

  /* The device id identifies which device wrote an event, and is the tie-break
     in canonical ordering. It is stable per install and carries nothing about
     the student: no name, no account, nothing that leaves with a sync payload
     that a school administrator might read. */
  function deviceId() {
    try {
      if (typeof DB !== "undefined" && DB && DB.installId) return String(DB.installId).slice(0, 12);
    } catch (e) { /* kernel may not have loaded yet */ }
    return "unknown";
  }

  function load(hunterId) {
    if (cache && cache.hunterId === hunterId) return cache.log;
    let log = null;
    try {
      if (typeof Store !== "undefined") log = Store.readJSON(LOG_KEY(hunterId));
    } catch (e) { log = null; }
    if (!log || !Array.isArray(log.events)) log = emptyLog(deviceId());
    if (!log.device) log.device = deviceId();
    if (!log.base) log.base = { ...INITIAL };
    log.seq = Number.isInteger(log.seq) ? log.seq : log.events.length;
    log.acked = Number.isInteger(log.acked) ? log.acked : 0;
    cache = { hunterId, log };
    return log;
  }

  function persist(hunterId, log) {
    try { if (typeof Store !== "undefined") Store.writeJSON(LOG_KEY(hunterId), log); }
    catch (e) { /* the store already reports its own failures */ }
  }

  function activeId() {
    try { return (typeof DB !== "undefined" && DB && DB.active) || null; } catch (e) { return null; }
  }

  /* Compaction may never drop an event the server has not acknowledged.

     Without this the sequence is: the phone works offline for a term, compacts,
     folds 1,800 events into a snapshot, then syncs — and the server, which never
     saw those events, replays a total far lower than the student's. The server
     would then look like it was taking XP away. `acked` is the count of events
     confirmed stored server-side, so compaction can only fold what is safely
     somewhere else. A log that cannot compact grows; a log that compacts too
     eagerly loses a year. */
  function compact(log) {
    if (log.events.length <= COMPACT_ABOVE) return log;
    const sorted = canonical(log.events);
    const wanted = sorted.length - KEEP_AFTER_COMPACT;
    const cut = Math.min(wanted, log.acked || 0);
    if (cut <= 0) { log.events = sorted; return log; }
    log.base = replayProgression(sorted.slice(0, cut), log.base);
    log.events = sorted.slice(cut);
    log.acked = Math.max(0, (log.acked || 0) - cut);
    return log;
  }

  return {
    /* Records a fact. `now` is injectable so tests can build a history without
       sleeping, and so a replay never depends on when it happened to run. */
    append(type, data, now) {
      const hunterId = activeId();
      if (!hunterId) return null;
      const log = load(hunterId);
      const ts = Number.isFinite(now) ? now : Date.now();
      let ev;
      try { ev = makeEvent({ type, data, ts, device: log.device, seq: log.seq }); }
      catch (e) { return null; }          /* a malformed event is dropped, never stored */
      log.seq += 1;
      log.events.push(ev);
      compact(log);
      persist(hunterId, log);
      return ev;
    },

    events(hunterId) {
      const id = hunterId || activeId();
      return id ? canonical(load(id).events) : [];
    },

    base(hunterId) {
      const id = hunterId || activeId();
      return id ? load(id).base : { ...INITIAL };
    },

    /* Progression as the log says it is, regardless of what the record claims. */
    progression(hunterId) {
      const id = hunterId || activeId();
      if (!id) return { ...INITIAL };
      const log = load(id);
      return replayProgression(canonical(log.events), log.base);
    },

    /* Shadow mode: what the record says versus what the log says. Surfaced, never
       auto-corrected — a mismatch is a bug to find, not a number to overwrite. */
    audit(hunterId) {
      const id = hunterId || activeId();
      if (!id) return null;
      let live = null;
      try { live = (typeof DB !== "undefined" && DB.hunters) ? DB.hunters[id] : null; } catch (e) { live = null; }
      if (!live) return null;
      const replayed = this.progression(id);
      return { ...compareProgression(live, replayed), replayed, events: load(id).events.length };
    },

    /* Merging another device's events. Ids are device+seq, so a retried sync or a
       restored backup collapses instead of double-counting. */
    absorb(hunterId, incoming) {
      const id = hunterId || activeId();
      if (!id) return 0;
      const log = load(id);
      const before = log.events.length;
      log.events = merge(log.events, (incoming || []).filter(isEvent));
      compact(log);
      persist(id, log);
      return log.events.length - before;
    },

    /* For sync and export. */
    export(hunterId) {
      const id = hunterId || activeId();
      if (!id) return null;
      const log = load(id);
      return { v: log.v, device: log.device, base: log.base, events: canonical(log.events) };
    },

    /* Called after the server confirms it stored a batch. Counts, not ids: the
       log is canonically ordered and the server is given it in that order, so
       "the first N are safely stored" is exact. */
    acknowledge(hunterId, count) {
      const id = hunterId || activeId();
      if (!id) return 0;
      const log = load(id);
      log.acked = Math.max(log.acked || 0, Math.min(Number(count) || 0, log.events.length));
      persist(id, log);
      return log.acked;
    },

    acked(hunterId) {
      const id = hunterId || activeId();
      return id ? (load(id).acked || 0) : 0;
    },

    _reset() { cache = null; },
    TYPES: EVENT_TYPES,
  };
})();

export { Log, LOG_KEY };
