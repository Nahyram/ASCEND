/* ASCEND — core/bus.js
   The seam the audit said was missing.

   v17 had exactly one cross-subsystem write in the entire codebase: class work
   became deadlines in community.js. Everything else was an island. Clearing a
   quest moved XP and nothing else; six wrong answers moved mastery and nothing
   else; a finished milestone moved a project bar and nothing else. The engines
   were built well and wired to nothing.

   The fix is not a rewrite. It is one place where a subsystem can say what just
   happened, and other subsystems can decide whether they care. Producers do not
   know their consumers. A consumer that throws does not take down the producer —
   a broken analytics listener must never stop a quest from being cleared.

   Contract, deliberately small:
     Bus.emit(type, payload)  → { type, payload, at, handled } — fires listeners
     Bus.on(type, fn)         → unsubscribe function
     Bus.onAny(fn)            → unsubscribe; fn(event) for every event
     Bus.recent(n)            → the last n events, for tests and the log
     Bus.types                → the frozen event vocabulary

   Ordering is registration order, synchronous, and depth-limited. Synchronous
   because a quest completion must be fully written before renderAll() reads the
   record back; depth-limited because a consumer that emits into its own producer
   is a bug, and an infinite loop is a worse way to find out than a console
   warning. */

const SYSTEM_EVENTS = Object.freeze({
  GOAL_CREATED:         "GOAL_CREATED",
  GOAL_COMPLETED:       "GOAL_COMPLETED",
  GOAL_STEP_DONE:       "GOAL_STEP_DONE",
  QUEST_CREATED:        "QUEST_CREATED",
  QUEST_COMPLETED:      "QUEST_COMPLETED",
  QUEST_UNCLEARED:      "QUEST_UNCLEARED",
  QUEST_MISSED:         "QUEST_MISSED",
  MASTERY_CHANGED:      "MASTERY_CHANGED",
  ERROR_LOGGED:         "ERROR_LOGGED",
  ERROR_RESOLVED:       "ERROR_RESOLVED",
  MILESTONE_COMPLETED:  "MILESTONE_COMPLETED",
  PROJECT_COMPLETED:    "PROJECT_COMPLETED",
  EVIDENCE_ADDED:       "EVIDENCE_ADDED",
  DEADLINE_APPROACHING: "DEADLINE_APPROACHING",
  OPPORTUNITY_MATCHED:  "OPPORTUNITY_MATCHED",
  APPLICATION_UPDATED:  "APPLICATION_UPDATED",
  STREAK_CHANGED:       "STREAK_CHANGED",
  RECOVERY_STARTED:     "RECOVERY_STARTED",
});

const Bus = (() => {
  const listeners = new Map();   /* type -> [fn] */
  const anyList = [];
  const log = [];
  const MAX_LOG = 60;
  const MAX_DEPTH = 6;
  let depth = 0;

  function on(type, fn){
    if(typeof fn !== "function") return () => {};
    if(!listeners.has(type)) listeners.set(type, []);
    const arr = listeners.get(type);
    arr.push(fn);
    return () => { const i = arr.indexOf(fn); if(i >= 0) arr.splice(i, 1); };
  }

  function onAny(fn){
    if(typeof fn !== "function") return () => {};
    anyList.push(fn);
    return () => { const i = anyList.indexOf(fn); if(i >= 0) anyList.splice(i, 1); };
  }

  function emit(type, payload = {}){
    const ev = { type, payload, at: Date.now(), handled: 0, errors: [] };
    /* A consumer emitting back into its own producer is a defect. Refusing at a
       depth limit turns a hung tab into one console line naming the chain. */
    if(depth >= MAX_DEPTH){
      ev.errors.push("depth limit — refused, possible event cycle on " + type);
      if(typeof console !== "undefined") console.warn("[bus] cycle refused at " + type);
      return ev;
    }
    depth++;
    try{
      for(const fn of (listeners.get(type) || []).slice()){
        try{ fn(payload, ev); ev.handled++; }
        catch(e){ ev.errors.push(type + ": " + (e && e.message)); }
      }
      for(const fn of anyList.slice()){
        try{ fn(ev); }catch(e){ ev.errors.push("any: " + (e && e.message)); }
      }
    } finally { depth--; }
    log.push({ type, at: ev.at, handled: ev.handled, keys: Object.keys(payload || {}) });
    if(log.length > MAX_LOG) log.shift();
    return ev;
  }

  return {
    emit, on, onAny,
    get types(){ return SYSTEM_EVENTS; },
    recent(n = 20){ return log.slice(-n); },
    /* test seam only — never called by the app */
    _reset(){ listeners.clear(); anyList.length = 0; log.length = 0; depth = 0; },
    _count(type){ return (listeners.get(type) || []).length; },
  };
})();

export { SYSTEM_EVENTS, Bus };
