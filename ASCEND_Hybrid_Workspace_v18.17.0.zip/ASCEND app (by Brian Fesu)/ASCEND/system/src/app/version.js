/* ASCEND — app/version.js
   The release identity, in one place.

   Before this file the version lived in three places that disagreed: sw.js
   named its cache "system-v17" in a v18 build, sw.js's own header comment said
   v14, and package.json did not exist. A cache name that does not change
   between releases is not a cosmetic problem — it is the cache-invalidation
   strategy, and a stale one serves last release's JavaScript to a student who
   has already downloaded this one.

   sw.js repeats the version as a literal rather than importScripts()-ing this
   file. That is deliberate. importScripts() would make the service worker fail
   to install if this file ever moved, and a service worker that fails to
   install takes offline with it — the one thing this product cannot lose. The
   duplication is instead held true by a check in offline-test.js that reads
   package.json, this file and sw.js and fails if any of the three disagree.
   Drift is caught by a command, not by a user. */

const SYSTEM_VERSION = "18.17.0";

/* The cache name. Changing the version changes this string, which is what makes
   the activate handler in sw.js delete the previous release's cache. */
const SYSTEM_CACHE = "system-v" + SYSTEM_VERSION;

/* Schema is versioned separately and on purpose: a patch release must not look
   like a migration, and a migration must not require a new cache. */
const SYSTEM_SCHEMA = 6;

function systemBuild() {
  return { version: SYSTEM_VERSION, cache: SYSTEM_CACHE, schema: SYSTEM_SCHEMA };
}

export { SYSTEM_VERSION, SYSTEM_CACHE, SYSTEM_SCHEMA, systemBuild };
