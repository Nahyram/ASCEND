/* ASCEND — app/theme.js */

const THEMES = ["void","abyss","day","system"];

function applyTheme(t){
  let use = t;
  if(t === "system") use = matchMedia("(prefers-color-scheme: light)").matches ? "day" : "void";
  document.documentElement.setAttribute("data-theme", use);
  const meta = document.querySelector('meta[name="theme-color"]');
  if(meta) meta.setAttribute("content", use === "day" ? "#eef3f9" : use === "abyss" ? "#000000" : "#05070d");
}

function currentTheme(){
  try{ const t = localStorage.getItem("system.theme"); if(THEMES.includes(t)) return t; }catch(e){}
  return "void";
}

function setTheme(t){
  if(!THEMES.includes(t)) return;
  try{ localStorage.setItem("system.theme", t); }catch(e){}
  applyTheme(t);
}

applyTheme(currentTheme());
matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => {
  if(currentTheme() === "system") applyTheme("system");
});

document.addEventListener("DOMContentLoaded", () => {
  const sel = document.getElementById("setTheme");
  if(sel){ sel.value = currentTheme(); sel.onchange = () => setTheme(sel.value); }
});

export { THEMES, applyTheme, currentTheme, setTheme };
