import { $ } from "../core/kernel.js";

/* ASCEND — views/wall.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ v8: MOTIVATION WALL — carousel ══════════════ */
/* v18: four of these six were third-party — an anime screenshot and two quote
   cards carrying another page's logo. The README had warned since v5 to strip
   them before distributing, which made every build unsellable until someone
   remembered. A warning in a README is not a control. They are now original
   typographic cards generated for this product, so the whole assets folder ships
   as-is. brand-poster and brand-logo are the hunter's own artwork and are kept. */
const WALL = [
  ["assets/brand-poster.jpg","THE SYSTEM — study smart. stay ahead. succeed."],
  ["assets/brand-logo.jpg","The mark of the System"],
  ["assets/quest-window.jpg","Train. Study. Show up again."],
  ["assets/art-hunter.jpg","You are the sum of what you finish."],
  ["assets/quote-focus.jpg","Levelling up costs separation and focus."],
  ["assets/quote-never-give-up.jpg","Everyone who made it failed first."],
];
let wallI = 0, wallTimer = null;
function renderWall(){
  if(!$("#wallImg")) return;
  const [srcp, cap] = WALL[wallI];
  const img = $("#wallImg"), miss = $("#wallMissing");
  img.onerror = () => {
    miss.innerHTML = "Image not found<br><b>" + srcp + "</b><br>The assets folder must sit next to index.html. Updating a Netlify site? Drag the whole folder \u2014 a drop replaces everything.";
    miss.classList.remove("hidden"); $("#wallCap").classList.add("hidden");
  };
  img.onload = () => { miss.classList.add("hidden"); $("#wallCap").classList.remove("hidden"); };
  img.src = srcp; img.alt = cap;
  $("#wallCap").textContent = cap;
  const dots = $("#wallDots"); dots.innerHTML = "";
  WALL.forEach((_,i) => {
    const d = document.createElement("i");
    if(i===wallI) d.className = "on";
    d.onclick = () => { wallI = i; renderWall(); wallAuto(); };
    dots.appendChild(d);
  });
}
function wallStep(n){ wallI = (wallI + n + WALL.length) % WALL.length; renderWall(); wallAuto(); }
/* The original checked #tab-train, a tab removed in v13, so it threw on a null
   every 8 seconds. app/router.js had quietly replaced it by loading later —
   which fixed the symptom by accident and left two definitions of the same
   function in the codebase. Fixed here instead, where the carousel actually is. */
function wallAuto(){
  clearInterval(wallTimer);
  wallTimer = setInterval(() => {
    const pane = $('[data-pane="tr-wall"]');
    if(document.hidden || !pane || pane.classList.contains("hidden")) return;
    wallI = (wallI + 1) % WALL.length; renderWall();
  }, 8000);
}
/* Guarded, and the guard is not defensive padding — it is required now.

   As a classic script this file ran after the markup and these elements always
   existed. Bundled, it is a module: if it throws while the bundle is
   initialising, EVERY other module in the bundle dies with it, including the
   bridge that publishes $, H, save and DB to the 72 classic scripts. One view
   touching a missing element would take the whole app down.

   That is the real cost of bundling, and module-check.js now fails any module
   under src/views/ that reaches for the DOM at import time. */
function wireWall(){
  const prev = $("#wallPrev"), next = $("#wallNext"), img = $("#wallImg");
  if(prev) prev.onclick = () => wallStep(-1);
  if(next) next.onclick = () => wallStep(1);
  if(img) img.onclick = () => {
    const pic = $("#imgModalPic"), modal = $("#imgModal");
    if(!pic || !modal) return;
    pic.src = img.src; pic.alt = img.alt;
    modal.classList.remove("hidden");
  };
  wallAuto();
}
wireWall();


export { WALL, renderWall, wallStep, wallAuto, wireWall };
