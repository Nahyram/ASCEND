/* ══════════════════════════════════════════════════════════════════
   THE SYSTEM — v11 DATA PACK
   New screen genres (television-first, since the old Screen leaned on
   films and anime) plus top-ups for shelves that were thin.

   These are real titles. The shelves grow past this point through the
   Online Gate, which pulls from public catalogues — see online.js.
   ══════════════════════════════════════════════════════════════════ */

/* ── brand-new screen genres ── */
const NEW_SCREEN_V11 = {
  s_drama:{ label:"TV — Drama", picks:[
    ["Breaking Bad","series","A chemistry teacher's slow ruin. Watch what ambition without values does."],
    ["The Wire","series","Institutions, not villains. The most honest show about how systems fail."],
    ["Mad Men","series","Ambition, reinvention and the cost of the mask."],
    ["This Is Us","series","Family across three timelines. Bring tissues."],
    ["Succession","series","Power inside a family business. Brutal and very funny."],
    ["The Crown","series","Duty versus self, one decade at a time."],
    ["Friday Night Lights","series","Small-town pressure and one very good coach."],
    ["Six Feet Under","series","A family of undertakers on how to actually live."],
    ["The Sopranos","series","The show that made television serious."],
    ["Rectify","series","Quiet, slow, devastating. Patience pays."],
    ["Anne with an E","series","An orphan who refuses to be small."],
    ["When They See Us","series","Four episodes on the Central Park Five. Hard, necessary watching."],
    ["Blood & Water","series","Cape Town teen drama with real teeth."]]},

  s_thriller:{ label:"TV — Thriller & Suspense", picks:[
    ["Prison Break","series","One engineer, one blueprint, one absurd plan."],
    ["Money Heist","series","Preparation as a superpower."],
    ["Ozark","series","Every clever fix creates two new problems."],
    ["Homeland","series","Obsession and intelligence work."],
    ["Bodyguard","series","Six hours, no slack."],
    ["The Night Manager","series","Le Carré, beautifully filmed."],
    ["Behind Her Eyes","series","Do not read anything about it first."],
    ["You","series","A study in how charm hides rot."],
    ["Squid Game","series","Debt, desperation and the games people accept."],
    ["Dark","series","Time travel that actually holds together. Take notes."],
    ["The Fall","series","A procedural with unusual moral weight."],
    ["Broadchurch","series","Grief in a small town."]]},

  s_medical:{ label:"TV — Medical & Science", picks:[
    ["House M.D.","series","Differential diagnosis as detective work. Great for science students."],
    ["Grey's Anatomy","series","The long-running one. Start at season one."],
    ["The Good Doctor","series","Competence, prejudice and patience."],
    ["Scrubs","series","Funny, then unexpectedly moving."],
    ["ER","series","The show that set the template."],
    ["The Knick","series","Surgery in 1900. Not for the squeamish."],
    ["Chernobyl","series","What it costs when the truth is inconvenient. Five hours, unforgettable."],
    ["Cosmos: A Spacetime Odyssey","series","Sagan's baton, carried well."],
    ["Planet Earth II","series","The best-shot nature series ever made."],
    ["Our Planet","series","The same beauty, with the bill attached."],
    ["The Blue Planet","series","Two thirds of the world, filmed properly."],
    ["Life Story","series","Every animal's journey from birth to breeding."]]},

  s_legal:{ label:"TV — Law, Politics & Power", picks:[
    ["Suits","series","Ambition, mentorship and a fake law degree."],
    ["Better Call Saul","series","How a decent man talks himself into something else."],
    ["The Good Wife","series","Reinvention after public humiliation."],
    ["Damages","series","Law as bare-knuckle strategy."],
    ["The West Wing","series","Government at its most idealistic. Aspirational, not documentary."],
    ["Yes, Minister","series","How bureaucracies really behave. Still accurate."],
    ["Borgen","series","Danish coalition politics. Better than it sounds."],
    ["House of Cards","series","Ambition without a floor."],
    ["The Newsroom","series","Idealism about journalism, argued loudly."],
    ["Silk","series","The barrister's grind."],
    ["Making a Murderer","series","What due process looks like when it bends."],
    ["13th","film","Ava DuVernay on the prison system and the amendment behind it."]]},

  s_family:{ label:"TV — Family & Growing Up", picks:[
    ["Avatar: The Last Airbender","series","Mastery, humility and war, in a children's show. Genuinely great."],
    ["Stranger Things","series","Friendship as the actual superpower."],
    ["The Mandalorian","series","Duty, quietly."],
    ["Gilmore Girls","series","Fast talk, small town, big ambitions."],
    ["Malcolm in the Middle","series","Chaos, affection and no money."],
    ["Modern Family","series","Three households, one long joke."],
    ["Young Sheldon","series","Being the odd, clever one."],
    ["Never Have I Ever","series","Grief, ambition and being sixteen."],
    ["Heartstopper","series","Gentle, and rare for being gentle."],
    ["Sex Education","series","Frank, funny and kinder than its title suggests. Older teens."],
    ["The Queen's Gambit","series","Obsession, chess and getting back up."],
    ["Derry Girls","series","Teenagers being idiots during the Troubles."]]},

  s_history:{ label:"TV — History & Biography", picks:[
    ["Band of Brothers","series","Easy Company, from training to Germany."],
    ["The Pacific","series","The other theatre, no less brutal."],
    ["Vikings","series","Ambition on longships."],
    ["Rome","series","The republic falling, from the ranks up."],
    ["Peaky Blinders","series","Strategy, family and postwar Birmingham."],
    ["The Last Kingdom","series","Divided loyalties, well told."],
    ["Shogun","series","Feudal Japan and the cost of being useful."],
    ["Roots","series","Still the standard."],
    ["The Men Who Built America","series","Ruthless industrialists, honestly framed."],
    ["Africa's Great Civilisations","series","Gates on a history schools skip."],
    ["Apollo 11","film","Only archive footage. Somehow that makes it bigger."],
    ["The Century of the Self","series","Curtis on how desire got engineered."]]},

  s_espionage:{ label:"TV — Spies & Investigation", picks:[
    ["Slow Horses","series","Failed spies, dry as sand."],
    ["The Americans","series","A marriage as cover, and then not."],
    ["Killing Eve","series","Two obsessions circling."],
    ["Spooks","series","Fast, disposable, addictive."],
    ["Tinker Tailor Soldier Spy","film","Patience as tradecraft."],
    ["Mindhunter","series","The birth of criminal profiling."],
    ["Sherlock","series","Deduction as performance art."],
    ["True Detective","series","Season one especially."],
    ["Line of Duty","series","Interview scenes as blood sport."],
    ["Unbelievable","series","Two detectives who actually listen."],
    ["The Sinner","series","Why, not who."],
    ["Luther","series","London, and a man losing the line."]]},

  s_reality:{ label:"TV — Competition & Craft", picks:[
    ["MasterChef","series","Skill under a clock."],
    ["The Great British Bake Off","series","Kindness as a format."],
    ["Chef's Table","series","Obsession, plated. Every episode is a masterclass in mastery."],
    ["Abstract: The Art of Design","series","How designers actually think."],
    ["The Last Dance","series","Jordan's final season, and what winning costs."],
    ["Drive to Survive","series","Engineering, ego and margins."],
    ["Shark Tank","series","Pitching, valuation and rejection in public."],
    ["The Apprentice (UK)","series","Watch for the mistakes, not the winners."],
    ["Making the Cut","series","Design under commercial pressure."],
    ["Blown Away","series","Glassblowing. Unexpectedly gripping."],
    ["The Repair Shop","series","Craft, patience and small kindnesses."],
    ["Is It Cake?","series","Nonsense. Watch it after exams."]]}
};

/* ── top-ups for shelves that were thin ── */
const MORE_BOOKS_V11 = {
  study:[],
  discipline:[
    ["The 5 AM Club","Robin Sharma"],
    ["Make It Stick","Peter Brown, Henry Roediger & Mark McDaniel","How learning actually sticks. Read this before your next revision cycle."],
    ["A Mind for Numbers","Barbara Oakley","Written for people who think they're bad at maths."],
    ["Ultralearning","Scott Young","How he did MIT's CS curriculum in twelve months."],
    ["How to Become a Straight-A Student","Cal Newport"],
    ["Limitless","Jim Kwik"],
    ["The Bullet Journal Method","Ryder Carroll"],
    ["Four Thousand Weeks","Oliver Burkeman","The anti-productivity book. You will not get it all done."]],
  psychology:[
    ["Emotional Intelligence","Daniel Goleman"],
    ["Quiet","Susan Cain","For everyone told to speak up more."],
    ["Man's Search for Meaning","Viktor Frankl","Written by a survivor. Short, and it rearranges you."],
    ["The Body Keeps the Score","Bessel van der Kolk"],
    ["Predictably Irrational","Dan Ariely"],
    ["Nudge","Richard Thaler & Cass Sunstein"],
    ["Stumbling on Happiness","Daniel Gilbert"]],
  tech:[
    ["Automate the Boring Stuff with Python","Al Sweigart","Free online. Start here if you have never coded."],
    ["Python Crash Course","Eric Matthes"],
    ["Eloquent JavaScript","Marijn Haverbeke","Also free online."],
    ["Clean Code","Robert C. Martin"],
    ["The Pragmatic Programmer","Andrew Hunt & David Thomas"],
    ["Grokking Algorithms","Aditya Bhargava","Algorithms with pictures. Actually readable."],
    ["Code","Charles Petzold","How a computer works, from light switches up."]],
  african:[
    ["Things Fall Apart","Chinua Achebe"],
    ["Half of a Yellow Sun","Chimamanda Ngozi Adichie"],
    ["Purple Hibiscus","Chimamanda Ngozi Adichie"],
    ["Americanah","Chimamanda Ngozi Adichie"],
    ["The Beautyful Ones Are Not Yet Born","Ayi Kwei Armah","Ghana after independence, unsparing."],
    ["Changes: A Love Story","Ama Ata Aidoo"],
    ["Our Sister Killjoy","Ama Ata Aidoo"],
    ["Faceless","Amma Darko"],
    ["Homegoing","Yaa Gyasi","Two sisters, two continents, three hundred years."],
    ["Transcendent Kingdom","Yaa Gyasi"],
    ["The Housemaid","Amma Darko"],
    ["Nervous Conditions","Tsitsi Dangarembga"],
    ["A Grain of Wheat","Ngũgĩ wa Thiong'o"],
    ["So Long a Letter","Mariama Bâ"],
    ["The Palm-Wine Drinkard","Amos Tutuola"],
    ["Dear Ijeawele","Chimamanda Ngozi Adichie"]]
};

const MORE_SCREEN_V11 = {
  s_docs:[
    ["Free Solo","film","Preparation, fear and one wall."],
    ["Icarus","film","A cycling experiment that turns into a doping scandal."],
    ["My Octopus Teacher","film","Patience, filmed."],
    ["Jiro Dreams of Sushi","film","Sixty years on one skill."],
    ["The Social Dilemma","film","Watch it, then check your screen time."],
    ["Won't You Be My Neighbor?","film","On being kind, deliberately."],
    ["Searching for Sugar Man","film","An unbelievable true story, told carefully."],
    ["Man on Wire","film","Preparation as art."]],
  s_biz:[
    ["The Founder","film","How McDonald's was actually taken."],
    ["The Big Short","film","2008, explained with jokes."],
    ["Moneyball","film","Data beating instinct."],
    ["Steve Jobs","film","Three product launches, one difficult man."],
    ["The Playlist","series","Spotify from six points of view."],
    ["WeCrashed","series","Charisma without accounting."],
    ["The Dropout","series","Theranos, and how far a story can travel."],
    ["Super Pumped","series","Uber's growth-at-all-costs years."]]
};

export { NEW_SCREEN_V11, MORE_BOOKS_V11, MORE_SCREEN_V11 };
