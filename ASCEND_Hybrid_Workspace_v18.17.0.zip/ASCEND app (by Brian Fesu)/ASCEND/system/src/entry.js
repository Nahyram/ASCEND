/* ASCEND — system/src/entry.js
   The one entry point the bundler is given.

   ## What this file is for

   ASCEND is 89 classic scripts sharing one global scope, where load order *is*
   the dependency graph. That arrangement has produced six duplicate-global
   collisions and two load-order defects across this project's history, and the
   two static guards that catch them (arch-check, module-readiness) exist only
   because no compiler was enforcing anything.

   Converting all 89 at once would be the same mistake this codebase has already
   made twice: a large rebuild that reintroduces fixed bugs. So the conversion is
   leaf-first, and this file is the seam that lets converted and unconverted code
   coexist while it happens.

   ## How the seam works

   Everything imported here is a real ES module with explicit exports. The bundle
   is emitted as a classic script and loaded first, and then BRIDGE republishes
   each name on `window` so the 75 scripts that have not been converted yet can
   still resolve `BALANCE`, `Store`, `Hooks` and the rest as bare globals exactly
   as before.

   ## The bridge is temporary, and is meant to shrink

   Every name below is a module export being handed back to global scope, which
   is the thing this migration exists to remove. So it is not allowed to be a
   junk drawer: `module-check.js` fails the build if a bridged name is not
   actually referenced by a remaining classic script. When a consumer converts,
   its import becomes explicit and the name leaves this list. The migration is
   finished when BRIDGE is empty and this file only imports `main`.

   Nothing else may write to `window` — that is checked too. */

import { SYSTEM_EVENTS, Bus }                    from "./core/bus.js";
import { Hooks }                                 from "./core/hooks.js";
import { SCHEMA, Store }                         from "./core/store.js";
import { $, $$, pad, todayKey, dateFromKey, DEFAULT_AVATAR,
         load, save, H, SYSTEM_READY }           from "./core/kernel.js";
import * as Kernel                               from "./core/kernel.js";
import { Armory }                                from "./armory.js";
import { WD, founderSeed, founderDeadlines, CURRICULA, seedQuests, uid } from "./core/seeds.js";
import { renderQuote }                           from "./content/quotes.js";
import { renderWall }                            from "./views/wall.js";
import { Log }                                  from "./core/log.js";
/* The domain lives in shared/ and is imported by the Node server too — one
   definition of the level curve, so a phone and an account can never report
   different levels for the same student. */
import { xpNeeded, replayProgression }          from "../../shared/domain/progression.js";
import { planForBudget, estimateMinutes, TIER_RANK } from "../../shared/domain/next-action.js";

import { BALANCE }                               from "./content/balance.js";
import { GENRES }                                from "./content/library.js";
import { SCREEN }                                from "./content/screen.js";
import { TOOLS }                                 from "./content/tools.js";
import { CAREERS, GATE }                         from "./content/careers.js";

import { SYSTEM_VERSION, SYSTEM_CACHE, systemBuild } from "./app/version.js";
/* theme.js applies the saved theme at import time. It used to load 46 scripts
   later; running it first is strictly better — the flash of the wrong theme on a
   slow phone was real, and the only DOM it touches is <html> and a <meta> that
   are both parsed before any script runs. */
import { setTheme }                              from "./app/theme.js";

import { LORE }                                  from "./lore.js";
import { MORE_BOOKS, NEW_GENRES, MORE_SCREEN, NEW_SCREEN,
         HOBBIES, COMPETITIONS, SCHOLARSHIPS }   from "./data.js";
import { NEW_SCREEN_V11, MORE_BOOKS_V11, MORE_SCREEN_V11 } from "./data-v11.js";
import { SKILLS, BRANCHES, skillById, nextSkillAfter,
         pointsEarned, pointsSpent }             from "./skills.js";

const BRIDGE = {
  /* core */
  SYSTEM_EVENTS, Bus, Hooks, SCHEMA, Store, Log,
  /* kernel — 70 classic scripts still read these as bare globals */
  $, $$, pad, todayKey, dateFromKey, DEFAULT_AVATAR, load, save, H, SYSTEM_READY, Armory,
  /* seeds, quotes and the wall — only the names classic scripts still read.
     ALLD, QUOTES, WALL, wallI, wallTimer, wallStep and wallAuto are internal to
     their own modules now and are deliberately NOT republished: a name on the
     bridge that nothing consumes is a name that never comes off it. */
  WD, founderSeed, founderDeadlines, CURRICULA, seedQuests, uid, renderQuote, renderWall,
  /* domain — shared with the server */
  xpNeeded, planForBudget, estimateMinutes, TIER_RANK,
  /* content */
  BALANCE, GENRES, SCREEN, TOOLS, CAREERS, GATE,
  /* app */
  SYSTEM_VERSION, SYSTEM_CACHE, systemBuild, setTheme,
  /* data */
  LORE, MORE_BOOKS, NEW_GENRES, MORE_SCREEN, NEW_SCREEN, HOBBIES,
  COMPETITIONS, SCHOLARSHIPS, NEW_SCREEN_V11, MORE_BOOKS_V11, MORE_SCREEN_V11,
  SKILLS, BRANCHES, skillById, nextSkillAfter, pointsEarned, pointsSpent,
};

for (const [name, value] of Object.entries(BRIDGE)) globalThis[name] = value;

/* ---------- DB, and why it is not in BRIDGE ----------

   Every other bridged name is stable: the value published here is the value
   forever. DB is not. kernel.js reassigns it once the store hydrates, because
   the IndexedDB driver cannot answer synchronously at load — so a copy taken now
   would be the EMPTY record, permanently, for all 70 classic scripts that read
   `DB` as a global. Every one of them would see a hunter with no quests while
   the modules saw the real one.

   A getter forwards to the live module binding instead. There is no setter, and
   that is deliberate: only kernel.js writes DB, which was measured across all 76
   classic scripts before this conversion rather than assumed, and a silent
   `DB = ...` from a view is exactly the class of bug this migration exists to
   make impossible. Such an assignment now throws in strict mode instead of
   quietly forking application state. */
Object.defineProperty(globalThis, "DB", {
  configurable: true,
  get(){ return Kernel.DB; },
});

/* ---------- the deliberate surface ----------
   BRIDGE is compatibility debt and must shrink to nothing. This is different: a
   named export point for things that are genuinely part of ASCEND's API rather
   than a bare global a classic script happens to read.

   replayProgression lives here rather than in BRIDGE because no classic script
   consumes it — the module-check rule "no name is bridged that nothing still
   needs" was right to reject it. Exposing a function as a compatibility shim
   purely so a test can reach it would have quietly turned that rule into a
   place to hide things. */
globalThis.ASCEND = Object.freeze({
  replayProgression,
  version: SYSTEM_VERSION,
});

/* Read by module-check.js so the ratchet counts what actually shipped rather
   than what this file appears to say. */
globalThis.__ASCEND_BRIDGE__ = Object.keys(BRIDGE);
