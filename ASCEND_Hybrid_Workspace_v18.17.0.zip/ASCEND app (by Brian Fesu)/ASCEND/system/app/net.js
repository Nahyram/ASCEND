/* THE SYSTEM v13 — app/net.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- service worker (only when hosted, not from file://) ----------
   v18: the failure used to be swallowed by `.catch(()=>{})`. That is the one
   error in this app that must not be silent — if registration fails, the app is
   online-only for ever and nothing anywhere says so. The student finds out on
   the bus. It is recorded so offlineAudit() and the Studio panel can report it,
   and logged so it is visible in a console. It is still not thrown: a failed
   registration must not stop the app from running. */
let SW_REGISTRATION_ERROR = null;
if("serviceWorker" in navigator && location.protocol.startsWith("http")){
  navigator.serviceWorker.register("sw.js").catch(err => {
    SW_REGISTRATION_ERROR = (err && err.message) || String(err);
    console.warn("[net] service worker registration failed \u2014 the app will not work offline:", SW_REGISTRATION_ERROR);
  });
} else if(!("serviceWorker" in navigator)){
  SW_REGISTRATION_ERROR = "This browser does not support service workers.";
} else {
  SW_REGISTRATION_ERROR = "Opened from a file:// URL. Service workers need http(s), so offline caching is off.";
}
window.addEventListener("online", () => { renderQuests(); pingCount(); });
window.addEventListener("offline", renderQuests);

