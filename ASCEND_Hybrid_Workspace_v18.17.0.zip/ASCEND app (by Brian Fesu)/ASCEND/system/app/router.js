/* THE SYSTEM v13 — app/router.js
   One place that knows what the views are, what they are for, and how to reach them.
   Loads after legacy-shell.js and takes over its nav wiring. */
"use strict";

/* ══════════════ information architecture (Phase 12) ══════════════
   v14 grew from 8 sections to 13, one phase at a time, each addition defensible on
   its own. Phase 12 §5 names exactly that failure mode — fifteen permanent
   destinations *is* the clutter, however reasonable each one seemed when it was
   added.

   The fix is not fewer features. It is that a student navigates by what they are
   trying to do, not by the order the codebase was built in. Six areas, each with a
   verb:

     HOME     orient    · what today asks of you
     LEARN    master    · Academy, books, the Archive, the tutor
     GROW     develop   · skills, crafts, opportunities, projects, wealth
     QUESTS   execute   · today's list, deadlines, goals, focus
     PROGRESS reflect   · standing, achievements, records, patterns, portfolio
     SYSTEM   configure · account, sync, settings

   Every previous section still exists and every deep link still resolves — the
   old key routes to its new home rather than 404ing, because a bookmark a student
   saved in March should still work in June. */
const AREAS = [
  { k:"home",     id:"tab-home",  ic:"◈", label:"Home",     verb:"Orient",
    purpose:"What today asks of you, and how you're holding up." },
  { k:"learn",    id:"tab-learn", ic:"✎", label:"Learn",    verb:"Master",
    purpose:"Subjects, syllabus, practice, books and the Archive." },
  { k:"grow",     id:"tab-grow",  ic:"⚔", label:"Grow",     verb:"Develop",
    purpose:"Skills, crafts, opportunities, projects, money and career." },
  { k:"quests",   id:"tab-quests",ic:"▤", label:"Quests",   verb:"Execute",
    purpose:"Today's list, focus sessions, deadlines and goals." },
  { k:"progress", id:"tab-path",  ic:"⬢", label:"Progress", verb:"Reflect",
    purpose:"Standing, achievements, records, patterns and your portfolio." },
  { k:"system",   id:"tab-set",   ic:"⚙", label:"System",   verb:"Configure",
    purpose:"Account, sync, services, security and your data." },
];

/* Each area's sections, in the order they appear in its sub-navigation. The
   sections themselves are untouched — this is filing, not a rewrite. */
const AREA_SECTIONS = {
  home:     ["home"],
  learn:    ["academy","learn","armory"],
  grow:     ["grow","beyond","build","wealth","circle"],
  quests:   ["quests"],
  progress: ["path","insight"],
  system:   ["gate","studio","set"],
};

const VIEWS = [
  { k:"home",    id:"tab-home",    ic:"◈", label:"Home",     area:"home",     group:"Daily",   purpose:"What today asks of you, and how you're holding up." },
  { k:"quests",  id:"tab-quests",  ic:"▤", label:"Quests",   area:"quests",   group:"Daily",   purpose:"Today's list, focus sessions, deadlines and goals." },
  { k:"academy", id:"tab-academy", ic:"✎", label:"Academy",  area:"learn",    group:"Learn",   purpose:"Subjects, syllabus, practice, review, mistakes and exams." },
  { k:"learn",   id:"tab-learn",   ic:"▣", label:"Library",  area:"learn",    group:"Learn",   purpose:"Books, screen, learning tools, the Archive and the tutor." },
  { k:"armory",  id:"tab-armory",  ic:"⛨", label:"Armory",   area:"learn",    group:"Learn",   purpose:"Your own notes, past papers and lesson videos, sorted." },
  { k:"grow",    id:"tab-grow",    ic:"⚔", label:"Skills",   area:"grow",     group:"Grow",    purpose:"Skills, training, the four crafts you're defending, and your why." },
  { k:"beyond",  id:"tab-beyond",  ic:"◎", label:"Beyond",   area:"grow",     group:"Grow",    purpose:"Competitions, programmes, scholarships, activities and challenges." },
  { k:"build",   id:"tab-build",   ic:"⬡", label:"Build",    area:"grow",     group:"Grow",    purpose:"Projects, evidence, portfolio and your growth journey." },
  { k:"wealth",  id:"tab-wealth",  ic:"◆", label:"Wealth",   area:"grow",     group:"Grow",    purpose:"The Vault, careers, the Arena and the Open Gate." },
  { k:"circle",  id:"tab-circle",  ic:"◍", label:"Circle",   area:"grow",     group:"Grow",    purpose:"Study groups, pacts, a report you hand over, and class work in." },
  { k:"path",    id:"tab-path",    ic:"⬢", label:"Standing", area:"progress", group:"Progress",purpose:"Level, rank, bosses, achievements, the world and your own records." },
  { k:"insight", id:"tab-insight", ic:"◐", label:"Insight",  area:"progress", group:"Progress",purpose:"What the record says about you — patterns, trends, the log." },
  { k:"gate",    id:"tab-gate",    ic:"⟳", label:"Gate",     area:"system",   group:"System",  purpose:"Account, sync, external services and your data." },
  { k:"studio",  id:"tab-studio",  ic:"◱", label:"Studio",   area:"system",   group:"System",  purpose:"Performance, the business model and launch readiness." },
  { k:"set",     id:"tab-set",     ic:"⚙", label:"Settings", area:"system",   group:"System",  purpose:"Profile, quests, security, data and access." },
];
const VIEW = Object.fromEntries(VIEWS.map(v => [v.k, v]));
/* §26 (P12) and §7 (P13): a mobile bar carries the most important destinations
   and nothing else. Five areas plus More — everything remains one tap away
   through the palette, which is faster than a bar of fifteen ever was. */
const DOCK = ["home","learn","quests","grow","progress"];
const areaOf = k => (VIEW[k] && VIEW[k].area) || "home";
const areaFirst = a => (AREA_SECTIONS[a] || ["home"])[0];

let currentView = "home";

/* ---------- rail + dock markup ---------- */
function buildNav(){
  const rail = $("#rail");
  if(rail){
    /* One entry per area, with its sections beneath. Thirteen destinations become
       six decisions, and nothing was removed to achieve it. */
    let html = '<div class="rail-brand">SYSTEM</div>';
    for(const a of AREAS){
      const sections = (AREA_SECTIONS[a.k] || []).map(k => VIEW[k]).filter(Boolean);
      html += `<div class="rail-area" data-area="${a.k}">
        <button class="sys-navbtn area" data-view="${areaFirst(a.k)}" data-tab="${areaFirst(a.k)}" title="${esc(a.purpose)}">
          <span class="ic" aria-hidden="true">${a.ic}</span><span>${a.label}</span>
          <span class="tally hidden" data-tally="${a.k}"></span></button>`;
      if(sections.length > 1){
        html += `<div class="rail-subs">` + sections.map(v =>
          `<button class="sys-subbtn" data-view="${v.k}" data-tab="${v.k}" title="${esc(v.purpose)}">${v.label}</button>`).join("") + `</div>`;
      }
      html += `</div>`;
    }
    html += `<div class="rail-foot"><button class="sys-navbtn" id="railPalette">
        <span class="ic" aria-hidden="true">⌕</span><span>Search &amp; commands</span></button></div>`;
    rail.innerHTML = html;
  }
  const nav = $("#nav");
  if(nav){
    nav.innerHTML = DOCK.map(k => {
      const a = AREAS.find(x => x.k === k);
      return `<button data-view="${areaFirst(k)}" data-tab="${areaFirst(k)}" data-dock="${k}"><span class="ic" aria-hidden="true">${a.ic}</span>${a.label}</button>`;
    }).join("") + `<button data-view="__more"><span class="ic" aria-hidden="true">⋯</span>More</button>`;
  }
  $$("[data-view]").forEach(b => b.onclick = () => {
    if(b.dataset.view === "__more"){ openPalette("go "); return; }
    go(b.dataset.view);
  });
  const rp = $("#railPalette"); if(rp) rp.onclick = () => openPalette("");
}

/* ---------- navigate ---------- */
function go(k, seg){ return Hooks.dispatch("go", goBase, this, arguments); }
function goBase(k, seg){
  const v = VIEW[k]; if(!v) return;
  currentView = k;
  $$(".tabpane").forEach(p => p.classList.add("hidden"));
  const pane = $("#" + v.id);
  if(pane){
    pane.classList.remove("hidden");
    pane.classList.remove("viewswap"); void pane.offsetWidth; pane.classList.add("viewswap");
  }
  /* the area lights up as well as the section, so "where am I" is answerable at a
     glance — Phase 12 §2's first question */
  const area = areaOf(k);
  $$("[data-view]").forEach(b => b.classList.toggle("on", b.dataset.view === k));
  $$("[data-dock]").forEach(b => b.classList.toggle("on", b.dataset.dock === area));
  $$(".rail-area").forEach(el => el.classList.toggle("open", el.dataset.area === area));
  const crumb = $("#crumb");
  const a = AREAS.find(x => x.k === area);
  /* §43 — a breadcrumb only where the hierarchy is real. Single-section areas
     would just repeat themselves. */
  if(crumb) crumb.innerHTML = (a && (AREA_SECTIONS[area] || []).length > 1 && a.label !== v.label)
    ? `<span class="crumb-area">${esc(a.label)}</span> ${esc(v.label)}<small>${esc(v.purpose)}</small>`
    : `${esc(v.label)}<small>${esc(v.purpose)}</small>`;
  /* §146 — a real page title per route */
  try{ document.title = `${v.label} — THE SYSTEM`; }catch(e){}
  if(seg) goSeg(seg);
  if(location.hash !== "#" + k + (seg ? "/" + seg : "")) history.replaceState(null, "", "#" + k + (seg ? "/" + seg : ""));
  try{ localStorage.setItem("system.view", k); }catch(e){}
  if(k === "home" && typeof renderHome === "function") renderHome();
  if(k === "insight" && typeof renderInsight === "function") renderInsight();
  if(k === "path" && typeof renderPath === "function") renderPath();
  if(k === "academy" && typeof renderAcademy === "function") renderAcademy();
  if(k === "beyond" && typeof renderBeyond === "function") renderBeyond();
  if(k === "build" && typeof renderBuild === "function") renderBuild();
  if(k === "gate" && typeof renderOnlineGate === "function") renderOnlineGate();
  if(k === "circle" && typeof renderCircle === "function") renderCircle();
  if(k === "studio" && typeof renderStudio === "function") renderStudio();
  window.scrollTo(0,0);
}

/* jump straight to a sub-tab inside the current view */
function goSeg(seg){
  const btn = $$(".segbar:not(.sub) button").find(b => b.dataset.seg === seg);
  if(btn) btn.click();
}

/* deep link: #grow/tr-forge */
function routeFromHash(){
  const [k, seg] = (location.hash || "").replace(/^#/, "").split("/");
  if(VIEW[k]) go(k, seg);
}
window.addEventListener("hashchange", routeFromHash);

/* ---------- counts on the rail ---------- */
function refreshTally(){
  const h = typeof H === "function" ? H() : null; if(!h) return;
  const left = questsFor().filter(q => !isDone(q)).length;
  const set = (k, n) => $$(`[data-tally="${k}"]`).forEach(el => {
    el.textContent = n; el.classList.toggle("hidden", !n);
  });
  set("quests", left);
  set("home", (h.penalties || []).filter(p => !p.done).length);
}

/* ---------- take over from the v12 shell ---------- */
Hooks.wrap("enterSystem", "v13 shell", function(next){
  buildNav();
  next();
  if(typeof buildPalette === "function") buildPalette();
  let start = "home";
  try{ const s = localStorage.getItem("system.view"); if(VIEW[s]) start = s; }catch(e){}
  if((location.hash || "").length > 1) routeFromHash(); else go(start);
  refreshTally();
  setInterval(refreshTally, 30000);
});

/* every render pass refreshes the shell chrome too */
Hooks.after("renderAll", "shell chrome", () => {
  if(typeof renderHome === "function") renderHome();
  if(typeof renderInsight === "function" && currentView === "insight") renderInsight();
  refreshTally();
});

/* The wall carousel timer used to be duplicated here to patch a broken version in
   views/wall.js. It now lives only in views/wall.js, next to the carousel it
   drives. */
