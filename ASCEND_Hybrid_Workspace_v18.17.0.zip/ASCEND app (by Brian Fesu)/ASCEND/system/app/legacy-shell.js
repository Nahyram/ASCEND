/* THE SYSTEM v13 — app/legacy-shell.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ MAIN ══════════════ */
function enterSystem(){ return Hooks.dispatch("enterSystem", enterSystemBase, this, arguments); }
function enterSystemBase(){
  $("#app").classList.remove("hidden"); $("#nav").classList.remove("hidden");
  rollover();
  renderAll();
  const h = H(); if(h && $("#sessBlock")) $("#sessBlock").value = h.blocklist || "";
  pingCount();
  tick(); setInterval(tick, 1000);
}
$$("#nav button").forEach(b => b.onclick = () => {
  $$("#nav button").forEach(x=>x.classList.remove("on")); b.classList.add("on");
  $$(".tabpane").forEach(p=>p.classList.add("hidden"));
  $("#tab-"+b.dataset.tab).classList.remove("hidden");
  window.scrollTo(0,0);
});
/* v8: segmented sub-tabs — one screen, one job */
$$(".segbar:not(.sub)").forEach(bar => {
  const pane = bar.parentElement;
  bar.querySelectorAll("button").forEach(b => b.onclick = () => {
    bar.querySelectorAll("button").forEach(x=>x.classList.remove("on")); b.classList.add("on");
    pane.querySelectorAll(":scope > .segpane").forEach(p => p.classList.toggle("hidden", p.dataset.pane !== b.dataset.seg));
    window.scrollTo(0,0);
  });
});

