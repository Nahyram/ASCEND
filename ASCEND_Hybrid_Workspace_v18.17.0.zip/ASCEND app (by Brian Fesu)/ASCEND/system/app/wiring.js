/* THE SYSTEM v13 — app/wiring.js
   Loads last. Connects the new shell to the parts of the old app that
   pointed at screens which have since moved. */
"use strict";

/* the skill tree used to live under Status; it lives under Grow now */
function gotoSkills(){ go("grow", "st-skills"); }

document.addEventListener("DOMContentLoaded", init13);
if(document.readyState !== "loading") init13();

function init13(){
  const p = document.getElementById("btnPalette");
  if(p) p.onclick = () => openPalette();

  /* number keys jump between views when you aren't typing */
  document.addEventListener("keydown", e => {
    if(e.ctrlKey || e.metaKey || e.altKey) return;
    if(/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) return;
    if(document.getElementById("palette") || document.getElementById("dialogs").classList.contains("on")) return;
    const n = Number(e.key);
    if(n >= 1 && n <= VIEWS.length){ e.preventDefault(); go(VIEWS[n - 1].k); }
  });
}

/* ══════════════ v14 — intelligence layer wiring ══════════════
   Same idiom the rest of the app uses: wrap, don't rewrite. `go` and `renderAll`
   already exist and already do the right thing; these two wrappers just make sure
   the brain's surfaces repaint at the same moments everything else does. */

Hooks.after("go", "brain repaint", (r, k, seg) => {
  if(typeof renderBrain === "function"){
    safeRender("brain", renderBrain);
  }
});

Hooks.wrap("renderAll", "intelligence layer", function(next){
  if(typeof invalidateModel === "function") invalidateModel();
  const r = next();
  if(typeof renderBrain === "function"){
    safeRender("brain", renderBrain);
  }
  return r;
});

/* Sunday's review, and the morning brief, announce themselves once — quietly, in
   the rail tally, rather than as a popup. Phase 12 §10 is right that turning every
   event into an interruption is how notification fatigue starts. */
function brainTally(){
  /* The rail now carries one tally per area rather than per section, so Insight's
     count belongs to Progress. Written as a lookup rather than a literal so the
     next filing change does not silently stop the badge appearing. */
  const key = (typeof areaOf === "function" ? areaOf("insight") : "insight");
  const el = document.querySelector(`[data-tally="${key}"]`);
  if(!el || typeof briefUnread !== "function") return;
  let n = 0;
  try{
    if(briefUnread()) n++;
    if(typeof reviewDue === "function" && reviewDue()) n++;
    if(typeof adaptiveProposals === "function") n += adaptiveProposals().length;
  }catch(e){ return; }
  el.textContent = n; el.classList.toggle("hidden", !n);
}
setInterval(brainTally, 60000);
document.addEventListener("DOMContentLoaded", () => setTimeout(brainTally, 2500));


/* ══════════════ v14 — Phase 15 timing ══════════════
   Wraps go() here rather than in services/perf.js, because this file is the last
   one to load and is therefore the only place a wrapper is guaranteed to sit on
   top of the real function rather than on nothing. */
if(typeof recordViewTime === "function"){
  Hooks.wrap("go", "view timing", function(next, k, seg){
    const t0 = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    const r = next(k, seg);
    const t1 = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    try{ recordViewTime(k, t1 - t0); }catch(e){}
    return r;
  });
}
