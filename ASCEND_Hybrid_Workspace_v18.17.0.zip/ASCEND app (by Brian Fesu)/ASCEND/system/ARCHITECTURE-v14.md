# THE SYSTEM v14 — the intelligence layer

Read `ARCHITECTURE.md` first; it still describes the v13 structure and none of it
has been invalidated. This document covers what v14 added and, more usefully, why
several obvious-looking options were not taken.

---

## Where v14 sits in the roadmap

| Phase | Status after v14 |
|-------|------------------|
| 1 · Product architecture & UX | done in v13 |
| 2 · Code modernisation | done in v13; **storage seam closed in v14** |
| 3 · AI intelligence & adaptive learning | **this release** |
| 4 · Gamification, progression & living world | **this release** |
| 5 · Academy & student learning engine | **this release** |
| 6 · Online Gate — cloud, sync, APIs, security | **this release** |
| 7 · Opportunities & extracurriculars | **this release** |
| 8 · Competitions & challenges | **this release** |
| 9 · Projects & portfolio | **this release** |
| 10 · Scholarships & global opportunities | **this release** |
| 11 · Achievement verification & rankings | **this release** |
| 12 · Student experience & information architecture | **this release** |
| 13 · Mobile & PWA | **this release** |
| 14 · QA, security & reliability | **this release** |
| 15 · Performance & production | **this release** |
| 16 · Community, teachers & schools | **this release** (with refusals) |
| 17 · Business & monetisation | **this release** |
| 18 · Launch & global growth | **this release** |

The phase documents ask that each phase be finished before the next begins, and
Phase 2's own honest-gaps list named the storage interface as the thing blocking
Phase 6. So v14 closed that first and then implemented Phase 3 in full.

---

## What was added

```
core/store.js          the only place that touches localStorage; schema migrations
services/model.js      user model, confidence system, playstyle profile
services/patterns.js   pattern engine — 13 detectors, all significance-tested
services/goals.js      goal ladder (year→week) and local goal breakdown
services/adaptive.js   difficulty proposals, decision ledger, recovery mode
services/recommend.js  ranked recommendations, each carrying its own reason
services/briefing.js   daily briefing and weekly review
services/ai.js         provider-neutral AI service with a local answer for everything
views/brain.js         the four surfaces plus the Home focus strip and goal ladder
styles/07-v14.css      styling for the above, tokens only
brain-test.js          44 checks, including the ones designed to fail if the engine bluffs

content/balance.js     Phase 4 — every tunable number, in one table
services/records.js    achievements, titles, rank gating, personal bests, anti-farming
services/world.js      boss quests, world progression, next milestone, seasons
views/progression.js   the Path — one page for everything progression-shaped

services/curriculum.js Phase 5 — subjects, units, topics, evidence-based mastery
services/practice.js   question bank, error log, mistake→boss, spaced review
services/exams.js      exam centre, derived revision plan, grades, study sessions
views/academy.js       the Academy's seven surfaces

services/cloud.js      Phase 6 — identity, change tracking, sync engine, entitlements
services/api.js        external API gateway: timeouts, cache, rate limits, key policy
services/opportunities.js Phases 7+8 — one model, competitions as a subtype
services/projects.js   Phase 9 — projects, evidence, portfolio
views/gate.js  views/beyond.js  views/build.js

services/scholarships.js  Phase 10 — funding lines, eligibility, application packages
services/verification.js  Phase 11 — verification states, personal boards, ranking engine
services/device.js        Phase 13 — capability, network, data saver, install, updates
services/integrity.js     Phase 14 — input safety, data repair, honest security posture
views/apply.js            the surfaces for 10, 11, 13 and 14

services/perf.js       Phase 15 — budgets, per-view timing, storage, offline audit
services/community.js  Phase 16 — groups, pacts, the report, and what is refused
services/business.js   Phase 17 — a paywall rule enforced by the build
services/launch.js     Phase 18 — launch gate, regions, activation, growth
services/journey.js    the LEARN→FUTURE loop, computed from the record
views/frontier.js      the loop map, Circle and Studio
```

Every one of the services is a pure function over local state. No network, no
model provider, nothing leaves the device unless the hunter has configured an
endpoint and pressed a button.

---

## The storage seam (Phase 2 closeout)

`core/kernel.js` used to call `localStorage` directly. It now calls
`Store.readJSON` / `Store.writeJSON`. That is a two-line change to kernel and it
is the whole point: Phase 6 needs cloud, Phase 13 needs IndexedDB for bulk, and
neither should require editing forty view files.

Drivers are registered objects implementing `get/set/del/keys`. Two ship: `local`,
and `memory` as a last resort so the app still runs in a browser with storage
disabled — with `Store.durable === false` so the UI can be honest about it rather
than silently losing the hunter.

**Migrations** run on load. `SCHEMA` is 2. The v1 → v2 migration adds `brain` and
`focusLog` to each hunter and gives existing goals a default horizon. It adds
fields and never removes one, and it is safe to run twice. A v13 export still
opens; a v14 export opens in v13 with the new fields ignored.

---

## The confidence system, and why it has teeth

Phase 3 §6 asks for confidence levels. The easy version is a label computed from
sample size alone, which is worth very little — a 40-point gap over 200 rows can
still be noise if the underlying rates are close.

`significant(rateA, nA, rateB, nB, floor)` in `model.js` requires a difference to
clear **both** a fixed floor **and** roughly two standard errors of the difference
between two proportions. Every comparative detector uses it.

This is not decoration. The test suite feeds the engine 56 days of deliberately
random data at a uniform 75% clear rate and asserts that it reports **nothing**.
Before the significance test was added, that run reported a weak weekday, a trend
and a fragility pattern — all three invented, all three phrased confidently. An
engine that finds patterns in noise is worse than no engine, because a student
will act on it.

The same suite plants three patterns (a collapsed weekday, a weak evening band, a
quest never cleared) and asserts all three are found. Both halves have to pass.

One related fix worth recording: the fragility detector counted any day under 25%
as a collapse, which meant a single missed weekend alarm — a one-quest day —
counted the same as a lost Tuesday. Collapse days now need at least three quests
scheduled.

---

## Adaptive difficulty proposes, never applies

This is the most important design decision in the release, and it is a deliberate
refusal of what Phase 3 §7 could be read as asking for.

`adaptiveProposals()` returns proposals. Each carries what it wants to change,
what it was computed from, and what happens if accepted. The hunter can accept,
snooze, or refuse, and all three are written to a decision ledger. A proposal
refused twice is never offered again.

Nothing in `adaptive.js` writes to the quest board unless `acceptProposal()` is
called from a user action. The test asserts this directly: it snapshots the quest
list, calls `adaptiveProposals()`, and fails if a single byte changed.

A system that quietly rewrites your schedule is one you stop being able to read,
and once you stop reading it you stop using it. The coach in v13 already worked
this way for the same reason.

---

## Recovery over punishment

`recoveryState()` detects consecutive days under 25% cleared. Recovery is offered,
not imposed. While it runs:

- the board shows the three cheapest mandatory quests, not all of them;
- penalties are suspended;
- the end date is stated up front.

Penalty suspension is implemented by wrapping `issuePenalty` in `adaptive.js`
rather than editing `services/penalty.js`. That keeps the v12 penalty logic exactly
as written and makes the suspension one visible line instead of a condition buried
three functions deep.

---

## The AI layer, and what it deliberately is not

`AI.ask(capability, { local, system, messages, context })`. The `local` callback
is **mandatory**: if a capability cannot be answered without the network, it does
not go behind an AI call.

Three refusals, all deliberate:

1. **No API key in the browser.** The only shipped adapter posts to the hunter's
   own worker, which holds the key server-side. This argument was settled back in
   v4.1 and Phase 6 §32 says the same thing.
2. **The record never leaves.** `compressContext()` strips anything matching
   name / avatar / pin / hash / endpoint / install / email / phone / address /
   `*log`, caps strings at 300 characters and arrays at 8 entries. The test asserts
   that a context containing a name, a PIN hash, an endpoint and a money log comes
   out holding only the three neutral numbers.
3. **It is never load-bearing.** The briefing, the review, the patterns, the
   recommendations and the goal breakdowns are all computed locally. With no
   endpoint configured — the default — the intelligence layer is complete. AI
   improves wording and handles open questions; it is not where the product's
   intelligence lives.

Cost control: 40 requests a day, a response cache keyed on the exact payload, a
20-second timeout, and context compression before anything is sent.

There is also `AI.promptFor(capability, ctx)`, which produces a prompt to paste
into any free AI app. On a school phone with no budget that has always been the
fallback that actually works.

## Goal breakdown is templates, not a model

Phase 3 §8 asks that a goal become a progression. §35 asks that a deterministic
algorithm be used where it beats AI. Breaking "prepare for my Physics exam" into
map-the-ground → close-the-gaps → prove-it is not a creative problem. The
deterministic version is instant, free, works offline, and cannot invent a step.

`classifyGoal()` reads the wording into one of six kinds — exam, skill, project,
body, money, generic — and each has a three-target ladder. When nothing matches, it
says so: "nothing in the wording pointed at a particular kind of goal, so this is
the general ladder." A plan that admits it is generic is more useful than one
pretending to be tailored.

---

## The ladder

Goals gained three optional fields: `horizon`, `due`, `parent`. Horizons run
year → half → quarter → month → week. `setParent` refuses a child whose horizon is
longer than its parent's and walks the chain to refuse cycles. Old goals default to
`month` and keep working untouched.

---

## Where the intelligence surfaces

Phase 3 §34 says intelligence should appear where the work is rather than in a
chatbot page. So:

| Surface | What appears |
|---------|--------------|
| Home | focus strip (1–5), recovery banner, and the directive now states *why* it chose that quest |
| Insight → Brief | today's briefing, the ranked list with reasons, playstyle |
| Insight → Patterns | detected patterns, each with its confidence and sample size |
| Insight → Plan | recovery, proposals, and the decision ledger |
| Insight → Review | the last seven days and one change for next week |
| Quests → Goals | the ladder, and "break this down for me" |

Navigation, the command palette and the service worker precache list all pick the
new panes up automatically, because v13 built them to be generated rather than
hand-maintained. Adding a `segpane` was genuinely all that was needed.

---

---

# Phase 4 — gamification and progression

## Everything tunable is in one table

`content/balance.js` holds XP awards, the level curve, level titles, rank
requirements, the six difficulty tiers, quest types, anti-farm limits, the world
map, 27 achievements, 8 titles and the season windows. No numbers, no thresholds.

This is §40, and it earns its place: v12 scattered XP values across seed data,
quest editors, skill effects and view files, so "make levelling slightly slower"
was a fifteen-file change nobody would attempt. It is now an edit to a table.

## Rank had to stop being a synonym for level

v12 derived rank purely from level, so a hunter could reach S-Rank by clearing
easy quests for long enough. §6 asks for rank to represent mastery instead, so
each tier now needs a level **and** evidence: quests cleared, a streak actually
held, achievements earned, bosses put down. The test asserts it directly — a
level-50 hunter with an empty record sits at E-Rank and is told exactly which
requirement is blocking them.

## Bosses are milestones with checkboxes

A boss (§14) is a chain of five or six stages. Six templates cover the cases a
student actually has — master a topic, beat a past paper, finish a project, break
a procrastination, finish a hard book, plus custom. §15 is respected: bosses are
symbolic obstacles, and nothing rewards doing anything unsafe.

Stages pay a difficulty-scaled amount; completing the chain pays properly. A goal
with three or more steps can be promoted straight into a boss rather than being
re-typed.

## Nothing functional is locked

The eight world areas (§29–31) map onto parts of the app that are **already
reachable from the navigation rail on a fresh install**. Unlocking an area is the
moment the System explains what that part of itself is for — not the moment it
becomes usable. Gating real features behind grinding would be the exploitative
design §23 and §31 warn against, and it would be worse here than in a game,
because the thing being gated is a student's study tools.

## Anti-farming, and the trap inside it

§41 asks that trivial repetition not produce unlimited progression. Two rules:

- **A tagged grant pays once.** `toggleQuest` is wrapped so a quest pays its XP
  once per day however many times it is ticked. Un-ticking never pays.
- **Untagged grants are capped** at 900 XP a day.

The first version capped *everything*, which failed its own test in an instructive
way: a boss falling on top of a full board legitimately exceeded the ceiling, so a
genuinely enormous day was punished for being real. The fix follows from what the
cap is for — a tagged grant has already been proved unrepeatable, so only untagged
grants (the ones that could loop) are capped.

## Personal bests over rankings

§35, and it is the right instinct. Records are written as they happen, so a bad
month cannot recompute them away. The test sets a 40-day streak, drops it to zero,
and asserts the record still reads 40.

---

## The statistics had to be fixed twice

Worth recording, because both fixes came from a test failing rather than from
review.

**First**: the engine reported patterns in uniform random data. Fixed by requiring
a difference to clear two standard errors as well as a fixed floor.

**Second**: it still did, intermittently. The cause was subtler — detectors pick
the *best and worst of k groups* and then test that pair as though it were a single
planned comparison. Testing the widest gap among seven weekdays at a
single-comparison threshold is how an engine ends up confidently announcing that
Tuesdays are your problem. `zForGroups(k)` now widens the bar with the number of
pairs, and the two detectors that compared a subset against a total containing it
(`strength`, `anchor`) now compare against *the rest* instead, which is the
comparison they were always meant to be making.

Both noise checks are now seeded rather than using `Math.random()`. A flaky test is
worse than no test: it trains you to re-run until green.

## Patterns now state their own action

The weekly review used to derive its "one change" by taking the last sentence of a
pattern's detail text. It produced `"This is not."` — grammatical, and meaningless.
Each detector now carries an explicit `action`, and the test requires every pattern
to have one of real length. A pattern that cannot say what to do about it is an
observation, not a finding.

---

---

# Phase 5 — the Academy

## The one thing this file set exists to prevent

§9 asks that "I studied this", "I understand this" and "I can solve problems with
this" be kept apart. That sounds like a modelling nicety. It is the whole product.

A student two weeks from an exam who has re-read a topic ten times feels prepared
and is not, and an app that rewards the re-reading with a progress bar is not
neutral — it is actively participating in the failure. So `masteryOf()` tracks
three separate claims, each with its own evidence:

| Claim | What counts as evidence |
|-------|-------------------------|
| studied | you marked it studied, or ran a session on it. Self-reported, weakest. |
| applied | ≥5 questions attempted, ≥70% correct, **and** at least one harder one right |
| recalled | ≥3 flashcard recalls with ≥70% success |

A topic cannot reach *mastered* without `applied` **and** `recalled` **and** a real
gap between reviews. The test suite asserts this from the wrong direction, which is
the direction that matters: it marks a topic studied twenty times and requires the
result to still be `learning` at 25%.

Mastery also **decays**. A topic last reviewed 120 days ago drops from 94% to 59% —
but never below 50%, because forgetting is not the same as never having learnt it.

## The revision plan is derived, never stored

§31 says do not schedule impossible workloads; §32 says if the student falls
behind, recalculate rather than shifting everything forward a day. Together those
rule out the obvious implementation — a calendar written once when the exam is
created — because that is precisely the design that ends up showing eleven hours
of revision on a Tuesday in week three.

`revisionPlan()` therefore computes from three things true *right now*: days left,
current mastery per topic, and the hours the student said they have. There is no
stored schedule, so there is nothing to fall behind on. The test moves an exam from
60 days out to 5 and asserts the foundation phase disappears on its own.

And when the arithmetic does not work, it says so rather than printing a plan that
quietly assumes twelve-hour days:

> At 1 hour a week you have about 0.6 hours before this exam, and 4 topics still
> need work — roughly 6 hours at a realistic pace. Either the hours go up, or the
> plan covers the topics that matter most and lets the rest go. Choosing
> deliberately beats running out of time by accident.

## Copyright is a design constraint, not a disclaimer

§16 and §33 are explicit and this build follows them: **no exam-board questions
ship with the app and none are scraped.** Every question in the bank is one the
student wrote or typed in from material they hold. For real past papers the
Academy records metadata and sends them to the official source.

That is not timidity. A study app that redistributes a board's papers is one that
gets taken down, taking the student's notes and error log with it.

## Mistakes are the feature, and they reuse Phase 4

The error log records a **cause**, not just a failure — §19's categories, because
"careless" and "did not know it" need opposite responses and lumping them together
is why error logs get abandoned by February.

Three unresolved errors on one topic makes it a *recovery candidate*, and
`bossFromTopic()` turns it into a five-stage boss chain. That reuses the Phase 4
mechanic rather than inventing a parallel one — the same argument Phase 9 §12 makes
about not building a second task system.

## Spaced review

A small SM-2 variant: ease 1.3–3.0, four grades, and "Again" returns the interval
to zero (§22 — repeated failure returns to learning). Card outcomes write back to
the topic's evidence record, which is what makes `recalled` mean anything.

The UI states that the interval is a suggestion built from the student's own
record. Phase 3 §15 is right that the app must not claim to predict human memory.

---

## The test harness was lying, and that is the most important fix here

The Phase 5 tests came back with sixteen failures whose messages all read
`Cannot read properties of undefined`. The cause was one line in `run()`.

When a `<script>` fails to *parse*, it never executes — so `window.__R` still held
the previous call's value, and `run()` returned it. Every later assertion read
stale data from an unrelated test. Some of those would have passed.

That is the worst failure mode a test suite has: it reports passes for tests that
never ran. `run()` now stamps a unique token before each call and throws if the
token survives.

The underlying bug it was masking: `\n` inside a template literal is interpreted
by the template literal, so a newline landed *inside* an inner double-quoted
string and broke the parse.

Two real product bugs surfaced once the harness stopped lying:

- **`importOutline` turned every topic into a unit.** It demanded two spaces or a
  leading bullet, so the most common way anyone writes an outline — one space then
  a dash — matched neither branch.
- The old migration assertion still expected schema 2 and would have kept passing
  against a stale expectation.

---

---

# Phases 6–9

## Phase 6 — a sync engine that has actually been run

There is no THE SYSTEM backend. The tempting move is to write the sync layer
against an imaginary server and declare it done, which produces code that has
never executed a conflict. So the transport is a driver and two ship: `local`
(a no-op — everything already works) and `loopback`, an **in-memory server with
its own revision counter and its own clock**.

`loopback` is not a stub. The test suite signs in, pushes, has a second device push
first, pushes again, forces a network failure, and signs out — and asserts on what
is actually in the server store afterwards. A `rest` adapter is four methods; the
shape it must implement is written at the bottom of `cloud.js`.

**Conflict rules are deliberately boring** (§15), because clever merging is how
data disappears: monotonic counters take the larger value, the done-record and
every log are *unioned* rather than replaced, id-keyed lists merge by id. Union
over replace does most of the work — two devices ticking different quests on the
same day is the common case and must not be a conflict at all. The test proves it:
device A's tick and device B's tick both survive, and neither device's XP is lost.

**Nothing is ever a barrier** (§54). Signing out keeps every byte. A failed sync
says "your local progress is safe" and backs off exponentially. The queue is
incremental (§14) and collapses runs — twenty quests ticked is one pending change,
not twenty.

### The API key question, answered rather than hedged

§22 and §32 say a key in frontend JavaScript is a public key. v13 stored the
hunter's own TMDB key in their record. Both arrangements are now supported and the
UI says which is in use: a **proxy URL** the hunter controls (correct), or a
**browser-held key** with the interface stating plainly that anything in a browser
is public and should be a throwaway. THE SYSTEM ships no key of its own.

`services/api.js` also makes §26 and §56 true rather than aspirational: every call
returns `{ ok, data, error, cached, stale }` and never throws, so TMDB being down
degrades the library and nothing else.

## Phases 7 & 8 — one model, and no listings at all

Phase 8 §44 says a competition is an opportunity subtype, not a second database, so
there is one model. Two tables would have meant two deadline engines and two
verification states drifting apart within a month.

**The decision worth defending: THE SYSTEM ships zero opportunities.** Phase 7 §5
and §42 require the official organiser to be the source of truth and forbid
inventing deadlines. An offline-first app on a student's phone cannot verify that a
scholarship deadline is still real. A directory of stale listings is worse than an
empty one — a student who misses a real deadline because we showed them last year's
has been materially harmed, and "our data was old" is not a defence anyone should
have to hear. So every record is one the student entered, everything carries a
last-checked date, anything unchecked for 30 days is flagged, and the primary
action is always the organiser's own page.

Matching never shows a bare percentage (§10). A passed deadline is a **gate**, not
a weight — the test asserts a closed opportunity scores zero however good the fit
looks, which is Phase 10 §15's rule arriving early.

**Scam protection** (§46) is five heuristics on what the student typed, phrased as
questions. One of them originally used the word "scam" about the listing in front
of the student; the test that forbids accusatory wording caught it and it was
rewritten. The advice never tells anyone to send money, share a password or send ID.

## Phase 9 — evidence is links, and nothing publishes itself

Three decisions:

**Evidence is metadata and links, not uploads.** Phase 6 has no file storage, and
putting a student's certificates into a localStorage record that syncs over mobile
data would be wrong twice over. Anything matching an identity or financial document
is refused outright with an explanation.

**Nothing reaches the portfolio by accident** (§48). `featureProject` does not
toggle a flag — it runs a readiness check and *refuses*, listing what is missing. A
project needs to be completed, evidenced and reflected on before it can be chosen,
and choosing is still a separate act.

**Verification means verification** (§32). Four states, and only two are reachable
from inside the app, because the other two require somebody outside it to look.

Progress is weighted milestones, not a task count (§9), and quality is six named
dimensions rather than one score (§35) — one number just invites optimising the
number.

---

## The harness lied again, in a new way

Three sync checks passed that had never run. The synchronous test body finished
before `signIn`'s promise resolved, so the later assertions were testing a client
that had never signed in — and returned `true` anyway.

It surfaced only because the round-trip assertion looked at the **server's** state
rather than at a return value. Async work now gets one ordered chain and one set of
assertions at the end.

That is twice this project that a green suite was hiding untested code. Both times
the fix was the same principle: assert on the state something else can observe, not
on what the function under test says about itself.

---

---

# Phases 10–14

## Phase 10 — "fully funded" is the most dangerous phrase in this domain

A student flies somewhere on the strength of it and finds accommodation was never
included. So funding is recorded per cost line — tuition, accommodation, meals,
travel, visa, materials, fees, stipend — each one covered / partial / not covered /
**not specified**, and the last never quietly becomes "free". With nothing
recorded the headline reads *"Funding not recorded"* and the caution says outright:
this does not mean it is free, it means nobody wrote down what it covers.

**Eligibility has five states and the top one is "nothing contradicts it"** (§12,
§56). The app cannot see a passport, a transcript or a bank statement, and §78 says
do not collect data on the chance it becomes useful — so `studentProfile()`
deliberately holds no date of birth, citizenship or income, and every criterion that
depends on them is returned as *unknown* with the reason. The test asserts the
profile does not contain those fields at all.

An **application package holds references, not copies** (§30, §107). Editing a
project updates every application pointing at it. The test renames a project and
checks the package still resolves to the new name and contains no copy of it.

§92 gets an implementation too: six open applications alongside an exam within a
month produces *"applications are not free — each one costs evenings you were going
to revise in. Two done properly beats five done at midnight."*

## Phase 11 — why there is no global leaderboard

§51 makes global rankings opt-in, §52 forbids presenting a tiny sample as a
definitive ranking, §71 requires minimum sample sizes. Phase 6 shipped a sync seam
and a loopback server — not a population.

A leaderboard over a database of one is not a partial implementation. It is a
fabrication of the thing the feature exists to provide. So the **ranking engine** is
built — metrics, tie rules (1, 1, 3), percentiles that return null below n=20,
snapshots, opt-out — and pointed at the only real population: this hunter's own
history. `rankAgainst(population, metric)` takes a cohort the day one exists.

**Verification means somebody outside the app looked.** Six states; only three are
settable in-app. The test asserts a user cannot promote their own achievement to
`verified` or `official`, and that THE SYSTEM's own achievements are marked as
describing app usage rather than outside accomplishment.

## Phase 12 — paying down the debt the previous session created

v14 grew from 8 sections to 13, one phase at a time, each addition defensible
alone. Phase 12 §5 names exactly that: fifteen permanent destinations *is* the
clutter, however reasonable each step seemed.

Six areas, each with a verb — **Home** orient, **Learn** master, **Grow** develop,
**Quests** execute, **Progress** reflect, **System** configure. Every section still
exists and **every old deep link still resolves**, which the test enumerates
explicitly: a bookmark saved in March works in June.

The rail groups by area with sections beneath; the mobile bar carries five areas
plus More; the breadcrumb shows `Grow › Beyond` only where the hierarchy is real
(§43); and each route sets a real page title (§146).

## Phase 13 — built for a mid-range Android on a metered bundle

That is this project's actual audience, and it drives every decision here rather
than a benchmark score. Data saver suppresses decorative weight and **skips external
calls up front** — twelve seconds of spinner ending in a timeout has spent data and
delivered nothing. The install prompt is withheld until the app has been used for
several days (§26). A waiting service worker never takes over a live session:
`SKIP_WAITING` fires only when the user asks (§59).

## Phase 14 — saying what a client-only app cannot protect

§19 is unambiguous that authorisation must be server-side. THE SYSTEM has no
server. The honest response is to say so, not to ship a `checkPermission()` that
returns true and looks reassuring in a diff. `securityPosture()` therefore lists
both halves, and the test requires the "does not protect" list to be non-empty and
to name authorisation with "no server" as the reason.

What it *does* enforce is tested rather than asserted: five XSS probes are entered
as project titles, rendered, and the DOM is inspected for injected `script`, `img`,
`svg` and `iframe` elements — zero, with the literal text visible. `safeUrl()`
refuses `javascript:`, `data:` and protocol-relative links. `integrityCheck()` finds
orphaned history, impossible values, broken cross-references and evidence claiming
more correct answers than attempts, and repairs only the safe ones on request.

---

## Three bugs the tests caught this session, and one gap

**A whole subsystem had never been tested.** `buildNav()` runs inside
`enterSystem()`, and the harness injects a hunter directly — so navigation markup
had never once been exercised, across five sessions. The area-highlight test failed
because the rail was empty, not because the highlighting was wrong. There is now a
check that the nav builds and that every section is reachable from it.

**Data saver did nothing.** It changed the banner and the CSS class; external calls
still fired, because the wrapper consulted the browser's `saveData` flag rather than
the user's setting. A setting that does not do what it says is worse than none —
the student stops believing the others.

**The rail tally broke silently.** Moving tallies from per-section to per-area left
`brainTally()` querying `[data-tally="insight"]`, which no longer exists. It now
resolves the area from the section so the next filing change cannot break it again.

**A test had drifted into order-dependence.** The rank check leaned on the clear
count left behind by thirty preceding tests and had drifted three quests below the
D-Rank threshold. It now builds exactly the evidence the tier requires, and then
removes one requirement to prove the gate is real rather than assumed.

---

---

# Defects found after Phase 14, and the class they belong to

All 18 phases' features were passing 118 checks. A static audit for duplicate
global declarations then found three, two of which were live regressions **I had
introduced myself** by naming new functions after existing ones.

In classic-script global scope the file that loads later silently replaces the
earlier definition. Nothing errors. Nothing is logged. The older feature simply
stops working.

| Collision | Effect | Shipped since |
|---|---|---|
| `renderGate` — views/gate.js over views/v9-views.js | The Open Gate's nine dropout-help lessons stopped rendering, and "Mark studied" called the cloud sync panel instead | Phase 6 |
| `renderRecords` — views/progression.js over views/core-views.js | The 90-day heatmap stopped being redrawn | Phase 4 |
| `wallAuto` — app/router.js over views/wall.js | A v13 patch was "working" only because it loaded later than the broken original | v13 |

The newer function was renamed in each case — `renderOnlineGate`,
`renderPersonalBests` — because the older name belongs to the older feature. The
carousel timer moved back into `views/wall.js`, next to the carousel it drives:
relying on load order to fix a bug is not a fix, it is a coincidence that holds
until someone reorders the scripts.

The rename then exposed a fourth: `app/router.js` still routed the Gate section to
`renderGate`, which after the rename meant the Open Gate lessons — so the Gate
section rendered the wrong panel entirely. A caller a rename misses is exactly what
the collision guard cannot see, which is why the render checks were added too.

## The precache generator had been lying

The service worker was missing **20 of 82** referenced files. The generator used
`re.sub(r'^const FILES = \[.*?\n\];', ..., flags=re.S)` — `^` without
`re.MULTILINE` matches only the start of the string, and the file starts with a
comment. So the substitution matched nothing, did nothing, and printed a success
count computed from the input rather than the result.

Offline is this product's central promise. Everything worked until the connection
went, and then it did not. The generator now asserts the substitution happened and
re-reads the file to confirm every entry landed.

Three of these four bugs share one root cause: **a success message computed from
intent rather than from the result.** It is the same failure as the two harness
bugs recorded above.

## Two static guards now run on every build

- **No global function may be declared in two files.** IIFE-wrapped files
  (`armory.js`, `online.js`, `core/store.js`, `ui-v11.js`) are correctly excluded,
  since their top level is not global — an earlier version of this check reported
  them as collisions and would have sent me editing working code.
- **The precache list must contain every script and stylesheet index.html loads.**

Five global collisions in this project's history now make the ES-module conversion
the single highest-value piece of outstanding work. Modules make this class of bug
a load-time error instead of a silent feature deletion.

---

---

# Phases 15–18

## Phase 15 — measuring what can be measured, and naming what cannot

Load, stress, soak and global-latency testing all need something deployed and a
population hitting it. There is neither. Inventing figures for them would be worse
than having none, because they would be quoted later as if they had been measured.

So `PERF_UNTESTED` is a permanent, visible list with a reason against each entry,
and it does not shrink until the thing it names actually happens. What *is*
measured is real: per-view render time (from a wrapper on the actual `go()`),
storage footprint broken down by part, bundle weight read from the document, and a
runtime offline audit against the browser's own cache.

Storage names prune candidates rather than pruning. History is the one thing a
student cannot regenerate.

## Phase 16 — a substantial refusal, in the product

The brief describes messaging, a student directory, public profiles, photo sharing
and teacher accounts that read a student's device. All are buildable. **None
ship.**

The reason is not technical. The audience is 13–18, and every one of those
features needs a moderation operation behind it — somebody reading reports, a
takedown path, an escalation route when an adult contacts a child, and a legal
position per country. There is one developer and no operation. Student-to-student
messaging shipped into that gap is not an incomplete feature; it is a hazard with
a study app around it.

What ships is the useful part that carries none of that risk:

- **Study groups** as a shared intention — first names you type, sessions you
  actually held, and an honest verdict when one stops meeting.
- **A report the student generates and hands over.** This inverts the usual
  arrangement deliberately: the teacher gets consistency, subject progress, exam
  dates and weak areas; reflections, notes and anything marked private never
  appear. An adult who can see everything a student writes changes what the
  student is willing to write.
- **Class work in** — paste what was set, get deadlines. No integration, no
  accounts, works with a photo of a whiteboard.
- **The refusals are shown in the app**, under "What is not here", with reasons.

## Phase 17 — the paywall rule is enforced by the build

`NEVER_PAID` lists 34 features — the Academy, practice, the error log, revision,
quests, goals, projects, the portfolio, offline, export. `registerPaidFeature()`
**refuses** any of them and warns loudly. A policy that lives only in prose is one
a future release quietly breaks when a revenue target appears; this way the
attempt fails at registration.

Paid is limited to things that genuinely cost money to run — sync, cloud backup,
online AI — plus one convenience that costs nothing to withhold. Prices are integer
minor units in a regional table, because purchasing power is not an exchange rate.
`licenceCheck()` returns `authority: "device"` and says outright that a client-side
licence check is not a licence check.

## Phase 18 — a gate with no override

`launchChecklist()` currently reports **not ready**, blocked on five items
including "backend deployed", "authorisation enforced server-side" and "privacy and
terms reviewed". There is no override function, and the test asserts none exists. A
checklist you can tick past is decoration.

It also distinguishes the two questions honestly: not ready for a *public* launch,
and entirely ready for the thing that matters now — real students using it on their
own devices, which needs none of those five.

Regions change behaviour, not labels: choosing Ghana turns data saver on by default
and puts WASSCE first. The locale seam exists with English only, and says so rather
than offering a picker that changes nothing.

`GROWTH_REFUSED` names referral rewards, streak-loss notifications and daily
come-back pushes. A product for 13–18-year-olds that grows by manufacturing anxiety
is a worse product even when the numbers look better.

## The loop, made answerable

`journeyState()` turns LEARN → DEVELOP → DISCOVER → BUILD → ACHIEVE → CONNECT →
GROW → FUTURE into something computed from the record. The verdict names the
**earliest empty stage**, never the furthest reached: someone with three projects
and no mastered topic has skipped LEARN, and telling them they are at BUILD would
be flattery with a progress bar attached.

Two new sections, not four — Circle under Grow, Studio under System. Phase 12 spent
a session cutting thirteen destinations to six areas, and filing four new panels
would have been the same mistake in a different coat.

## The collision guard earned itself

Writing the loop map, I named it `renderJourney` — which `views/build.js` has owned
since Phase 9 for the growth timeline. **The guard added earlier this session caught
it before it shipped**, which is the fourth time in this project that a new function
was about to silently delete an older feature by sharing its name.

It also caught a quieter one: `services/perf.js` wrapped `go()` at load time, but it
loads long before `app/router.js` declares `go` — so the wrapper installed on
nothing and every timing read back as zero, with no error. The wrapper moved to
`app/wiring.js`, which loads last. In a classic-script build, load order *is* the
dependency graph, and a wrapper that installs too early fails silently.

---

## Testing

`brain-test.js` — 137 checks. `harness.js` — the v13 walk, unchanged and still
green. Run both:

```
npm install jsdom
node harness.js
node brain-test.js
```

The checks worth knowing about:

- plants three patterns and requires all three to be found;
- feeds uniform random data and requires **silence**;
- requires every recommendation to carry a reason of real length;
- snapshots the quest board and fails if proposals mutate it;
- asserts penalties are actually blocked during recovery and restored after;
- asserts a v13 record migrates forward with its name, quests and goals intact;
- asserts the AI context filter drops identifying fields.

---

## Still open, honestly

1. **ES modules and a bundler.** Still wanted, still after more tests exist. v14
   added eight files to a load order that is already 50 entries long.
2. **Light-theme token conversion** in `04-views.css` and `05-modules.css`. v14's
   own stylesheet is token-only, so it does not add to the debt, but it does not
   pay it off either.
3. **View files still hold business logic.** `views/core-views.js` remains 243
   lines of mixed rendering and rules. The new services are the shape to copy.
4. **Cloud sync, accounts, leaderboards.** The storage seam now exists, which was
   the blocker. Phase 6 is genuinely reachable from here.
5. **Session length is not recorded**, so the pattern engine cannot detect the
   "long sessions vs very short sessions" case Phase 3 §5 lists. Focus sessions in
   `services/audio.js` would need to write a log first.
6. **Exam Mode** (Phase 3 §17) is only partly here — deadline intelligence and
   goal breakdown cover the reasoning, but the subject/topic/mastery model belongs
   to Phase 5's Academy and building half of it now would mean rebuilding it then.
7. **Weekly review does not persist snapshots.** It recomputes from the record, so
   a review read in January cannot be re-read verbatim in March.
8. **Phase 4 deferred deliberately:** prestige (§26), mystery chests and random
   events (§33), cosmetics and currency (§21–22), and skill mastery tiers (§9).
   Prestige and seasons need a full year of real use before their numbers can be
   set honestly; cosmetics need an art pipeline that does not exist. Seasons ship
   as a window only — nothing earned ever expires with one.
9. **Phase 5 deferred:** the notes workspace (§23–24) — the Armory already stores
   materials and a full backlinked editor is its own project; the Socratic AI tutor
   modes (§11–14) beyond what `services/ai.js` already exposes; past-paper timing
   mode (§33–34); and learning paths / custom courses (§44–45).
10. **Phases 6–9 deferred:** real authentication (there is no backend to
    authenticate against — the seam exists and `loopback` proves the engine);
    payments (Phase 17 owns it, and `EntitlementService` is the seam);
    team competitions and shared projects (Phase 16 owns collaboration);
    a public portfolio URL, which needs hosting that does not exist yet.
11. ~~Navigation is thirteen sections.~~ **Fixed in Phase 12** — six areas, every
    section kept, every deep link still resolving.
12. **Phases 10–14 deferred:** admin panels and verifier workflows (§43 P7, §86
    P10, §93 P11) need a backend and a verifier network; global, country and school
    leaderboards need a population; load, stress and soak testing (Phase 15) need
    somewhere deployed to load-test.
12. **Skill interactions (§10)** remain the v11 passive effects. Wiring them into
   the new XP funnel is a small job and belongs with Phase 5's mastery model.
