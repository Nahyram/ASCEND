/* ASCEND — bundle.js — GENERATED FILE, DO NOT EDIT.

   Built from system/src/ by build.js. Edit the modules there and run:

       npm run build

   Committed so that index.html opens with no toolchain. module-check.js fails
   the suite if this file and system/src/ disagree, so it cannot silently drift
   the way the precache list and the version string both did. */
(() => {
  // system/src/core/bus.js
  var SYSTEM_EVENTS = Object.freeze({
    GOAL_CREATED: "GOAL_CREATED",
    GOAL_COMPLETED: "GOAL_COMPLETED",
    GOAL_STEP_DONE: "GOAL_STEP_DONE",
    QUEST_CREATED: "QUEST_CREATED",
    QUEST_COMPLETED: "QUEST_COMPLETED",
    QUEST_UNCLEARED: "QUEST_UNCLEARED",
    QUEST_MISSED: "QUEST_MISSED",
    MASTERY_CHANGED: "MASTERY_CHANGED",
    ERROR_LOGGED: "ERROR_LOGGED",
    ERROR_RESOLVED: "ERROR_RESOLVED",
    MILESTONE_COMPLETED: "MILESTONE_COMPLETED",
    PROJECT_COMPLETED: "PROJECT_COMPLETED",
    EVIDENCE_ADDED: "EVIDENCE_ADDED",
    DEADLINE_APPROACHING: "DEADLINE_APPROACHING",
    OPPORTUNITY_MATCHED: "OPPORTUNITY_MATCHED",
    APPLICATION_UPDATED: "APPLICATION_UPDATED",
    STREAK_CHANGED: "STREAK_CHANGED",
    RECOVERY_STARTED: "RECOVERY_STARTED"
  });
  var Bus = /* @__PURE__ */ (() => {
    const listeners = /* @__PURE__ */ new Map();
    const anyList = [];
    const log = [];
    const MAX_LOG = 60;
    const MAX_DEPTH = 6;
    let depth = 0;
    function on(type, fn) {
      if (typeof fn !== "function") return () => {
      };
      if (!listeners.has(type)) listeners.set(type, []);
      const arr = listeners.get(type);
      arr.push(fn);
      return () => {
        const i = arr.indexOf(fn);
        if (i >= 0) arr.splice(i, 1);
      };
    }
    function onAny(fn) {
      if (typeof fn !== "function") return () => {
      };
      anyList.push(fn);
      return () => {
        const i = anyList.indexOf(fn);
        if (i >= 0) anyList.splice(i, 1);
      };
    }
    function emit(type, payload = {}) {
      const ev = { type, payload, at: Date.now(), handled: 0, errors: [] };
      if (depth >= MAX_DEPTH) {
        ev.errors.push("depth limit — refused, possible event cycle on " + type);
        if (typeof console !== "undefined") console.warn("[bus] cycle refused at " + type);
        return ev;
      }
      depth++;
      try {
        for (const fn of (listeners.get(type) || []).slice()) {
          try {
            fn(payload, ev);
            ev.handled++;
          } catch (e) {
            ev.errors.push(type + ": " + (e && e.message));
          }
        }
        for (const fn of anyList.slice()) {
          try {
            fn(ev);
          } catch (e) {
            ev.errors.push("any: " + (e && e.message));
          }
        }
      } finally {
        depth--;
      }
      log.push({ type, at: ev.at, handled: ev.handled, keys: Object.keys(payload || {}) });
      if (log.length > MAX_LOG) log.shift();
      return ev;
    }
    return {
      emit,
      on,
      onAny,
      get types() {
        return SYSTEM_EVENTS;
      },
      recent(n = 20) {
        return log.slice(-n);
      },
      /* test seam only — never called by the app */
      _reset() {
        listeners.clear();
        anyList.length = 0;
        log.length = 0;
        depth = 0;
      },
      _count(type) {
        return (listeners.get(type) || []).length;
      }
    };
  })();

  // system/src/core/hooks.js
  var Hooks = /* @__PURE__ */ (() => {
    const reg = /* @__PURE__ */ new Map();
    const failures = [];
    const MAX_FAILURES = 40;
    function add(name, kind, label, fn) {
      if (typeof fn !== "function") return () => {
      };
      if (typeof name !== "string" || !name) return () => {
      };
      if (!reg.has(name)) reg.set(name, []);
      const list = reg.get(name);
      const entry = { kind, label: String(label || "unlabelled"), fn };
      list.push(entry);
      return () => {
        const i = list.indexOf(entry);
        if (i >= 0) list.splice(i, 1);
      };
    }
    function note(name, label, kind, err) {
      failures.push({
        name,
        label,
        kind,
        message: err && err.message || String(err),
        at: Date.now()
      });
      if (failures.length > MAX_FAILURES) failures.shift();
      if (typeof console !== "undefined" && console.warn) {
        console.warn("[hooks] " + name + " · " + kind + ' "' + label + '" threw: ' + (err && err.message || err));
      }
    }
    function dispatch(name, base, thisArg, args) {
      const list = reg.get(name);
      const argv = Array.prototype.slice.call(args || []);
      if (!list || !list.length) return base.apply(thisArg, argv);
      let call = function(...a) {
        return base.apply(thisArg, a);
      };
      for (const entry of list) {
        const next = call;
        const { kind, label, fn } = entry;
        if (kind === "wrap") {
          call = function(...a) {
            try {
              return fn.call(thisArg, next, ...a);
            } catch (e) {
              note(name, label, kind, e);
              throw e;
            }
          };
        } else if (kind === "before") {
          call = function(...a) {
            try {
              fn.apply(thisArg, a);
            } catch (e) {
              note(name, label, kind, e);
              throw e;
            }
            return next(...a);
          };
        } else if (kind === "after") {
          call = function(...a) {
            const r = next(...a);
            try {
              fn.call(thisArg, r, ...a);
            } catch (e) {
              note(name, label, kind, e);
              throw e;
            }
            return r;
          };
        } else if (kind === "replace") {
          call = function(...a) {
            try {
              return fn.apply(thisArg, a);
            } catch (e) {
              note(name, label, kind, e);
              throw e;
            }
          };
        }
      }
      return call(...argv);
    }
    return {
      wrap: (name, label, fn) => add(name, "wrap", label, fn),
      before: (name, label, fn) => add(name, "before", label, fn),
      after: (name, label, fn) => add(name, "after", label, fn),
      replace: (name, label, fn) => add(name, "replace", label, fn),
      dispatch,
      list(name) {
        return (reg.get(name) || []).map((e) => ({ kind: e.kind, label: e.label }));
      },
      names() {
        return [...reg.keys()].sort();
      },
      count(name) {
        return (reg.get(name) || []).length;
      },
      failures(n = 20) {
        return failures.slice(-n);
      },
      /* test seam only — never called by the app */
      _reset() {
        reg.clear();
        failures.length = 0;
      }
    };
  })();

  // system/src/core/store.js
  var SCHEMA = 6;
  var StoreDrivers = {
    local: {
      name: "local",
      available() {
        try {
          localStorage.setItem("__t", "1");
          localStorage.removeItem("__t");
          return true;
        } catch (e) {
          return false;
        }
      },
      get(k) {
        return localStorage.getItem(k);
      },
      set(k, v) {
        localStorage.setItem(k, v);
      },
      del(k) {
        localStorage.removeItem(k);
      },
      keys() {
        return Object.keys(localStorage);
      }
    },
    /* ---------- IndexedDB ----------
         The reason to move: localStorage is capped near 5 MB per origin and, more
         importantly, every write is synchronous and serialises the entire record on
         the main thread. A fresh record is 5.8 KB, so the cap is not the pressure —
         two years of daily practice logs on a mid-range Android phone is.
    
         What this is NOT yet: the whole record is still one key, so a write is still
         all-or-nothing. Splitting it per domain is what actually fixes corruption
         granularity, and it belongs with the event log rather than here, where it
         would be a second risky change in the same release. */
    idb: {
      name: "idb",
      DB_NAME: "ascend.store",
      STORE: "kv",
      VERSION: 1,
      _cache: /* @__PURE__ */ new Map(),
      _db: null,
      _hydrated: false,
      _pending: /* @__PURE__ */ new Map(),
      _flushing: null,
      _timer: null,
      _onError: null,
      available() {
        try {
          return typeof indexedDB !== "undefined" && indexedDB !== null;
        } catch (e) {
          return false;
        }
      },
      _open() {
        if (this._db) return Promise.resolve(this._db);
        return new Promise((resolve, reject) => {
          let rq;
          try {
            rq = indexedDB.open(this.DB_NAME, this.VERSION);
          } catch (e) {
            return reject(e);
          }
          rq.onupgradeneeded = () => {
            const db = rq.result;
            if (!db.objectStoreNames.contains(this.STORE)) db.createObjectStore(this.STORE);
          };
          rq.onsuccess = () => {
            this._db = rq.result;
            resolve(this._db);
          };
          rq.onerror = () => reject(rq.error || new Error("indexedDB.open failed"));
          rq.onblocked = () => reject(new Error("indexedDB is blocked by another tab"));
        });
      },
      /* Reads every key into the synchronous cache. Until this resolves the driver
         reports nothing and refuses to flush, so a save() that races the boot
         cannot write an empty record over a real one. */
      async hydrate() {
        const db = await this._open();
        const all = await new Promise((resolve, reject) => {
          const tx = db.transaction(this.STORE, "readonly");
          const os = tx.objectStore(this.STORE);
          const out = /* @__PURE__ */ new Map();
          const rq = os.openCursor();
          rq.onsuccess = () => {
            const c = rq.result;
            if (!c) return resolve(out);
            out.set(String(c.key), c.value);
            c.continue();
          };
          rq.onerror = () => reject(rq.error || new Error("cursor failed"));
        });
        this._cache = all;
        this._hydrated = true;
        return all.size;
      },
      get(k) {
        return this._cache.has(k) ? this._cache.get(k) : null;
      },
      set(k, v) {
        this._cache.set(k, v);
        this._queue(k);
      },
      del(k) {
        this._cache.delete(k);
        this._queue(k);
      },
      keys() {
        return [...this._cache.keys()];
      },
      _queue(k) {
        this._pending.set(k, this._cache.has(k) ? this._cache.get(k) : void 0);
        if (!this._hydrated) return;
        if (this._timer) return;
        this._timer = setTimeout(() => {
          this._timer = null;
          this.flush();
        }, 0);
      },
      flush() {
        if (this._flushing) return this._flushing.then(() => this.flush());
        if (!this._hydrated || !this._pending.size) return Promise.resolve();
        const batch = this._pending;
        this._pending = /* @__PURE__ */ new Map();
        this._flushing = this._open().then((db) => new Promise((resolve, reject) => {
          const tx = db.transaction(this.STORE, "readwrite");
          const os = tx.objectStore(this.STORE);
          for (const [k, v] of batch) {
            if (v === void 0) os.delete(k);
            else os.put(v, k);
          }
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error || new Error("write failed"));
          tx.onabort = () => reject(tx.error || new Error("write aborted"));
        })).catch((e) => {
          for (const [k, v] of batch) if (!this._pending.has(k)) this._pending.set(k, v);
          if (typeof this._onError === "function") this._onError(e);
        }).finally(() => {
          this._flushing = null;
        });
        return this._flushing;
      }
    },
    /* Last resort so the app still runs in a locked-down browser. Nothing survives
       a reload, and the UI is told so rather than silently losing the hunter. */
    memory: {
      name: "memory",
      _m: /* @__PURE__ */ new Map(),
      available() {
        return true;
      },
      get(k) {
        return this._m.has(k) ? this._m.get(k) : null;
      },
      set(k, v) {
        this._m.set(k, v);
      },
      del(k) {
        this._m.delete(k);
      },
      keys() {
        return [...this._m.keys()];
      }
    }
  };
  var Store2 = (() => {
    const driver = StoreDrivers.idb.available() ? StoreDrivers.idb : StoreDrivers.local.available() ? StoreDrivers.local : StoreDrivers.memory;
    const listeners = /* @__PURE__ */ new Set();
    let lastError = null;
    let hydrating = null;
    let migratedFrom = null;
    const MIGRATED_KEY = "ascend.migrated.from.local";
    async function migrateFromLocal() {
      if (driver !== StoreDrivers.idb) return null;
      if (driver.get(MIGRATED_KEY)) return "already";
      if (!StoreDrivers.local.available()) return null;
      let keys = [];
      try {
        keys = StoreDrivers.local.keys().filter((k) => k.startsWith("system.") || k.startsWith("ascend."));
      } catch (e) {
        return null;
      }
      if (!keys.length) return null;
      const collisions = keys.filter((k) => driver.get(k) != null);
      if (collisions.length) return "skipped-existing";
      for (const k of keys) driver.set(k, StoreDrivers.local.get(k));
      driver.set(MIGRATED_KEY, (/* @__PURE__ */ new Date()).toISOString());
      await driver.flush();
      const written = await driver.hydrate();
      for (const k of keys) {
        if (driver.get(k) !== StoreDrivers.local.get(k)) {
          driver.del(MIGRATED_KEY);
          await driver.flush();
          throw new Error("migration verification failed for " + k);
        }
      }
      void written;
      return "migrated:" + keys.length;
    }
    function hydrate() {
      if (hydrating) return hydrating;
      hydrating = (async () => {
        if (driver !== StoreDrivers.idb) return { driver: driver.name, keys: driver.keys().length };
        try {
          await driver.hydrate();
          migratedFrom = await migrateFromLocal();
          return { driver: driver.name, keys: driver.keys().length, migratedFrom };
        } catch (e) {
          lastError = e;
          return { driver: driver.name, keys: 0, error: e.message, fellBack: true };
        }
      })();
      return hydrating;
    }
    function readJSON(key) {
      try {
        const raw = driver.get(key);
        return raw == null ? null : JSON.parse(raw);
      } catch (e) {
        lastError = e;
        return null;
      }
    }
    function writeJSON(key, value) {
      try {
        driver.set(key, JSON.stringify(value));
        lastError = null;
        listeners.forEach((fn) => {
          try {
            fn(key, value);
          } catch (e) {
          }
        });
        return { ok: true };
      } catch (e) {
        lastError = e;
        return { ok: false, error: e };
      }
    }
    const MIGRATIONS = {
      1: (rec) => {
        for (const h of Object.values(rec.hunters || {})) {
          if (!h.brain) h.brain = { decisions: [], snoozed: {}, recovery: null, lastBrief: null, lastReview: null };
          if (!h.focusLog) h.focusLog = {};
          if (Array.isArray(h.goals)) {
            for (const g of h.goals) {
              if (!g.horizon) g.horizon = "month";
              if (!("due" in g)) g.due = null;
              if (!("parent" in g)) g.parent = null;
            }
          }
        }
        return rec;
      },
      2: (rec) => {
        for (const h of Object.values(rec.hunters || {})) {
          if (!h.academy) h.academy = {
            qualification: h.curriculum || "",
            subjects: [],
            questions: [],
            cards: [],
            errors: [],
            sessions: [],
            exams: [],
            grades: []
          };
        }
        return rec;
      },
      3: (rec) => {
        for (const h of Object.values(rec.hunters || {})) {
          if (!h.cloud) h.cloud = {
            mode: "local",
            account: null,
            token: null,
            queue: [],
            rev: 0,
            serverRev: 0,
            lastSync: null,
            lastError: null,
            settings: { auto: true, wifiOnly: false, include: { progress: true, academy: true, projects: true } }
          };
          if (!h.opportunities) h.opportunities = { items: [], activities: [], challenges: [], ignored: [] };
          if (!h.projects) h.projects = { items: [], portfolio: { about: "", headline: "", sections: [], theme: "minimal", visibility: "private" } };
          if (!h.apiCfg) h.apiCfg = { proxyBase: "", keys: {} };
        }
        return rec;
      },
      4: (rec) => {
        for (const h of Object.values(rec.hunters || {})) {
          if (!h.circle) h.circle = { groups: [], pacts: [], reports: [] };
          if (!h.prefs) h.prefs = {};
        }
        return rec;
      },
      5: (rec) => {
        for (const h of Object.values(rec.hunters || {})) {
          if (!Array.isArray(h.quests)) continue;
          for (const q of h.quests) if (q.link && typeof q.link !== "object") delete q.link;
        }
        return rec;
      }
    };
    function migrate(rec) {
      if (!rec || typeof rec !== "object") return rec;
      let v = Number(rec.schema) || 1;
      while (v < SCHEMA && MIGRATIONS[v]) {
        try {
          rec = MIGRATIONS[v](rec) || rec;
        } catch (e) {
          break;
        }
        v++;
      }
      rec.schema = Math.max(v, Number(rec.schema) || 1);
      return rec;
    }
    if (typeof addEventListener === "function" && driver === StoreDrivers.idb) {
      addEventListener("pagehide", () => {
        try {
          driver.flush();
        } catch (e) {
        }
      });
      addEventListener("visibilitychange", () => {
        try {
          if (document.visibilityState === "hidden") driver.flush();
        } catch (e) {
        }
      });
    }
    if (driver === StoreDrivers.idb) {
      driver._onError = (e) => {
        lastError = e;
        if (typeof toast === "function") toast("Could not save", "Your work is still on screen. ASCEND will keep retrying.", "blood");
      };
    }
    return {
      get driver() {
        return driver.name;
      },
      get durable() {
        return driver.name !== "memory";
      },
      get lastError() {
        return lastError;
      },
      get ready() {
        return driver !== StoreDrivers.idb || driver._hydrated;
      },
      get migratedFrom() {
        return migratedFrom;
      },
      hydrate,
      flush: () => driver === StoreDrivers.idb ? driver.flush() : Promise.resolve(),
      readJSON,
      writeJSON,
      migrate,
      remove: (k) => {
        try {
          driver.del(k);
        } catch (e) {
        }
      },
      keys: () => {
        try {
          return driver.keys();
        } catch (e) {
          return [];
        }
      },
      subscribe(fn) {
        listeners.add(fn);
        return () => listeners.delete(fn);
      },
      /* rough usage figure for Settings — localStorage has no quota API */
      bytes() {
        try {
          return driver.keys().reduce((n, k) => n + (driver.get(k) || "").length + k.length, 0);
        } catch (e) {
          return 0;
        }
      }
    };
  })();

  // system/src/core/kernel.js
  var LS = "system.v1";
  var $ = (s) => document.querySelector(s);
  var $$ = (s) => [...document.querySelectorAll(s)];
  var pad = (n) => String(n).padStart(2, "0");
  var todayKey = (d = /* @__PURE__ */ new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  var dateFromKey = (k) => {
    const [y, m, d] = String(k).split("-").map(Number);
    return y && m && d ? new Date(y, m - 1, d, 12, 0, 0) : /* @__PURE__ */ new Date(NaN);
  };
  var DEFAULT_AVATAR = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' fill='%230a1424'/><text x='50' y='64' font-size='42' text-anchor='middle' fill='%2338d6ff' font-family='monospace'>?</text></svg>";
  var DB2 = load();
  function load() {
    try {
      const r = Store2.readJSON(LS);
      if (r && r.hunters) {
        r.store = r.store || {};
        if (typeof r.store.countEndpoint !== "string") r.store.countEndpoint = "";
        r.sec = r.sec || { fails: {}, until: {} };
        if (!r.installId) r.installId = [...crypto.getRandomValues(new Uint8Array(12))].map((b) => b.toString(16).padStart(2, "0")).join("");
        return Store2.migrate(r);
      }
    } catch (e) {
    }
    return Store2.migrate({
      schema: SCHEMA,
      hunters: {},
      active: null,
      store: { payLink: "", blurb: "The System is built by an independent creator. If it's changing how your day runs, you can back it.", countEndpoint: "" },
      sec: { fails: {}, until: {} },
      installId: [...crypto.getRandomValues(new Uint8Array(12))].map((b) => b.toString(16).padStart(2, "0")).join("")
    });
  }
  function save() {
    if (typeof guardedSave === "function") {
      const g = guardedSave(DB2);
      if (!g.ok && typeof toast === "function") toast("Could not save", g.message, "blood");
      return g.ok;
    }
    const r = Store2.writeJSON(LS, DB2);
    if (!r.ok && typeof toast === "function") toast("Storage full", "Free up space or export your hunter file.", "blood");
    return r.ok;
  }
  var H = () => DB2.hunters[DB2.active];
  var SYSTEM_READY = (typeof Store2 !== "undefined" && Store2.hydrate ? Store2.hydrate() : Promise.resolve({ driver: "local" })).then((info) => {
    if (info && info.driver === "idb" && !info.fellBack) DB2 = load();
    return info;
  }).catch(() => ({ driver: "unknown", error: true }));

  // system/src/armory.js
  var Armory = (function() {
    const dv = (b) => new DataView(b);
    const u16 = (v, o) => v.getUint16(o, true);
    const u32 = (v, o) => v.getUint32(o, true);
    const u64 = (v, o) => {
      const lo = v.getUint32(o, true), hi = v.getUint32(o + 4, true);
      return hi * 4294967296 + lo;
    };
    const dec = (buf, utf8) => new TextDecoder(utf8 ? "utf-8" : "windows-1252", { fatal: false }).decode(buf);
    const baseName = (p) => String(p).split("/").pop();
    const extOf = (p) => {
      const n = baseName(p);
      const i = n.lastIndexOf(".");
      return i > 0 ? n.slice(i + 1).toLowerCase() : "";
    };
    const fmtBytes = (n) => {
      if (!n && n !== 0) return "—";
      const u = ["B", "KB", "MB", "GB", "TB"];
      let i = 0, x = n;
      while (x >= 1024 && i < u.length - 1) {
        x /= 1024;
        i++;
      }
      return (x >= 10 || i === 0 ? Math.round(x) : x.toFixed(1)) + " " + u[i];
    };
    const SIG_EOCD = 101010256;
    const SIG_Z64_LOC = 117853008;
    const SIG_Z64_EOD = 101075792;
    const SIG_CDH = 33639248;
    const SIG_LFH = 67324752;
    async function slice(file, start, end) {
      return new Uint8Array(await file.slice(start, end).arrayBuffer());
    }
    async function findEOCD(file) {
      const maxTail = Math.min(file.size, 65557 + 64);
      const tail = await slice(file, file.size - maxTail, file.size);
      const v = dv(tail.buffer);
      for (let i = tail.length - 22; i >= 0; i--) {
        if (u32(v, i) === SIG_EOCD) {
          return { buf: tail, off: i, base: file.size - maxTail };
        }
      }
      return null;
    }
    async function readZipIndex(file, onProgress) {
      if (file.size < 22) throw new Error("File is too small to be a zip archive.");
      const eocd = await findEOCD(file);
      if (!eocd) throw new Error("No zip directory found. If this is a .rar or .7z, unzip it first — the browser can only read .zip.");
      const v = dv(eocd.buf.buffer);
      let count = u16(v, eocd.off + 10);
      let cdSize = u32(v, eocd.off + 12);
      let cdStart = u32(v, eocd.off + 16);
      let zip64 = false;
      const locAbs = eocd.base + eocd.off - 20;
      if (locAbs >= 0 && (count === 65535 || cdSize === 4294967295 || cdStart === 4294967295)) {
        const loc = await slice(file, locAbs, locAbs + 20);
        const lv = dv(loc.buffer);
        if (u32(lv, 0) === SIG_Z64_LOC) {
          const eodOff = u64(lv, 8);
          const eod = await slice(file, eodOff, eodOff + 56);
          const ev = dv(eod.buffer);
          if (u32(ev, 0) === SIG_Z64_EOD) {
            zip64 = true;
            count = u64(ev, 32);
            cdSize = u64(ev, 40);
            cdStart = u64(ev, 48);
          }
        }
      }
      if (!isFinite(cdStart) || cdStart < 0 || cdStart > file.size) throw new Error("The zip directory points outside the file. The archive looks truncated or corrupt.");
      if (cdSize > 256 * 1024 * 1024) throw new Error("This archive's directory alone is over 256 MB. That is far past anything a browser should hold.");
      const cd = await slice(file, cdStart, cdStart + cdSize);
      const cv = dv(cd.buffer);
      const entries = [];
      let p = 0, n = 0;
      while (p + 46 <= cd.length) {
        if (u32(cv, p) !== SIG_CDH) break;
        const flags = u16(cv, p + 8);
        const method = u16(cv, p + 10);
        const mtime = u16(cv, p + 12), mdate = u16(cv, p + 14);
        const crc = u32(cv, p + 16);
        let csize = u32(cv, p + 20);
        let usize = u32(cv, p + 24);
        const nLen = u16(cv, p + 28);
        const eLen = u16(cv, p + 30);
        const cLen = u16(cv, p + 32);
        const attrs = u32(cv, p + 38);
        let lho = u32(cv, p + 42);
        const nameBuf = cd.subarray(p + 46, p + 46 + nLen);
        const name = dec(nameBuf, (flags & 2048) !== 0);
        let ep = p + 46 + nLen;
        const eEnd = ep + eLen;
        while (ep + 4 <= eEnd) {
          const hid = u16(cv, ep), hsz = u16(cv, ep + 2);
          if (hid === 1) {
            let q = ep + 4;
            if (usize === 4294967295 && q + 8 <= eEnd) {
              usize = u64(cv, q);
              q += 8;
            }
            if (csize === 4294967295 && q + 8 <= eEnd) {
              csize = u64(cv, q);
              q += 8;
            }
            if (lho === 4294967295 && q + 8 <= eEnd) {
              lho = u64(cv, q);
              q += 8;
            }
          }
          ep += 4 + hsz;
        }
        const isDir = name.endsWith("/") || (attrs & 16) !== 0 && usize === 0;
        if (!isDir && name) {
          entries.push({
            name,
            size: usize,
            csize,
            method,
            crc,
            off: lho,
            enc: (flags & 1) !== 0,
            /* entry is password-protected */
            date: dosDate(mdate, mtime)
          });
        }
        p = ep + cLen;
        n++;
        if (onProgress && n % 2e3 === 0) onProgress(n, count);
        if (n > 4e5) break;
      }
      return { entries, zip64, declared: count, cdSize };
    }
    function dosDate(d, t) {
      try {
        const y = 1980 + (d >> 9 & 127), mo = d >> 5 & 15, da = d & 31;
        return new Date(y, Math.max(0, mo - 1), Math.max(1, da), t >> 11 & 31, t >> 5 & 63).getTime();
      } catch (e) {
        return 0;
      }
    }
    async function extractEntry(file, entry, capBytes) {
      const cap = capBytes || 64 * 1024 * 1024;
      if (entry.size > cap) throw new Error("That file is " + fmtBytes(entry.size) + ". Open it from the original archive on your device instead — the browser should not hold it in memory.");
      if (entry.enc) throw new Error("That entry is password-protected inside the zip. The System cannot open it.");
      const head = await slice(file, entry.off, entry.off + 30);
      const hv = dv(head.buffer);
      if (u32(hv, 0) !== SIG_LFH) throw new Error("Local header missing — the archive may be damaged.");
      const nLen = u16(hv, 26), eLen = u16(hv, 28);
      const start = entry.off + 30 + nLen + eLen;
      const raw = await slice(file, start, start + entry.csize);
      if (entry.method === 0) return raw;
      if (entry.method === 8) {
        if (typeof DecompressionStream === "undefined") throw new Error("This browser cannot decompress zip entries. Chrome, Edge or Safari 16.4+ can.");
        const ds = new DecompressionStream("deflate-raw");
        const out = new Response(new Blob([raw]).stream().pipeThrough(ds));
        return new Uint8Array(await out.arrayBuffer());
      }
      throw new Error("Compression method " + entry.method + " is not supported (only store and deflate are).");
    }
    async function pickDirectory() {
      if (!window.showDirectoryPicker) throw new Error("This browser has no folder picker. Use Chrome or Edge on desktop or Android — or drop a .zip instead, which works everywhere.");
      return await window.showDirectoryPicker({ id: "system-armory", mode: "read" });
    }
    async function walkDirectory(dirHandle, onProgress, limit) {
      const cap = limit || 6e4;
      const out = [];
      async function rec(handle, path, depth) {
        if (out.length >= cap || depth > 12) return;
        for await (const [name, h] of handle.entries()) {
          if (out.length >= cap) return;
          const p = path ? path + "/" + name : name;
          if (h.kind === "directory") {
            await rec(h, p, depth + 1);
          } else {
            let size = 0, date = 0;
            try {
              const f = await h.getFile();
              size = f.size;
              date = f.lastModified;
            } catch (e) {
            }
            out.push({ name: p, size, date, handleName: name, dirPath: path });
            if (onProgress && out.length % 250 === 0) onProgress(out.length);
          }
        }
      }
      await rec(dirHandle, "", 0);
      return out;
    }
    function fromFileList(list) {
      return [...list].map((f) => ({
        name: f.webkitRelativePath || f.name,
        size: f.size,
        date: f.lastModified,
        file: f
      }));
    }
    const SUBJECTS = [
      ["further_maths", "Further Mathematics", ["further mathematics", "further maths", "further math", "f-maths", "fmaths"], ["9231", "0606", "4037"]],
      ["maths", "Mathematics", ["mathematics", "maths", "math", "algebra", "calculus", "trigonometry", "geometry", "statistics", "core math", "elective math", "additional math", "add maths", "pure math", "mechanics"], ["0580", "0581", "4024", "9709", "0607"]],
      ["physics", "Physics", ["physics", "phy"], ["0625", "0972", "9702", "5054"]],
      ["chemistry", "Chemistry", ["chemistry", "chem"], ["0620", "0971", "9701", "5070"]],
      ["biology", "Biology", ["biology", "bio"], ["0610", "0970", "9700", "5090"]],
      ["science", "Combined / Integrated Science", ["combined science", "coordinated science", "integrated science", "general science", "physical science"], ["0653", "0654", "0973"]],
      ["eng_lang", "English Language", ["english language", "english lang", "use of english", "first language english", "esl", "english as a second"], ["0500", "0510", "0511", "1123", "8021"]],
      ["eng_lit", "English Literature", ["english literature", "literature in english", "lit in english", "literature"], ["0475", "0486", "0992", "9695"]],
      ["ict", "ICT & Computing", ["information and communication", "information technology", "computer science", "computing", "ict", "programming", "python", "coding"], ["0417", "0418", "0478", "2210", "9618", "9608"]],
      ["econ", "Economics", ["economics", "econ", "microeconomics", "macroeconomics"], ["0455", "2281", "9708"]],
      ["business", "Business Studies", ["business studies", "business management", "business", "entrepreneurship"], ["0450", "0986", "7115", "9609"]],
      ["accounting", "Accounting", ["accounting", "accounts", "financial accounting", "cost accounting", "principles of accounts"], ["0452", "7110", "9706"]],
      ["geography", "Geography", ["geography", "geog"], ["0460", "0976", "2217", "9696"]],
      ["history", "History", ["history", "hist"], ["0470", "0977", "2147", "9489"]],
      ["government", "Government & Politics", ["government", "politics", "civic education", "civics"], ["9787"]],
      ["social", "Social Studies", ["social studies", "sociology"], ["0495", "9699"]],
      ["religion", "Religious Studies", ["religious studies", "religious education", "christian religious", "islamic studies", "rme", "crs", "ire", "bible knowledge"], ["0490", "2058", "9011"]],
      ["french", "French", ["french", "francais", "français"], ["0520", "7156", "9716"]],
      ["spanish", "Spanish", ["spanish", "espanol", "español"], ["0530", "7160", "9719"]],
      ["german", "German", ["german", "deutsch"], ["0525", "7159"]],
      ["chinese", "Chinese", ["chinese", "mandarin"], ["0547", "0509"]],
      ["ghana_lang", "Ghanaian Language", ["twi", "asante twi", "akuapem", "fante", "ewe", "ga ", "dagbani", "dagaare", "nzema", "gonja", "kasem"], []],
      ["art", "Art & Design", ["art and design", "art & design", "fine art", "visual art", "graphic design", "drawing"], ["0400", "0989", "9479"]],
      ["music", "Music", ["music", "theory of music"], ["0410", "0978", "9483"]],
      ["drama", "Drama & Theatre", ["drama", "theatre", "theater", "performing art"], ["0411", "9482"]],
      ["pe", "Physical Education", ["physical education", "p.e.", "sport science"], ["0413", "9396"]],
      ["psych", "Psychology", ["psychology", "psych"], ["0500p", "9990"]],
      ["food", "Food & Nutrition", ["food and nutrition", "food & nutrition", "home economics", "catering", "management in living"], ["0648", "6065"]],
      ["design_tech", "Design & Technology", ["design and technology", "technical drawing", "engineering drawing", "woodwork", "metalwork", "building construction", "applied electricity"], ["0445", "0979", "9705"]],
      ["global", "Global Perspectives", ["global perspectives", "global perspective", "world issues"], ["0457", "9239"]],
      ["agric", "Agricultural Science", ["agricultural science", "agriculture", "agric", "general agriculture"], ["0600", "5038"]],
      ["env", "Environmental Management", ["environmental management", "environmental science"], ["0680", "8291"]],
      ["sat", "SAT / Standardised Tests", ["sat ", "digital sat", "psat", "act ", "gre ", "ielts", "toefl"], []]
    ];
    const SUBJ_TERMS = (() => {
      const rows = [];
      SUBJECTS.forEach(([key, , terms, codes]) => {
        terms.forEach((t) => rows.push([t, key, t.length + 100]));
        (codes || []).forEach((c) => rows.push([c, key, c.length + 300]));
      });
      return rows.sort((a, b) => b[2] - a[2]);
    })();
    const SUBJ_LABEL = Object.fromEntries(SUBJECTS.map(([k, l]) => [k, l]));
    SUBJ_LABEL.unsorted = "Unsorted";
    function detectSubject(path) {
      const hay = " " + String(path).toLowerCase().replace(/[_\-.]/g, " ").replace(/\s+/g, " ") + " ";
      for (const [term, key] of SUBJ_TERMS) {
        if (/^\d{4}$/.test(term)) {
          if (new RegExp("(^|[^0-9])" + term + "([^0-9]|$)").test(hay)) return key;
        } else if (hay.includes(" " + term.trim() + " ") || hay.includes(term)) {
          return key;
        }
      }
      return "unsorted";
    }
    const VIDEO_EXT = ["mp4", "mkv", "avi", "mov", "webm", "m4v", "flv", "wmv", "mpg", "mpeg", "3gp", "ts", "ogv"];
    const AUDIO_EXT = ["mp3", "m4a", "wav", "ogg", "aac", "flac", "opus", "wma"];
    const DOC_EXT = ["pdf", "doc", "docx", "odt", "rtf", "txt", "md", "ppt", "pptx", "odp", "xls", "xlsx", "csv", "epub", "mobi", "djvu", "pages", "key", "numbers"];
    const IMG_EXT = ["jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "tif", "tiff", "svg"];
    const CIE_RE = /\b(\d{4})[_\- ]?([wsm])(\d{2})[_\- ]?(qp|ms|in|ci|er|gt|sy|sf|sm|sp|rp|tn|pm)[_\- ]?(\d{1,2})?\b/i;
    const PAPER_KIND = {
      qp: "Question paper",
      ms: "Mark scheme",
      in: "Insert",
      ci: "Confidential instructions",
      er: "Examiner report",
      gt: "Grade thresholds",
      sy: "Syllabus",
      sf: "Source",
      sm: "Specimen",
      sp: "Specimen paper",
      rp: "Resource",
      tn: "Teacher notes",
      pm: "Mark scheme"
    };
    const SESSION = { m: "Feb/March", s: "May/June", w: "Oct/Nov" };
    const SESSION_ORDER = { m: 1, s: 2, w: 3 };
    function detectType(path) {
      const p = String(path).toLowerCase();
      const e = extOf(p);
      if (VIDEO_EXT.includes(e)) return "video";
      if (AUDIO_EXT.includes(e)) return "audio";
      const cie = p.match(CIE_RE);
      if (cie) return cie[4].toLowerCase() === "sy" ? "syllabus" : "past";
      if (/\b(past ?papers?|question ?papers?|mark ?scheme|marking ?scheme|examiner ?report|exam ?paper|pastq|past q|wassce|waec|neco|jamb|may ?june|oct ?nov|november \d{4}|june \d{4})\b/.test(p)) return "past";
      if (/\b(syllabus|specification|scheme of work|curriculum|course outline)\b/.test(p)) return "syllabus";
      if (/\b(textbook|coursebook|course book|student book|students book|workbook|revision guide|study guide|endorsed|edition)\b/.test(p) || e === "epub" || e === "mobi" || e === "djvu") return "book";
      if (/\b(flash ?cards?|anki|quizlet|mcq|quiz|test yourself)\b/.test(p)) return "flash";
      if (DOC_EXT.includes(e) || IMG_EXT.includes(e)) return "notes";
      return "other";
    }
    const TYPE_LABEL = {
      notes: "Notes",
      past: "Past papers",
      video: "Videos",
      audio: "Audio",
      book: "Textbooks",
      syllabus: "Syllabus",
      flash: "Flashcards & quizzes",
      other: "Other files"
    };
    const TYPE_ORDER = ["notes", "past", "video", "audio", "book", "syllabus", "flash", "other"];
    function detectPaperMeta(path) {
      const p = String(path);
      const m = p.match(CIE_RE);
      if (m) {
        const yy = parseInt(m[3], 10);
        return {
          code: m[1],
          year: yy + (yy > 60 ? 1900 : 2e3),
          session: m[2].toLowerCase(),
          kind: (m[4] || "").toLowerCase(),
          paper: m[5] ? parseInt(m[5], 10) : null
        };
      }
      const out = { code: null, year: null, session: null, kind: null, paper: null };
      const y = p.match(/\b(19[89]\d|20[0-4]\d)\b/);
      if (y) out.year = parseInt(y[1], 10);
      const low = p.toLowerCase();
      if (/\b(may|june|jun|summer)\b/.test(low)) out.session = "s";
      else if (/\b(oct|nov|winter)\b/.test(low)) out.session = "w";
      else if (/\b(feb|mar|march)\b/.test(low)) out.session = "m";
      if (/\bmark ?scheme|\bms\b|answers?\b/.test(low)) out.kind = "ms";
      else if (/\bquestion ?paper|\bqp\b/.test(low)) out.kind = "qp";
      const pn = low.match(/\bpaper ?(\d{1,2})\b/);
      if (pn) out.paper = parseInt(pn[1], 10);
      return out;
    }
    function sortPapers(rows, oldestFirst) {
      const dir = oldestFirst ? 1 : -1;
      return rows.slice().sort((a, b) => {
        const ay = a.meta.year || 0, by = b.meta.year || 0;
        if (ay !== by) return (ay - by) * dir;
        const as = SESSION_ORDER[a.meta.session] || 0, bs = SESSION_ORDER[b.meta.session] || 0;
        if (as !== bs) return (as - bs) * dir;
        const ap = a.meta.paper || 99, bp = b.meta.paper || 99;
        if (ap !== bp) return ap - bp;
        const rank = (k) => k === "qp" ? 0 : k === "in" ? 1 : k === "ms" ? 2 : k === "er" ? 3 : 4;
        const ar = rank(a.meta.kind), br = rank(b.meta.kind);
        if (ar !== br) return ar - br;
        return a.name.localeCompare(b.name);
      });
    }
    const EXEC_EXT = [
      "exe",
      "msi",
      "bat",
      "cmd",
      "com",
      "scr",
      "pif",
      "cpl",
      "vbs",
      "vbe",
      "js",
      "jse",
      "wsf",
      "wsh",
      "ps1",
      "psm1",
      "psd1",
      "sh",
      "bash",
      "jar",
      "apk",
      "app",
      "dmg",
      "deb",
      "rpm",
      "dll",
      "sys",
      "lnk",
      "reg",
      "hta",
      "gadget",
      "inf",
      "ade",
      "adp",
      "chm",
      "msc",
      "msp",
      "mst",
      "ocx",
      "paf",
      "pol",
      "scf",
      "vb",
      "vxd",
      "ws"
    ];
    const MACRO_EXT = ["docm", "xlsm", "pptm", "dotm", "xltm", "potm", "xlam", "ppam", "xll", "xlsb"];
    const ARCH_EXT = ["zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso", "cab", "tgz", "z", "arj", "ace", "img"];
    const RTL_RE = /[\u202A-\u202E\u2066-\u2069\u200E\u200F]/;
    function wardCheck(entry) {
      const flags = [];
      const name = baseName(entry.name);
      const low = name.toLowerCase();
      const e = extOf(name);
      const path = String(entry.name);
      if (EXEC_EXT.includes(e))
        flags.push({ sev: "block", code: "executable", msg: "Executable or script file (." + e + "). Study material is never an executable." });
      if (MACRO_EXT.includes(e))
        flags.push({ sev: "warn", code: "macro", msg: "Macro-enabled Office file. Open with macros disabled, or ask for a plain ." + e.replace("m", "x") + "." });
      const parts = low.split(".");
      if (parts.length > 2) {
        const inner = parts[parts.length - 2];
        if ([...DOC_EXT, ...IMG_EXT, ...VIDEO_EXT].includes(inner) && (EXEC_EXT.includes(e) || ARCH_EXT.includes(e)))
          flags.push({ sev: "block", code: "double-ext", msg: "Disguised name: looks like a ." + inner + " but is actually a ." + e + "." });
      }
      if (RTL_RE.test(name))
        flags.push({ sev: "block", code: "rtl", msg: "Filename contains direction-override characters — used to hide a real extension." });
      if (path.includes("../") || path.includes("..\\") || /^([a-z]:[\\/]|[\\/])/i.test(path))
        flags.push({ sev: "block", code: "traversal", msg: "Entry path escapes the archive folder (zip-slip). Malformed or hostile archive." });
      if (ARCH_EXT.includes(e))
        flags.push({ sev: "note", code: "nested", msg: "Nested archive — the Ward cannot see inside it. Unpack and re-scan if you need it." });
      if (entry.enc)
        flags.push({ sev: "warn", code: "encrypted", msg: "Password-protected entry. Encrypted contents cannot be inspected." });
      if (entry.csize > 0 && entry.size > 50 * 1024 * 1024) {
        const ratio = entry.size / entry.csize;
        if (ratio > 200)
          flags.push({ sev: "block", code: "bomb", msg: "Compression ratio " + Math.round(ratio) + ":1 on " + fmtBytes(entry.size) + " — the signature of a decompression bomb." });
      }
      if (entry.size === 0)
        flags.push({ sev: "note", code: "empty", msg: "Empty file." });
      const sev = flags.some((f) => f.sev === "block") ? "block" : flags.some((f) => f.sev === "warn") ? "warn" : flags.length ? "note" : "clean";
      return { sev, flags };
    }
    const MAGIC = [
      [[37, 80, 68, 70], "pdf"],
      [[80, 75, 3, 4], "zip"],
      /* also docx/xlsx/pptx/epub */
      [[255, 216, 255], "jpg"],
      [[137, 80, 78, 71], "png"],
      [[71, 73, 70, 56], "gif"],
      [[82, 73, 70, 70], "riff"],
      [[26, 69, 223, 163], "mkv"],
      [[208, 207, 17, 224], "ole"],
      /* legacy doc/xls/ppt */
      [[77, 90], "exe"],
      /* MZ — Windows PE */
      [[127, 69, 76, 70], "elf"],
      /* Linux binary */
      [[202, 254, 186, 190], "macho"],
      [[35, 33], "shebang"]
    ];
    const ZIP_FAMILY = ["zip", "docx", "xlsx", "pptx", "docm", "xlsm", "pptm", "epub", "odt", "ods", "odp", "apk", "jar", "kmz"];
    const OLE_FAMILY = ["doc", "xls", "ppt", "msi", "msg"];
    const EICAR = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*";
    function sniff(bytes) {
      for (const [sig, kind] of MAGIC) {
        if (sig.every((b, i) => bytes[i] === b)) return kind;
      }
      const head = new TextDecoder("utf-8", { fatal: false }).decode(bytes.subarray(0, 512)).toLowerCase();
      if (head.includes("<?xml") && head.includes("<svg")) return "svg";
      if (head.includes("<!doctype html") || head.includes("<html")) return "html";
      return "unknown";
    }
    function deepCheck(name, head) {
      const flags = [];
      const e = extOf(name);
      const kind = sniff(head);
      const text = new TextDecoder("utf-8", { fatal: false }).decode(head);
      const low = text.toLowerCase();
      const expect = ZIP_FAMILY.includes(e) ? "zip" : OLE_FAMILY.includes(e) ? "ole" : e === "jpeg" ? "jpg" : e;
      if (kind === "exe" || kind === "elf" || kind === "macho" || kind === "shebang") {
        if (!EXEC_EXT.includes(e))
          flags.push({ sev: "block", code: "masquerade", msg: "File is a compiled program or script, not a ." + e + ". Do not open it." });
      } else if (kind !== "unknown" && expect && kind !== expect && !(kind === "riff" && ["wav", "avi", "webp"].includes(e))) {
        flags.push({ sev: "warn", code: "mismatch", msg: "Contents look like " + kind.toUpperCase() + " but the name says ." + e + "." });
      }
      if (e === "pdf" || kind === "pdf") {
        if (/\/javascript|\/js\b/i.test(text)) flags.push({ sev: "warn", code: "pdf-js", msg: "PDF contains embedded JavaScript." });
        if (/\/openaction/i.test(text)) flags.push({ sev: "warn", code: "pdf-auto", msg: "PDF runs an action on open." });
        if (/\/launch|\/embeddedfile/i.test(text)) flags.push({ sev: "warn", code: "pdf-launch", msg: "PDF can launch a file or carries an attachment." });
      }
      if (kind === "svg" || kind === "html" || ["svg", "html", "htm", "xhtml"].includes(e)) {
        if (low.includes("<script") || /on(load|error|click)\s*=/.test(low))
          flags.push({ sev: "warn", code: "active-html", msg: "Page contains scripts. The System renders it as plain text only." });
      }
      if (text.includes(EICAR))
        flags.push({ sev: "block", code: "eicar", msg: "EICAR antivirus test file detected. Harmless by design — and proof the Ward is reading bytes." });
      return { kind, flags };
    }
    function buildIndex(rows, source) {
      const files = [];
      let blocked = 0, warned = 0;
      rows.forEach((r, i) => {
        const w = wardCheck(r);
        const rec = {
          i,
          name: r.name,
          base: baseName(r.name),
          ext: extOf(r.name),
          size: r.size || 0,
          date: r.date || 0,
          subject: detectSubject(r.name),
          type: detectType(r.name),
          meta: detectPaperMeta(r.name),
          ward: w.sev,
          flags: w.flags,
          off: r.off,
          csize: r.csize,
          method: r.method,
          enc: r.enc,
          dirPath: r.dirPath
        };
        if (w.sev === "block") {
          blocked++;
          rec.quarantine = true;
        } else if (w.sev === "warn") warned++;
        files.push(rec);
      });
      const bySubject = {};
      files.forEach((f) => {
        if (f.quarantine) return;
        const s = bySubject[f.subject] = bySubject[f.subject] || {};
        (s[f.type] = s[f.type] || []).push(f);
      });
      Object.values(bySubject).forEach((groups) => {
        Object.keys(groups).forEach((t) => {
          groups[t] = t === "past" ? sortPapers(groups[t], false) : groups[t].sort((a, b) => a.base.localeCompare(b.base, void 0, { numeric: true }));
        });
      });
      const totalBytes = files.reduce((n, f) => n + (f.size || 0), 0);
      return {
        source,
        created: Date.now(),
        files,
        bySubject,
        stats: {
          count: files.length,
          bytes: totalBytes,
          blocked,
          warned,
          subjects: Object.keys(bySubject).length
        }
      };
    }
    const DBN = "system-armory", STORE = "kv";
    function idb() {
      return new Promise((res, rej) => {
        const rq = indexedDB.open(DBN, 1);
        rq.onupgradeneeded = () => {
          rq.result.createObjectStore(STORE);
        };
        rq.onsuccess = () => res(rq.result);
        rq.onerror = () => rej(rq.error);
      });
    }
    async function kvSet(k, v) {
      const d = await idb();
      return new Promise((res, rej) => {
        const tx = d.transaction(STORE, "readwrite");
        tx.objectStore(STORE).put(v, k);
        tx.oncomplete = () => res(true);
        tx.onerror = () => rej(tx.error);
      });
    }
    async function kvGet(k) {
      const d = await idb();
      return new Promise((res, rej) => {
        const tx = d.transaction(STORE, "readonly");
        const rq = tx.objectStore(STORE).get(k);
        rq.onsuccess = () => res(rq.result);
        rq.onerror = () => rej(rq.error);
      });
    }
    async function kvDel(k) {
      const d = await idb();
      return new Promise((res, rej) => {
        const tx = d.transaction(STORE, "readwrite");
        tx.objectStore(STORE).delete(k);
        tx.oncomplete = () => res(true);
        tx.onerror = () => rej(tx.error);
      });
    }
    return {
      readZipIndex,
      extractEntry,
      pickDirectory,
      walkDirectory,
      fromFileList,
      detectSubject,
      detectType,
      detectPaperMeta,
      sortPapers,
      wardCheck,
      deepCheck,
      sniff,
      buildIndex,
      kvSet,
      kvGet,
      kvDel,
      SUBJECTS,
      SUBJ_LABEL,
      TYPE_LABEL,
      TYPE_ORDER,
      PAPER_KIND,
      SESSION,
      VIDEO_EXT,
      EXEC_EXT,
      fmtBytes,
      baseName,
      extOf
    };
  })();

  // system/src/core/seeds.js
  var WD = [1, 2, 3, 4, 5];
  var ALLD = [0, 1, 2, 3, 4, 5, 6];
  function founderSeed() {
    const q = (time, name, cat, days, mand = false, xp = null) => ({ id: uid(), time, name, cat, days, mand, xp: xp ?? (mand ? 25 : 15) });
    return [
      q("06:00", "Wake Up — the grind claims the morning", "discipline", ALLD, true, 30),
      q("06:20", "Exercise — a founder needs a body that keeps up", "body", ALLD, false, 20),
      q("10:00", "Deep Build — weekend product sprint (2 hrs)", "mind", [0, 6], false, 35),
      q("16:00", "Learn — programming · AI · marketing (1 hr)", "mind", ALLD, true, 25),
      q("17:15", "Build — create or improve one product (1 hr)", "mind", ALLD, true, 30),
      q("18:30", "Share — post one useful thing online (30 min)", "discipline", ALLD, true, 20),
      q("19:15", "Listen — talk to or observe one student customer", "mind", [2, 4, 6], false, 20),
      q("20:30", "Ship Log — journal what moved the business today", "discipline", ALLD, false, 15),
      q("21:45", "Bedtime — founders who sleep outbuild founders who don't", "rest", ALLD, true, 20)
    ];
  }
  function founderDeadlines() {
    const dl = (name, inDays, weight) => {
      const d = /* @__PURE__ */ new Date();
      d.setDate(d.getDate() + inDays);
      return { id: uid(), name, date: todayKey(d), weight: String(weight) };
    };
    return [
      dl("Foundation: brand name chosen", 3, 2),
      dl("Foundation: mission written in one sentence", 3, 2),
      dl("Foundation: target customer defined", 5, 2),
      dl("Foundation: product ladder mapped (free → paid → premium)", 7, 3),
      dl("Foundation: content strategy — one channel picked", 9, 2),
      dl("Foundation: sales system — payment link live", 12, 3),
      dl("Foundation: growth system — weekly review slot set", 14, 1),
      dl("90-Day: tools mastered — AI chat · Canva · Docs", 14, 1),
      dl("90-Day: store live (Selar / Payhip / Gumroad) with adult payout set up", 21, 3),
      dl("90-Day: first 10 products listed", 28, 3),
      dl("90-Day: Exam Success Bundle launched", 45, 2),
      dl("90-Day: catalog at 25 quality products", 60, 2),
      dl("90-Day: 12 short videos posted (TikTok / Shorts / Reels)", 75, 2),
      dl("90-Day: first 10 sales — review what worked", 90, 3)
    ];
  }
  var CURRICULA = {
    igcse: {
      label: "IGCSE",
      a: ["Extended Math", "Add Math", "Physics", "ICT", "Extended Math"],
      b: ["English Language", "French", "Business", "English Language", "French"],
      c: ["Physics", "ICT", "Extended Math", "Add Math", "Business"],
      revise: "Revise / Past Papers / Notes"
    },
    gcse: {
      label: "GCSE",
      a: ["GCSE Maths", "GCSE English Language", "GCSE Sciences", "GCSE Maths", "GCSE Sciences"],
      b: ["GCSE English Literature", "GCSE Sciences", "GCSE Maths", "GCSE Option Subject", "GCSE English Language"],
      c: ["GCSE Option Subject", "GCSE Option Subject", "GCSE English Literature", "GCSE Sciences", "GCSE Maths — Past Papers"],
      revise: "GCSE past papers & mark schemes"
    },
    alevel: {
      label: "A-Level",
      a: ["A-Level Subject 1 — New Topic", "A-Level Subject 2 — New Topic", "A-Level Subject 3 — New Topic", "A-Level Subject 1 — New Topic", "A-Level Subject 2 — New Topic"],
      b: ["A-Level Subject 2 — Notes & Flashcards", "A-Level Subject 3 — Notes & Flashcards", "A-Level Subject 1 — Notes & Flashcards", "A-Level Subject 2 — Notes & Flashcards", "A-Level Subject 3 — Notes & Flashcards"],
      c: ["A-Level Subject 3 — Past Questions", "A-Level Subject 1 — Past Questions", "A-Level Subject 2 — Past Questions", "A-Level Subject 3 — Past Questions", "A-Level Subject 1 — Past Questions"],
      revise: "A-Level past papers & mark schemes"
    },
    wassce: {
      label: "WASSCE",
      a: ["Core Mathematics", "Integrated Science", "Core Mathematics", "Elective 1", "Integrated Science"],
      b: ["English Language", "Elective 1", "Elective 2", "English Language", "Elective 2"],
      c: ["Social Studies", "Elective 3", "Elective 1 — Past Questions", "Elective 3", "Core Maths — Past Questions"],
      revise: "WASSCE past questions (WAEC)"
    },
    sat: {
      label: "SAT",
      a: ["SAT Math — Algebra & Problem Solving", "SAT Reading & Writing Drills", "SAT Math — Advanced Topics", "SAT Reading & Writing Drills", "SAT Math — Timed Section"],
      b: ["SAT Vocabulary & Grammar Rules", "SAT Math Practice Set", "SAT Reading Passages", "SAT Math Practice Set", "SAT Writing — Rhetoric Questions"],
      c: ["SAT Timed Practice Section", "Error Log Review", "SAT Timed Practice Section", "Error Log Review", "Full-Length Practice Block"],
      revise: "Review error log & flashcards"
    },
    ib: {
      label: "IB Diploma",
      a: ["IB HL Subject 1", "IB HL Subject 2", "IB HL Subject 3", "IB HL Subject 1", "IB HL Subject 2"],
      b: ["IB SL Subject 4", "IB SL Subject 5", "IB SL Subject 6", "IB SL Subject 4", "IB SL Subject 5"],
      c: ["TOK / Extended Essay Work", "IB HL Subject 3", "Internal Assessment Work", "IB SL Subject 6", "TOK / Extended Essay Work"],
      revise: "IB past papers & IA/EE progress"
    },
    custom: {
      label: "Custom",
      a: ["Study Block 1 — Your Subject", "Study Block 1 — Your Subject", "Study Block 1 — Your Subject", "Study Block 1 — Your Subject", "Study Block 1 — Your Subject"],
      b: ["Study Block 2 — Your Subject", "Study Block 2 — Your Subject", "Study Block 2 — Your Subject", "Study Block 2 — Your Subject", "Study Block 2 — Your Subject"],
      c: ["Study Block 3 — Your Subject", "Study Block 3 — Your Subject", "Study Block 3 — Your Subject", "Study Block 3 — Your Subject", "Study Block 3 — Your Subject"],
      revise: "Revise / past questions / notes"
    }
  };
  function seedQuests(cur) {
    const C = CURRICULA[cur] || CURRICULA.igcse;
    const q = (time, name, cat, days, mand = false, xp = null) => ({ id: uid(), time, name, cat, days, mand, xp: xp ?? (mand ? 25 : 15) });
    const out = [
      q("05:20", "Wake Up — time to level up", "discipline", WD, true, 30),
      q("05:50", "Wash Car", "discipline", [1, 2, 4, 5], false, 10),
      q("05:50", "Speech Writing & Oratory", "mind", [3], false, 20),
      q("07:00", "Cleaning", "discipline", WD, false, 10),
      q("08:45", "Exercise / Martial Arts", "body", WD, true, 25),
      q("09:05", "Cold Bath (cold focus)", "body", WD, false, 15)
    ];
    [["09:30", C.a], ["11:30", C.b], ["12:45", C.c]].forEach(([time, names], si) => {
      names.forEach((name, i) => out.push(q(time, name, "study", [i + 1], true, 25)));
      if (si === 0) out.push(q("10:45", "Breakfast", "rest", WD, false, 5));
      if (si === 1) out.push(q("12:30", "Break", "rest", WD, false, 5));
    });
    out.push(
      q("13:45", C.revise, "study", WD, true, 25),
      q("14:00", "Learn Japanese", "mind", WD, false, 20),
      q("14:45", "Programming & Robotics", "mind", WD, false, 20),
      q("15:30", "Chess Practice", "mind", WD, false, 15),
      q("16:15", "Piano Practice", "mind", WD, false, 15),
      q("17:00", "Exercise / Martial Arts", "body", WD, true, 25),
      q("18:00", "Hot Bath", "rest", WD, false, 5),
      q("18:30", "Dinner", "rest", WD, false, 5),
      q("19:15", "Deep Study / Weak Areas", "study", WD, true, 30),
      q("20:00", "Read / Documentaries / Self-Improvement", "mind", WD, false, 15),
      q("20:45", "Plan Tomorrow / Journal / Reflection", "discipline", WD, true, 20),
      q("21:30", "Bedtime — rest to perform best", "rest", WD, true, 20)
    );
    return out;
  }
  function uid() {
    return Math.random().toString(36).slice(2, 9);
  }

  // system/src/content/quotes.js
  var QUOTES = [
    { q: "Victorious warriors win first and then go to war.", by: "Sun Tzu", src: "The Art of War" },
    { q: "The impediment to action advances action. What stands in the way becomes the way.", by: "Marcus Aurelius", src: "Meditations" },
    { q: "There is more than one path to the top of the mountain.", by: "Miyamoto Musashi", src: "The Book of Five Rings" },
    { q: "Never was anything great achieved without danger.", by: "Niccolò Machiavelli", src: "The Prince" },
    { q: "Luck is what happens when preparation meets opportunity.", by: "Seneca", src: "Stoic philosopher" },
    { q: "There is nothing more deceptive than an obvious fact.", by: "Sherlock Holmes", src: "Arthur Conan Doyle" },
    { q: "A lesson without pain is meaningless.", by: "Edward Elric", src: "Fullmetal Alchemist" },
    { q: "If you don't take risks, you can't create a future.", by: "Monkey D. Luffy", src: "One Piece" },
    { q: "If the king does not move, his subjects will not follow.", by: "Lelouch vi Britannia", src: "Code Geass" },
    { q: "A person who cannot sacrifice anything can never change anything.", by: "Armin Arlert", src: "Attack on Titan" },
    { q: "Fear is not evil. It tells you what your weakness is.", by: "Gildarts Clive", src: "Fairy Tail" },
    { q: "If heroes run and hide, who will stay and fight?", by: "Saitama", src: "One-Punch Man" },
    { q: "Do, or do not. There is no try.", by: "Yoda", src: "Star Wars" },
    { q: "Why do we fall? So we can learn to pick ourselves up.", by: "Alfred Pennyworth", src: "Batman Begins" },
    { q: "Great men are not born great, they grow great.", by: "Don Vito Corleone", src: "The Godfather" },
    { q: "Every man dies. Not every man really lives.", by: "William Wallace", src: "Braveheart" },
    { q: "It's about how hard you can get hit and keep moving forward.", by: "Rocky Balboa", src: "Rocky Balboa" },
    { q: "Get busy living, or get busy dying.", by: "Andy Dufresne", src: "The Shawshank Redemption" },
    { q: "It is our choices that show what we truly are.", by: "Albus Dumbledore", src: "Harry Potter" },
    { q: "All we have to decide is what to do with the time given us.", by: "Gandalf", src: "The Lord of the Rings" },
    { q: "You fall to the level of your systems.", by: "James Clear", src: "Atomic Habits" },
    { q: "Hard choices, easy life. Easy choices, hard life.", by: "Jerzy Gregorek", src: "champion weightlifter" },
    { q: "Discipline equals freedom.", by: "Jocko Willink", src: "Discipline Equals Freedom" },
    { q: "Whether you think you can or you can't, you're right.", by: "Henry Ford", src: "industrialist" },
    { q: "Winter does not negotiate. Neither should your standards.", by: "Kael Orion", src: "The Mastermind's Winter Arc" },
    { q: "The System does not grade effort. It grades what got done.", by: "THE SYSTEM", src: "daily directive" },
    { q: "Nobody is coming to save the day you are wasting.", by: "THE SYSTEM", src: "daily directive" },
    { q: "You are always training something. Today it was either focus or distraction.", by: "THE SYSTEM", src: "daily directive" }
  ];
  function renderQuote() {
    if (!$("#quoteText")) return;
    const i = Math.floor(Date.now() / 864e5) % QUOTES.length, x = QUOTES[i];
    $("#quoteText").textContent = "“" + x.q + "”";
    $("#quoteBy").textContent = "— " + x.by;
    $("#quoteSrc").textContent = x.src;
  }

  // system/src/views/wall.js
  var WALL = [
    ["assets/brand-poster.jpg", "THE SYSTEM — study smart. stay ahead. succeed."],
    ["assets/brand-logo.jpg", "The mark of the System"],
    ["assets/quest-window.jpg", "Train. Study. Show up again."],
    ["assets/art-hunter.jpg", "You are the sum of what you finish."],
    ["assets/quote-focus.jpg", "Levelling up costs separation and focus."],
    ["assets/quote-never-give-up.jpg", "Everyone who made it failed first."]
  ];
  var wallI = 0;
  var wallTimer = null;
  function renderWall() {
    if (!$("#wallImg")) return;
    const [srcp, cap] = WALL[wallI];
    const img = $("#wallImg"), miss = $("#wallMissing");
    img.onerror = () => {
      miss.innerHTML = "Image not found<br><b>" + srcp + "</b><br>The assets folder must sit next to index.html. Updating a Netlify site? Drag the whole folder — a drop replaces everything.";
      miss.classList.remove("hidden");
      $("#wallCap").classList.add("hidden");
    };
    img.onload = () => {
      miss.classList.add("hidden");
      $("#wallCap").classList.remove("hidden");
    };
    img.src = srcp;
    img.alt = cap;
    $("#wallCap").textContent = cap;
    const dots = $("#wallDots");
    dots.innerHTML = "";
    WALL.forEach((_, i) => {
      const d = document.createElement("i");
      if (i === wallI) d.className = "on";
      d.onclick = () => {
        wallI = i;
        renderWall();
        wallAuto();
      };
      dots.appendChild(d);
    });
  }
  function wallStep(n) {
    wallI = (wallI + n + WALL.length) % WALL.length;
    renderWall();
    wallAuto();
  }
  function wallAuto() {
    clearInterval(wallTimer);
    wallTimer = setInterval(() => {
      const pane = $('[data-pane="tr-wall"]');
      if (document.hidden || !pane || pane.classList.contains("hidden")) return;
      wallI = (wallI + 1) % WALL.length;
      renderWall();
    }, 8e3);
  }
  function wireWall() {
    const prev = $("#wallPrev"), next = $("#wallNext"), img = $("#wallImg");
    if (prev) prev.onclick = () => wallStep(-1);
    if (next) next.onclick = () => wallStep(1);
    if (img) img.onclick = () => {
      const pic = $("#imgModalPic"), modal = $("#imgModal");
      if (!pic || !modal) return;
      pic.src = img.src;
      pic.alt = img.alt;
      modal.classList.remove("hidden");
    };
    wallAuto();
  }
  wireWall();

  // shared/events.js
  var EVENT_TYPES = Object.freeze({
    XP_GRANTED: "XP_GRANTED"
  });
  var LOG_VERSION = 1;
  function makeEvent({ type, data = {}, ts, device, seq }) {
    if (!EVENT_TYPES[type]) throw new Error("unknown event type: " + type);
    if (!Number.isFinite(ts)) throw new Error("event needs a numeric ts");
    if (!device) throw new Error("event needs a device");
    if (!Number.isInteger(seq) || seq < 0) throw new Error("event needs a non-negative integer seq");
    return Object.freeze({ v: LOG_VERSION, id: device + ":" + seq, seq, ts, device, type, data });
  }
  function isEvent(e) {
    return !!e && typeof e === "object" && typeof e.id === "string" && typeof e.type === "string" && Number.isFinite(e.ts) && typeof e.device === "string" && Number.isInteger(e.seq);
  }
  function compareEvents(a, b) {
    if (a.ts !== b.ts) return a.ts < b.ts ? -1 : 1;
    if (a.device !== b.device) return a.device < b.device ? -1 : 1;
    if (a.seq !== b.seq) return a.seq < b.seq ? -1 : 1;
    return 0;
  }
  function canonical(events) {
    return [...events].filter(isEvent).sort(compareEvents);
  }
  function merge(...lists) {
    const seen = /* @__PURE__ */ new Map();
    for (const list of lists) for (const e of list || []) if (isEvent(e) && !seen.has(e.id)) seen.set(e.id, e);
    return canonical([...seen.values()]);
  }

  // shared/domain/progression.js
  var xpNeeded = (level) => Math.round(100 * Math.pow(level, 1.35));
  var INITIAL = Object.freeze({ xp: 0, level: 1, totalXp: 0, grants: 0 });
  function reduceProgression(state, ev) {
    switch (ev.type) {
      case EVENT_TYPES.XP_GRANTED: {
        const n = Number(ev.data && ev.data.n);
        if (!Number.isFinite(n) || n <= 0) return state;
        let xp = state.xp + n;
        let level = state.level;
        let guard = 0;
        while (xp >= xpNeeded(level) && guard++ < 1e4) {
          xp -= xpNeeded(level);
          level += 1;
        }
        return { xp, level, totalXp: state.totalXp + n, grants: state.grants + 1 };
      }
      default:
        return state;
    }
  }
  function replayProgression(events, base = INITIAL) {
    let state = { xp: base.xp | 0, level: base.level || 1, totalXp: base.totalXp | 0, grants: base.grants | 0 };
    for (const ev of events) state = reduceProgression(state, ev);
    return state;
  }
  function compareProgression(live, replayed) {
    const fields = ["xp", "level", "totalXp"];
    const diffs = fields.filter((f) => Number(live && live[f]) !== Number(replayed[f])).map((f) => ({ field: f, live: Number(live && live[f]), replayed: Number(replayed[f]) }));
    return { agrees: diffs.length === 0, diffs };
  }

  // system/src/core/log.js
  var LOG_KEY = (id) => "ascend.log.v1." + id;
  var COMPACT_ABOVE = 2e3;
  var KEEP_AFTER_COMPACT = 500;
  function emptyLog(device) {
    return { v: LOG_VERSION, device, seq: 0, base: { ...INITIAL }, events: [], acked: 0 };
  }
  var Log = /* @__PURE__ */ (() => {
    let cache = null;
    function deviceId() {
      try {
        if (typeof DB !== "undefined" && DB && DB.installId) return String(DB.installId).slice(0, 12);
      } catch (e) {
      }
      return "unknown";
    }
    function load2(hunterId) {
      if (cache && cache.hunterId === hunterId) return cache.log;
      let log = null;
      try {
        if (typeof Store !== "undefined") log = Store.readJSON(LOG_KEY(hunterId));
      } catch (e) {
        log = null;
      }
      if (!log || !Array.isArray(log.events)) log = emptyLog(deviceId());
      if (!log.device) log.device = deviceId();
      if (!log.base) log.base = { ...INITIAL };
      log.seq = Number.isInteger(log.seq) ? log.seq : log.events.length;
      log.acked = Number.isInteger(log.acked) ? log.acked : 0;
      cache = { hunterId, log };
      return log;
    }
    function persist(hunterId, log) {
      try {
        if (typeof Store !== "undefined") Store.writeJSON(LOG_KEY(hunterId), log);
      } catch (e) {
      }
    }
    function activeId() {
      try {
        return typeof DB !== "undefined" && DB && DB.active || null;
      } catch (e) {
        return null;
      }
    }
    function compact(log) {
      if (log.events.length <= COMPACT_ABOVE) return log;
      const sorted = canonical(log.events);
      const wanted = sorted.length - KEEP_AFTER_COMPACT;
      const cut = Math.min(wanted, log.acked || 0);
      if (cut <= 0) {
        log.events = sorted;
        return log;
      }
      log.base = replayProgression(sorted.slice(0, cut), log.base);
      log.events = sorted.slice(cut);
      log.acked = Math.max(0, (log.acked || 0) - cut);
      return log;
    }
    return {
      /* Records a fact. `now` is injectable so tests can build a history without
         sleeping, and so a replay never depends on when it happened to run. */
      append(type, data, now) {
        const hunterId = activeId();
        if (!hunterId) return null;
        const log = load2(hunterId);
        const ts = Number.isFinite(now) ? now : Date.now();
        let ev;
        try {
          ev = makeEvent({ type, data, ts, device: log.device, seq: log.seq });
        } catch (e) {
          return null;
        }
        log.seq += 1;
        log.events.push(ev);
        compact(log);
        persist(hunterId, log);
        return ev;
      },
      events(hunterId) {
        const id = hunterId || activeId();
        return id ? canonical(load2(id).events) : [];
      },
      base(hunterId) {
        const id = hunterId || activeId();
        return id ? load2(id).base : { ...INITIAL };
      },
      /* Progression as the log says it is, regardless of what the record claims. */
      progression(hunterId) {
        const id = hunterId || activeId();
        if (!id) return { ...INITIAL };
        const log = load2(id);
        return replayProgression(canonical(log.events), log.base);
      },
      /* Shadow mode: what the record says versus what the log says. Surfaced, never
         auto-corrected — a mismatch is a bug to find, not a number to overwrite. */
      audit(hunterId) {
        const id = hunterId || activeId();
        if (!id) return null;
        let live = null;
        try {
          live = typeof DB !== "undefined" && DB.hunters ? DB.hunters[id] : null;
        } catch (e) {
          live = null;
        }
        if (!live) return null;
        const replayed = this.progression(id);
        return { ...compareProgression(live, replayed), replayed, events: load2(id).events.length };
      },
      /* Merging another device's events. Ids are device+seq, so a retried sync or a
         restored backup collapses instead of double-counting. */
      absorb(hunterId, incoming) {
        const id = hunterId || activeId();
        if (!id) return 0;
        const log = load2(id);
        const before = log.events.length;
        log.events = merge(log.events, (incoming || []).filter(isEvent));
        compact(log);
        persist(id, log);
        return log.events.length - before;
      },
      /* For sync and export. */
      export(hunterId) {
        const id = hunterId || activeId();
        if (!id) return null;
        const log = load2(id);
        return { v: log.v, device: log.device, base: log.base, events: canonical(log.events) };
      },
      /* Called after the server confirms it stored a batch. Counts, not ids: the
         log is canonically ordered and the server is given it in that order, so
         "the first N are safely stored" is exact. */
      acknowledge(hunterId, count) {
        const id = hunterId || activeId();
        if (!id) return 0;
        const log = load2(id);
        log.acked = Math.max(log.acked || 0, Math.min(Number(count) || 0, log.events.length));
        persist(id, log);
        return log.acked;
      },
      acked(hunterId) {
        const id = hunterId || activeId();
        return id ? load2(id).acked || 0 : 0;
      },
      _reset() {
        cache = null;
      },
      TYPES: EVENT_TYPES
    };
  })();

  // shared/domain/next-action.js
  var TIER_RANK = Object.freeze({ high: 0, medium: 1, optional: 2 });
  var DEFAULTS = Object.freeze({
    recovery: 15,
    deadline: 45,
    overdue: 20,
    next: 20,
    errors: 25,
    /* a set of missed questions, revisited */
    exam: 45,
    stale: 20,
    /* a topic that has decayed and needs one pass */
    project: 40,
    opp: 20,
    /* an application step */
    goal: 30,
    weak: 20,
    style: 20
  });
  var DEFAULT_MINUTES = 20;
  function estimateMinutes(rec, hint) {
    if (Number.isFinite(hint) && hint > 0) return Math.round(hint);
    if (rec && Number.isFinite(rec.minutes) && rec.minutes > 0) return Math.round(rec.minutes);
    const kind = String(rec && rec.id || "").split(":")[0];
    return DEFAULTS[kind] || DEFAULT_MINUTES;
  }
  function planForBudget(recs, budgetMinutes) {
    const list = Array.isArray(recs) ? recs : [];
    const budget = Number(budgetMinutes);
    const stated = Number.isFinite(budget) && budget > 0;
    let spent = 0;
    let fitted = 0;
    const plan = list.map((r) => {
      const minutes = estimateMinutes(r);
      if (!stated) return { ...r, minutes, fits: true, startsAt: null };
      const isHard = (r.tier || "optional") === "high";
      const roomLeft = budget - spent;
      const fits = minutes <= roomLeft;
      if (fits) {
        const startsAt = spent;
        spent += minutes;
        fitted++;
        return { ...r, minutes, fits: true, startsAt };
      }
      return {
        ...r,
        minutes,
        fits: false,
        startsAt: null,
        overruns: isHard,
        shortfall: minutes - Math.max(0, roomLeft)
      };
    });
    const overrunning = plan.filter((p) => p.overruns);
    return {
      plan,
      budget: stated ? budget : null,
      spent,
      remaining: stated ? Math.max(0, budget - spent) : null,
      fitted,
      overrunning: overrunning.length,
      /* One sentence the UI can print. Written here so the client and any future
         server-side brief say the same thing. */
      note: !stated ? "No time stated, so this is the full ranking rather than a plan." : overrunning.length ? `${fitted} of these fit in ${budget} minutes. ${overrunning.length} cannot be made to fit and ${overrunning.length === 1 ? "is" : "are"} shown anyway, because ${overrunning.length === 1 ? "it is" : "they are"} not optional — a deadline does not move because the evening is short.` : fitted === plan.length ? `All of this fits in ${budget} minutes, with ${Math.max(0, budget - spent)} to spare.` : `${fitted} of these fit in ${budget} minutes. The rest are ranked below and can wait.`
    };
  }

  // system/src/content/balance.js
  var BALANCE = {
    /* ---------- XP awards ----------
       §3: reward meaningful action, never app usage. There is deliberately no
       "opened the app", "checked your stats" or "logged in today" entry. */
    xp: {
      questBase: 15,
      /* an optional quest, before its own xp overrides this */
      questMandatory: 25,
      goalStep: 10,
      goalTarget: 60,
      /* every step under a target cleared */
      goalComplete: 200,
      bookFinished: 80,
      hobbySession: 12,
      focusSession: 20,
      reflection: 15,
      bossStage: 50,
      bossComplete: 400,
      milestone: 250
    },
    /* ---------- the level curve ----------
       §4: early levels reachable, later ones meaningful, and never the exponential
       nonsense that makes level 60 a theoretical object. The v12 curve was
       100·level^1.35, which is kept — it is a good curve — but the constant is now
       visible and adjustable rather than buried in progression.js. */
    level: {
      base: 100,
      exponent: 1.35,
      /* §5: titles per band. The existing lore is Solo-Leveling-adjacent hunter
         fiction, so these follow it rather than importing a generic ladder. */
      titles: [
        { at: 1, name: "Awakened" },
        { at: 5, name: "Initiate" },
        { at: 10, name: "Adept" },
        { at: 20, name: "Specialist" },
        { at: 30, name: "Elite" },
        { at: 45, name: "Veteran" },
        { at: 60, name: "Master" },
        { at: 80, name: "Grandmaster" },
        { at: 100, name: "Monarch" }
      ]
    },
    /* ---------- ranks ----------
       §6: level measures progression, rank measures demonstrated mastery. v12 tied
       rank purely to level, which meant a hunter could reach S-Rank by clearing
       easy quests for long enough. Rank now requires evidence as well as level. */
    ranks: [
      { r: "E", level: 1, need: {} },
      { r: "D", level: 10, need: { cleared: 150, streak: 5, achievements: 3 } },
      { r: "C", level: 20, need: { cleared: 400, streak: 10, achievements: 8, bosses: 1 } },
      { r: "B", level: 35, need: { cleared: 900, streak: 20, achievements: 14, bosses: 3 } },
      { r: "A", level: 50, need: { cleared: 1800, streak: 30, achievements: 22, bosses: 6 } },
      { r: "S", level: 70, need: { cleared: 3200, streak: 45, achievements: 32, bosses: 10 } },
      { r: "N", level: 90, need: { cleared: 5e3, streak: 60, achievements: 44, bosses: 16 } }
    ],
    rankNames: {
      E: "E-Rank",
      D: "D-Rank",
      C: "C-Rank",
      B: "B-Rank",
      A: "A-Rank",
      S: "S-Rank",
      N: "National Level Hunter"
    },
    /* ---------- stats: what counts as evidence (§7) ----------
         "Do not automatically claim a student has increased a stat merely because
         they clicked complete. Stats should be derived from evidence and activity
         patterns where possible."
    
         The split below is the whole rule, and it falls out of what a category
         actually measures:
    
           selfEvident   the act IS the measurement. Waking at 05:20 or finishing a
                         workout is not a claim about capability — it is a claim
                         about turning up, and ticking it is an honest record of
                         exactly that. Consistency here is the "activity pattern"
                         §7 explicitly allows.
    
           needsEvidence the act is EFFORT, not capability. Sitting with a Physics
                         book for an hour is real and earns XP, but it is not proof
                         that any Physics was learnt. Intellect and Perception are
                         paid from demonstrated mastery movement instead — see
                         recordAnswer() in services/practice.js.
    
         XP is unaffected in both cases. Effort is real and is still paid for; what
         is withheld is the capability claim. */
    stats: {
      selfEvident: ["discipline", "body", "rest"],
      needsEvidence: ["study", "mind"],
      evidenceHint: "Answer practice questions in Academy — accuracy is the evidence."
    },
    /* ---------- quest difficulty (§13) ----------
       Difficulty is estimated effort, not decoration: the multiplier is what makes
       a Legendary quest worth attempting instead of five Trivial ones. */
    difficulty: [
      { k: "trivial", label: "Trivial", mins: 5, mult: 0.5 },
      { k: "easy", label: "Easy", mins: 15, mult: 0.8 },
      { k: "moderate", label: "Moderate", mins: 30, mult: 1 },
      { k: "hard", label: "Hard", mins: 60, mult: 1.5 },
      { k: "epic", label: "Epic", mins: 120, mult: 2.2 },
      { k: "legendary", label: "Legendary", mins: 240, mult: 3 }
    ],
    /* ---------- quest hierarchy (§11) ---------- */
    questTypes: [
      { k: "daily", label: "Daily", blurb: "A small action, today." },
      { k: "weekly", label: "Weekly", blurb: "A short-term objective." },
      { k: "main", label: "Main", blurb: "Something you actually want." },
      { k: "boss", label: "Boss", blurb: "A milestone built from smaller quests." },
      { k: "story", label: "Story", blurb: "The Archive opens as you progress." },
      { k: "milestone", label: "Milestone", blurb: "A real-world achievement, recorded." },
      { k: "recovery", label: "Recovery", blurb: "Getting back on the board." }
    ],
    /* ---------- anti-exploitation (§41) ----------
       Repeatedly clearing and un-clearing the same quest must not print XP. */
    antiFarm: {
      sameQuestPerDay: 1,
      /* XP paid once per quest per day, re-ticks are free */
      dailyXpCap: 900,
      /* generous for a real day, absurd for a farmer */
      minSecondsBetweenClaims: 3
    },
    /* ---------- the world (§29, §30, §31) ----------
       Areas represent categories of growth, and each maps onto a part of the app
       that already exists. Unlocking an area is not a new feature — it is the
       moment the System explains what a part of itself is for. Nothing essential
       is ever locked: everything below is already reachable from navigation. */
    world: [
      {
        k: "gate",
        name: "The Gate",
        maps: "Home & quests",
        at: { level: 1 },
        blurb: "Where every hunter starts. The board, the day, the directive."
      },
      {
        k: "academy",
        name: "The Academy",
        maps: "Learn",
        at: { level: 3, cleared: 20 },
        blurb: "Books, the tutor, the Archive. Knowledge you choose rather than knowledge assigned."
      },
      {
        k: "forge",
        name: "The Forge",
        maps: "Grow · Forge",
        at: { level: 6, cleared: 60 },
        blurb: "Four crafts, defended daily. This is where skill stops being a plan."
      },
      {
        k: "arena",
        name: "The Arena",
        maps: "Wealth · Arena",
        at: { level: 10, bosses: 1 },
        blurb: "Competitions and scholarships. Where the work meets other people's standards."
      },
      {
        k: "observatory",
        name: "The Observatory",
        maps: "Insight",
        at: { level: 12, cleared: 200 },
        blurb: "The record read back to you — patterns, proposals, the weekly review."
      },
      {
        k: "vault",
        name: "The Vault",
        maps: "Wealth",
        at: { level: 16, cleared: 350 },
        blurb: "Money handled deliberately. The Freedom jar that is never spent."
      },
      {
        k: "citadel",
        name: "The Citadel",
        maps: "Progression",
        at: { level: 25, achievements: 12 },
        blurb: "Everything you have built, in one place. Titles, records, milestones."
      },
      {
        k: "frontier",
        name: "The Frontier",
        maps: "Goals & projects",
        at: { level: 40, bosses: 5 },
        blurb: "Beyond the syllabus. The things nobody set for you."
      }
    ],
    /* ---------- achievements (§18) ----------
       Categories per the phase doc. `check` is a key the engine knows how to
       evaluate; the numbers are here so they can be tuned without code edits. */
    achievements: [
      /* PROGRESSION */
      { id: "lvl5", cat: "progression", name: "Awakened", need: { level: 5 }, blurb: "Reach level 5." },
      { id: "lvl10", cat: "progression", name: "Adept", need: { level: 10 }, blurb: "Reach level 10." },
      { id: "lvl25", cat: "progression", name: "Specialist", need: { level: 25 }, blurb: "Reach level 25." },
      { id: "lvl50", cat: "progression", name: "Elite", need: { level: 50 }, blurb: "Reach level 50." },
      { id: "rankC", cat: "progression", name: "C-Rank Hunter", need: { rank: "C" }, blurb: "Earn C-Rank — level and evidence." },
      { id: "rankA", cat: "progression", name: "A-Rank Hunter", need: { rank: "A" }, blurb: "Earn A-Rank." },
      /* CONSISTENCY */
      { id: "streak7", cat: "consistency", name: "One Week Held", need: { streak: 7 }, blurb: "A seven-day streak." },
      { id: "streak30", cat: "consistency", name: "The Month", need: { streak: 30 }, blurb: "Thirty days without breaking." },
      { id: "streak100", cat: "consistency", name: "Hundred", need: { streak: 100 }, blurb: "One hundred consecutive days." },
      { id: "perfect", cat: "consistency", name: "Clean Sweep", need: { perfectDays: 1 }, blurb: "Clear every quest scheduled in a day." },
      { id: "perfect10", cat: "consistency", name: "Ten Clean Days", need: { perfectDays: 10 }, blurb: "Ten perfect days." },
      { id: "cleared500", cat: "consistency", name: "Five Hundred", need: { cleared: 500 }, blurb: "Five hundred quests cleared." },
      /* LEARNING */
      { id: "book1", cat: "learning", name: "First Finish", need: { books: 1 }, blurb: "Finish a book." },
      { id: "book10", cat: "learning", name: "Ten Volumes", need: { books: 10 }, blurb: "Finish ten books." },
      { id: "study100", cat: "learning", name: "Hundred Sessions", need: { catCleared: { cat: "study", n: 100 } }, blurb: "Clear 100 study quests." },
      { id: "hobby30", cat: "learning", name: "Craftsman", need: { hobbyDays: 30 }, blurb: "Practise a craft on thirty separate days." },
      /* MILESTONES */
      { id: "boss1", cat: "milestone", name: "First Fall", need: { bosses: 1 }, blurb: "Complete a boss quest." },
      { id: "boss5", cat: "milestone", name: "Five Fallen", need: { bosses: 5 }, blurb: "Complete five boss quests." },
      { id: "goal1", cat: "milestone", name: "Finished It", need: { goalsDone: 1 }, blurb: "Complete a goal, every step." },
      { id: "goal5", cat: "milestone", name: "Serial Finisher", need: { goalsDone: 5 }, blurb: "Complete five goals." },
      /* EXPLORATION */
      { id: "world3", cat: "exploration", name: "Cartographer", need: { areas: 3 }, blurb: "Unlock three areas of the world." },
      { id: "world6", cat: "exploration", name: "Far Traveller", need: { areas: 6 }, blurb: "Unlock six areas." },
      { id: "skills5", cat: "exploration", name: "Branching Out", need: { skills: 5 }, blurb: "Learn five skills." },
      /* RECOVERY — deliberately an achievement, not a mark against you.
         §24: one missed day must not read as failure. Coming back is the skill. */
      {
        id: "return",
        cat: "consistency",
        name: "The Return",
        need: { recoveries: 1 },
        blurb: "Complete a recovery after a collapsed week. Getting back is the harder skill."
      },
      /* SECRET (§18) — discoverable, not listed until earned */
      {
        id: "dawn",
        cat: "secret",
        name: "Before Dawn",
        secret: true,
        need: { clearedBefore: 6 },
        blurb: "Cleared a quest before 6 AM."
      },
      {
        id: "nightowl",
        cat: "secret",
        name: "Late Shift",
        secret: true,
        need: { clearedAfter: 23 },
        blurb: "Cleared a quest after 11 PM."
      },
      {
        id: "comeback",
        cat: "secret",
        name: "From Zero",
        secret: true,
        need: { zeroToPerfect: true },
        blurb: "A perfect day directly after a day with nothing cleared."
      }
    ],
    /* ---------- titles (§19) ----------
       Earned from achievements, equipped by choice, purely cosmetic. */
    titles: [
      { id: "t_scholar", name: "The Scholar", from: "book10", blurb: "Ten books finished." },
      { id: "t_relentless", name: "The Relentless", from: "streak30", blurb: "Thirty days unbroken." },
      { id: "t_builder", name: "The Builder", from: "hobby30", blurb: "Thirty days at a craft." },
      { id: "t_strategist", name: "The Strategist", from: "goal5", blurb: "Five goals seen through." },
      { id: "t_slayer", name: "The Slayer", from: "boss5", blurb: "Five bosses down." },
      { id: "t_explorer", name: "The Explorer", from: "world6", blurb: "Six areas unlocked." },
      { id: "t_returned", name: "The Returned", from: "return", blurb: "Came back from a collapsed week." },
      { id: "t_elite", name: "The Elite", from: "lvl50", blurb: "Level fifty." }
    ],
    /* ---------- seasons (§27) ----------
       Optional. Nothing a student needs is ever seasonal — these only re-zero the
       comparison window so a bad November is not carried forever. */
    seasons: [
      { k: "s1", name: "Awakening", from: "09-01", to: "12-31" },
      { k: "s2", name: "Ascension", from: "01-01", to: "04-30" },
      { k: "s3", name: "Mastery", from: "05-01", to: "08-31" }
    ]
  };

  // system/src/content/library.js
  var GENRES = {
    discipline: { label: "Discipline & Self-Mastery", books: [
      ["Atomic Habits", "James Clear", "Small systems, ruthlessly repeated. This app in book form."],
      ["The Power of Habit", "Charles Duhigg", "How the cue–routine–reward loop runs your life."],
      ["Deep Work", "Cal Newport", "Focused hours are worth ten distracted ones."],
      ["Digital Minimalism", "Cal Newport", "Take the phone back before it takes the decade."],
      ["The War of Art", "Steven Pressfield", "Names the enemy: Resistance. You've met it."],
      ["Mindset", "Carol Dweck", "'I'm just not good at it' is a decision, not a diagnosis."],
      ["Grit", "Angela Duckworth", "Why passion plus persistence beats talent."],
      ["The Compound Effect", "Darren Hardy", "Boring daily choices, extraordinary ten-year outcomes."],
      ["The Slight Edge", "Jeff Olson", "Easy to do. Easy not to do. That's the whole game."],
      ["Discipline Is Destiny", "Ryan Holiday", "Self-control as the master virtue."],
      ["The 7 Habits of Highly Effective Teens", "Sean Covey", "The classic playbook, translated for your age."],
      ["Make Your Bed", "William H. McRaven", "A Navy admiral on winning the day before 7am."],
      ["Essentialism", "Greg McKeown", "Do less, but do it like it matters."]
    ] },
    money: { label: "Money & Wealth", books: [
      ["The Richest Man in Babylon", "George S. Clason", "Pay yourself first, told as ancient parables."],
      ["Rich Dad Poor Dad", "Robert Kiyosaki", "Assets versus liabilities — the distinction most adults never learn."],
      ["The Psychology of Money", "Morgan Housel", "Wealth is behaviour, not maths."],
      ["Secrets of the Millionaire Mind", "T. Harv Eker", "Your inner money thermostat, and how to reset it."],
      ["I Will Teach You to Be Rich", "Ramit Sethi", "A blunt operating manual for automating money."],
      ["The Millionaire Next Door", "Thomas Stanley & William Danko", "Real millionaires drive old cars. The data proves it."],
      ["Think and Grow Rich", "Napoleon Hill", "The 1937 classic on desire, plans and persistence."],
      ["The Simple Path to Wealth", "JL Collins", "Index investing explained like a letter to a daughter."],
      ["The Intelligent Investor", "Benjamin Graham", "Warren Buffett calls it the best investing book ever."],
      ["Your Money or Your Life", "Vicki Robin", "Every purchase costs hours of your life. Count them."],
      ["The Millionaire Fastlane", "MJ DeMarco", "Why the slow lane is slow, and what scales instead."],
      ["The Latte Factor", "David Bach", "Small leaks, told as a story you'll finish in a day."],
      ["Just Keep Buying", "Nick Maggiulli", "A data scientist settles the saving-vs-investing fights."]
    ] },
    strategy: { label: "Strategy & Power", books: [
      ["The Art of War", "Sun Tzu", "Win before the battle starts."],
      ["The Book of Five Rings", "Miyamoto Musashi", "An undefeated duelist on mastery and timing."],
      ["The Prince", "Niccolò Machiavelli", "How power actually behaves — never be surprised by it."],
      ["Mastery", "Robert Greene", "Apprentice, practitioner, master. The long road, mapped."],
      ["The 33 Strategies of War", "Robert Greene", "Campaign thinking for exams, business and life."],
      ["The 48 Laws of Power", "Robert Greene", "Read it as a defence manual."],
      ["The Art of Learning", "Josh Waitzkin", "A chess prodigy on how mastery actually feels."],
      ["Good Strategy Bad Strategy", "Richard Rumelt", "Most 'strategy' is slogans. Here's the real thing."],
      ["The Great Mental Models Vol. 1", "Shane Parrish", "Thinking tools the best decision-makers share."],
      ["Thinking in Bets", "Annie Duke", "A poker champion on deciding with incomplete information."],
      ["The Obstacle Is the Way", "Ryan Holiday", "Stoicism weaponised for setbacks."],
      ["Only the Paranoid Survive", "Andrew Grove", "Intel's CEO on surviving the moments everything changes."],
      ["The Art of Strategy", "Avinash Dixit & Barry Nalebuff", "Game theory for everyday duels."]
    ] },
    psychology: { label: "Psychology & Influence", books: [
      ["Influence", "Robert Cialdini", "The six levers people pull on you daily."],
      ["Thinking, Fast and Slow", "Daniel Kahneman", "Your brain's two systems, and where each lies to you."],
      ["How to Win Friends and Influence People", "Dale Carnegie", "Still the best social skills manual written."],
      ["Man's Search for Meaning", "Viktor Frankl", "What keeps humans standing when everything is taken."],
      ["The Laws of Human Nature", "Robert Greene", "People-reading as a trained skill."],
      ["Never Split the Difference", "Chris Voss", "An FBI hostage negotiator teaches you to negotiate anything."],
      ["Predictably Irrational", "Dan Ariely", "The hidden forces behind your worst decisions."],
      ["Emotional Intelligence", "Daniel Goleman", "Why EQ decides more outcomes than IQ."],
      ["The Chimp Paradox", "Steve Peters", "The mind model elite athletes use to stay calm."],
      ["Flow", "Mihaly Csikszentmihalyi", "The science of the state where hours vanish."],
      ["Quiet", "Susan Cain", "The quiet ones are not broken. They're loaded."],
      ["Surrounded by Idiots", "Thomas Erikson", "Four personality colours, and how to talk to each."],
      ["The Happiness Advantage", "Shawn Achor", "Happiness fuels performance, not the reverse."]
    ] },
    biography: { label: "Biography & Memoir", books: [
      ["Long Walk to Freedom", "Nelson Mandela", "Twenty-seven years in prison without surrendering the mission."],
      ["Born a Crime", "Trevor Noah", "Growing up broke, sharp and unstoppable in South Africa."],
      ["I Am Malala", "Malala Yousafzai", "Shot for going to school. Kept going."],
      ["Ghana: The Autobiography of Kwame Nkrumah", "Kwame Nkrumah", "The man who talked an empire out of your country."],
      ["Shoe Dog", "Phil Knight", "Nike's founder on how messy building really is."],
      ["Steve Jobs", "Walter Isaacson", "Obsession with the product, for better and worse."],
      ["Elon Musk", "Walter Isaacson", "Rockets, risk and a work ethic bordering on violence."],
      ["Becoming", "Michelle Obama", "From the South Side of Chicago to the White House."],
      ["The Autobiography of Malcolm X", "Malcolm X & Alex Haley", "A prison library built one of history's sharpest minds."],
      ["Total Recall", "Arnold Schwarzenegger", "Bodybuilder, movie star, governor. One rulebook."],
      ["The Last Lecture", "Randy Pausch", "A dying professor's final class on living."],
      ["Leonardo da Vinci", "Walter Isaacson", "Curiosity as a superpower."],
      ["Alexander Hamilton", "Ron Chernow", "An orphan immigrant writes himself into history."]
    ] },
    business: { label: "Business & Startups", books: [
      ["Zero to One", "Peter Thiel", "Don't compete — create something that didn't exist."],
      ["The Lean Startup", "Eric Ries", "Build small, test fast, stop guessing."],
      ["The Diary of a CEO", "Steven Bartlett", "33 laws from a founder who started with nothing."],
      ["The $100 Startup", "Chris Guillebeau", "You don't need capital. You need a customer."],
      ["Company of One", "Paul Jarvis", "Staying small on purpose and keeping the freedom."],
      ["The Almanack of Naval Ravikant", "Eric Jorgenson", "Wealth and leverage, compressed to aphorisms. Free online."],
      ["The Hard Thing About Hard Things", "Ben Horowitz", "What running a company feels like when it's on fire."],
      ["Start With Why", "Simon Sinek", "People don't buy what you do. They buy why."],
      ["Rework", "Jason Fried & David Heinemeier Hansson", "Anti-hustle, pro-shipping. Short chapters, hard punches."],
      ["The E-Myth Revisited", "Michael Gerber", "Work ON the business, not just in it."],
      ["The Mom Test", "Rob Fitzpatrick", "How to ask customers questions they can't lie to."],
      ["Anything You Want", "Derek Sivers", "Built a company by accident, sold it for millions, kept his soul."],
      ["The Personal MBA", "Josh Kaufman", "A business degree's worth of ideas in one volume."]
    ] },
    fantasy: { label: "Fantasy", books: [
      ["Mistborn", "Brandon Sanderson", "A street thief, a heist, and the best magic system in print."],
      ["The Way of Kings", "Brandon Sanderson", "Epic on a scale that rewires your standards."],
      ["The Hobbit", "J.R.R. Tolkien", "The template every adventure since has copied."],
      ["The Lion, the Witch and the Wardrobe", "C.S. Lewis", "A wardrobe, a war, a world."],
      ["Harry Potter and the Philosopher's Stone", "J.K. Rowling", "You know. But have you actually read it?"],
      ["Percy Jackson: The Lightning Thief", "Rick Riordan", "Greek gods, modern chaos, zero boring pages."],
      ["Eragon", "Christopher Paolini", "Written by a teenager. Sold millions. Let that sink in."],
      ["Children of Blood and Bone", "Tomi Adeyemi", "West African mythology powering a revolution."],
      ["Raybearer", "Jordan Ifueko", "A West African-inspired empire and a girl raised to betray it."],
      ["An Ember in the Ashes", "Sabaa Tahir", "A scholar and a soldier inside a brutal empire."],
      ["Six of Crows", "Leigh Bardugo", "Six criminals, one impossible heist."],
      ["The Name of the Wind", "Patrick Rothfuss", "A legend narrates his own rise from nothing."],
      ["Beasts Made of Night", "Tochi Onyebuchi", "Sin-eaters in a Nigerian-inspired walled city."]
    ] },
    scifi: { label: "Science Fiction", books: [
      ["Ender's Game", "Orson Scott Card", "A child strategist carries a war. Pure mastermind fuel."],
      ["Dune", "Frank Herbert", "Politics, ecology and prophecy on a desert planet."],
      ["Project Hail Mary", "Andy Weir", "One man, one ship, problem-solving as a survival sport."],
      ["The Martian", "Andy Weir", "Stranded on Mars with maths and duct tape."],
      ["Foundation", "Isaac Asimov", "Predicting the fall of an empire — and planning around it."],
      ["Ready Player One", "Ernest Cline", "A treasure hunt inside a game world."],
      ["The Hunger Games", "Suzanne Collins", "Strategy, survival and the cost of spectacle."],
      ["Scythe", "Neal Shusterman", "When death is solved, someone must still deal it."],
      ["Red Rising", "Pierce Brown", "A miner infiltrates the ruling class. Slow burn, then war."],
      ["Cinder", "Marissa Meyer", "Cinderella as a cyborg mechanic."],
      ["Binti", "Nnedi Okorafor", "A Himba girl takes her maths to the stars. Africanfuturism."],
      ["I, Robot", "Isaac Asimov", "The three laws, and every loophole in them."],
      ["The Hitchhiker's Guide to the Galaxy", "Douglas Adams", "The funniest book ever written about the end of the world."]
    ] },
    mystery: { label: "Mystery & Thriller", books: [
      ["And Then There Were None", "Agatha Christie", "Ten strangers, one island, the tightest plot ever built."],
      ["Murder on the Orient Express", "Agatha Christie", "A train, a snowdrift, twelve suspects."],
      ["The Adventures of Sherlock Holmes", "Arthur Conan Doyle", "Deduction as a superpower. Free — it's public domain."],
      ["The Westing Game", "Ellen Raskin", "A dead millionaire's will turns sixteen heirs into a puzzle."],
      ["The Inheritance Games", "Jennifer Lynn Barnes", "A broke student inherits billions — if she survives the riddle."],
      ["A Good Girl's Guide to Murder", "Holly Jackson", "A student reopens a closed case for a school project."],
      ["One of Us Is Lying", "Karen M. McManus", "Detention, five students, one doesn't walk out."],
      ["Truly Devious", "Maureen Johnson", "A cold case at a school built by an eccentric genius."],
      ["Five Survive", "Holly Jackson", "Eight hours, one RV, a sniper outside."],
      ["Enola Holmes: The Case of the Missing Marquess", "Nancy Springer", "Sherlock's little sister is the smarter one."],
      ["The Da Vinci Code", "Dan Brown", "Puzzles chased across Europe at full sprint."],
      ["The Silent Patient", "Alex Michaelides", "She shot her husband and never spoke again."],
      ["My Sister, the Serial Killer", "Oyinkan Braithwaite", "Lagos, two sisters, and a very dark family habit."]
    ] },
    classics: { label: "Classics", books: [
      ["Things Fall Apart", "Chinua Achebe", "The African classic. If you read one book here, this."],
      ["The Count of Monte Cristo", "Alexandre Dumas", "Betrayed, imprisoned, returns with a plan. The original mastermind arc."],
      ["Animal Farm", "George Orwell", "Power corrupting, explained in a farmyard."],
      ["1984", "George Orwell", "Surveillance, propaganda, and the price of truth."],
      ["To Kill a Mockingbird", "Harper Lee", "Courage is doing right when losing is certain."],
      ["Lord of the Flies", "William Golding", "What people become when the rules go quiet."],
      ["The Great Gatsby", "F. Scott Fitzgerald", "Money, obsession, and the lie inside the dream."],
      ["Pride and Prejudice", "Jane Austen", "The sharpest social chess ever written."],
      ["The Old Man and the Sea", "Ernest Hemingway", "One man, one fish, everything about endurance."],
      ["Of Mice and Men", "John Steinbeck", "Two drifters and a dream in a hard world."],
      ["Jane Eyre", "Charlotte Brontë", "An orphan who refuses to shrink."],
      ["Frankenstein", "Mary Shelley", "Written by a teenager. Invented science fiction."],
      ["The Odyssey", "Homer", "The ten-year journey every story since has borrowed."]
    ] },
    history: { label: "History & Big Ideas", books: [
      ["Sapiens", "Yuval Noah Harari", "The whole human story in one sweep."],
      ["Prisoners of Geography", "Tim Marshall", "Ten maps that explain why the world acts the way it does."],
      ["The Silk Roads", "Peter Frankopan", "World history with the centre moved east."],
      ["Guns, Germs, and Steel", "Jared Diamond", "Why continents' fates diverged."],
      ["A Short History of Nearly Everything", "Bill Bryson", "Science made ridiculous fun."],
      ["The Boy Who Harnessed the Wind", "William Kamkwamba", "A Malawian teenager builds a windmill from scrap and library books."],
      ["Hidden Figures", "Margot Lee Shetterly", "The Black women mathematicians who put men on the moon."],
      ["The Diary of a Young Girl", "Anne Frank", "History at eye level."],
      ["The Wright Brothers", "David McCullough", "Two bicycle mechanics out-engineer the world."],
      ["Longitude", "Dava Sobel", "One clockmaker solves the deadliest problem at sea."],
      ["The Immortal Life of Henrietta Lacks", "Rebecca Skloot", "One woman's cells changed medicine. Nobody asked her."],
      ["Born in Blackness", "Howard W. French", "Africa's central role in making the modern world."],
      ["African History: A Very Short Introduction", "John Parker & Richard Rathbone", "The continent's story, compact and serious."]
    ] },
    philosophy: { label: "Philosophy & Stoicism", books: [
      ["Meditations", "Marcus Aurelius", "A Roman emperor's private notes to himself. Still undefeated."],
      ["The Enchiridion", "Epictetus", "A freed slave's handbook on what you control."],
      ["Letters from a Stoic", "Seneca", "Advice that reads like it was written last week."],
      ["The Daily Stoic", "Ryan Holiday", "One page a day. Pairs perfectly with your quests."],
      ["Ego Is the Enemy", "Ryan Holiday", "The opponent who shares your name."],
      ["Sophie's World", "Jostein Gaarder", "The history of philosophy hidden inside a mystery novel."],
      ["Tao Te Ching", "Laozi", "Eighty-one short verses on power through stillness."],
      ["The Republic", "Plato", "Justice, the cave, and the first blueprint of a state."],
      ["Siddhartha", "Hermann Hesse", "One man's search through wealth, love and the river."],
      ["The Alchemist", "Paulo Coelho", "A fable about following the work that is yours."],
      ["Ikigai", "Héctor García & Francesc Miralles", "The Japanese frame for a life worth grinding for."],
      ["The Courage to Be Disliked", "Ichiro Kishimi & Fumitake Koga", "Freedom is other people's opinions losing their grip."],
      ["The Four Agreements", "Don Miguel Ruiz", "Four rules that quietly delete most self-made suffering."]
    ] },
    manga: { label: "Manga & Manhwa", books: [
      ["Solo Leveling", "Chugong / DUBU", "You know why."],
      ["Omniscient Reader's Viewpoint", "Sing Shong / Sleepy-C", "The only reader of a novel gets trapped in its ending."],
      ["The Beginning After the End", "TurtleMe / Fuyuki23", "A king reborn, levelling from zero with old wisdom."],
      ["Fullmetal Alchemist", "Hiromu Arakawa", "Equivalent exchange: nothing gained without something given."],
      ["Death Note", "Tsugumi Ohba & Takeshi Obata", "Two masterminds in a duel of pure planning."],
      ["Dr. Stone", "Riichiro Inagaki & Boichi", "Rebuilding civilisation with science, from stone age zero."],
      ["One Piece", "Eiichiro Oda", "Three decades of never abandoning the dream."],
      ["Naruto", "Masashi Kishimoto", "The dead-last outworks every genius. That's the thesis."],
      ["My Hero Academia", "Kohei Horikoshi", "Born powerless, chooses heroism anyway."],
      ["Demon Slayer", "Koyoharu Gotouge", "Total effort, total focus, one breath at a time."],
      ["Haikyu!!", "Haruichi Furudate", "Obsessive practice, made electric."],
      ["Blue Lock", "Muneyuki Kaneshiro & Yusuke Nomura", "Ego as fuel: 300 strikers, one survivor."],
      ["Slam Dunk", "Takehiko Inoue", "The greatest sports manga ever drawn."]
    ] },
    adventure: { label: "Adventure & Survival", books: [
      ["Hatchet", "Gary Paulsen", "A boy, a crash, a hatchet, the wild."],
      ["The Call of the Wild", "Jack London", "A dog's descent into strength."],
      ["Treasure Island", "Robert Louis Stevenson", "The pirate story that started them all."],
      ["Robinson Crusoe", "Daniel Defoe", "Shipwrecked and building a world from nothing."],
      ["Life of Pi", "Yann Martel", "A boy, a lifeboat, a tiger, the Pacific."],
      ["Endurance", "Alfred Lansing", "Shackleton's crew, trapped in Antarctic ice. All survive. Read how."],
      ["Into Thin Air", "Jon Krakauer", "The 1996 Everest disaster, from inside it."],
      ["Touching the Void", "Joe Simpson", "Cut the rope or die together. Then it gets worse."],
      ["Kon-Tiki", "Thor Heyerdahl", "Crossing the Pacific on a balsa raft to prove a point."],
      ["The Explorer", "Katherine Rundell", "Four children, a plane crash, the Amazon."],
      ["Journey to the Center of the Earth", "Jules Verne", "Down through a volcano into the impossible."],
      ["Around the World in Eighty Days", "Jules Verne", "A bet, a schedule, and zero margin for error."],
      ["Stormbreaker", "Anthony Horowitz", "A teenage spy who never volunteered."]
    ] },
    african: { label: "African Literature", books: [
      ["Purple Hibiscus", "Chimamanda Ngozi Adichie", "A quiet girl finds her voice in a loud house."],
      ["Homegoing", "Yaa Gyasi", "Two Ghanaian sisters, eight generations, one unbroken thread."],
      ["The Beautyful Ones Are Not Yet Born", "Ayi Kwei Armah", "A Ghanaian classic about staying clean in a corrupt season."],
      ["Changes: A Love Story", "Ama Ata Aidoo", "A modern Ghanaian woman choosing her own terms."],
      ["Americanah", "Chimamanda Ngozi Adichie", "Lagos, America, and what leaving does to identity."],
      ["Half of a Yellow Sun", "Chimamanda Ngozi Adichie", "Biafra, through the people who lived it."],
      ["So Long a Letter", "Mariama Bâ", "One widow's letter carries a generation of women."],
      ["Nervous Conditions", "Tsitsi Dangarembga", "A Zimbabwean girl hungry for the education around her."],
      ["Weep Not, Child", "Ngũgĩ wa Thiong'o", "A Kenyan boy holds onto school as the country burns."],
      ["No Longer at Ease", "Chinua Achebe", "A scholarship son caught between two moral worlds."],
      ["Stay With Me", "Ayọ̀bámi Adébáyọ̀", "A marriage tested by everything Nigeria can throw at it."],
      ["Kintu", "Jennifer Nansubuga Makumbi", "A Ugandan curse traced across centuries."],
      ["The Fishermen", "Chigozie Obioma", "Four brothers, one prophecy, a Greek tragedy in Akure."]
    ] },
    science: { label: "Science & Mathematics", books: [
      ["A Brief History of Time", "Stephen Hawking", "The universe, from a mind that refused its limits."],
      ["Cosmos", "Carl Sagan", "Science as wonder. The book that made scientists."],
      ["Astrophysics for People in a Hurry", "Neil deGrasse Tyson", "The universe between classes."],
      ["The Selfish Gene", "Richard Dawkins", "Evolution seen from the gene's point of view."],
      ["The Gene", "Siddhartha Mukherjee", "The story of heredity, beautifully told."],
      ["What If?", "Randall Munroe", "Serious physics applied to absurd questions."],
      ["Humble Pi", "Matt Parker", "When maths goes wrong in the real world. Hilarious, instructive."],
      ["Fermat's Enigma", "Simon Singh", "A 350-year-old maths problem and the man who cracked it."],
      ["The Code Book", "Simon Singh", "Secret writing from Caesar to quantum cryptography."],
      ["The Man Who Counted", "Malba Tahan", "Maths puzzles wrapped in Arabian tales."],
      ["Alex's Adventures in Numberland", "Alex Bellos", "Why numbers are stranger and funnier than school admits."],
      ["Six Easy Pieces", "Richard Feynman", "Physics from the best explainer who ever lived."],
      ["Surely You're Joking, Mr. Feynman!", "Richard Feynman", "A Nobel physicist who treated everything as play."]
    ] },
    tech: { label: "Tech & Code", books: [
      ["Python Crash Course", "Eric Matthes", "The fastest respectable route from zero to building."],
      ["Automate the Boring Stuff with Python", "Al Sweigart", "Make the computer do your chores. Free online."],
      ["Eloquent JavaScript", "Marijn Haverbeke", "The language of the web, taught properly. Free online."],
      ["Clean Code", "Robert C. Martin", "Write code the next person can read."],
      ["The Pragmatic Programmer", "Andrew Hunt & David Thomas", "The craft, beyond the syntax."],
      ["Cracking the Coding Interview", "Gayle Laakmann McDowell", "The gate into six-figure tech jobs, mapped."],
      ["Hello World", "Hannah Fry", "Algorithms already run your life. Meet them."],
      ["The Innovators", "Walter Isaacson", "The people who built the digital age."],
      ["Hackers", "Steven Levy", "The original code obsessives, 1950s to the PC."],
      ["Ghost in the Wires", "Kevin Mitnick", "The world's most-wanted hacker tells his own chase."],
      ["Life 3.0", "Max Tegmark", "What AI means for being human."],
      ["AI 2041", "Kai-Fu Lee & Chen Qiufan", "Ten stories of the next twenty years, by an AI insider."],
      ["The Phoenix Project", "Gene Kim", "How real tech organisations fail and get fixed, as a novel."]
    ] },
    sports: { label: "Sports & Peak Performance", books: [
      ["The Mamba Mentality", "Kobe Bryant", "How Kobe watched, trained and thought."],
      ["Relentless", "Tim Grover", "Jordan and Kobe's trainer on the difference between good and unstoppable."],
      ["The Inner Game of Tennis", "W. Timothy Gallwey", "The opponent inside your own head."],
      ["Legacy", "James Kerr", "What the All Blacks — the winningest team ever — do differently."],
      ["Mind Gym", "Gary Mack", "An athlete's mind is a muscle. Train it."],
      ["The Champion's Mind", "Jim Afremow", "How great athletes think, train and thrive."],
      ["Peak", "Anders Ericsson", "The actual science behind the '10,000 hours'."],
      ["Bounce", "Matthew Syed", "Talent is a myth. Practice structure is everything."],
      ["The Boys in the Boat", "Daniel James Brown", "Nine broke students out-row Hitler's Olympics."],
      ["Moneyball", "Michael Lewis", "Winning with numbers when you can't win with money."],
      ["Quiet Strength", "Tony Dungy", "Championship leadership without shouting."],
      ["Messi", "Guillem Balagué", "The definitive account of the quiet genius."],
      ["I Am Zlatan", "Zlatan Ibrahimović", "From a rough estate to the top, with zero apologies."]
    ] },
    poetry: { label: "Poetry & Verse", books: [
      ["The Poet X", "Elizabeth Acevedo", "A Harlem girl's life told in slam verse. Reads like fire."],
      ["Long Way Down", "Jason Reynolds", "Sixty seconds in an elevator, one impossible choice, all in verse."],
      ["Clap When You Land", "Elizabeth Acevedo", "Two sisters, one plane crash, two countries."],
      ["Brown Girl Dreaming", "Jacqueline Woodson", "A childhood in verse between South and Brooklyn."],
      ["Inside Out & Back Again", "Thanhhà Lại", "A refugee year, poem by poem."],
      ["And Still I Rise", "Maya Angelou", "Defiance you can memorise."],
      ["The Hill We Climb", "Amanda Gorman", "The inauguration poem that stopped a country."],
      ["The Prophet", "Kahlil Gibran", "On love, work and sorrow — carried in pockets for a century."],
      ["If— and Other Poems", "Rudyard Kipling", "The poem about keeping your head. Learn it."],
      ["Night of My Blood", "Kofi Awoonor", "Ghana's great poet, weaving Ewe oral tradition into English."],
      ["Selected Poems", "Langston Hughes", "The voice of the Harlem Renaissance."],
      ["The Rime of the Ancient Mariner", "Samuel Taylor Coleridge", "A curse, an albatross, unforgettable lines."],
      ["Shakespeare's Sonnets", "William Shakespeare", "154 arguments that language has a ceiling — and this is it."]
    ] },
    romance: { label: "Romance (YA)", books: [
      ["To All the Boys I've Loved Before", "Jenny Han", "Five secret letters escape into the world."],
      ["The Fault in Our Stars", "John Green", "Two sharp minds fall in love inside hard limits."],
      ["Eleanor & Park", "Rainbow Rowell", "Two misfits and one bus seat, 1986."],
      ["The Sun Is Also a Star", "Nicola Yoon", "One New York day, two lives, twelve hours."],
      ["Everything, Everything", "Nicola Yoon", "A girl allergic to the world meets a reason to risk it."],
      ["Frankly in Love", "David Yoon", "Fake dating to satisfy two sets of parents. It backfires beautifully."],
      ["Love from A to Z", "S.K. Ali", "Two Muslim teens, one shared notebook of marvels and oddities."],
      ["Geekerella", "Ashley Poston", "Cinderella retold at a fan convention."],
      ["Pride", "Ibi Zoboi", "Pride and Prejudice, remixed in Brooklyn."],
      ["You Should See Me in a Crown", "Leah Johnson", "Prom queen campaign as an exit strategy."],
      ["Anna and the French Kiss", "Stephanie Perkins", "Boarding school in Paris. It writes itself."],
      ["Heartstopper", "Alice Oseman", "The gentlest graphic novel in the world."],
      ["Along for the Ride", "Sarah Dessen", "Insomnia, a beach town, and learning to ride a bike at 18."]
    ] }
  };

  // system/src/content/screen.js
  var SCREEN = {
    s_action: { label: "Action & Adventure", picks: [
      ["Spider-Man: Into the Spider-Verse", "film", "Anyone can wear the mask. Also the best-looking film ever animated."],
      ["The Dark Knight", "film", "A masterclass in strategy versus chaos."],
      ["Inception", "film", "A heist inside dreams. Watch twice."],
      ["The Batman", "film", "Detective work first, punches second."],
      ["Black Panther", "film", "Wakanda. Enough said."],
      ["Top Gun: Maverick", "film", "Preparation, pressure, and earning the seat."],
      ["Mission: Impossible — Fallout", "film", "What total commitment to craft looks like."],
      ["Avengers: Endgame", "film", "Ten years of setup, one payoff."],
      ["Edge of Tomorrow", "film", "Live, die, repeat — failure as a training loop."],
      ["The Karate Kid", "film", "Wax on, wax off: boring reps become mastery."]
    ] },
    s_anime_act: { label: "Anime — Action & Shonen", picks: [
      ["Solo Leveling", "anime", "The reason this app exists."],
      ["Fullmetal Alchemist: Brotherhood", "anime", "The most complete story anime has produced."],
      ["Demon Slayer", "anime", "Total effort, one breath at a time."],
      ["Jujutsu Kaisen", "anime", "Cursed energy, clean animation, no filler."],
      ["Attack on Titan", "anime", "Strategy and sacrifice behind the walls."],
      ["My Hero Academia", "anime", "Born powerless, chooses heroism anyway."],
      ["One Piece", "anime", "The longest lesson in never quitting."],
      ["Naruto: Shippuden", "anime", "The dead-last outworks every genius."],
      ["Hunter x Hunter", "anime", "Power systems with actual rules — and exams."],
      ["One-Punch Man", "anime", "100 push-ups, 100 sit-ups, 100 squats, 10km. Sound familiar?"]
    ] },
    s_anime_mind: { label: "Anime — Mind Games & Strategy", picks: [
      ["Death Note", "anime", "Two masterminds in a duel of pure planning."],
      ["Code Geass", "anime", "Chess played with armies."],
      ["Steins;Gate", "anime", "Time travel done with real consequences."],
      ["The Promised Neverland", "anime", "Children out-planning their keepers. Season one is perfect."],
      ["Dr. Stone", "anime", "Rebuilding civilisation with science alone. Study fuel."],
      ["Classroom of the Elite", "anime", "A school where everything is a test — especially the people."],
      ["Assassination Classroom", "anime", "The strangest teacher, the best lessons on effort."],
      ["Moriarty the Patriot", "anime", "Sherlock's rival gets the spotlight."],
      ["Spy x Family", "anime", "A spy, an assassin, a telepath — one fake family."],
      ["Hyouka", "anime", "Small mysteries, sharp minds, quiet brilliance."]
    ] },
    s_scifi: { label: "Sci-Fi", picks: [
      ["Interstellar", "film", "Love, gravity, and doing the maths anyway."],
      ["The Martian", "film", "Problem-solving as a survival sport."],
      ["Dune", "film", "Politics and prophecy on a desert planet."],
      ["Arrival", "film", "Language as the ultimate technology."],
      ["Ready Player One", "film", "A treasure hunt inside a game world."],
      ["Back to the Future", "film", "The most watchable film ever engineered."],
      ["WALL-E", "film", "A robot with more heart than most humans."],
      ["Avatar", "film", "The world-building benchmark."],
      ["Stranger Things", "series", "Kids on bikes versus the dark. Hawkins forever."],
      ["Dark", "series", "A German time-travel puzzle box. Take notes — you'll need them."]
    ] },
    s_mystery: { label: "Mystery & Thriller", picks: [
      ["Knives Out", "film", "A modern whodunit with teeth."],
      ["The Prestige", "film", "Two magicians, one obsession. Watch the ending twice."],
      ["Now You See Me", "film", "Heists dressed as magic shows."],
      ["Enola Holmes", "film", "Sherlock's little sister outthinks everyone."],
      ["Murder on the Orient Express", "film", "Christie's classic, on rails."],
      ["Sherlock", "series", "Deduction as a superpower, updated."],
      ["Lupin", "series", "A gentleman thief plays the long game in Paris."],
      ["Wednesday", "series", "Deadpan detective work at Nevermore."],
      ["A Good Girl's Guide to Murder", "series", "The book, faithfully on screen."],
      ["Money Heist", "series", "The most-watched heist plan in television history."]
    ] },
    s_fantasy: { label: "Fantasy", picks: [
      ["The Lord of the Rings: The Fellowship of the Ring", "film", "The standard every epic is measured against."],
      ["Harry Potter and the Philosopher's Stone", "film", "Where it all began."],
      ["Spirited Away", "film", "Miyazaki's masterpiece. Courage in a spirit world."],
      ["Howl's Moving Castle", "film", "A walking castle and a curse worth having."],
      ["The Chronicles of Narnia", "film", "A wardrobe, a war, a world."],
      ["Puss in Boots: The Last Wish", "film", "Secretly one of the best films about fear ever made."],
      ["Avatar: The Last Airbender", "series", "Flawless three-season arc. Mastery, honour, redemption."],
      ["The Dragon Prince", "series", "From Avatar's writers. Politics plus magic."],
      ["Percy Jackson and the Olympians", "series", "Greek gods, modern chaos."],
      ["Shadow and Bone", "series", "The Grishaverse — and the Six of Crows."]
    ] },
    s_true: { label: "True Stories", picks: [
      ["The Pursuit of Happyness", "film", "Homeless single father to stockbroker. True."],
      ["Hidden Figures", "film", "The mathematicians NASA tried not to see."],
      ["Queen of Katwe", "film", "A Ugandan girl from the slums becomes a chess master. True."],
      ["The Boy Who Harnessed the Wind", "film", "The windmill book, beautifully filmed."],
      ["King Richard", "film", "The plan behind Venus and Serena, written before they were born."],
      ["42", "film", "Jackie Robinson breaks the colour line with discipline as armour."],
      ["The Blind Side", "film", "Protection, family, and a left tackle."],
      ["Catch Me If You Can", "film", "A teenage con artist outruns the FBI. Mostly true."],
      ["A Beautiful Mind", "film", "A genius at war with his own mind."],
      ["Bohemian Rhapsody", "film", "Queen, and the cost of the show."]
    ] },
    s_biz: { label: "Business & Money", picks: [
      ["The Social Network", "film", "Facebook's founding — genius, betrayal, equity."],
      ["The Founder", "film", "How McDonald's was taken, not built. Watch who owns what."],
      ["Moneyball", "film", "Winning with numbers when you can't win with money."],
      ["Joy", "film", "A mop, a patent, and a woman who wouldn't fold."],
      ["Self Made", "series", "Madam C.J. Walker — America's first female self-made millionaire."],
      ["The Playlist", "series", "Spotify's founding, told from six angles."],
      ["Shark Tank", "series", "Live pitching. Study the questions, not the drama."],
      ["Inside Bill's Brain", "series", "How Bill Gates thinks, reads and solves."],
      ["The Men Who Built America", "series", "Rockefeller, Carnegie, Morgan — empire mechanics."],
      ["Limitless with Chris Hemsworth", "series", "The science of pushing a human body's limits."]
    ] },
    s_sport: { label: "Sports & Underdogs", picks: [
      ["Rocky", "film", "The blueprint for every underdog story since."],
      ["Creed", "film", "The legacy continues — earn the name."],
      ["Coach Carter", "film", "Locked the gym until the grades came up. True story."],
      ["Remember the Titans", "film", "A team as the answer to a divided town."],
      ["Ford v Ferrari", "film", "Engineering, ego and 7,000 RPM."],
      ["Cool Runnings", "film", "Jamaica's bobsled team. Joy as fuel."],
      ["McFarland, USA", "film", "Field workers become champion runners. True."],
      ["Million Dollar Arm", "film", "Scouting cricket bowlers into baseball. True."],
      ["The Last Dance", "series", "Jordan's Bulls — obsession, documented."],
      ["Formula 1: Drive to Survive", "series", "The pressure business behind the racing."]
    ] },
    s_comedy: { label: "Comedy & Feel-Good", picks: [
      ["Paddington 2", "film", "Kindness as a superpower. Genuinely perfect."],
      ["The Truman Show", "film", "What if your whole life was the show?"],
      ["School of Rock", "film", "A fraud teaches the realest lessons."],
      ["Ferris Bueller's Day Off", "film", "Life moves pretty fast."],
      ["Home Alone", "film", "Preparation beats size. Every time."],
      ["The Secret Life of Walter Mitty", "film", "Stop daydreaming the life. Go get it."],
      ["Hunt for the Wilderpeople", "film", "A boy, a grump, a manhunt, New Zealand."],
      ["Klaus", "film", "How legends get started — one act at a time."],
      ["Soul", "film", "Purpose is not what you think it is."],
      ["Young Sheldon", "series", "A boy genius survives Texas. Warm and sharp."]
    ] },
    s_africa: { label: "African Cinema", picks: [
      ["The Burial of Kojo", "film", "Ghana's dreamlike Netflix debut — Accra has never looked like this."],
      ["Keteke", "film", "A Ghanaian couple races a train to reach home for a birth. Comedy gold."],
      ["Aloe Vera", "film", "Two feuding Ghanaian towns, one forbidden friendship, full colour."],
      ["Lionheart", "film", "A daughter fights to save her father's Nigerian transport company."],
      ["Aníkúlápó", "film", "Yoruba epic — a man who cheats death and overreaches."],
      ["The Woman King", "film", "The Agojie, Dahomey's real all-female army."],
      ["Queen of Katwe", "film", "Filmed in Kampala with real texture."],
      ["Iwájú", "series", "Disney's animated Lagos — flying cars, real class lines."],
      ["Supa Team 4", "series", "Zambian schoolgirl superheroes. Watch with younger siblings."],
      ["Far From Home", "series", "A scholarship kid inside Lagos's richest school."]
    ] },
    s_docs: { label: "Documentaries — Brain Food", picks: [
      ["Free Solo", "doc", "3,000 feet, no rope. Preparation as religion."],
      ["14 Peaks: Nothing Is Impossible", "doc", "All fourteen 8,000m mountains in seven months."],
      ["My Octopus Teacher", "doc", "A year of showing up, rewarded."],
      ["The Social Dilemma", "doc", "The people who built the feed explain the trap."],
      ["Cosmos: A Spacetime Odyssey", "series", "The universe, gorgeously explained."],
      ["Our Planet", "series", "Earth at its most cinematic."],
      ["Planet Earth II", "series", "The cities episode alone is worth it."],
      ["Explained", "series", "One complex topic per 20 minutes."],
      ["The Mind, Explained", "series", "Memory, focus, dreams — your hardware manual."],
      ["Abstract: The Art of Design", "series", "How world-class designers actually think."]
    ] }
  };

  // system/src/content/tools.js
  var TOOLS = [
    ["Exam Prep — your curriculum, mastered", [
      ["Khan Academy", "khanacademy.org", "Free, world-class lessons in maths and sciences. The default answer to 'I don't get this topic'."],
      ["Save My Exams", "savemyexams.com", "IGCSE/GCSE/A-Level revision notes and past-paper questions by topic. Built for your exact syllabus."],
      ["Physics & Maths Tutor", "physicsandmathstutor.com", "Free past papers and topic questions for IGCSE through A-Level. The paper-grinding site."],
      ["Seneca Learning", "senecalearning.com", "Free smart-repetition courses mapped to GCSE/A-Level specs."],
      ["BBC Bitesize", "bbc.co.uk/bitesize", "Clean, free study notes for core subjects."],
      ["Quizlet", "quizlet.com", "Flashcards for everything, made by millions of students before you."],
      ["Anki", "apps.ankiweb.net", "The serious flashcard app. Spaced repetition — how med students memorise oceans."]
    ]],
    ["University-Level, Free", [
      ["Harvard CS50", "cs50.harvard.edu/x", "Harvard's legendary intro to computer science. Free, with a certificate path."],
      ["MIT OpenCourseWare", "ocw.mit.edu", "Actual MIT courses — lectures, notes, exams — free."],
      ["edX", "edx.org", "University courses from Harvard, MIT and more. Audit free."],
      ["Coursera", "coursera.org", "University and industry courses. Financial aid can make certificates free — apply, it works."],
      ["OpenLearn", "open.edu/openlearn", "The Open University's free course library."],
      ["CrashCourse", "youtube.com/@crashcourse", "Every school subject, explained fast and well."]
    ]],
    ["Code & Build", [
      ["freeCodeCamp", "freecodecamp.org", "Zero to certified developer, completely free. The dropout's university."],
      ["The Odin Project", "theodinproject.com", "A full free web-development curriculum that makes you build."],
      ["Codecademy", "codecademy.com", "Interactive coding in the browser. Free tier is plenty to start."],
      ["W3Schools", "w3schools.com", "The reference — try every web technology in the browser."],
      ["Scrimba", "scrimba.com", "Interactive screencasts where you pause and edit the teacher's code."],
      ["Kaggle Learn", "kaggle.com/learn", "Free micro-courses in Python, data and machine learning, plus real competitions."],
      ["Replit", "replit.com", "Code anything from a browser — no laptop setup needed."]
    ]],
    ["Skills That Pay", [
      ["Google Skillshop & Digital Garage", "skillshop.withgoogle.com", "Free Google certifications in ads, analytics and digital marketing. Real CV weight."],
      ["HubSpot Academy", "academy.hubspot.com", "Free certified courses in marketing, sales and content."],
      ["Canva Design School", "canva.com/learn", "Design fundamentals on the tool half of Ghana's flyers are made with."],
      ["ALX Africa", "alxafrica.com", "Serious tech and professional programmes built for African students. Scholarships exist."],
      ["Duolingo", "duolingo.com", "A second language, five minutes at a time."],
      ["3Blue1Brown", "youtube.com/@3blue1brown", "Maths made visual and beautiful. Watch one video and you'll understand."],
      ["Veritasium", "youtube.com/@veritasium", "Physics and engineering stories that make you smarter by accident."],
      ["The Organic Chemistry Tutor", "youtube.com/@TheOrganicChemistryTutor", "Every maths, physics and chemistry topic, worked calmly on a black screen."]
    ]]
  ];

  // system/src/content/careers.js
  var CAREERS = [
    {
      k: "swe",
      n: "Software Engineer",
      f: "Tech",
      pay: "Global range roughly $60k–$300k+/yr; remote work reaches Ghana",
      d: "Build the apps, sites and systems the world runs on.",
      s: "Start freeCodeCamp or CS50 tonight. Build three small real projects this year — this app counts as watching one get built."
    },
    {
      k: "ai",
      n: "AI / Machine Learning Engineer",
      f: "Tech",
      pay: "Among the highest-paid skills alive; top roles $150k–$500k+",
      d: "Build and train the models behind AI products.",
      s: "Master maths (algebra, calculus, statistics) at school — it is the actual entry gate. Then Python, then Kaggle Learn."
    },
    {
      k: "data",
      n: "Data Scientist",
      f: "Tech",
      pay: "Roughly $70k–$250k globally; every industry hires",
      d: "Turn raw data into decisions companies pay for.",
      s: "Statistics is your best friend now. Python + spreadsheets + one Kaggle competition before you finish school."
    },
    {
      k: "cyber",
      n: "Cybersecurity Specialist",
      f: "Tech",
      pay: "Roughly $70k–$250k; shortage everywhere, Ghana included",
      d: "Defend systems and money from attackers — legally.",
      s: "Learn how networks work, then practise on legal labs like TryHackMe. Never touch real systems without permission."
    },
    {
      k: "doctor",
      n: "Medical Doctor / Surgeon",
      f: "Medicine",
      pay: "High and stable worldwide; specialists earn multiples more",
      d: "Diagnose, treat, operate. The profession that never loses demand.",
      s: "Biology, chemistry, physics — excellent grades, no shortcuts. This road runs through school and it is long. Shadow a clinic if you can."
    },
    {
      k: "pharm",
      n: "Pharmacist",
      f: "Medicine",
      pay: "Solid professional income; ownership of a pharmacy scales it",
      d: "Medicines expert — hospital, retail, or industry.",
      s: "Chemistry and biology now. Note the wealth move: pharmacists who OWN pharmacies climb fastest."
    },
    {
      k: "dentist",
      n: "Dentist",
      f: "Medicine",
      pay: "Consistently top-five earning profession in most countries",
      d: "Oral health, surgery, and often your own practice.",
      s: "Sciences now, dental school later, own the chair eventually — practice owners out-earn employees heavily."
    },
    {
      k: "law",
      n: "Corporate / Commercial Lawyer",
      f: "Law",
      pay: "Top firms pay very highly; partners earn multiples",
      d: "Contracts, deals, and disputes for companies — where law meets money.",
      s: "Read constantly, join every debate, and learn to write with precision. Your weapon is language under pressure."
    },
    {
      k: "ib",
      n: "Investment Banker",
      f: "Finance",
      pay: "Very high from year one; brutal hours are the price",
      d: "Advise companies on raising money, buying and selling each other.",
      s: "Excel in maths and economics. Start reading financial news weekly — understanding a deal by 17 puts you years ahead."
    },
    {
      k: "actuary",
      n: "Actuary",
      f: "Finance",
      pay: "Roughly $80k–$250k; rises with each professional exam passed",
      d: "Price risk for insurers and pensions with mathematics.",
      s: "Pure maths strength. The path is professional exams, not prestige degrees — a disciplined grinder's dream career."
    },
    {
      k: "quant",
      n: "Quantitative Analyst",
      f: "Finance",
      pay: "Among finance's highest; top funds pay like tech royalty",
      d: "Build mathematical models that trade markets.",
      s: "Maths + programming, both at a high level. Every hour on either is a deposit."
    },
    {
      k: "acct",
      n: "Chartered Accountant → CFO",
      f: "Finance",
      pay: "Solid start; CFO track reaches executive pay",
      d: "The language of business — every company must speak it.",
      s: "Take accounting/business seriously now; the ICAG or ACCA qualification later is a passport that works in every country."
    },
    {
      k: "petro",
      n: "Petroleum / Mining Engineer",
      f: "Engineering",
      pay: "Among engineering's best-paid, and Ghana has the resources",
      d: "Extract oil, gas and minerals — Ghana's own gold and oil economy hires these.",
      s: "Physics, chemistry and maths. Follow what happens in Ghana's Jubilee oil field and the mining sector — that is your future workplace."
    },
    {
      k: "elec",
      n: "Electrical / Power Engineer",
      f: "Engineering",
      pay: "Solid to high; energy transition is multiplying demand",
      d: "Design power systems, electronics, and the grid itself.",
      s: "Physics now, and tinker — repair things, build small circuits, break stuff you own."
    },
    {
      k: "civil",
      n: "Civil / Structural Engineer",
      f: "Engineering",
      pay: "Solid income; project leaders and firm owners earn far more",
      d: "Roads, bridges, buildings — Africa is constructing itself for the next 50 years.",
      s: "Maths and physics, plus technical drawing if offered. Notice structures everywhere you go."
    },
    {
      k: "renew",
      n: "Renewable Energy Engineer",
      f: "Engineering",
      pay: "Growing fast; solar is booming across West Africa",
      d: "Solar, wind and storage systems — the century's build-out.",
      s: "Physics first. Learn how a solar installation actually works — panels, inverter, batteries — and you're ahead of most adults."
    },
    {
      k: "pilot",
      n: "Commercial Pilot",
      f: "Aviation",
      pay: "High once flying; training is the expensive gate",
      d: "Fly for airlines — a licence the whole world accepts.",
      s: "Physics, geography, fitness, and clean discipline records. Research cadet programmes that sponsor training."
    },
    {
      k: "arch",
      n: "Architect",
      f: "Design",
      pay: "Mid to high; firm owners and developers earn far more",
      d: "Design the buildings others merely construct.",
      s: "Draw daily. Maths plus art is the rare stack this career runs on. Study buildings you admire in Accra."
    },
    {
      k: "pm",
      n: "Product Manager (Tech)",
      f: "Tech",
      pay: "Roughly $90k–$300k at serious companies",
      d: "Decide what gets built and why — the mini-CEO of a product.",
      s: "Build tiny products now (even paper plans), show them to real users, learn from what they ignore."
    },
    {
      k: "ux",
      n: "UX / Product Designer",
      f: "Design",
      pay: "Roughly $60k–$200k; portfolio beats certificates",
      d: "Design how apps look, feel and flow.",
      s: "Figma is free. Redesign one app you use badly — that's portfolio piece one."
    },
    {
      k: "mkt",
      n: "Digital Marketer / Growth",
      f: "Business",
      pay: "Scales with results; the best negotiate percentage of revenue",
      d: "Get products in front of the people who need them, measurably.",
      s: "Run one page or channel seriously for six months and study what the numbers do. Google's free certificates put paper behind it."
    },
    {
      k: "creator",
      n: "Content Creator / Media Entrepreneur",
      f: "Media",
      pay: "Honest truth: most earn little, the top earn millions — a power-law game",
      d: "Build an audience, then products, sponsorships and businesses on top of it.",
      s: "Publish weekly for a year before judging yourself. Consistency is the entire entrance exam. Treat it as a business from day one."
    },
    {
      k: "estate",
      n: "Real Estate Developer",
      f: "Business",
      pay: "Capital-heavy and slow, with one of the highest ceilings in Ghana",
      d: "Buy land, build, rent, repeat — the classic quiet fortune.",
      s: "You can't buy land yet, so buy knowledge: learn how land title works in Ghana, follow property prices, and master sales."
    },
    {
      k: "sales",
      n: "Sales / Business Development",
      f: "Business",
      pay: "Commission is uncapped — top closers out-earn their managers",
      d: "Every company lives or dies on this. The most transferable high-income skill.",
      s: "Sell something small this term — anything, to anyone. Ten rejections is the tuition; one yes is the diploma."
    },
    {
      k: "founder",
      n: "THE OWNER'S PATH — Founder / Entrepreneur",
      f: "◆ Ownership",
      pay: "Uncapped in both directions — the only road that reaches billionaire",
      d: "Build a business you own. Salaries are capped by definition; equity is not. Every billionaire alive holds ownership, not a payslip. The honest print: most ventures fail, the winners usually failed first, and the skills below are the parachute either way.",
      s: "Stack any two professions above (that's your unfair advantage), study the Wealth Academy's Billionaire Blueprint, and launch something tiny this year — a product, a service, a store. Owning 100% of something small teaches what no school can."
    }
  ];
  var GATE = [
    { t: "Read This First", b: "The Gate is not an advert for dropping out. If school is still open to you, stay and use it — it is the cheapest structured training you will ever be offered, and careers like medicine, law and licensed engineering pass through it with no exceptions. The Gate exists for a different hunter: the one already out — money, family, circumstances — or forced out and refusing to stay down. If that is you, hear the System clearly: school is one road to knowledge, not the toll gate on it. The library is open. The internet is open. The Gate is open. What is not available is the version of you that quits learning because a classroom closed." },
    { t: "The Way Back In — Ghana Edition", b: "In Ghana the door back into certification never fully shuts. WASSCE can be written as a PRIVATE CANDIDATE (the Nov/Dec exams) — people prepare by self-study, remedial classes or online tools and sit the papers without being enrolled in a school. Pass, and university and nursing/teacher training routes reopen as if you never left. Distance learning and mature-student entry exist at Ghanaian universities too. Write this on your wall: dropping out delays certificates; only stopping deletes them." },
    { t: "The Free University in Your Pocket", b: "Everything in Library → The Arsenal is open to you, and three of those doors were practically built for people outside school: Khan Academy rebuilds your maths and science from wherever they cracked; freeCodeCamp and The Odin Project take you from zero to employable developer, free, and employers in tech genuinely hire certificate-free skill; Coursera's financial aid makes real university certificates free if you write the application. Two focused hours a day on ONE of these beats a distracted classroom. The timetable in this app is your school bell now." },
    { t: "Skills That Pay Without a Certificate", b: "These trades and skills sell on demonstrated ability, not paper: coding and web development (the portfolio IS the certificate); graphic design and video editing (same); digital marketing; sales (the greatest degree-free equaliser alive); photography; phone and electronics repair; tailoring and fashion; hairdressing and barbering; auto mechanics; welding and fabrication; electrical installation; plumbing; carpentry; catering and baking. Notice what they share: visible results. A dropout with proof beats a graduate with promises in every one of these markets. Your job is to build the proof." },
    { t: "Paths That DO Demand School — Know Them", b: "Honesty so you choose with open eyes: doctor, pharmacist, dentist, nurse, lawyer, licensed/professional engineer, architect, commercial pilot — these require formal qualification by LAW, not by snobbery, and no portfolio substitutes. If one of these is your true target, the Gate's assignment is different: it becomes the Way Back In (card 2). Use the free tools to rebuild your grades, sit WASSCE privately, and re-enter the pipeline. Harder than never leaving? Yes. Impossible? Not even close — every university in Ghana has mature students who took exactly this road." },
    { t: "Certificates That Carry Weight (No Degree Needed)", b: "Paper still helps, and some of it is reachable from a phone: Google Career Certificates (IT support, data analytics, project management, UX — hiring companies recognise them); freeCodeCamp certifications; ALX Africa programmes; HubSpot and Google marketing certifications; CompTIA for IT; and in the trades, Ghana's NVTI (National Vocational Training Institute) tests and certifies practical skills — a recognised proficiency certificate for tailors, mechanics, electricians and more. Stack one recognised certificate on top of demonstrated skill and most doors stop asking about school." },
    { t: "The Apprenticeship Road", b: "Ghana's oldest school is the master's workshop, and it still works: attach yourself to the best tailor, mechanic, electrician, welder or caterer within reach and trade labour for training. Make it serious — agree the terms (duration, what you'll learn, any fees) clearly and in writing where possible, show up earlier than asked, and treat sweeping the floor as the entrance exam it is. Three years under a real master plus an NVTI certificate is a career. Add the Vault's discipline and the Academy's lessons, and it becomes your OWN workshop with apprentices of your own." },
    { t: "First Income Playbook", b: "Out of school, income cannot wait for perfect — so run the ladder: 1) SERVE — pick one skill people near you already pay for and do five jobs, even cheap ones; you are buying proof, not profit. 2) SHOW — photograph every result; your WhatsApp status and a simple page are your shop window. 3) RAISE — with proof in hand, charge properly and ask every satisfied customer for one referral by name. 4) SPLIT — every cedi through the Vault, no exceptions; the Freedom jar is how a hustle becomes an escape and not a treadmill. 5) CLIMB — reinvest the Learn jar into the next skill up the value chain. Months one to three are ugly for everyone. The ladder pays the ones still on it in month twelve." },
    { t: "The Trap List — Predators Hunt Here", b: "The moment you are young, out of school and hungry for money, you become the exact target market for Ghana's prettiest traps: betting and 'aviator' apps (the maths is built for you to lose — they are not income, they are a tax on hope); forex and crypto 'mentors' selling signals and account management (if their trading truly printed money, your GHS 200 fee would be beneath them); pyramid and 'recruit two people' schemes (the product is you); advance-fee 'connection men' selling jobs and visas; and any offer where urgency, secrecy and testimonies replace boring, checkable detail. The System's rule is one line: real money answers questions, fake money forbids them. Walk from anything that punishes questions." }
  ];

  // system/src/app/version.js
  var SYSTEM_VERSION = "18.16.0";
  var SYSTEM_CACHE = "system-v" + SYSTEM_VERSION;
  var SYSTEM_SCHEMA = 6;
  function systemBuild() {
    return { version: SYSTEM_VERSION, cache: SYSTEM_CACHE, schema: SYSTEM_SCHEMA };
  }

  // system/src/app/theme.js
  var THEMES = ["void", "abyss", "day", "system"];
  function applyTheme(t) {
    let use = t;
    if (t === "system") use = matchMedia("(prefers-color-scheme: light)").matches ? "day" : "void";
    document.documentElement.setAttribute("data-theme", use);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", use === "day" ? "#eef3f9" : use === "abyss" ? "#000000" : "#05070d");
  }
  function currentTheme() {
    try {
      const t = localStorage.getItem("system.theme");
      if (THEMES.includes(t)) return t;
    } catch (e) {
    }
    return "void";
  }
  function setTheme(t) {
    if (!THEMES.includes(t)) return;
    try {
      localStorage.setItem("system.theme", t);
    } catch (e) {
    }
    applyTheme(t);
  }
  applyTheme(currentTheme());
  matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => {
    if (currentTheme() === "system") applyTheme("system");
  });
  document.addEventListener("DOMContentLoaded", () => {
    const sel = document.getElementById("setTheme");
    if (sel) {
      sel.value = currentTheme();
      sel.onchange = () => setTheme(sel.value);
    }
  });

  // system/src/lore.js
  var LORE = [{ "t": "Prologue — The Weakest Player", "lvl": 1, "txt": "The rain fell against the towering glass walls of Dominion Academy like thousands of needles striking steel. Midnight shadows stretched across the campus, swallowing the marble walkways and elite dormitories in darkness while most students slept peacefully inside their expensive rooms, unaware that one boy still remained awake beneath the academy lights. Deep inside the nearly empty training hall, Kael Orion stood alone before a cracked mirror with sweat dripping slowly from his chin onto the cold floor below. His breathing was uneven, his muscles trembling violently from exhaustion, and dark bruises covered his arms from hours of relentless training. The digital clock mounted high on the wall read 2:47 AM. Most students at Dominion Academy spent their nights building alliances, attending underground parties, or competing for Influence Points through politics and manipulation. Kael spent his nights destroying himself piece by piece in silence. He tightened the worn bandages around his hands before throwing another punch into the heavy bag hanging before him. The impact echoed through the empty gym like a gunshot. Again. Again. Again. Every strike carried frustration buried deep inside his chest. Every movement was fueled by memories of humiliation, mockery, weakness, and the cold laughter of students who once looked at him like he was worthless. Dominion Academy was not a place where weakness survived. It was a battlefield disguised as a school, and Kael had entered it as the weakest player on the board. Weeks earlier he had walked through the academy gates with uncertain eyes and a rank so low it immediately made him the target of predators. Students laughed openly when they saw his entrance score displayed on the public rankings. Some whispered insults behind his back while others openly mocked him to his face. His Influence Points disappeared within days after upperclassmen cornered him in the hallway and forced him to surrender everything he had. Nobody helped him. Nobody cared. At Dominion Academy, weakness was entertainment. Kael remembered sitting alone on the rooftop that night while cold wind moved through his black hair and the city lights stretched endlessly beyond the academy walls. He remembered staring down at the students below like pieces scattered across a giant chessboard while thoughts of failure consumed him completely. That had been the moment the system appeared. A glowing blue interface materialized before his eyes with mechanical precision, displaying words that would permanently alter the course of his life. STRATEGIST SYSTEM ACTIVATED. From that night onward, Kael stopped seeing people as simply classmates. He saw patterns. Connections. Weaknesses. Motives. The academy transformed from an overwhelming nightmare into a system waiting to be understood. Now winter had arrived, and with it came a transformation no one fully noticed at first. Every morning Kael woke before sunrise while the dormitories remained silent beneath the darkness. At exactly 5:00 AM his alarm rang through the cold room, and without hesitation he forced himself out of bed regardless of how little sleep he had managed to get the night before. His body constantly ached. Some mornings his muscles screamed so violently he could barely stand upright. Other mornings his mind felt drowned beneath exhaustion after spending entire nights studying behavioral analysis, strategic theory, influence economics, and psychological warfare through the Strategist System. None of it mattered. Kael never waited for motivation because motivation was unreliable. Motivation disappeared the moment conditions became painful.\nDiscipline remained. While countless students searched for temporary excitement or shortcuts to power, Kael built routines so brutal and consistent they slowly reshaped him from the inside out. Cold showers before dawn. Morning runs through freezing rain. Hours in the library studying advanced strategic models while memorizing student behavior patterns. Weight training until his hands tore open. Nights spent analyzing alliances across Dominion Academy while the system quietly processed thousands of variables behind his eyes. Every day repeated like machinery grinding forward without mercy. The academy slowly began changing around him even though most students failed to notice the source of the shift. Rumors spread faster than before. Alliances collapsed unexpectedly. Underground betting networks destabilized overnight. Certain students suddenly made decisions that benefited Kael’s hidden network without even realizing they were being guided toward specific outcomes. What looked like coincidence to everyone else looked like architecture to Kael. He no longer reacted emotionally to events unfolding around him because emotions clouded calculations. Instead he observed. Adjusted. Predicted. Manipulated. The Strategist System evolved alongside him, displaying increasingly complex probability lines and behavioral simulations across his vision. Students became moving variables within a larger equation, and Dominion Academy itself transformed into a living battlefield of information. Yet despite the growing influence surrounding his name, Kael never stopped training. Never stopped studying. Never stopped refining himself in isolation while the rest of the academy remained distracted by visible power. Mira Kazuki noticed the transformation first. One evening she found him sitting alone in the academy library beneath dim fluorescent lights while snow drifted quietly beyond the massive windows. Books on military strategy, psychology, economics, and influence theory surrounded him in towering stacks while his tablet displayed a constantly shifting map of student interactions across campus. Mira studied him silently for several seconds before speaking. “You’re changing,” she said quietly. Kael glanced up from the screen with calm indifference. “Everyone changes.” Mira narrowed her eyes slightly. “No,” she replied. “Most people adapt to survive. You’re becoming something else entirely.” Kael did not answer immediately. Instead he closed the tablet slowly and looked out toward the dark academy courtyard where students moved through the snowfall like tiny shadows beneath the lights. He understood what Mira meant, though he would never admit it openly. Dominion Academy had forced evolution upon him. Weakness had been burned out through humiliation, repetition, and relentless pressure. Every sleepless night. Every lonely morning. Every drop of sweat falling onto cold gym floors. Every calculated move within the academy’s hidden wars. All of it had transformed him into something dangerous. The underground arena reopened shortly after winter break began, drawing massive crowds eager to witness the academy’s strongest fighters battle for Influence Points. The atmosphere inside the chamber felt electric as students shouted bets and holographic ranking boards flashed above the arena floor. Kael stood quietly near the edge of the crowd with his hands in his pockets while the Strategist System analyzed movement patterns throughout the room. Across the arena, Leon Hartwell destroyed another opponent with overwhelming force while spectators erupted into cheers. Yet Kael barely watched the fight itself. Instead his eyes moved across the audience, studying reactions, alliances, emotional investment, and information flow. Aria Valen noticed\nimmediately. She leaned casually against the railing beside him with an amused smile. “You still don’t watch the actual fights,” she said. Kael remained calm. “The fight is never the important part.” Aria laughed softly while snowflakes melted against her silver hair near the arena entrance. “That answer sounds terrifying.” Perhaps it was. Because Kael no longer cared about appearing normal. He cared about results. Winter deepened. The academy grew colder. So did Kael. Students eventually stopped mocking him openly. Not because he had become the strongest physically, but because something about him now felt impossible to approach carelessly. His presence carried a quiet pressure that unsettled people instinctively. He walked through the academy calmly while others argued, competed, and struggled for temporary victories around him. Every step looked controlled. Every word calculated. His body had changed as well from months of relentless training. Sharp muscle lines formed beneath black clothing, scars marked his hands, and exhaustion permanently shadowed his eyes from endless nights without proper rest. Yet despite the physical transformation, the most dangerous change existed within his mind. Kael no longer feared the academy. He no longer feared stronger students. He no longer feared failure itself. Fear had been replaced by obsession. The obsession to rise high enough that nobody would ever again look down on him with pity. Late one night Kael returned to the rooftop where everything had first begun. Snow covered the railing in thin layers of white while freezing wind swept across the silent campus below. The Strategist System activated automatically before his eyes, projecting glowing blue light into the darkness. USER STATUS UPDATED Strength: Increasing Observation: Advanced Strategy: Elite Tier Influence: Expanding Kael stared silently at the words while the academy lights flickered beneath him like stars trapped on earth. Somewhere below, students laughed with friends, chased rankings, fought battles, and dreamed about becoming important within Dominion Academy. None of them fully understood the game unfolding around them. None of them realized how deeply the invisible threads of influence already stretched across the campus. Kael rested his arms against the rooftop railing and closed his eyes briefly as cold snow touched his face. He remembered the weak boy who once stood here believing he would never survive this academy. That version of himself was gone now. Destroyed.\nRebuilt. The winter arc had never been about becoming stronger than everyone else overnight. It had been about enduring what others refused to endure. Waking up when others slept. Working while others complained. Remaining disciplined while others searched for motivation. Learning while others chased attention. Suffering quietly while everyone else looked for comfort. Far below him, Dominion Academy continued moving like a giant chessboard beneath the night. Kael opened his eyes slowly. For the first time since arriving at the academy… He no longer felt like a piece. He felt like the player." }, { "t": "Chapter 2 — The Rise of the Shadow", "lvl": 2, "txt": "The Strategic Tournament changed everything. By the following morning Dominion Academy no longer viewed Kael Orion as background noise hidden among thousands of ambitious students. His name spread through classrooms, dormitories, underground forums, and elite social circles with terrifying speed. Students who once ignored him now lowered their voices whenever he walked past. Others watched him carefully from across hallways as though trying to understand how someone so quiet had dismantled entire teams of elite strategists without relying on brute force. Rumors multiplied faster than the academy administration could suppress them. Some claimed Kael possessed insider information from the faculty. Others believed he came from a hidden political family manipulating the academy behind the scenes. A few even whispered that he had predicted the entire tournament outcome weeks in advance before it ever began. Kael neither denied nor confirmed anything. Silence itself became another weapon. Snow continued falling across Dominion Academy as winter tightened its grip around the massive campus. The academy grounds looked beautiful beneath the cold white lights and frozen pathways, but beneath that calm surface tension spread everywhere. The Strategic Tournament had destabilized the hierarchy. For years Dominion Academy had been ruled by visible strength — combat specialists, charismatic leaders, and wealthy elites who controlled factions openly\nthrough fear or admiration. Kael’s victory introduced something far more dangerous into the ecosystem: invisible power. Students now understood that influence could exist without recognition. Control could exist without authority. Someone could dominate the board without ever stepping into the spotlight until the exact moment they chose to. Kael walked alone through the courtyard while snowflakes drifted against his black coat. The Strategist System quietly updated across his vision. SHADOW NETWORK STATUS Nodes Active: 37 Influence Growth: Accelerating Threat Assessment: Rising Potential Hostile Attention Detected He barely reacted. The academy had finally started noticing him. That was inevitable. What mattered now was surviving the consequences. As Kael entered the main academic building, conversations immediately softened around him. Groups of students glanced away the moment his eyes moved toward them. Others pretended not to stare while secretly observing every movement he made. Kael ignored all of it with calm detachment. Attention itself was meaningless unless properly utilized. Fear was useful. Curiosity was useful. Admiration was useful. Every emotion people directed toward him created leverage if handled correctly. “You’re enjoying this way too much.” Kael turned slightly as Mira Kazuki appeared beside him carrying several books against her chest. Her sharp eyes scanned the surrounding students before returning toward him with visible irritation. “The academy’s becoming paranoid,” she continued quietly. “Half the student body thinks you manipulated the entire tournament from the shadows.” Kael slipped his hands into his pockets calmly. “Only half?” Mira sighed heavily. “That response is exactly why people think you’re dangerous.” Dangerous. The word lingered in his mind for a moment. Months ago people described him as weak. Forgettable. Irrelevant. Now they called him dangerous.\nInteresting how quickly perception changed. The two continued walking through the corridor while students instinctively moved aside to clear space around them. Mira noticed it immediately. Her expression tightened slightly. “See that?” she asked quietly. “They’re avoiding you.” Kael remained expressionless. “Fear creates distance.” Mira glanced toward him carefully. “And does that bother you?” For several seconds Kael said nothing. Snowlight reflected faintly through the corridor windows across his dark eyes while countless calculations moved silently behind them. Finally he answered in a calm voice. “No.” Because the truth was simple. Loneliness stopped hurting once you became obsessed with growth. That evening Kael returned to the training hall after classes ended. The gym remained mostly empty except for the distant sound of weights clanging somewhere near the far wall. He removed his jacket slowly before wrapping fresh bandages around his scarred hands. His muscles still ached constantly from weeks of overtraining, but he welcomed the pain now. Pain meant movement. Pain meant progress. Weakness had once controlled his life because he feared discomfort. That version of himself no longer existed. The heavy bag swung violently beneath another brutal punch. Then another. Then another. Sweat dripped onto the floor while cold air filled the massive room. Kael’s breathing deepened as his strikes accelerated with controlled precision. His body moved mechanically through combinations repeated thousands of times over endless nights. Every movement reflected discipline carved into muscle memory through repetition. No motivation. No excitement. Just routine. Across the gym several first-year students secretly watched him train from a distance. “He’s insane,” one whispered quietly. “No wonder he won the tournament.” “You think he sleeps?” Kael ignored them completely. People always admired results while overlooking the suffering required to create them.\nHours passed. The gym slowly emptied. Midnight approached. Still Kael continued training beneath the dim fluorescent lights while snowstorms raged outside the academy walls. Eventually the Strategist System activated again across his vision. WARNING: PHYSICAL STRAIN EXCEEDING SAFE PARAMETERS. Kael wiped sweat from his face without slowing down. Warnings meant nothing. Limits were negotiable. The sound of footsteps suddenly echoed through the empty gym behind him. Kael stopped striking the heavy bag and turned slightly as Aria Valen entered the room carrying two canned coffees in her hands. She studied him silently for several seconds before tossing one drink toward him casually. Kael caught it instantly. “You train like someone running from death,” Aria said quietly. Kael opened the can slowly. “Maybe I am.” Aria leaned against the nearby wall while watching him carefully. Unlike most students, she never looked intimidated around him. Curious, yes. Fascinated, definitely. But never afraid. That made her dangerous in her own way. “You know what’s funny?” she asked softly. “What?” “Everyone thinks your strength comes from being a genius strategist.” Kael remained silent. Aria smiled faintly. “But that’s not your real advantage,” she continued. “Your real advantage is that you’re willing to suffer longer than everyone else.” For the first time that night, Kael paused completely. Because she was right.\nDominion Academy was filled with talented people. Natural fighters. Brilliant analysts. Charismatic leaders. Wealthy elites. But most of them still depended on comfort. Ego. Motivation. Pride. They stopped once effort became painful enough. Kael didn’t. That difference changed everything. The following week the academy administration announced something unexpected. A special winter evaluation. All first and second-year students would participate in a large-scale competitive assessment designed to measure combat ability, intelligence, leadership, and psychological resilience under pressure. Rankings would be updated permanently afterward. Elite students immediately began preparing themselves obsessively because the evaluation could dramatically alter the academy hierarchy before the next semester. But Kael noticed something else. The Strategist System highlighted the announcement in red. HIGH RISK EVENT DETECTED PROBABILITY OF TARGETED HOSTILITY: 78% Someone was planning something. As students flooded across campus discussing the upcoming evaluation, Kael stood alone beside the massive ranking board in the central courtyard while snow drifted quietly around him. Names shifted constantly across the glowing display as Influence Points updated in real time. Leon Hartwell remained near the top through overwhelming combat dominance. Mira ranked high through analytical excellence. Aria’s influence continued rising unpredictably. And then there was Kael Orion. His name now sat far higher than it once had. Too high to ignore. A reflection appeared beside him in the frozen glass surface of the ranking board. Kael’s expression hardened slightly. Three upperclassmen approached from behind through the snow-covered courtyard with slow deliberate movements. Their uniforms marked them as members of one of the academy’s strongest second-year factions.\nThe leader smiled coldly. “So,” he said quietly, “you’re the famous mastermind everyone keeps talking about.” The surrounding students immediately sensed tension and began moving away instinctively. Kael remained calm. The Strategist System activated instantly. HOSTILE ENCOUNTER DETECTED Analyzing opponents… Combat Probability: Unfavorable Strategic Alternatives Available. The second-year student stepped closer. “You’ve attracted a lot of attention recently,” he continued. “Some people upstairs don’t like sudden changes in the hierarchy.” Kael stared at him silently while snowflakes melted against his dark hair. The academy had finally responded. The game was evolving again. And deep beneath the cold silence of winter, Kael felt something dangerous awaken inside him. Excitement." }, { "t": "Chapter 3 — Pressure", "lvl": 3, "txt": "Snowstorms swallowed Dominion Academy the night before the winter evaluation. Freezing wind moved violently between the towering academy buildings while students rushed through the campus carrying strategy notes, combat gear, and tablets filled with simulation data. Tension infected the atmosphere like poison. Every hallway conversation sounded sharper. Every glance carried calculation behind it. The winter evaluation was not simply another exam — it was an opportunity to climb the hierarchy permanently. Students who performed well could gain influence powerful enough to reshape their future within the academy. Those who failed would become targets. Kael Orion sat alone near the far corner of the library while rain and snow struck the massive windows beside him. Several books lay open across the table, though he had stopped reading nearly twenty minutes earlier. Instead his attention remained fixed on the glowing blue system interface hovering faintly before his eyes. HOSTILE NETWORK DETECTED Source: Second-Year Faction — “Vanguard” Intent Probability: Suppression / Elimination Recommended Response: Strategic Countermeasures Kael closed his eyes briefly. So it had finally happened. The upperclassmen were moving. For weeks he had anticipated resistance from the academy’s established factions. Power structures hated unpredictability. His sudden rise through the Strategic Tournament disrupted too many calculations too quickly. Dominion Academy functioned like an ecosystem where powerful students maintained balance through visible dominance and hidden agreements. Kael represented something dangerous because nobody fully understood his methods. People feared what they could not predict. Across the library Mira Kazuki approached slowly before sitting opposite him without speaking immediately. Her sharp eyes studied his calm expression carefully while the silence stretched between them. “You already know, don’t you?” she asked quietly. Kael looked toward her. “The Vanguard faction,” she continued. “They’ve been asking questions about you all day.”\nKael leaned back slightly in his chair. “That was expected.” Mira frowned. “That response is abnormal.” “Why?” “Because most first-years would panic after learning one of the academy’s strongest second-year groups is targeting them.” Kael remained silent for several seconds. Then he answered calmly. “Panic doesn’t improve outcomes.” Mira stared at him with growing frustration. Sometimes talking to Kael felt less like speaking with a person and more like speaking with a machine designed entirely around efficiency. She hated how composed he remained regardless of pressure. Yet at the same time, part of her understood why the academy found him unsettling. Because he never behaved emotionally. Even now, with dangerous upperclassmen preparing to crush him before his influence expanded further, Kael looked completely calm beneath the cold library lights. “You should be careful tomorrow,” Mira said quietly. “The evaluation isn’t only monitored by instructors. Factions use events like this to measure threats.” Kael nodded once. “I know.” The problem was… He had already started planning several moves ahead. That night Kael returned to the rooftop alone. Snow covered the concrete floor in thin white layers while freezing wind swept violently across the academy skyline. Far below, Dominion Academy glowed beneath the darkness like a massive machine still operating long after midnight. Hundreds of students remained awake preparing for tomorrow’s evaluation while countless hidden schemes moved silently beneath the surface.\nKael stepped toward the railing slowly. The Strategist System activated again. SIMULATION RUNNING… Possible Outcomes Calculated: 2,847 Highest Survival Probability Path Selected. Blue lines spread across his vision like interconnected webs. Predictions. Behavioral probabilities. Strategic pathways. The system analyzed every major faction participating in tomorrow’s event while generating possible scenarios faster than human thought itself. Yet despite all its calculations… Kael understood one important truth. No system alone could make him strong. The system only provided information. He still had to endure the suffering personally. Without hesitation Kael dropped to the freezing rooftop floor and began push-ups against the snow-covered concrete. His exhausted muscles screamed immediately in protest from the previous night’s training, but he ignored the pain completely. One repetition. Then another. Then another. Cold air burned through his lungs. Sweat mixed with melting snow beneath his hands. His arms trembled violently. Still he continued. Because somewhere along the way training stopped being about improvement. It became identity. Kael no longer exercised because he wanted results. He exercised because discipline itself had become the foundation holding his mind together. If he stopped moving… If he stopped progressing…\nThen weakness would return. And he hated weakness more than pain. Hours later the first signs of dawn finally appeared beyond the distant city skyline. The academy speakers activated simultaneously across campus. “Attention all students. Winter Evaluation Phase One will begin in one hour. All participants report immediately to the central simulation arena.” Dominion Academy awakened instantly. Students flooded through dormitories and corridors while tension spread visibly across the campus. Some looked confident. Others looked terrified. Groups gathered around faction leaders discussing strategies rapidly before entering the evaluation grounds. Kael walked through the chaos alone. Dark circles rested beneath his eyes from another sleepless night. His black uniform remained perfectly composed despite exhaustion weighing heavily against his body. Students moved aside instinctively when they noticed him approaching. Whispers followed immediately behind. “That’s him…” “The strategist…” “You think the rumors are true?” “He manipulated the tournament…” Kael ignored every word. Attention no longer distracted him. The central simulation arena towered before the academy like a futuristic fortress surrounded by enormous holographic screens displaying participant rankings. Thousands of students filled the massive structure while instructors observed from elevated platforms high above the arena floor. At the center stood Head Instructor Magnus Reinheart.\nA former military strategist famous for psychological warfare simulations. His sharp eyes scanned the crowd coldly before he finally spoke. “Today’s evaluation is simple,” he announced. “Survive.” The arena immediately fell silent. Magnus continued calmly. “Dominion Academy was never designed to reward talent alone. Talent without resilience is worthless. Intelligence without adaptability is fragile. Strength without discipline collapses under pressure.” Kael’s eyes narrowed slightly. Interesting. The instructor’s philosophy aligned perfectly with his own evolution. Massive holographic walls suddenly activated around the arena, revealing a sprawling digital battlefield unlike anything the first-years had seen before. Ruined cities. Collapsing infrastructure. Resource zones. Hidden territories. Hundreds of participants would compete simultaneously within the simulation while factions battled for dominance under constantly changing conditions. “Phase One,” Magnus announced, “will test psychological endurance.” The lights dimmed instantly. Then chaos began. Simulation pods sealed around every participant simultaneously before plunging them into complete immersion. Kael opened his eyes inside a destroyed urban battlefield covered in smoke and burning debris. Sirens echoed through distant streets while artificial rain poured heavily from dark skies overhead. Around him dozens of other students materialized within the simulation environment, immediately scrambling for resources and territory. The Strategist System activated at once. REAL-TIME ANALYSIS ENGAGED Threat Density: High Hidden Variables Detected.\nKael remained motionless for several seconds while everyone else rushed forward recklessly. Then… He noticed something strange. The system highlighted several students around him in red. Not random participants. Vanguard faction operatives. So this was their plan. Use the evaluation itself as cover. A nearby student suddenly shouted while pointing toward Kael. “There he is!” Instantly several upperclassmen began moving toward him through the ruined streets. Fast. Coordinated. Deliberate. The surrounding participants immediately backed away, unwilling to involve themselves against Vanguard members. Kael stood completely still beneath the pouring rain while the approaching students closed the distance rapidly. Most people in that moment would feel fear. Kael felt calculation. Because the moment the first move appears… The board finally becomes visible. One Vanguard member cracked his knuckles confidently while approaching through the smokefilled street. “Nothing personal,” he said coldly. “You just became too noticeable.”\nKael’s exhausted eyes remained calm. Then, slowly… He smiled. And for the first time since entering Dominion Academy… Someone else felt afraid." }, { "t": "Chapter 4 — The Predator’s Smile", "lvl": 4, "txt": "Rain hammered against the ruined streets of the simulation while distant explosions illuminated the shattered skyline in flashes of orange light. Smoke drifted between collapsed buildings like ghosts moving through the battlefield, and somewhere far away the sound of gunfire echoed endlessly across the digital city. Most students inside the simulation were already panicking. Some sprinted desperately toward resource zones while others formed temporary alliances out of fear, hoping numbers alone would increase their survival chances. Chaos consumed the battlefield exactly as Dominion Academy intended. Kael Orion stood alone in the middle of the flooded street while five Vanguard operatives slowly surrounded him through the rain. The atmosphere changed instantly. The surrounding students backed away instinctively, sensing violence before it even began. Nobody wanted involvement with Vanguard. The faction controlled enormous influence across the academy’s second-year hierarchy, and opposing them openly was practically social suicide. Yet despite the obvious danger closing around him, Kael remained completely calm beneath the storm. One of the upperclassmen laughed quietly.\n“So the rumors were true,” he said while studying Kael carefully. “You really don’t panic.” Kael said nothing. Rainwater dripped slowly from his dark hair while the Strategist System continued processing information across his vision. COMBAT ANALYSIS COMPLETE Direct Confrontation Probability: 18% Psychological Manipulation Probability: 71% Environmental Exploitation Available. The tallest Vanguard member stepped forward through the rain with visible confidence. Unlike ordinary students, these second-years carried themselves like experienced predators. Their movements were controlled. Efficient. Disciplined. Dominion Academy had hardened them through years of competition. “You made a mistake winning the tournament,” the leader continued coldly. “People like you should stay hidden.” Kael finally spoke. “Why?” The student narrowed his eyes slightly. “Because this academy crushes threats before they grow.” For several seconds silence filled the ruined street except for the sound of rain striking concrete. Then Kael smiled faintly. Not arrogantly. Not emotionally. Just calmly. And something about that expression immediately unsettled the Vanguard members. Because it was not the smile of someone cornered. It was the smile of someone observing predictable behavior. “You’re making an assumption,” Kael said quietly.\nThe leader frowned. “What assumption?” “That you’re the hunters.” The moment the sentence ended, the Strategist System highlighted dozens of movement paths across Kael’s vision simultaneously. Tiny details most people ignored suddenly aligned together inside his mind with mechanical precision. Nearby building stability. Resource spawn timings. Student movement patterns. Simulation reinforcement schedules. Vanguard positioning. Blind spots. Escape routes. The battlefield stopped looking chaotic. It became structure. One of the Vanguard members suddenly lunged forward aggressively, clearly intending to end the confrontation quickly through overwhelming force. His fist cut violently through the rain toward Kael’s face— —but Kael moved first. Not faster. Earlier. He stepped sideways at the exact moment required, causing the attacker’s momentum to carry forward uncontrollably across the flooded pavement. Before the student could recover, Kael grabbed his arm and redirected him directly into a broken steel support beam hidden beneath the rainwater. CRACK. The impact echoed brutally through the street. The surrounding students froze in shock. The Vanguard member collapsed immediately, unconscious. Kael released him calmly and stepped backward into the rain once more. Silence. Even the remaining Vanguard students looked stunned. Because they finally understood something important. Kael wasn’t physically stronger than them.\nBut he was calculating everything faster. The leader’s expression darkened instantly. “Get him.” The other operatives attacked simultaneously. Kael’s heartbeat slowed. The Strategist System accelerated around him. PREDICTION MODE ACTIVE. Everything sharpened. Rainfall trajectories. Footstep pressure. Muscle movement. Environmental geometry. His exhausted body moved through the battlefield with ruthless efficiency while his mind calculated probabilities continuously. One opponent attacked from the left — Kael retreated exactly three steps backward, causing the strike to collide with falling debris triggered moments earlier by unstable building damage. Another operative attempted to block his movement route, but Kael intentionally redirected him toward a narrow alley where two desperate first-year students panicked and activated combat drones accidentally. Chaos spread instantly. Screams echoed nearby. The battlefield destabilized further. And through all of it… Kael remained calm. Because this was the difference between intelligence and strategy. Intelligence solved problems. Strategy created situations where opponents destroyed themselves.\n“You little—!” The Vanguard leader charged directly toward him through the rain with visible fury. Unlike the others, he adapted quickly. Dangerous. Experienced. His movements lacked hesitation entirely as he closed distance rapidly. Kael analyzed instantly. Too fast to evade directly. Alternative route required. The Strategist System highlighted a collapsing traffic structure above the street. Probability Window: 1.8 Seconds. Kael moved immediately. The leader pursued aggressively, believing Kael was retreating under pressure. Around them the ruined city continued collapsing piece by piece while simulated warfare intensified across nearby districts. Then Kael stopped suddenly. The Vanguard leader instinctively swung forward— —and Kael kicked the damaged support pillar beside him. The already weakened structure collapsed instantly. Metal and concrete crashed downward violently between them as the street exploded beneath falling debris. The Vanguard leader barely avoided being crushed, but the separation created exactly what Kael wanted. Distance. Confusion. Control. Kael disappeared into the smoke before the others recovered. The remaining Vanguard members shouted furiously while searching the battlefield, but visibility had already deteriorated beyond reliable pursuit conditions. Fires spread through nearby buildings while simulation drones activated emergency lockdown barriers across multiple streets.\nKael moved silently through the chaos alone. Breathing steady. Eyes cold. Body exhausted. But alive. The Strategist System updated again. PHASE ONE SURVIVAL PROBABILITY INCREASED Hostile Faction Psychological Stability: Disrupted. Kael slowed near the upper level of a destroyed parking structure overlooking the battlefield below. Hundreds of students still fought desperately across the simulation while instructors observed everything from the real-world monitoring systems outside. Somewhere beyond the smoke and rain… People were watching him carefully now. That reality changed things. He could no longer remain invisible. Kael rested briefly against the concrete wall while blood slowly dripped from a cut near his arm. The injury was minor. His body, however, felt dangerously close to exhaustion after weeks of relentless training and sleep deprivation. Yet despite the fatigue consuming him… His mind felt sharper than ever. Footsteps approached suddenly from behind. Kael turned instantly. Aria Valen emerged through the smoke carrying a stolen tactical bag over one shoulder while rainwater dripped from her silver hair. She looked completely unbothered by the chaos surrounding them. “You know,” she said casually, “most people don’t psychologically dismantle upperclassmen during survival evaluations.”\nKael exhaled quietly. “You were watching?” “I was nearby.” She grinned slightly. “That smile you gave them was terrifying, by the way.” Kael remained silent. Aria stepped beside him and looked down toward the battlefield below where students still fought violently for survival. “The academy’s going to fear you after this,” she said softly. Kael stared across the ruined city in silence for several moments. Then he answered quietly. “They already do.” Before Aria could respond, every screen across the simulation suddenly flashed red. PHASE ONE COMPLETE REMAINING PARTICIPANTS: 214 / 1000 The battlefield froze instantly. Rain stopped. Explosions vanished. The simulation environment dissolved slowly into darkness around them. Yet before the world fully disappeared, Kael noticed one final thing. Far below… The Vanguard leader stood motionless within the collapsing street while staring directly upward toward him. Not angry. Not confident. Careful. Because for the first time…\nHe no longer saw Kael Orion as prey." }, { "t": "Chapter 5 — Eyes of the Academy", "lvl": 6, "txt": "The simulation chamber opened with a metallic hiss. Hundreds of exhausted students emerged slowly from their pods beneath the cold white lights of the evaluation arena. Some looked relieved simply to have survived. Others carried expressions of humiliation after early elimination. Medical drones moved efficiently between rows while instructors reviewed performance data projected across enormous holographic screens above the stadium floor. The atmosphere felt heavier now. Different. Because everyone had witnessed what happened during Phase One. Kael Orion stepped out of his pod calmly while rainwater from the simulation still clung faintly to his black uniform. His body ached violently beneath the exhaustion. The cut on his arm continued bleeding slightly through the torn fabric near his sleeve, and lack of sleep pressed against his mind like concrete. Yet outwardly he appeared completely composed.\nThat composure unsettled people more than anything else. Conversations immediately quieted around him. Students stared openly now. Not with mockery anymore. With caution. “They sent Vanguard after him…” “And he still survived…” “No, not survived — he outplayed them.” “How does a first-year even do that?” Kael ignored every whisper while walking through the massive arena toward the exit corridors. Above him the holographic rankings updated continuously as survival points recalculated after Phase One. Then the screen flashed. PHASE ONE TOP PERFORMERS 1 — Leon Hartwell 2 — Mira Kazuki 3 — Kael Orion 4 — Aria Valen The entire arena reacted instantly. Shock spread visibly across the crowd. Third place. Kael had entered Dominion Academy as a nobody barely acknowledged by the system rankings. Now his name stood among the academy’s elite performers during one of the harshest evaluations of the year. Too fast. Far too fast. And rapid growth always attracted enemies.\nHigh above the arena floor, inside the instructor observation chamber, Magnus Reinheart watched silently while reviewing Kael’s evaluation footage. Multiple holographic screens replayed the confrontation against Vanguard from different angles simultaneously. Every movement. Every environmental manipulation. Every psychological calculation. An older instructor beside him folded his arms. “He lacks overwhelming physical ability,” the man observed. Magnus nodded once. “Yes.” “Yet he controlled the battlefield anyway.” Silence. Then Magnus zoomed closer toward the exact moment Kael smiled beneath the rain. The instructor’s expression sharpened slightly. “That,” Magnus said quietly, “is not the expression of a student reacting under pressure.” The older instructor frowned. “What do you mean?” Magnus continued watching the footage carefully before answering. “He already understood the outcome.” Meanwhile, far below the instructor chambers, Kael walked alone through the academy corridors while students instinctively created distance around him. Snowlight reflected faintly through the glass walls surrounding the campus while whispers followed behind every step he took. Yet despite the growing tension… Kael’s attention remained elsewhere. The Strategist System continued processing new information rapidly across his vision. NEW VARIABLES DETECTED Instructor Observation Increased Faction Hostility Escalating Influence Expansion Accelerating\nKael exhaled quietly. Things were becoming complicated. Until now he had controlled most situations from the shadows where visibility remained limited. But after today, anonymity no longer existed. Dominion Academy had seen enough to recognize him as a strategic threat. That changed the game entirely. As he turned the corner near the western dormitory corridor, a voice suddenly stopped him. “You’re injured.” Kael glanced sideways. Mira Kazuki stood near the hallway window holding a medical kit in one hand while snow drifted silently outside behind her. Her expression remained calm, though irritation lingered beneath the surface as usual. “It’s minor,” Kael replied. Mira stepped closer anyway. “You say that about everything.” Without waiting for permission, she grabbed his injured arm and pulled him toward the nearby empty classroom. Kael considered resisting briefly before deciding it was inefficient. The room remained silent except for distant wind outside while Mira cleaned the cut carefully beneath the fluorescent lights. “You could’ve been eliminated today,” she said quietly. Kael leaned against the desk behind him. “But I wasn’t.” “That’s not the point.” Mira’s movements paused slightly before she continued. “You push yourself too hard.” Kael looked toward the dark classroom windows silently. Mira sighed softly.\n“You barely sleep. You train until your body breaks down. You spend every second calculating things nobody else even notices.” She tightened the bandage around his arm carefully. “At this rate, you’re going to destroy yourself before graduation.” For several seconds silence filled the room. Then Kael finally answered. “Maybe.” Mira frowned immediately. “That wasn’t supposed to be agreement.” Kael’s eyes lowered slightly toward the fresh bandages around his arm. People misunderstood something important about ambition. They thought growth came from inspiration. In reality… Growth usually came from fear. Fear of remaining weak. Fear of being powerless again. Fear of becoming the same insignificant person you once hated. Kael carried those fears constantly. They followed him every morning before sunrise. Every sleepless night. Every exhausting training session. Every strategic calculation. He did not improve because it was enjoyable. He improved because stopping felt unbearable. Mira studied him carefully.\nThen her voice softened slightly. “You know,” she said quietly, “normal people rest sometimes.” Kael almost smiled faintly. “I’ll consider it.” “You won’t.” “No.” For the first time that evening, Mira laughed quietly under her breath. Then suddenly— Every academy screen activated at once. A mechanical announcement echoed through the corridors immediately afterward. “Attention all remaining participants. Winter Evaluation Phase Two will begin tomorrow at 0600 hours.” Students across campus froze instantly. The announcement continued. “Phase Two will involve direct team-based strategic combat. Participants will be assigned temporary operational units. Survival and performance will determine permanent ranking adjustments.” Kael’s eyes narrowed slightly. Team-based combat? Interesting. The Strategist System updated immediately. WARNING Unstable Variables Approaching. A second screen suddenly appeared beneath the announcement displaying the newly assigned operational teams. Students flooded toward the holographic lists instantly.\nKael stepped forward slowly while Mira followed beside him. Then both stopped simultaneously. Because the screen displayed something unexpected. OPERATIONAL UNIT 7 Kael Orion Aria Valen Leon Hartwell Vanguard Representative — Elias Vayne The corridor atmosphere changed immediately. Mira’s expression hardened. “That’s not coincidence.” No. It definitely wasn’t. Elias Vayne. The Vanguard leader from the simulation. The same upperclassman who had attempted to eliminate Kael during Phase One. Now assigned directly onto the same team. Across the crowded hallway students immediately began whispering again while tension spread visibly through the crowd. Everyone understood what this meant. The academy administration was testing something. Or perhaps… Someone wanted to see what happened when predators were forced into the same cage. Kael stared silently at the glowing screen while countless possibilities moved through his mind. Then another realization appeared. Leon Hartwell. One of Dominion Academy’s strongest combat specialists.\nAria Valen. Unpredictable. Observant. Dangerous. Elias Vayne. Hostile. Experienced. Intelligent. This was not a normal evaluation team. This was pressure intentionally designed to create conflict. Mira looked toward Kael carefully. “You should be cautious,” she warned quietly. “That group is unstable.” Kael remained calm. Then slowly… He smiled again. Not because the situation was safe. But because challenge itself had become addictive. And somewhere deep inside his exhausted mind… He already wanted to see who would break first." }, { "t": "Chapter 6 — Operational Unit 7", "lvl": 8, "txt": "The snowstorm intensified overnight.\nFreezing wind slammed violently against the towering windows of Dominion Academy while darkness consumed the campus beneath endless sheets of white. Most students spent the night preparing obsessively for Phase Two of the winter evaluation, yet almost nobody slept properly. Tension infected the academy like a living organism. Hallways remained active past midnight as students argued strategies, negotiated temporary alliances, and studied combat simulations beneath the cold fluorescent lights. Dominion Academy no longer felt like a school. It felt like a military installation preparing for war. Kael Orion sat alone inside the nearly empty training hall while dim overhead lights reflected against the polished floor beneath him. His body felt dangerously close to collapse after weeks of continuous strain. The fresh bandages around his arm remained slightly stained from the previous evaluation phase, bruises darkened his ribs beneath the uniform, and exhaustion pressed constantly against the edges of his mind like static noise. Yet despite all of it, he continued training alone in silence. Punches echoed rhythmically through the empty gym while sweat dripped steadily from his chin onto the floor below. Every movement carried brutal precision carved through repetition rather than emotion. There was no anger left inside his strikes anymore. No frustration. Only discipline. Somewhere during the past few months Kael had stopped relying on feelings entirely. Feelings changed too easily. Discipline endured regardless of exhaustion, weather, pain, or fear. That was why he continued moving long after his body begged him to stop. The Strategist System activated faintly across his vision while he wrapped fresh tape around his hands once again. PHYSICAL CONDITION: DEGRADED Sleep Deprivation: Severe Operational Efficiency: 82% Recommendation: Immediate Recovery Period Kael ignored the recommendation completely. Recovery felt inefficient. The academy was accelerating too quickly now. Every day brought new threats, new calculations, new opportunities, and new enemies. Slowing down even briefly felt dangerous because Dominion Academy rewarded momentum mercilessly. Students who hesitated became prey. Students who relaxed fell behind. Kael understood that reality better than most because he had once lived at the bottom of the hierarchy himself. Weakness inside this academy was not merely inconvenient — it was permission for others to exploit you. The heavy bag shook violently beneath another strike. Then another.\nThen another. Hours passed. Outside the storm continued raging across the academy skyline while Kael trained alone deep into the night without speaking a single word. Eventually footsteps echoed faintly from the gym entrance behind him. He did not stop moving. “You really are insane.” Kael exhaled slowly before lowering his fists. Leon Hartwell stood near the doorway with his hands inside his jacket pockets while snow melted across his broad shoulders. Even among Dominion Academy’s elite students, Leon carried an overwhelming physical presence that naturally dominated most environments. Tall. Powerful. Confident. The type of person who looked born to stand at the top of hierarchies. Yet unlike many combat specialists inside the academy, his confidence lacked arrogance. That made him more dangerous. Kael grabbed a towel quietly. “You’re awake late.” Leon looked around the empty training hall. “You say that like you haven’t been here all night.” Fair point. For several moments silence filled the gym except for the distant storm outside. Leon studied Kael carefully while the strategist wiped sweat from his face beneath the dim lights. It was strange seeing someone the academy increasingly described as terrifying looking so physically exhausted in person. Dark circles rested permanently beneath Kael’s eyes now, and despite his calm posture there was visible strain hidden inside the way he moved. Leon had fought countless opponents inside Dominion Academy’s combat arenas, but Kael unsettled him differently from anyone else. Not because of physical danger. Because Kael looked like someone slowly sacrificing pieces of himself for a goal nobody else fully understood. “You know Vanguard’s going to cause problems tomorrow,” Leon said eventually. Kael nodded once. “Yes.” “And you still look calm.”\nKael leaned against the nearby wall while breathing slowly. “Panic wastes energy.” Leon stared at him for several seconds before laughing quietly under his breath. “You really talk like that all the time, huh?” “Yes.” “That’s terrifying.” Kael almost smiled faintly. Leon stepped further into the gym before speaking again, his expression becoming more serious now. “Elias Vayne isn’t stupid,” he said quietly. “People think Vanguard survives because of numbers, but that’s wrong. Elias controls the faction because he’s patient. Careful. He waits until he fully understands people before making moves.” Kael listened silently. Interesting. That aligned with his own analysis. Most dangerous opponents were not aggressive ones. They were controlled ones. Leon crossed his arms. “If the academy intentionally grouped us together, there’s probably a reason.” His eyes narrowed slightly. “Question is whether they’re testing teamwork… or trying to provoke conflict.” Both, Kael thought immediately. Because Dominion Academy never wasted opportunities for psychological pressure. Before either could continue, another voice suddenly echoed through the gym entrance. “Oh good, the scary people are already gathering.” Aria Valen entered carrying several drinks in one hand while snowflakes clung faintly to her silver hair beneath the hallway lights. Unlike the exhaustion surrounding most students tonight, she somehow looked energetic as ever, though Kael noticed immediately that even her movements carried more tension than usual beneath the surface. “You brought coffee?” Leon asked.\nAria shrugged casually. “If we’re getting psychologically tortured tomorrow, we might as well stay awake together.” She tossed one drink toward Leon before walking directly toward Kael and handing him another. Their fingers brushed briefly during the exchange. Cold. Kael realized her hands were freezing from the storm outside. “You should rest,” Aria said quietly while studying him carefully. “You look like death.” “I’m functional.” “That wasn’t convincing.” Leon laughed again quietly while opening his drink. “See? I told you he talks like a machine.” Kael ignored both of them calmly. Yet despite himself… Something about the atmosphere felt strangely unfamiliar. Normal. For months his life inside Dominion Academy had consisted almost entirely of isolation, calculation, and endless self-improvement. Training alone. Studying alone. Planning alone. Every relationship existed within strategic distance because trusting people carelessly inside the academy was dangerous. Yet now… Standing inside the nearly empty gym at midnight while snowstorms consumed the world outside… The isolation felt slightly less absolute. Dangerous thought. Kael immediately suppressed it. Attachment complicated judgment. Still, part of him quietly understood why people feared losing companionship.\nBecause after enough loneliness… Even temporary connection became addictive. The academy announcement speakers suddenly activated across the campus. “All remaining participants report to the central operational arena immediately. Phase Two will begin in thirty minutes.” The atmosphere shifted instantly. Leon straightened slightly. Aria exhaled dramatically. “Well,” she muttered, “time to survive.” Kael placed the unopened coffee aside before grabbing his black coat from nearby equipment racks. His muscles protested sharply the moment he moved, exhaustion surging through his body again now that training adrenaline faded slightly. But none of it mattered. The game was continuing. And Dominion Academy never paused for weakness. The central operational arena looked completely different compared to the previous evaluation phase. Massive holographic battle maps stretched across the enormous chamber floor while hundreds of students gathered beneath glowing tactical displays suspended high above them. Instructors moved through the crowd like military officers preparing soldiers for deployment rather than teachers overseeing an academic exercise. Every operational unit stood together now beneath designated sectors across the arena. Operational Unit 7 gathered near the eastern platform. The tension surrounding the group became obvious immediately. Elias Vayne stood waiting beside the tactical display with several Vanguard members observing from distant platforms nearby. Tall and sharply composed beneath his dark academy uniform, Elias carried himself with the quiet confidence of someone accustomed to control. Yet the moment his eyes met Kael’s across the operational floor, something subtle changed inside the atmosphere. Recognition. Not underestimation anymore. Assessment.\n“You survived longer than expected,” Elias said calmly once Kael approached. Kael stopped several feet away. “So did you.” Leon sighed quietly under his breath. “Great. This is already uncomfortable.” Aria looked openly entertained instead. Elias ignored both completely while continuing to study Kael carefully. “I reviewed the Phase One recordings,” he said. “You rely heavily on environmental manipulation and predictive behavior analysis.” Kael remained expressionless. “And?” “And I was curious whether your strategies only function under controlled conditions.” Interesting. Elias wasn’t provoking emotionally. He was probing analytically. That made him far more dangerous than ordinary faction leaders. Before Kael could respond, the massive screens above the operational arena suddenly activated simultaneously. Head Instructor Magnus Reinheart appeared across every display while silence immediately consumed the entire chamber. “Phase Two,” Magnus announced calmly, “will evaluate operational command capability under unstable battlefield conditions.” The holographic battlefield expanded beneath the arena floor instantly. A massive frozen city appeared. Destroyed infrastructure. Limited resources. Dynamic combat zones. Multiple operational objectives scattered across hazardous territory.\nThen Magnus continued. “Each unit will operate independently inside the battlefield for seventy-two simulated hours. Success will depend on leadership, adaptability, resource management, and survival.” His sharp eyes seemed to move across the crowd individually. “One additional condition has been added.” The entire arena became silent. Magnus spoke again. “Operational betrayal is permitted.” Students reacted immediately. Shock spread across the chamber. Some units instantly began arguing among themselves while others exchanged suspicious looks. Dominion Academy had just legalized internal sabotage within operational teams. Psychological warfare. Kael understood the purpose immediately. Pressure revealed truth faster than comfort ever could. Magnus’ expression remained cold across the massive screens overhead. “Trust carefully,” he said quietly. “The battlefield begins now.” The operational arena lights shut off instantly. Simulation deployment activated. And somewhere deep beneath the freezing silence of the academy… Operational Unit 7 entered the war zone already knowing one terrifying reality. The enemy might not be outside the team. It might be standing beside them." }, { "t": "Chapter 7 — Frozen Battlefield", "lvl": 10, "txt": "The world materialized in absolute cold. Operational Unit 7 spawned near the center district of the frozen simulation city beneath collapsing gray skies while violent snowstorms swept endlessly between ruined skyscrapers. Ice covered the shattered roads in thick layers, abandoned vehicles remained buried beneath frozen debris, and distant explosions echoed across the city like thunder rolling through mountains. The battlefield felt horrifyingly real. Wind sliced against exposed skin with painful intensity while visibility shifted unpredictably beneath the storm. Around them the massive holographic city stretched outward for kilometers in every direction, divided into resource sectors, strategic checkpoints, and hostile operational zones already occupied by rival teams. Kael Orion stood silently at the edge of a collapsed overpass while the Strategist System immediately activated across his vision. Hundreds of variables flooded his mind simultaneously. Terrain analysis. Resource density. Heat signatures. Enemy movement probabilities. Structural stability. Escape routes. Ambush zones. The system processed everything with cold mechanical efficiency while snow drifted across his black coat beneath the ruined skyline. BATTLEFIELD ANALYSIS COMPLETE Operational Conditions: Extreme Alliance Stability Probability: Low Betrayal Likelihood Within Unit: 63% Kael’s eyes narrowed slightly. Higher than expected. Nearby, Leon Hartwell surveyed the ruined city with obvious focus while adjusting tactical equipment distributed automatically at deployment. Even within freezing conditions his posture remained composed and battle-ready, like someone naturally designed for high-pressure environments. Aria Valen wandered several steps away near the frozen remains of a destroyed transport vehicle while curiously observing the battlefield with bright silver eyes that somehow still carried traces of amusement despite the danger surrounding them. Elias Vayne, meanwhile, remained completely still near the center of the operational zone, silently studying every member of the unit one by one. Nobody trusted anyone. And everyone knew it. The silence finally broke when Elias spoke calmly through the storm. “We establish resource control first,” he said. “Heat generators, supply routes, defensive territory.”\nLeon crossed his arms slightly. “Logical.” Aria tilted her head. “Boring, but logical.” Then Elias looked directly toward Kael. “You disagree.” Not a question. An observation. Kael glanced across the frozen battlefield quietly before answering. “Static defense loses longterm.” Leon frowned slightly. “Explain.” Kael stepped toward the holographic tactical map projected from his wrist device while snowstorms continued raging around the group. “Most operational teams will prioritize territorial control immediately,” he said calmly. “That creates predictable clustering around major resource sectors.” His finger moved across the map slowly. “Once supply pressure increases, those sectors become traps.” Aria’s smile widened faintly. Elias remained silent. Kael continued. “The strongest position during unstable warfare is controlled mobility. Not territory.” For several moments only the sound of wind filled the ruined city. Then Leon laughed quietly under his breath. “You really do think differently from everyone else.” Elias finally spoke again. “And if we abandon fixed territory, how do we survive long-term exposure conditions?” Kael’s eyes shifted toward the distant eastern district where smoke rose faintly through the storm. “We don’t survive through defense,” he answered calmly. “We survive through control of movement.” Silence again.\nBecause they all immediately understood what he meant. Supply interception. Route manipulation. Predictive warfare. Kael was already thinking several operational phases ahead. Aria suddenly grinned openly. “See? This is why he’s terrifying.” Elias studied Kael carefully beneath the storm while countless calculations clearly moved behind his own eyes now as well. Unlike most students inside Dominion Academy, Elias did not dismiss unusual intelligence out of pride. That made him extremely dangerous. He adapted quickly. Finally he nodded once. “Fine,” he said calmly. “We test your approach.” No argument. No emotional resistance. Just adaptation. Interesting. Kael immediately updated his threat assessment internally. Elias Vayne was absolutely not someone who should be underestimated. Operational Unit 7 began moving through the frozen city shortly afterward beneath near-zero visibility conditions. Snowstorms intensified continuously while distant combat echoed across neighboring sectors where other units had already begun fighting for control of supply infrastructure. The ruined streets forced careful navigation through collapsed highways, frozen subway tunnels, and partially destroyed skyscrapers barely standing beneath the endless storm. Hours passed. The battlefield became increasingly hostile. Multiple operational teams had already been eliminated according to intermittent system broadcasts echoing across the city. Some collapsed from direct combat. Others from environmental failure after losing heat resources. Dominion Academy’s evaluation clearly prioritized psychological deterioration as much as tactical performance.\nKael walked near the front of the unit silently while analyzing movement patterns across the battlefield through the Strategist System. His body felt heavier with every passing hour due to accumulated exhaustion and lack of recovery, yet mentally he remained horrifyingly focused. Pressure sharpened him. Chaos clarified things. Within unstable environments his mind naturally accelerated rather than fractured. Suddenly— “Stop.” The word came from Kael instantly. The unit froze. Leon looked around sharply. “What?” Kael stared toward the narrow intersection ahead where snow drifted violently between destroyed buildings. “Ambush.” Elias’ eyes narrowed immediately. “Evidence?” Kael pointed quietly toward the frozen pavement. Minimal footprints. Too shallow. Artificial placement. Then toward the surrounding structures. Broken glass positioned incorrectly. Snow displacement patterns inconsistent with wind direction. Someone was hiding nearby. Leon’s expression hardened instantly. “Damn.” Almost immediately gunfire erupted from the upper buildings surrounding the intersection as another operational unit launched their attack prematurely after realizing detection had occurred. Tactical drones descended through the storm while students armed with simulation rifles opened fire from elevated positions above the street.\nChaos exploded instantly. Leon moved first. The powerful fighter charged directly forward through the snowstorm with overwhelming force while shielding the group behind reinforced barriers. His combat instincts were monstrous. Tactical drones shattered apart beneath precise strikes while enemy positions collapsed under aggressive pressure. Aria moved unpredictably through the battlefield like living static, redirecting enemy attention through bizarre movement patterns that made accurate targeting nearly impossible. She laughed once during the chaos — not out of cruelty, but excitement. The battlefield energized her. Elias coordinated suppression angles efficiently while maintaining defensive structure around the unit’s movement routes. And Kael— Kael watched everything. Not emotionally. Strategically. The battlefield slowed again inside his perception while the Strategist System processed dozens of future outcomes simultaneously. Enemy retreat routes. Ammunition limitations. Positional weaknesses. Operational psychology. Then Kael noticed it. The enemy team leader wasn’t attacking aggressively. He was waiting. Baiting Unit 7 deeper into the intersection kill zone. Trap within trap. Interesting. Most people would continue reacting to the immediate firefight. Kael analyzed the battlefield structure itself. Then he realized the true objective.\n“They’re collapsing the buildings,” he said immediately. Leon turned sharply mid-combat. “What?” “Move now.” No hesitation existed in Kael’s voice. That alone triggered immediate response. The entire unit retreated backward seconds before explosive charges detonated violently across the surrounding structures. Massive sections of frozen buildings collapsed into the intersection with catastrophic force while concrete, ice, and steel crashed downward through the storm like an avalanche consuming the street entirely. The battlefield disappeared beneath destruction. Silence followed briefly afterward except for falling debris and distant wind. Operational Unit 7 survived by less than five seconds. Leon stared back toward the ruined intersection with visible disbelief. “How the hell did you predict that?” Kael breathed slowly while snow settled across his shoulders. “The enemy leader never intended direct victory,” he replied calmly. “He intended environmental elimination.” Aria looked openly impressed now. Even Elias remained silent for several seconds before finally speaking again. “You noticed behavioral hesitation.” Kael glanced toward him briefly. “Yes.” Elias exhaled slowly through the freezing air. For the first time since deployment… Respect appeared in his expression. Not friendship.\nNot trust. Recognition. And sometimes recognition between dangerous people mattered more than loyalty ever could. Night eventually descended across the frozen battlefield hours later while Operational Unit 7 established temporary shelter inside the remains of an abandoned transit station beneath the city streets. A small heat generator hummed weakly near the center of the room while distant explosions echoed above them through layers of ice and concrete. Nobody slept. Not really. Leon maintained equipment quietly near the entrance while Aria sat wrapped in blankets beside the generator studying Kael with obvious curiosity again. Elias reviewed battlefield maps alone near the far wall. Kael remained seated near the darkness beyond the generator light while the Strategist System continued updating silently across his exhausted vision. Then Elias suddenly spoke. “You plan too far ahead.” Kael looked toward him. Elias’ expression remained calm. “That becomes dangerous eventually.” “How?” “Because eventually,” Elias said quietly, “people stop becoming pieces.” Silence filled the underground station. Kael understood the implication immediately. Emotion. Attachment. Human unpredictability. Weakness.\nYet before he could answer, Aria suddenly spoke softly from beside the generator. “I don’t think Kael sees people as pieces anymore.” Everyone looked toward her. Even Kael. Aria smiled faintly beneath the dim underground light. “I think he’s just scared of losing them.”" }, { "t": "Chapter 8 — Cracks in the Ice", "lvl": 12, "txt": "Silence settled heavily inside the abandoned transit station after Aria’s words. The weak generator hummed quietly beneath the frozen underground chamber while pale orange light flickered against cracked concrete walls covered in frost. Somewhere far above them the snowstorm continued raging across the ruined city, but down here the battlefield suddenly felt smaller. Colder. More dangerous in a different way. Because Aria had touched something Kael never allowed people to see. For several seconds nobody spoke. Leon glanced briefly between them while pretending to focus on his tactical gear. Elias remained near the far wall with his arms crossed, though Kael noticed immediately that the Vanguard leader’s attention had shifted completely away from the battlefield maps now. Everyone was watching him. Waiting. Kael finally broke the silence calmly. “You’re wrong.”\nAria tilted her head slightly. “Am I?” “Yes.” But the response lacked force. That alone told her enough. A faint smile appeared on her face before she leaned back against the station wall again without pushing further. She understood something important about Kael already — direct pressure rarely worked on him. The harder someone forced confrontation, the more emotionally distant he became. Yet small observations… quiet truths… those reached him far more deeply than he liked admitting. Kael looked away toward the darkness near the tunnel entrance while the Strategist System continued moving silently across his vision. Yet for once the endless calculations felt strangely unfocused. Aria’s words repeated inside his mind against his will. I think he’s just scared of losing them. Dangerous thought. Very dangerous. Because she was partially correct. Not entirely. But enough. Kael had spent most of his life disconnected from people long before entering Dominion Academy. Isolation became natural after enough disappointment. Easier. Safer. He learned early that attachment created vulnerability and vulnerability attracted pain. That belief only intensified after arriving at the academy, where manipulation, betrayal, and competition shaped nearly every relationship. Trusting people carelessly inside Dominion was equivalent to handing them a weapon. So Kael adapted. He turned himself into strategy instead of emotion. Discipline instead of comfort. Calculation instead of connection. Yet despite all that…\nSomewhere along the way Leon’s straightforward honesty, Mira’s quiet concern, and Aria’s relentless curiosity had begun slipping through the walls he built around himself. And that terrified him more than any battlefield. The station lights flickered suddenly. Immediately everyone became alert again. Elias moved toward the tactical scanner while Leon stood instinctively near the entrance corridor. Kael’s focus sharpened instantly as the Strategist System highlighted warning signals across his vision. MOTION DETECTED Multiple Heat Signatures Approaching Estimated Hostile Probability: 91% “Company,” Kael said quietly. The atmosphere changed instantly. Aria stood immediately while Leon clenched his fists once beneath the dim underground lights. Elias checked the tactical scanner briefly before his expression hardened. “Three operational units,” he confirmed calmly. “Moving together.” Leon frowned sharply. “An alliance?” “No,” Kael answered immediately. Everyone looked toward him. He stepped closer toward the tactical display while analyzing the movement patterns rapidly. “Too unstable,” he continued. “These units weren’t coordinating earlier in the evaluation.” His eyes narrowed slightly. “They’re being driven.” Elias understood first. “Herded.” Kael nodded once. Someone was forcing multiple weakened teams toward Operational Unit 7 intentionally. The question was why.\nThen the Strategist System updated again. HIGH-PROBABILITY SCENARIO GENERATED Objective: Exhaustion Warfare. Kael realized it instantly. This was not a direct elimination attempt. It was attrition. Someone understood Unit 7 was too dangerous for straightforward confrontation and had instead decided to wear them down through continuous pressure until exhaustion created mistakes. Intelligent. Very intelligent. Leon cracked his neck once while preparing for combat. “Doesn’t matter,” he said calmly. “We hold them here.” “No.” The response came from Kael immediately. Leon frowned. “Why not?” “Because this station is the trap.” Kael moved across the tactical display rapidly while explaining. “The enemy knows we need shelter and heat. That makes our movement predictable.” He pointed toward the surrounding underground tunnel systems beneath the city. “If we remain stationary, they’ll continuously cycle operational units toward us until resources collapse.” Elias studied the map carefully. “Mobile pressure warfare,” he muttered quietly. Again, he adapted instantly. Kael respected that. Most students inside Dominion Academy argued emotionally when their plans failed. Elias abandoned ineffective approaches without hesitation. That quality made him exceptionally dangerous long-term.\n“We move east,” Kael continued. “Industrial sector. High structural density. Better concealment.” Leon looked unconvinced. “And the operational units already approaching?” Kael’s expression remained calm. “We redirect them.” Aria smiled immediately. “There’s the scary strategist again.” Minutes later Operational Unit 7 abandoned the transit station completely, disappearing into the frozen tunnel systems beneath the city moments before hostile teams reached the area above. Snowstorms continued roaring violently overhead while freezing darkness consumed the underground pathways stretching endlessly beneath the battlefield. The environment became increasingly oppressive the deeper they traveled. Ice covered the tunnel walls in jagged layers while unstable electrical systems flickered sporadically overhead. Distant echoes moved strangely through the underground network, making it difficult to separate real sounds from battlefield illusions generated by the simulation itself. Kael walked near the front silently while analyzing route probabilities through the Strategist System. Yet beneath his usual composure exhaustion continued accumulating dangerously. His body moved efficiently through discipline alone now. Muscles ached constantly beneath the freezing temperatures, reaction speed had begun declining slightly, and lack of proper recovery pressed heavily against his concentration. He could still function. But not indefinitely. The system noticed immediately. WARNING Operational Degradation Accelerating Current Performance Sustainability: Limited Kael ignored the warning. Again. Because stopping still felt unacceptable.\nEventually the underground tunnels opened into the remains of a massive industrial district near the eastern edge of the battlefield. Towering frozen factories stretched across the horizon beneath endless snowfall while abandoned transport rails disappeared into the storm-covered distance. Unlike the city center, this sector felt eerily empty. Too empty. Kael slowed immediately. Something felt wrong. Elias noticed too. “Why is there no activity here?” Before Kael could answer— A deafening explosion shattered the silence. The entire industrial district erupted instantly. Shockwaves tore through nearby structures while automated defense drones activated across rooftops and factory towers simultaneously. Floodlights cut violently through the snowstorm as machine-gun fire rained down across the operational zone from multiple directions. Ambush. A massive one. Operational Unit 7 scattered immediately through the frozen industrial complex while explosions ripped apart the ground around them. Enemy teams emerged from hidden positions across the factories with terrifying coordination. Too coordinated. Kael’s eyes widened slightly. This wasn’t random battlefield convergence. Someone had predicted their movement route. Leon smashed directly through incoming drones with overwhelming force while shielding Aria from collapsing debris near the transport rails. Elias coordinated defensive positioning rapidly while engaging enemy units advancing through the factories. But Kael—\nKael stopped moving for half a second. Because he finally understood. This operation had been prepared specifically for him. Someone inside the battlefield was reading his strategies. The realization hit coldly. Which meant one terrifying possibility existed. A strategist equal to him… had entered the game. Then, through the storm and smoke, a voice echoed calmly from the upper factory platforms above. “You really are difficult to corner, Kael Orion.” Every instinct inside Kael sharpened instantly. A tall figure stepped forward beneath the falling snow while tactical screens glowed faintly around him. Third-year uniform. Unknown identity. Calm posture. Cold eyes. And unlike everyone else in Dominion Academy… He looked at Kael without fear. Only interest. The stranger smiled faintly beneath the storm. “I’ve been wanting to meet the academy’s new ghost.”" }, { "t": "Chapter 9 — The Third-Year Strategist", "lvl": 14, "txt": "Snow exploded sideways through the industrial district while automated drones swarmed across the battlefield like mechanical predators descending from the storm. Gunfire echoed violently between frozen factories, shattered transport rails sparked beneath collapsing debris, and the entire eastern sector descended into chaos within seconds. Operational Unit 7 scattered instinctively under the ambush pressure while enemy teams emerged from elevated platforms and hidden structures with frightening coordination. But Kael Orion barely noticed the battlefield anymore. Because his attention remained completely fixed on the third-year student standing above the factory platforms beneath the snowfall. Everything about him felt wrong. Not physically overwhelming like Leon. Not openly dangerous like Elias. Not unpredictably sharp like Aria. Worse. Controlled. The unknown strategist stood calmly while tactical holograms flickered faintly around his gloves beneath the freezing wind. His academy uniform carried the silver insignia reserved for Dominion Academy’s highest-ranked third-year operational division — a level occupied only by students considered future national assets by the institution itself. Yet despite the chaos surrounding the battlefield, he looked almost relaxed while observing Kael through the storm. Like someone finally finding an interesting puzzle after years of boredom. The Strategist System activated violently across Kael’s vision. HIGH-LEVEL THREAT DETECTED Prediction Interference Detected Enemy Analysis Capability: Extreme That had never happened before. Not once.\nKael’s eyes narrowed immediately. The stranger smiled faintly. “So the system reacts to me too,” he said calmly. For the first time in months… Kael felt genuine shock. How? The Strategist System existed only within his perception. Nobody should have been able to infer its existence directly. Yet the third-year strategist observed him with terrifying precision, as though reading calculations happening invisibly behind Kael’s eyes. Leon crashed through a combat drone nearby before shouting over the battlefield chaos. “Kael! Focus!” Instantly Kael’s concentration snapped back toward the battlefield around him. Enemy operational units continued advancing aggressively through the industrial district while drones maintained suppressive fire from elevated structures above. This was not merely an ambush anymore. It was containment. The third-year strategist had built a battlefield designed specifically to overwhelm predictive movement patterns through layered pressure and restricted mobility zones. Brilliant. Dangerously brilliant. Kael analyzed the structure rapidly while dodging incoming fire through the snowstorm. Every route Operational Unit 7 attempted naturally funneled them deeper into controlled kill sectors. The battlefield itself had become a weapon. Elias realized it too. “He’s shaping our movement,” he said sharply while covering Leon’s flank through the debris. Kael nodded once. “Yes.”\nAria appeared beside Kael moments later after narrowly avoiding collapsing factory machinery. Snow covered her silver hair while her breathing came slightly faster now beneath the pressure surrounding them. “You know him?” she asked quickly. “No.” “But you understand him already.” Kael’s eyes remained fixed upward toward the third-year strategist above them. Partially. Enough to recognize the danger. Because unlike ordinary opponents, this person did not rely on reacting to battlefield events. He created psychological pressure layers intentionally. That meant he understood something fundamental about strategy most students never learned. The human mind collapses before the body does. The third-year strategist stepped slowly across the elevated platform while observing the battlefield below with calm interest. “Allow me to introduce myself properly,” he said through the storm. “Cassian Vale. Third-Year Strategic Command Division.” The surrounding operational teams reacted immediately. Even enemy students looked tense hearing the name aloud. Leon’s expression hardened instantly. “You’re kidding.” Aria exhaled quietly. “Well… that’s bad.” Kael noticed their reactions immediately. Cassian Vale. Important. Very important.\nElias spoke next while maintaining defensive positioning. “Top-ranked strategist in Dominion Academy,” he said coldly. “Undefeated in operational simulations for two consecutive years.” Interesting. Cassian smiled slightly after hearing the explanation. “I dislike the word undefeated,” he said calmly. “It encourages arrogance.” Then his eyes returned directly toward Kael again. “But you already understand that, don’t you?” The battlefield suddenly shifted. Multiple drone formations repositioned simultaneously while enemy operational units advanced from three different sectors at once. The pressure increased instantly. This was no longer observation. Cassian had begun testing them seriously. Kael’s mind accelerated rapidly beneath the storm while the Strategist System processed probabilities faster than ever before. Yet for the first time since arriving at Dominion Academy… Prediction lines became unstable. Because Cassian intentionally introduced irrational battlefield variables to disrupt long-term forecasting models. Controlled unpredictability. A strategist weaponizing chaos itself. Dangerous. Very dangerous. Leon smashed another drone apart violently before glaring upward toward Cassian. “Enough playing games!” he shouted. “Fight directly!” Cassian glanced toward him briefly. “No.” Simple answer.\nCalm answer. “Direct conflict wastes resources,” Cassian continued. “Proper strategy minimizes unnecessary exposure.” Leon looked ready to charge upward immediately, but Kael stopped him. “Don’t.” Leon turned sharply. “Why?” “Because that’s what he wants.” The moment Kael said it, Cassian smiled faintly again. Correct. Kael understood now. Every aggressive impulse on this battlefield had already been anticipated and prepared for. Cassian was not trying to overpower Operational Unit 7 directly. He was studying how they behaved under escalating pressure. This entire battle was analysis. And Kael was the primary subject. The realization irritated him slightly. Not emotionally. Strategically. Because someone else had finally stepped high enough onto the board to observe him properly. Snowstorms intensified violently around the factories while drones continued closing inward through the industrial sector. Operational Unit 7 was losing maneuvering space rapidly now. Elias stepped beside Kael while monitoring enemy movement routes carefully. “You have something,” he said quietly. Not a question. Kael remained silent for several seconds while calculations moved endlessly through his exhausted mind.\nThen— Yes. A weakness existed. Not within the battlefield. Within Cassian himself. Kael finally understood the third-year strategist’s core flaw. “He’s curious,” Kael said calmly. Aria blinked. “What?” “Cassian values analysis more than victory.” Elias’ eyes narrowed slightly as realization spread across his expression too. Interesting. Kael continued immediately. “He could eliminate us directly through concentrated pressure, but he hasn’t.” His gaze remained fixed upward through the storm. “Because he wants observation data.” Cassian’s faint smile disappeared slightly. Tiny reaction. But enough. Kael saw it instantly. There it is. The battlefield changed the moment Kael recognized the flaw. Suddenly the entire operational structure surrounding them became visible in a different way. Cassian controlled pressure carefully because overwhelming force too early would end the experiment before meaningful adaptation occurred. Which meant— He was holding back intentionally. And holding back created exploitable openings.\nKael stepped forward through the snowstorm slowly while staring directly upward toward the elevated platform. Then he spoke loudly enough for the battlefield to hear. “You’re lonely.” Silence. Even the battlefield itself seemed to pause. Leon looked confused. Aria’s eyes widened slightly. Elias immediately understood. Cassian’s expression remained calm externally… …but his drones hesitated for 0.4 seconds. Enough confirmation. Kael continued. “You became too intelligent for normal competition a long time ago,” he said calmly through the storm. “Now you create increasingly complex battlefields because ordinary victories stopped meaning anything.” The snow continued falling heavily between them. Cassian watched silently now. No smile. No interruption. Kael stepped further forward. “You’re not here to win the evaluation,” he said quietly. “You’re here because you finally found someone interesting enough to challenge your boredom.” For the first time since appearing on the battlefield… Cassian Vale stopped looking completely untouchable.\nNot because Kael defeated him. But because Kael understood him. And for people who lived entirely inside strategy and calculation… Being understood was sometimes more dangerous than losing." }, { "t": "Chapter 10 — The Ghost and the King", "lvl": 16, "txt": "Snow descended endlessly across the industrial battlefield while silence spread between the ruined factories like invisible pressure crushing the atmosphere itself. Combat drones hovered motionless above shattered transport rails. Enemy operational teams stopped advancing instinctively. Even Leon and Aria remained completely still now after hearing Kael’s words echo through the storm. You’re lonely. Nobody inside Dominion Academy would ever dare say something like that to Cassian Vale. Because nobody saw him as human anymore. Only as a monster of intelligence standing above the academy hierarchy. Yet Kael had done more than insult him. He had identified him. And that changed the battlefield completely. Cassian Vale stood motionless atop the frozen factory platform while snow collected slowly against his dark third-year uniform. For the first time since appearing, the calm amusement in his expression faded slightly beneath something quieter. More dangerous. Not anger. Not embarrassment. Recognition.\nThe Strategist System reacted immediately across Kael’s vision. ENEMY PSYCHOLOGICAL STATE: ALTERED Battlefield Stability Shifting Prediction Accuracy Restored: Partial Interesting. Kael had disrupted him. Not emotionally enough to cause recklessness. But enough to interrupt the perfect control surrounding the battlefield. That alone was enormous. Most people misunderstood strategy. They believed it was simply intelligence applied efficiently. In reality, strategy depended heavily on psychological balance. The moment someone became emotionally unstable — even slightly — their calculations shifted. Tiny hesitation. Altered priorities. Invisible changes in decision weighting. Kael had just introduced instability into the most dangerous strategist inside Dominion Academy. Cassian finally smiled again. But differently now. Smaller. Sharper. “You’re impressive,” he admitted quietly through the storm. “Most students only observe outcomes.” His eyes locked directly onto Kael beneath the snowfall. “You observe isolation.” Kael remained calm. Because he understood exactly what stood before him now. Cassian Vale represented a possible future version of himself. Someone who climbed so high intellectually that ordinary human interaction became impossible. Someone who viewed battlefields, systems, and people through endless layers of analysis until genuine connection disappeared entirely beneath calculation. That was the real danger.\nNot losing to Cassian. Becoming him. The realization settled heavily inside Kael’s mind. Meanwhile Leon finally broke the silence near the lower battlefield sector. “Okay,” he muttered while looking between them, “this conversation is becoming terrifying.” Aria almost laughed quietly despite the battlefield tension. “You’re just realizing that now?” Elias said nothing. But Kael noticed something important. The Vanguard leader was observing both strategists very carefully now, as though witnessing something deeply unsettling unfold in real time. Because Elias understood the truth too. This was no longer merely an operational battle. It was ideological. Two minds shaped by isolation. Two strategists who weaponized understanding itself. And somewhere between them existed a question neither openly spoke aloud. What happens when intelligence completely replaces humanity? The battlefield suddenly shifted again. Cassian raised one hand slightly. Immediately every combat drone in the industrial district powered down simultaneously. The surrounding enemy operational teams froze in confusion. Even Leon looked surprised. “What’s he doing?” Cassian stepped forward slowly along the elevated platform while snowstorms continued raging around him. “The evaluation has become inefficient,” he said calmly. “Further pressure no longer provides useful analysis.”\nAria blinked. “Wait… that’s it?” “No,” Cassian replied quietly. “This is the beginning.” Then his eyes returned toward Kael once more. “You’ve spent months adapting to Dominion Academy,” he continued. “But adaptation alone eventually fails.” Snow drifted violently between them while his expression sharpened slightly. “At some point, Kael Orion… the system stops being enough.” The words hit harder than expected. Because they were true. Kael understood it instantly. The Strategist System accelerated his growth dramatically. It enhanced prediction, analysis, observation, and battlefield processing beyond normal human limitations. Yet despite everything it provided… It could not solve exhaustion. Loneliness. Fear. Human limitation itself. No system could completely replace internal collapse. Cassian turned away slowly toward the frozen skyline beyond the battlefield. “You remind me of myself two years ago,” he said quietly. “That concerns me.” For several seconds the storm swallowed the silence between them. Then Kael asked the question directly. “Why interfere with the evaluation at all?” Cassian stopped walking. “Because Dominion Academy is changing.” The atmosphere shifted again immediately.\nEven Elias focused more sharply now. Cassian continued calmly without turning around. “The academy leadership believes instability is approaching beyond these walls. Political conflict. Economic fractures. Military restructuring.” Snow blew violently across the factory rooftops. “They’re no longer training students merely to compete academically.” Leon frowned slightly. “Then what are they training us for?” Cassian finally looked back toward them. “Control.” The word settled across the battlefield like another layer of ice. Because everyone immediately understood the implication. Dominion Academy was not producing students anymore. It was producing future power structures. Strategists. Leaders. Manipulators. Weapons. Kael’s eyes narrowed slightly while countless thoughts moved rapidly through his exhausted mind. Suddenly many things about the academy made more sense. The brutal evaluations. Psychological warfare normalization. Hierarchical pressure systems. Constant adaptation demands. Dominion Academy intentionally destroyed weakness because it expected students to survive environments far harsher than school itself. Interesting. And dangerous. Very dangerous. A warning siren suddenly echoed across the frozen city before every battlefield screen activated simultaneously.\nPHASE TWO FINAL HOUR INITIATED Remaining Operational Units: 12 Priority Objective Released. New tactical markers exploded across the holographic map instantly. One location. Central command tower. The final battlefield objective. Cassian glanced briefly toward the notification before speaking one last time. “The academy wants to see which students naturally rise when pressure becomes absolute,” he said quietly. “So ask yourself carefully, Kael Orion…” His eyes sharpened beneath the storm. “When this game eventually becomes real…” “Who do you intend to become?” Then— Without another word— Cassian Vale disappeared into the snowstorm alongside the remaining enemy operational units. The battlefield fell silent afterward. No drones. No gunfire. Only endless snowfall descending across ruined factories beneath the dead gray sky. Leon exhaled heavily first. “I officially hate third-years.” Aria laughed quietly. “No, you’re just scared.” “Correct.” Even Elias looked unusually thoughtful now while staring toward the direction Cassian vanished. Kael remained silent.\nBecause Cassian’s final question continued echoing inside his mind. Who do you intend to become? For months Kael focused entirely on growth. Strategy. Survival. Ascension. He trained obsessively, sacrificed sleep, isolated himself emotionally, and reshaped his identity around discipline powerful enough to crush weakness permanently. But he rarely stopped to ask why. Not deeply. Not honestly. Did he want control? Influence? Power? Protection? Revenge against the helplessness he once felt? Or had improvement itself simply become addiction? The Strategist System quietly activated again across his vision. NEW OBJECTIVE AVAILABLE SURVIVE THE ENDGAME. Kael stared silently at the words while snow drifted endlessly across the frozen battlefield. Then slowly… He began walking toward the final objective tower in the distance. Not because he fully understood the answer yet. But because somewhere deep inside himself… He intended to find it." }, { "t": "Chapter 12 — The Final March", "lvl": 18, "txt": "The storm grew worse as Operational Unit 7 left the abandoned operations center behind. Snowfall consumed the battlefield in endless waves of white while freezing wind howled between the skeletal remains of collapsed buildings across the city. Visibility deteriorated to only several meters at most, forcing the surviving operational units to navigate through instinct, tactical prediction, and fragmented system maps flickering inconsistently beneath the extreme weather conditions. Dominion Academy had intentionally designed the final phase this way. Pressure every variable until logic itself became difficult to maintain. Exhaustion. Isolation. Environmental hostility. Constant uncertainty. The academy wanted to discover which students retained clarity when the world around them began collapsing. Kael Orion walked at the front of the formation silently while snow gathered across his black coat and dark hair beneath the freezing night sky. The Strategist System continued operating continuously across his vision, but even the system’s predictive overlays had started becoming unstable under the growing complexity of the battlefield. Too many surviving units were converging toward the central command tower simultaneously now. Too many conflicting strategies. Too many irrational decisions created by desperation and fatigue. The board had become chaotic. And chaos was dangerous because it weakened precision. Yet strangely… Kael’s mind remained calm. Not emotionally calm. Sharper than calm. Like a blade growing colder beneath pressure instead of cracking under it. Behind him Leon moved steadily through the storm carrying enough physical presence to feel almost inhuman despite the brutal conditions surrounding them. Even after continuous combat across multiple battlefield sectors, the fighter still carried himself like someone capable of smashing directly through any obstacle placed before him. Aria stayed slightly closer to Kael now compared to earlier phases without openly acknowledging the change herself. Sometimes her shoulder nearly brushed against his while moving through narrow streets buried beneath snowdrifts, though whether intentional or unconscious remained impossible to determine. Elias remained near the rear of the formation, silent as ever while monitoring their surroundings with frightening attention to detail. No one fully trusted anyone.\nYet somehow… Operational Unit 7 had stopped functioning like strangers. That realization lingered quietly in Kael’s thoughts while they crossed the frozen river dividing the city sectors through the remains of a shattered suspension bridge barely holding together above the ice below. Dominion Academy originally intended the team assignment to create instability. Betrayal. Psychological fracture. Instead the pressure had forged something unexpected between them. Mutual understanding. Not friendship. Not yet. But something stronger than temporary alliance. The command tower loomed larger through the storm ahead now, rising above the frozen city like a black monolith cutting into the clouds themselves. Emergency lights blinked faintly near the upper levels while operational sirens echoed endlessly through the battlefield around it. Multiple surviving units were already converging toward the structure from different directions, and distant combat flashes occasionally illuminated the snow-covered skyline as desperate clashes erupted closer to the final objective. Leon finally broke the silence while staring toward the tower. “You ever notice how Dominion Academy keeps escalating things until they stop feeling like school evaluations?” Aria laughed quietly beneath her scarf. “You noticed that just now?” “I’m serious.” “So am I.” Elias spoke calmly from behind them before the conversation could continue further. “The academy isn’t interested in education anymore.” His eyes remained fixed on the tower ahead. “It’s observing adaptability under collapse conditions.” Kael glanced slightly toward him. Interesting wording. Collapse conditions.\nNot combat. Not competition. Collapse. Cassian Vale’s earlier warning returned immediately inside Kael’s mind. The academy is changing. Snow swirled violently around the ruined streets while the four continued moving toward the tower in silence once more. Kael could feel exhaustion spreading deeper into his body with every passing hour now despite how carefully he suppressed it externally. His legs felt heavier. Reaction speed had started declining subtly. Concentration occasionally blurred for fractions of a second before discipline forced clarity back into place again. Weeks of relentless training, sleep deprivation, and continuous operational pressure had finally begun demanding consequences. The Strategist System detected it immediately. WARNING Mental and Physical Stability Approaching Critical Threshold Extended Operational Capability No Longer Sustainable Kael ignored the message. Again. Because the final objective stood directly ahead now. Stopping here was impossible. Yet despite his composure, Aria suddenly slowed beside him while studying his expression carefully through the storm. “You’re fading.” The observation came quietly enough that only he heard it. Kael kept walking. “I’m functional.” “That’s not what I said.” For several moments neither spoke while snow crunched beneath their boots across the frozen bridge.\nThen Aria lowered her voice slightly. “You don’t have to keep carrying everything alone.” The words hit strangely hard. Kael’s eyes shifted forward toward the command tower ahead while countless responses formed and disappeared inside his mind almost instantly. Because logically speaking… She was wrong. People became liabilities under enough pressure. Dependence created exploitable weaknesses. Isolation increased survivability. Every strategic principle he followed reinforced those conclusions. So why did part of him want to believe her anyway? Dangerous thought again. The moment stretched quietly between them until suddenly— Movement. Elias reacted first. “Down!” Everyone dropped instantly as sniper fire tore through the storm from upper building sectors surrounding the bridge. The frozen steel cables exploded beside them while enemy operational teams emerged from hidden positions across the ruined riverbanks. Ambush. Again. But different this time. Not calculated like Cassian’s battlefield manipulations. Desperate.\nViolent. Final-phase survivors fighting without restraint anymore because elimination now meant complete failure after enduring everything else. Leon moved immediately with overwhelming aggression, charging directly toward enemy positions through the snowfall while debris exploded around him beneath continuous suppressive fire. Elias coordinated defensive routes efficiently while returning precision shots through the storm. Aria disappeared into the battlefield chaos with terrifying unpredictability once again, moving through enemy blind spots almost effortlessly despite the collapsing environment around them. And Kael— Kael analyzed. Always. Even exhausted. Even freezing. Even while the battlefield dissolved into chaos around him. The Strategist System accelerated again across his vision while prediction models spread rapidly through the operational zone. Enemy movement patterns. Ammunition limitations. Structural weaknesses across the bridge supports. Psychological instability levels among surviving teams. Then Kael noticed something important. The attacking units weren’t coordinated properly. Fear had already fractured them. Which meant— One push would collapse everything. Kael stood slowly beneath the storm despite incoming fire and spoke loudly enough for the battlefield to hear. “The western support cables are damaged,” he announced calmly. “This bridge collapses within three minutes.” Silence followed instantly.\nEnemy units hesitated. Uncertainty spread visibly through their movements. Because no one could immediately tell whether he was telling the truth. That hesitation was enough. Panic spread through the attackers almost immediately afterward as several operational teams began retreating instinctively rather than risk entrapment on the unstable bridge structure. Formation discipline shattered within seconds while accusations and confusion erupted between surviving units beneath the storm. Aria glanced toward Kael from across the battlefield with visible disbelief. “You lied.” “Yes.” Leon laughed loudly despite combat chaos surrounding them. “That’s actually terrifying.” The remaining enemy teams collapsed into disorder moments later, retreating entirely from the river crossing without forcing prolonged engagement. Operational Unit 7 survived again. Not through overwhelming force. Through manipulation. Kael watched the battlefield settle quietly beneath the storm while distant footsteps disappeared into the snow-covered city. Then suddenly— The bridge trembled violently beneath them. Everyone froze. Elias’ eyes widened slightly. “That wasn’t a bluff.” A deep metallic groan echoed through the frozen structure as massive cracks spread across the bridge supports beneath accumulated combat damage.\nKael stared downward silently. Interesting. Very unfortunate timing. Then the entire suspension bridge began collapsing into the frozen river below." }, { "t": "Chapter 13 — Falling", "lvl": 20, "txt": "The world lurched sideways. A deafening metallic scream tore through the frozen night as the suspension bridge finally gave way beneath accumulated structural damage, sniper impact fractures, and the unbearable weight of the battlefield itself. Massive steel cables snapped violently through the storm like execution wires while entire sections of the bridge collapsed downward toward the frozen river below. Snow exploded upward in enormous waves beneath falling debris, shattered transport vehicles plunged into darkness beneath the ice, and the surviving operational teams scattered in panic across the disintegrating structure. For half a second the battlefield dissolved into pure chaos. Then gravity took control. Kael Orion felt the bridge collapse beneath his feet instantly. The frozen steel platform tilted sharply while cracks spread violently across the surface under him. His body reacted through instinct and discipline alone as the Strategist System flooded his vision with emergency calculations, escape vectors, survival probabilities, and structural trajectory predictions faster than human thought itself. CRITICAL EVENT DETECTED Bridge Structural Integrity: Failed Immediate Action Required Kael pushed forward toward stable support beams near the eastern anchor point just as another explosion shattered the roadway behind him. Snow and debris erupted through the air while the entire central section of the bridge began tearing away into the frozen river below. “Kael!”\nAria’s voice cut through the storm. He turned instinctively. Wrong decision. The steel beneath his feet collapsed completely. For one terrifying moment there was nothing below him except darkness, ice, and endless falling snow. Then impact. Kael slammed violently against one of the lower bridge support beams while the collapsing structure twisted around him with catastrophic force. Pain exploded through his ribs and shoulder instantly before momentum hurled him sideways against fractured steel cables hanging over the frozen river beneath the storm. The world spun violently. Cold air tore through his lungs. Somewhere above him Leon shouted something through the chaos, but the sound disappeared beneath collapsing metal and roaring wind. Kael’s right hand caught the damaged suspension cable instinctively moments before he fell completely into the river below. The force nearly ripped his shoulder apart. Pain shot through his arm immediately while the broken cable swung dangerously above the frozen water beneath him. Snowstorms blurred visibility almost entirely now while enormous pieces of the bridge continued collapsing around him into the darkness below. Kael gritted his teeth silently while stabilizing his grip. Below him— Cracked ice. Freezing black water. Falling debris. One mistake meant death.\nThe Strategist System activated again rapidly. SURVIVAL PROBABILITY: 31% Physical Condition: Critical Strain Recommendation: Immediate Climb Route Kael forced himself upward along the damaged cable despite the agony spreading through his shoulder and ribs. Every movement burned now. Exhaustion crashed violently into him beneath the adrenaline while blood from reopened wounds stained the snow-covered steel beneath his gloves. Above him the bridge continued collapsing section by section through the storm. Then suddenly— The cable snapped again. Kael dropped instantly. His grip barely caught another fractured support line several meters lower before gravity could drag him fully into the river. The violent stop nearly forced unconsciousness through his exhausted body. Pain blurred his vision for several seconds while freezing wind howled endlessly around him. This was bad. Very bad. For the first time since entering Dominion Academy… Kael realized he might actually die. Not strategically. Not metaphorically. Literally. The thought felt strangely calm. No panic. No fear. Only clarity.\nInteresting. His body hung suspended above freezing darkness while the storm consumed the battlefield overhead. Operational sounds had become distant now beneath the collapsed bridge structure. Kael could barely see the tower anymore through the falling snow and twisted steel surrounding him. Then footsteps echoed faintly above. Careful. Fast. Someone climbing downward through the fractured remains of the bridge. Kael immediately prepared for enemy contact despite his condition. But instead— Silver hair appeared through the storm. Aria. Relief hit harder than expected. Dangerous realization. Aria reached the fractured support beams several meters above him while snow and freezing wind tore violently around her. Her breathing came fast from exertion, yet her eyes immediately locked onto him with unmistakable panic hidden beneath forced composure. “You idiot.” Kael almost laughed faintly despite the situation. Interesting first response. “You came back,” he said quietly. Aria looked genuinely angry now. “Of course I came back.” The answer arrived instantly. Without hesitation. That affected him more than it should have.\nShe carefully lowered herself across the unstable steel framework toward him while the remaining sections of the bridge groaned dangerously overhead. Every movement risked collapse. One wrong shift in weight and both of them would fall directly into the frozen river below. “You’re injured,” she said immediately after reaching him. “Functional.” “Shut up.” Even now she sounded irritated hearing that word. Aria secured one arm around the damaged support beam before extending her other hand toward him carefully through the storm. “Take it.” Kael stared at her hand silently. Small. Cold. Shaking slightly from exhaustion. For some reason that sight struck him harder than the collapsing battlefield around them. Because she was scared. Not for herself. For him. The realization felt unfamiliar enough to momentarily disrupt his thoughts completely. “Kael.” Her voice sharpened slightly now. “Hurry.” Another violent tremor shook the collapsing bridge structure above them. More debris crashed into the river while freezing water exploded upward beneath the storm. Time was running out.\nKael finally reached upward slowly and grabbed her hand. Warm. Even through freezing temperatures and tactical gloves, the contact felt strangely warm. Aria immediately tightened her grip and began pulling him upward along the fractured support lines with far more strength than he expected. Kael climbed carefully beside her while pain surged through his body continuously beneath the freezing wind. For several minutes neither spoke. The storm surrounded them completely. Only breathing. Only survival. Only the pressure of her hand refusing to let go no matter how unstable the structure became beneath them. Then quietly— “You really scare me sometimes.” The words nearly disappeared beneath the storm. Kael looked sideways toward her while climbing. Aria kept her eyes forward. “You act like your life doesn’t matter,” she continued softly. “Like you’ll sacrifice yourself the moment logic tells you to.” Silence stretched between them while snow fell endlessly around the shattered bridge. Kael didn’t answer immediately because part of him understood she was right. Not entirely. But enough. Somewhere during his obsession with growth and survival, he had started viewing himself more as a weapon than a person. A strategist. A tool. Something useful only while functioning efficiently.\nCassian’s words returned again inside his mind. At some point, the system stops being enough. Aria suddenly tightened her grip against his hand again while pulling herself onto a stable section of the ruined bridge support. “You’re allowed to care whether you survive, Kael.” The sentence hit deeper than any battlefield injury he’d taken so far. Because nobody had ever said something like that to him before. Not seriously. Not sincerely. For several seconds Kael simply stared at her silently while snow drifted around them beneath the dead gray sky. Then slowly— Very slowly— He climbed upward beside her toward the remaining operational route leading to the command tower ahead. And for the first time since entering Dominion Academy… The idea of surviving no longer felt important solely because of ambition." }, { "t": "Chapter 14 — The Tower of Dominion", "lvl": 22, "txt": "By the time Kael Orion and Aria finally escaped the collapsed bridge, the storm had evolved into something monstrous. Snow no longer fell gently across the battlefield. It attacked. Violent white winds tore through the ruined city with enough force to shake damaged buildings while freezing air sliced against exposed skin like blades. Emergency sirens echoed continuously across distant sectors where\nsurviving operational units continued collapsing one by one beneath the pressure of the final phase. Fires burned weakly beneath the snow-covered skyline, their orange glow swallowed almost immediately by the endless blizzard consuming the city. And ahead of everything— The command tower stood waiting. Massive. Black. Silent. Its upper levels disappeared into the storm clouds themselves while shattered floodlights flickered faintly around the surrounding perimeter walls. Dominion Academy had designed the structure intentionally to feel oppressive. The tower did not resemble a school facility anymore. It resembled a fortress constructed to survive the end of civilization itself. Kael and Aria moved carefully through the final district leading toward the tower while exhaustion dragged heavily against both of them now. Their uniforms were damaged from the bridge collapse, snow clung across their clothing and hair, and freezing wind had begun numbing exposed skin despite continuous movement. Yet neither slowed down. Because stopping meant failure. Somewhere deeper beneath that truth, however… Another reason existed now too. Neither wanted to leave the other behind. The realization remained unspoken between them while they crossed through abandoned streets buried beneath layers of ice and battlefield debris. Kael’s body felt dangerously close to operational collapse now. Every breath carried sharp pain through his ribs after the bridge impact, his shoulder remained partially unstable from hanging against the suspension cables, and prolonged system usage had begun creating faint migraines behind his eyes that pulsed rhythmically with every passing minute. The Strategist System noticed immediately. PHYSICAL LIMITS EXCEEDED Sustained Functionality No Longer Recommended Emergency Recovery Required Kael dismissed the warnings automatically.\nAgain. Yet this time Aria noticed the movement in his expression almost instantly. “You’re doing it again.” Kael glanced sideways slightly. “Doing what?” “Ignoring yourself.” The answer came too quickly. Too accurately. Kael looked away toward the tower ahead without responding while snowstorms roared around them. Aria sighed quietly beneath the freezing wind. “You know, most people usually stop pushing themselves before reaching actual self-destruction.” “Most people don’t survive Dominion Academy.” “That’s not an answer.” No. It wasn’t. The silence that followed felt strangely heavy. Not uncomfortable. Worse. Honest. Kael had spent so long turning himself into discipline and calculation that he barely remembered how ordinary conversations were supposed to feel anymore. Yet around Aria, moments like this kept appearing unexpectedly between battles and strategic planning. Small fragments of something almost peaceful hidden beneath the violence surrounding their lives. Dangerous. Very dangerous. Because peaceful things were easier to lose.\nAs they approached the outer perimeter surrounding the command tower, distant combat sounds suddenly echoed through the storm ahead. Explosions. Gunfire. Collapsing structures. Multiple operational units had already reached the tower entrance and were fighting desperately for control of the final objective. Kael’s focus sharpened immediately despite exhaustion. The battlefield entered its final stage. The outer sector surrounding the tower resembled a war zone now. Destroyed tactical drones littered the frozen ground while sections of the defensive perimeter walls had partially collapsed beneath continuous combat pressure. Several eliminated students sat near emergency extraction points beneath medical supervision while academy staff observed silently from armored platforms positioned outside the battlefield zone. Dominion Academy instructors watched everything without interference. Cold. Detached. Like scientists observing behavioral experiments rather than teachers protecting students. Interesting. Very interesting. Aria slowed slightly beside him while studying the battlefield ahead through the storm. “How many teams do you think are left?” Kael activated the Strategist System again briefly. Multiple heat signatures remained active inside the tower itself. Others moved through the surrounding perimeter sectors unpredictably beneath the storm. “Five operational units,” he answered quietly. Aria exhaled softly. “So this is really the end.” No. Kael thought silently while staring toward the tower above them. This felt more like a beginning.\nBefore they could move further, footsteps suddenly approached rapidly through the snowstorm from the western sector nearby. Both immediately shifted into combat readiness until familiar figures emerged through the blizzard moments later. Leon Hartwell. Elias Vayne. Alive. Leon looked relieved the moment he saw them. “Finally. I was starting to think the bridge buried both of you.” “Almost did,” Aria replied. Elias’ sharp eyes immediately studied Kael’s condition beneath the storm. “You’re injured worse than before.” “I’m functional.” Leon groaned loudly. “If he says that one more time, I’m throwing him into the river myself.” Unexpectedly, Aria laughed. A real laugh. Bright enough to momentarily cut through the darkness surrounding the battlefield. Kael noticed it instinctively. And so did Leon. The fighter’s expression shifted almost immediately into subtle realization before a faint smirk appeared across his face. Interesting. Very interesting. Aria noticed too late. “Don’t start.” Leon raised both hands innocently. “I didn’t say anything.” “You were about to.”\n“Correct.” Even Elias looked mildly amused now, though he hid it significantly better. Kael remained silent throughout the exchange, yet internally something unfamiliar moved beneath the endless strategic calculations consuming his thoughts. Warmth. Small. Unstable. Human. The moment shattered seconds later when the tower entrance exploded outward violently. Everyone snapped toward the battlefield instantly. A surviving operational unit crashed through the frozen perimeter doors while retreating under heavy pressure from inside the structure. Several students were visibly injured now, their tactical equipment damaged beyond functionality while fear spread openly across their faces. One of them shouted desperately into the storm. “There’s a monster in there!” Silence followed. Then slowly— Footsteps echoed from the darkness beyond the tower entrance. Measured. Calm. Controlled. Cassian Vale emerged through the shattered gateway beneath the falling snow. Alone. No visible injuries. No exhaustion.\nHis dark coat moved softly beneath the storm while tactical holograms flickered faintly around one gloved hand. The surviving operational unit immediately retreated further backward upon seeing him appear. Not because they were ordered to. Because they were terrified. Cassian’s eyes moved across the battlefield calmly before stopping directly on Kael once more. Then, through the storm— He smiled slightly. “Welcome to the final board.”" }, { "t": "Chapter 15 — The Final Board", "lvl": 24, "txt": "The battlefield fell silent the moment Cassian Vale stepped out of the tower. Snowstorms still raged violently across the ruined city, freezing wind still tore through collapsed buildings and shattered perimeter walls, distant fires still burned beneath the white chaos swallowing the battlefield whole — yet somehow none of it mattered anymore. The atmosphere itself shifted beneath his presence. Surviving operational units instinctively retreated further across the outer courtyard while eliminated students watched silently from extraction zones with visible unease spreading through their expressions. Because Cassian did not look exhausted. That alone felt terrifying. Every remaining student inside the winter evaluation had been pushed to physical and psychological limits beyond ordinary endurance. Bruised bodies. Sleep deprivation. Fractured concentration. Emotional instability. Dominion Academy had stripped them down layer by layer until only raw instinct and discipline remained. Yet Cassian Vale stood beneath the storm like someone untouched by it. Calm. Precise.\nPerfectly controlled. Kael Orion stared toward him through the falling snow while the Strategist System activated violently across his vision once again. THREAT LEVEL: EXTREME Prediction Interference Intensifying Strategic Environment Destabilized Interesting. Even now the system struggled analyzing him fully. Leon stepped slightly forward beside Kael while tension hardened visibly across his posture. “So,” he muttered quietly, “that’s the final boss.” Aria almost smiled despite herself. “You really think in combat-game terminology during lifethreatening situations?” “Yes.” “Fair.” Elias remained silent. But Kael noticed the Vanguard leader subtly adjusting his stance near the perimeter wall. Defensive positioning. Controlled breathing. Tactical awareness at maximum capacity. Even Elias Vayne viewed Cassian carefully. That alone spoke volumes. The third-year strategist continued walking slowly across the frozen courtyard while snow accumulated against his dark coat beneath the storm. Several damaged tactical drones hovered behind him silently like obedient shadows while shattered operational markers flickered faintly across the battlefield displays surrounding the tower entrance. Then finally— Cassian stopped moving. Directly across from Operational Unit 7. For several moments no one spoke. Only wind.\nOnly snowfall. Only pressure. Then Cassian’s calm voice echoed softly through the blizzard. “You survived longer than expected.” Leon frowned immediately. “That sounds insulting.” “It wasn’t intended that way.” Which somehow sounded worse. Cassian’s eyes shifted briefly across each member of Operational Unit 7 before returning toward Kael again. That focus did not go unnoticed by the others anymore. Kael had become the center of the board. Not officially. Psychologically. And everyone present understood it. “You manipulated the battlefield well,” Cassian continued quietly. “Especially under deteriorating conditions.” His gaze sharpened slightly. “Most strategists collapse once pressure becomes personal.” The bridge. Aria. The implication was obvious. Kael remained calm externally despite the subtle observation beneath Cassian’s words. “You monitored the collapse.” “Yes.” “Why?” Cassian tilted his head slightly beneath the storm. “Because outcomes become interesting once emotion enters the equation.”\nThe answer unsettled Kael immediately. Not because it was wrong. Because part of him understood it. Cassian studied people the same way Kael studied systems. That was the danger. The difference between them no longer lay in intelligence. It lay in what they still considered human. Suddenly the operational screens surrounding the courtyard activated simultaneously while academy sirens echoed once more through the battlefield. FINAL PHASE DIRECTIVE LAST OPERATIONAL OBJECTIVE: COMMAND CONTROL Remaining Units Authorized for Full Engagement The final stage had officially begun. No more hidden tests. No more layered evaluations. Whoever controlled the tower at the end of the phase would stand victorious. Snowstorms intensified violently around the courtyard as surviving operational units slowly began repositioning across the battlefield perimeter. Tactical weapons activated. Defensive routes formed. Everyone prepared for the final clash. Then unexpectedly— Cassian looked toward Kael again and spoke calmly. “Walk with me.” Silence. Leon blinked once. “What?” Aria’s eyes narrowed immediately. Elias said nothing, though his attention sharpened noticeably.\nKael remained motionless for several seconds. “Why?” Cassian turned slightly toward the tower entrance behind him while snow drifted endlessly through the shattered gateway. “Because there’s something you need to see before this evaluation ends.” Every instinct inside Kael warned caution immediately. Trap possibility: high. Manipulation probability: extreme. Unknown variables: numerous. Yet beneath all those calculations… Curiosity appeared too. Cassian glanced sideways slightly. “You already know you’ll follow.” Annoyingly… He was correct. Kael stepped forward slowly. Leon immediately grabbed his arm. “Hold on. You’re seriously going alone with him?” “Yes.” “That’s a terrible idea.” “Probably.” Aria moved closer now too, visible concern hidden beneath controlled composure. “Kael.” The way she said his name felt different now. Closer. More personal. Dangerous.\nKael looked toward her briefly while snow settled softly against her silver hair beneath the storm. For half a second neither spoke. Then quietly— “I’ll return.” The promise escaped before he fully analyzed it. Aria stared at him silently after hearing those words. Then slowly… She nodded once. Cassian observed the interaction carefully. Interesting. Very interesting. Without another word, Kael followed Cassian toward the tower entrance while Operational Unit 7 remained behind beneath the storm-covered battlefield. Snow and freezing wind faded gradually as the massive doors closed behind them, sealing the outside chaos away almost instantly. Silence replaced the battlefield. The interior of the command tower felt unnaturally warm compared to the frozen city outside. Dim tactical lights illuminated endless corridors lined with operational screens, surveillance systems, and massive holographic displays tracking battlefield data in real time. Yet despite the advanced technology surrounding them, the tower itself felt empty. Not abandoned. Controlled. Cassian walked calmly through the corridors without looking back while Kael followed several steps behind, analyzing everything carefully. No guards. No hidden ambush positions. No operational traps.\nInteresting. Eventually they entered a massive observation chamber near the center of the tower. Floor-toceiling windows overlooked the entire frozen battlefield beyond while countless holographic screens floated across the dark room displaying academy performance metrics, psychological evaluations, and strategic rankings. Kael’s eyes narrowed slightly. This was not part of the student-accessible evaluation system. Cassian stopped near the center platform before speaking quietly. “Dominion Academy records everything.” The holographic displays shifted instantly. Kael froze. Because the screens now showed him. Hundreds of clips. Training alone late at night. Studying battlefield simulations. Endless exhaustion. Sleepless mornings. Injuries hidden beneath uniforms. Isolation. Discipline. Obsession. The academy had monitored all of it. A strange coldness spread through Kael’s chest while he stared silently at the floating recordings surrounding the chamber. Cassian watched him carefully.\n“You wanted to become exceptional,” he said quietly. “So the academy observed how far you were willing to go.” Kael’s voice remained calm. “You sound like this is normal.” “It is.” No hesitation. No morality. Just fact. The realization settled heavily inside the room. Dominion Academy did not nurture talent. It cultivated pressure until extraordinary people emerged naturally from survival itself. Then Cassian spoke again. “Do you know why I brought you here?” Kael remained silent. Cassian’s eyes sharpened slightly beneath the dim tactical light. “Because you still believe becoming stronger will eventually solve the emptiness inside you.” The words hit harder than expected. And for the first time since entering the tower… Kael had no immediate response." }, { "t": "Chapter 16 — What Remains After", "lvl": 26, "txt": "Ascension Snowstorms battered the tower windows endlessly while silence settled across the observation chamber like another layer of pressure pressing against the air itself. Beneath the dim glow of floating holographic displays, Kael Orion stood motionless while fragments of his own life surrounded him from every direction. Training sessions recorded late at night long after other students slept. Moments of physical collapse hidden inside empty academy hallways. Bruised hands wrapped silently beneath cold sink water. Sleepless mornings spent reviewing tactical simulations while exhaustion hollowed his expression further day after day. Every sacrifice. Every obsession. Every moment Dominion Academy had quietly watched him reshape himself into something harder. Something colder. The screens moved continuously around the chamber while the storm outside blurred the frozen battlefield beneath endless white. Cassian Vale remained standing near the central tactical platform with perfect composure as always, though now Kael finally understood why the third-year strategist felt so unsettling to everyone around him. Cassian was not merely intelligent. He was what happened when someone crossed the line between ambition and transformation completely. A person who no longer viewed himself from the inside. Only analytically. Like a system observing itself.\n“You still think strength is the answer,” Cassian said quietly while another recording flickered across the chamber walls — Kael training alone despite obvious injury several weeks earlier. “That if you continue improving fast enough, eventually the fear disappears.” His eyes shifted toward Kael calmly. “But fear evolves faster than achievement.” The words lingered heavily inside the room. Kael stared silently at the recordings surrounding him while countless thoughts moved beneath the surface of his expression. Because part of him understood exactly what Cassian meant. Every time Kael reached a new level inside Dominion Academy, the satisfaction lasted only briefly before another fear replaced the previous one. First he feared weakness. Then irrelevance. Then failure. Then vulnerability. Then emotional attachment itself. Growth never ended the pressure. It only changed its shape. Cassian stepped slowly toward the observation windows overlooking the battlefield far below while tactical data reflected faintly against the dark glass around him. “Do you know why Dominion Academy fascinates people like us?” he asked quietly. Kael finally answered. “Pressure.” “Yes.” Cassian nodded once. “Because ordinary environments reward conformity. Dominion rewards evolution.” Outside the tower, distant explosions illuminated the snowstorm briefly while surviving operational units continued fighting through the final phase beneath the collapsing sky. Yet from up here the battlefield looked strangely small. Controlled. Almost insignificant compared to the larger realization settling inside the chamber. Dominion Academy was never truly about education. It was acceleration. The institution gathered exceptional minds, isolated them under extreme pressure, then observed which students adapted strongly enough to survive psychological transformation without completely breaking apart. Not everyone succeeded.\nSome collapsed physically. Others emotionally. And some… Like Cassian… Survived too well. Kael’s eyes narrowed slightly while studying the third-year strategist near the observation windows. “You regret something.” The statement came calmly. Directly. Cassian smiled faintly without turning around. “Interesting.” “You avoid emotional language constantly,” Kael continued quietly. “Except when discussing people who lose themselves.” Silence followed. The storm hammered violently against the tower glass while holographic recordings continued moving slowly around the dark chamber. Then finally— Cassian spoke again. “I used to believe isolation was necessary for greatness.” The confession sounded strangely distant. Like someone reciting conclusions reached years ago. “I removed distractions,” he continued calmly. “Attachment. Hesitation. Dependency. Eventually I became efficient enough that nobody around me could keep pace intellectually anymore.” His reflection stared back at him from the frozen windows. “At first that felt powerful.” Kael listened silently.\nBecause every word felt dangerously familiar. Cassian finally looked toward him again. “But eventually,” he said quietly, “you realize being understood matters more than being superior.” The room fell silent again afterward. Kael’s mind drifted immediately toward moments he had tried repeatedly to suppress during the evaluation. Aria grabbing his hand above the frozen river. Mira patching his wounds late at night while quietly frustrated by his self-destruction. Leon trusting his judgment without needing manipulation. Even Elias adapting beside him instead of fighting for dominance. Connections. Small. Fragile. Human. For months Kael viewed those things as operational risks. Yet standing here now, inside the observation chamber above the battlefield… He finally understood something uncomfortable. Those moments had kept him human far more effectively than discipline ever did. Cassian studied him carefully before speaking once more. “You’re approaching a crossroads, Kael Orion.” The Strategist System flickered softly across Kael’s vision again, though strangely its usual mechanical clarity felt quieter now beneath the conversation unfolding inside the chamber. “One path leads toward absolute control,” Cassian continued. “Efficiency. Superiority. Isolation.” His eyes sharpened slightly. “The other path is far more unstable.”\n“Connection.” “Yes.” Kael looked toward the battlefield beyond the windows while snowstorms swallowed the city below. Connection created vulnerability. But isolation created emptiness. And suddenly… For the first time… He genuinely didn’t know which frightened him more. Before the silence could deepen further, the entire tower suddenly trembled violently. Emergency alarms erupted instantly across the chamber. WARNING COMMAND TOWER PERIMETER BREACHED MULTIPLE HOSTILE UNITS ENTERING LOWER SECTORS Cassian’s expression shifted immediately back toward cold operational focus while tactical displays updated rapidly around the room. Surviving operational teams had launched a full assault on the tower simultaneously during their conversation. Interesting timing. Very intentional timing. Kael analyzed the battlefield data rapidly. No. Not random. The surviving teams realized something important. Operational Unit 7 and Cassian Vale represented the greatest threats remaining. If allowed to fully consolidate control inside the tower, the evaluation would effectively end. So now—\nEveryone was attacking at once. The final board had become complete chaos. Distant explosions echoed upward through the structure while automated defense systems activated across the lower tower sectors. Snow and smoke blurred visibility beyond the observation windows while emergency lights flooded the chamber crimson. Cassian looked toward Kael one final time. “This is your last lesson.” The strategist’s calm voice carried clearly even through the alarms surrounding them. “Power means nothing if there’s nobody left beside you when you reach the top.” Then— For the first time since meeting him— Cassian smiled naturally. Not analytically. Not strategically. Human. And somehow… That expression felt far sadder than anything else Kael had seen during the entire evaluation. Another explosion shook the tower violently. The battlefield had arrived." }, { "t": "Chapter 17 — The Ones Waiting Below", "lvl": 28, "txt": "The command tower shook continuously beneath the full-scale assault.\nExplosions thundered upward through the lower sectors while emergency sirens screamed across every operational floor of the structure. Red warning lights flooded the observation chamber in violent pulses, staining the walls and holographic displays crimson while snowstorms raged endlessly beyond the massive glass windows overlooking the battlefield below. Dominion Academy’s winter evaluation had finally reached its breaking point. No more strategy layers remained. No more calculated pacing. Only collapse. Kael Orion stood silently near the center of the chamber while tactical alerts flooded the floating screens around him. Multiple operational units had breached the outer defensive perimeter simultaneously and were advancing through the lower tower sectors under desperate assault conditions. Automated defense drones were failing one by one beneath overwhelming pressure. Combat reports updated rapidly across the battlefield displays. Remaining Units: 4 Operational Stability: Critical Tower Control Status: Unstable Interesting. The board had become pure chaos. And chaos always revealed people honestly. Cassian Vale deactivated several holographic displays with a casual motion before turning away from the observation windows overlooking the storm. The cold strategist’s expression had returned to perfect composure once again after their conversation moments earlier, yet something subtle had changed inside the atmosphere surrounding him. Not weakness. Acceptance. As though the final outcome no longer mattered to him personally. “You should go,” Cassian said calmly. Kael’s eyes narrowed slightly. “What about you?” “I’ll slow the remaining operational teams.” “That lowers your victory probability.”\n“Yes.” No hesitation. No concern. Just fact. The realization struck Kael immediately. Cassian had already stopped viewing the evaluation as important. This conversation— This meeting— Had been his real objective from the beginning. Kael studied him silently beneath the emergency lights while explosions echoed violently through the tower structure below them. “You planned this.” Cassian smiled faintly. “Partially.” The tower trembled again beneath another massive impact somewhere in the lower sectors. Smoke drifted faintly into the observation chamber through damaged ventilation systems now while operational alarms intensified continuously around them. Then Cassian spoke one final time. “Don’t become a ghost, Kael.” The sentence landed harder than expected. Because Kael understood exactly what he meant. A ghost was someone who continued moving forward long after losing the ability to truly connect with the world around them. Someone who sacrificed so much of themselves for ambition, control, and survival that eventually nothing human remained beneath the discipline. Cassian had reached that point already. And standing here now… He was warning Kael not to follow him completely.\nAnother explosion rocked the tower violently. This time much closer. The lower floors had collapsed. Kael immediately turned toward the chamber exit while the Strategist System rapidly reconstructed battlefield predictions across his vision. Aria. Leon. Elias. They were still below. Without another word, Kael sprinted from the observation chamber and disappeared into the tower corridors beneath flashing emergency lights. Cassian remained alone afterward beside the frozen observation windows overlooking the battlefield far below. Snowstorms swallowed the ruined city endlessly while tactical screens flickered around the dark chamber. For several moments the strategist simply stood there silently. Then quietly— Almost to himself— “He already chose.” The lower tower sectors had become war zones. Smoke filled the corridors while shattered tactical drones burned across collapsed stairwells and destroyed defensive barricades. Surviving operational teams fought desperately through the command structure beneath failing emergency systems while academy observers watched silently through reinforced monitoring sectors hidden deeper within the tower. Kael moved rapidly downward through the chaos despite exhaustion tearing violently through his body now. Every step hurt. His ribs burned sharply beneath damaged bandages, migraines pulsed behind his eyes from extended system strain, and adrenaline was the only thing still forcing motion through muscles already approaching collapse. Yet none of it mattered.\nBecause for the first time since entering Dominion Academy… His priority was no longer merely winning. The realization followed him through every shattered hallway and collapsing operational corridor while distant combat echoed below. Then finally— He found them. Leon stood near the remains of a destroyed barricade holding back two surviving operational units almost entirely by himself while debris and gunfire exploded around the sector. Elias coordinated defensive angles from nearby cover despite visible injuries across his shoulder. Aria moved through the battlefield chaos near the central stairwell, redirecting enemy movement patterns while evacuating injured students caught beneath collapsing structures. Kael stopped briefly. Because suddenly… The battlefield looked different. Not strategically. Personally. Months ago he would have analyzed this scene purely through tactical efficiency. Assets. Probabilities. Operational value. Now— He saw people. Exhausted people. Fighting beside each other despite fear, pain, and uncertainty. Protecting each other instinctively even when victory itself had become secondary. Warmth spread faintly through Kael’s chest beneath the freezing chaos surrounding the tower. Small. Unfamiliar.\nHuman. Then Aria saw him. Relief crossed her expression instantly before she tried hiding it beneath her usual composure. “You came back.” The sentence hit strangely hard. Because she sounded genuinely worried he wouldn’t. Kael moved toward them immediately while explosions continued shaking the tower structure around them. “Status?” Leon laughed breathlessly despite the situation. “Terrible.” “Accurate assessment,” Elias added calmly. Aria stepped closer toward Kael while quickly studying his condition beneath the emergency lights. Her expression tightened almost immediately after noticing how exhausted he truly looked now. “You pushed yourself too far again.” Probably. Yet before Kael could answer, the entire tower suddenly groaned violently beneath them. Structural failure. Critical. Emergency alarms erupted instantly. WARNING COMMAND TOWER COLLAPSE IMMINENT ALL PARTICIPANTS EVACUATE IMMEDIATELY The battlefield froze. Then chaos exploded. Surviving operational units abandoned combat almost instantly while students rushed desperately toward evacuation routes through collapsing corridors and burning stairwells. Sections of the\ntower began falling apart floor by floor beneath catastrophic damage accumulated throughout the evaluation. Leon looked upward sharply. “We need to move now.” Correct. Kael activated the Strategist System immediately despite the agony spreading through his mind. Emergency escape vectors appeared rapidly across his vision. Only one viable route remained. Western maintenance sector. But— Kael’s eyes narrowed suddenly. Something was wrong. One heat signature remained stationary near the upper observation floors. Cassian. Still inside the tower. For half a second Kael stood completely still while the collapsing structure roared around them. Then— Without warning— He turned back toward the upper floors. Aria immediately grabbed his wrist. “What are you doing?” Kael looked toward the collapsing tower above them silently. Then quietly— “He’s still up there.” Silence.\nLeon stared at him like he was insane. “Kael, the tower’s collapsing.” “Yes.” “You can’t seriously—” “I know.” Aria’s grip tightened slightly around his wrist while fear flickered visibly through her expression now beneath the emergency lights. “Kael.” The way she said his name stopped him briefly. Because suddenly he understood something important. Someone was afraid of losing him. Not strategically. Personally. The realization hit harder than collapsing buildings or battlefield injuries ever could. For several seconds neither moved while alarms screamed around them and the tower continued falling apart. Then slowly— Kael looked back toward the upper sectors one final time. And chose not to go. Not because Cassian wasn’t important. But because for the first time in his life… Someone waiting beside him mattered more than the climb upward alone." }, { "t": "Chapter 18 — Beyond the Winter", "lvl": 30, "txt": "The tower collapsed behind them as dawn began rising over Dominion Academy. Massive sections of the command structure tore apart beneath the weight of accumulated damage while fire and steel disappeared into the snowstorm consuming the battlefield. Emergency evacuation lights flashed violently across the frozen city while academy personnel secured surviving students through organized extraction routes around the perimeter sectors. The winter evaluation was over. Yet strangely… The battlefield did not feel victorious. It felt quiet. Exhausted. Like something larger than competition itself had finally ended. Kael Orion stood several hundred meters away from the collapsing tower beneath the fading storm while cold morning light slowly emerged through the endless gray clouds overhead. Snow continued falling softly around the ruined city now, though the violence of the blizzard had weakened significantly compared to earlier hours. The battlefield looked different beneath daylight. Less like war. More like aftermath. Students moved silently through evacuation zones nearby while medical teams treated injuries beneath portable floodlights and emergency shelters. Some participants sat alone in the snow staring blankly toward the destroyed tower. Others laughed weakly from pure relief at surviving the evaluation at all. Dominion Academy instructors observed everything with the same unreadable expressions as always. Cold. Detached. Watching. Kael remained standing near the outer perimeter wall while the Strategist System flickered weakly across his exhausted vision one final time.\nWINTER EVALUATION COMPLETE Performance Ranking: Exceptional Psychological Adaptation: Significant New Objective Pending… Then— For the first time since receiving the system— The interface disappeared completely. Silence followed. No calculations. No predictions. No operational overlays. Just cold morning air and the sound of distant snowfall surrounding the ruined battlefield. Strange. Kael suddenly realized how quiet his own mind felt without constant system activity filling the empty spaces. Footsteps approached slowly behind him through the snow. Aria. Kael recognized the rhythm instinctively now. She stopped beside him quietly while wrapping a heavier academy coat tighter around herself against the freezing wind. Snowflakes settled softly against her silver hair beneath the pale morning light while exhaustion lingered clearly beneath her eyes after surviving the final phase. Neither spoke immediately. They simply stood there together watching the remains of the tower collapse slowly into silence. Eventually Aria glanced sideways toward him. “You’re thinking too much again.” Kael almost smiled faintly.\nProbably true. “The evaluation changed you,” she said softly. Not a question. An observation. Kael looked toward the distant battlefield while considering the statement carefully. Yes. It had. Months ago he entered Dominion Academy believing strength alone would solve everything. If he became intelligent enough, disciplined enough, strategic enough, then weakness would disappear permanently. Fear would disappear. Isolation would stop mattering. But Cassian had shown him the flaw in that path. Power without connection eventually became emptiness wearing the shape of superiority. And standing here now beneath the fading winter storm… Kael finally understood something simple. No one truly climbs forever alone. Not without losing pieces of themselves along the way. Aria watched him quietly before speaking again. “You know,” she said softly, “you look less cold now.” Interesting. Because internally he still felt unfinished. Still uncertain. Still afraid sometimes. Yet perhaps that was normal. Perhaps becoming stronger was never supposed to erase fear entirely.\nPerhaps real growth meant learning what deserved protecting despite fear remaining. Kael turned slightly toward her. “Thank you.” Aria blinked once in visible surprise. Then immediately narrowed her eyes suspiciously. “Hold on.” She pointed at him dramatically. “Who are you and what did you do with the emotionally repressed strategist?” Kael actually laughed quietly. A real laugh. Small. Short. But genuine. Aria froze after hearing it. Then slowly… A smile spread across her face brighter than anything else on the battlefield. Warm. Dangerously warm. For a brief moment neither looked away. Then Leon’s voice suddenly echoed across the evacuation sector. “There you two are!” The atmosphere shattered instantly. Leon approached through the snow carrying enough energy to feel unnatural after everything they survived while Elias followed several steps behind with his usual calm composure intact despite visible injuries across his shoulder.\nLeon stopped near them before grinning broadly. “Good news. We survived psychological warfare, tactical collapse, freezing temperatures, near-death experiences, and academy insanity.” He paused dramatically. “Bad news: classes start again next week.” Aria groaned immediately. “Cruel.” “Extremely.” Even Elias looked mildly irritated by the concept. Kael watched them silently for a moment while morning light slowly spread across Dominion Academy beyond the battlefield. Interesting. Very interesting. At some point during the winter evaluation… These people had stopped feeling like temporary variables. They mattered now. Not strategically. Personally. The realization no longer frightened him as much as before. Far above the battlefield, hidden within one of the surviving academy observation sectors, Cassian Vale stood alone beside the reinforced windows overlooking the evacuation zones below. Snow drifted softly beyond the glass while medical teams and surviving students moved through the ruined city beneath the pale dawn. His sharp eyes rested briefly on Kael and the others standing together near the outer perimeter. Then quietly— Almost imperceptibly— Cassian smiled. Not because Kael had become stronger.\nBut because he hadn’t lost himself completely while doing so. Behind Cassian, the observation room doors opened slowly. Head Instructor Magnus Reinheart entered the chamber beneath the dim tactical lights while battlefield reports flickered across nearby holographic screens. “You interfered more than necessary,” Magnus observed calmly. Cassian looked back toward the battlefield below. “Yes.” “Why?” For several seconds only silence filled the observation room. Then Cassian answered quietly. “Because this generation might finally survive what’s coming.” Magnus’ expression sharpened slightly after hearing that. Outside, dawn continued rising over Dominion Academy while snow covered the battlefield scars left behind by the winter evaluation. The academy remained cold. Dangerous. Unforgiving. Yet somewhere beneath the endless pressure surrounding it… Something new had begun moving quietly across the board. Not merely ambition. Not merely survival. Connection. And perhaps— For someone like Kael Orion—\nThat was the most dangerous evolution of all. END OF WINTER ARC" }];

  // system/src/data.js
  var MORE_BOOKS = {
    discipline: [
      ["Can't Hurt Me", "David Goggins", "The 40% rule. Brutal, and it works."],
      ["The Subtle Art of Not Giving a F*ck", "Mark Manson"],
      ["12 Rules for Life", "Jordan Peterson"],
      ["The Miracle Morning", "Hal Elrod"],
      ["Eat That Frog!", "Brian Tracy"],
      ["The One Thing", "Gary Keller"],
      ["Indistractable", "Nir Eyal"],
      ["Tiny Habits", "BJ Fogg"],
      ["Hyperfocus", "Chris Bailey"],
      ["The Now Habit", "Neil Fiore"],
      ["Solving the Procrastination Puzzle", "Timothy Pychyl"],
      ["Do Hard Things", "Alex & Brett Harris"],
      ["Willpower", "Roy Baumeister & John Tierney"],
      ["Peak", "Anders Ericsson", "Where the 10,000-hour idea actually came from."],
      ["Atomic Focus", "Various"],
      ["The Practicing Mind", "Thomas Sterner"],
      ["Never Finished", "David Goggins"],
      ["Relentless", "Tim Grover", "Jordan's trainer on the three types of competitor."],
      ["Winning", "Tim Grover"],
      ["The Daily Stoic", "Ryan Holiday"]
    ],
    money: [
      ["Money: Master the Game", "Tony Robbins"],
      ["The Total Money Makeover", "Dave Ramsey"],
      ["Broke Millennial", "Erin Lowry"],
      ["The Barefoot Investor", "Scott Pape"],
      ["A Random Walk Down Wall Street", "Burton Malkiel"],
      ["Common Stocks and Uncommon Profits", "Philip Fisher"],
      ["One Up On Wall Street", "Peter Lynch"],
      ["The Little Book of Common Sense Investing", "John C. Bogle"],
      ["The Essays of Warren Buffett", "Warren Buffett & Lawrence Cunningham"],
      ["Poor Charlie's Almanack", "Charlie Munger"],
      ["Die With Zero", "Bill Perkins"],
      ["The Almanack of Naval Ravikant", "Eric Jorgenson", "Wealth without a job. Read the leverage chapter twice."],
      ["Financial Freedom", "Grant Sabatier"],
      ["Set for Life", "Scott Trench"],
      ["Money Men", "Dan McCrum"],
      ["The Behavioral Investor", "Daniel Crosby"],
      ["Unshakeable", "Tony Robbins"],
      ["Rich Dad's Cashflow Quadrant", "Robert Kiyosaki"],
      ["The Bogleheads' Guide to Investing", "Taylor Larimore et al."],
      ["Money Master the Rules", "Various"]
    ],
    strategy: [
      ["The 22 Immutable Laws of Marketing", "Al Ries & Jack Trout"],
      ["Blue Ocean Strategy", "W. Chan Kim & Renée Mauborgne"],
      ["Playing to Win", "A.G. Lafley & Roger Martin"],
      ["Seven Powers", "Hamilton Helmer"],
      ["The Innovator's Dilemma", "Clayton Christensen"],
      ["Competitive Strategy", "Michael Porter"],
      ["Super Thinking", "Gabriel Weinberg & Lauren McCann"],
      ["Range", "David Epstein", "Generalists win more often than the story admits."],
      ["Antifragile", "Nassim Nicholas Taleb"],
      ["The Black Swan", "Nassim Nicholas Taleb"],
      ["Fooled by Randomness", "Nassim Nicholas Taleb"],
      ["Skin in the Game", "Nassim Nicholas Taleb"],
      ["On War", "Carl von Clausewitz"],
      ["The Daily Laws", "Robert Greene"],
      ["The Art of Thinking Clearly", "Rolf Dobelli"],
      ["Thinking in Systems", "Donella Meadows"],
      ["Decisive", "Chip & Dan Heath"],
      ["The 4 Disciplines of Execution", "McChesney, Covey & Huling"],
      ["Chess Strategy for Club Players", "Herman Grooten"],
      ["Radical Candor", "Kim Scott"]
    ],
    psychology: [
      ["Atomic Attraction", "Christopher Canwell"],
      ["Emotional Intelligence", "Daniel Goleman"],
      ["Predictably Irrational", "Dan Ariely"],
      ["Blink", "Malcolm Gladwell"],
      ["Outliers", "Malcolm Gladwell"],
      ["Talking to Strangers", "Malcolm Gladwell"],
      ["Quiet", "Susan Cain", "If you're the quiet one, this is your case file."],
      ["The Body Keeps the Score", "Bessel van der Kolk"],
      ["Nonviolent Communication", "Marshall Rosenberg"],
      ["Games People Play", "Eric Berne"],
      ["What Every BODY Is Saying", "Joe Navarro"],
      ["Pre-Suasion", "Robert Cialdini"],
      ["The Charisma Myth", "Olivia Fox Cabane"],
      ["Surrounded by Idiots", "Thomas Erikson"],
      ["Attached", "Amir Levine & Rachel Heller"],
      ["Stumbling on Happiness", "Daniel Gilbert"],
      ["Flow", "Mihaly Csikszentmihalyi"],
      ["Drive", "Daniel Pink"],
      ["Hooked", "Nir Eyal"],
      ["Rejection Proof", "Jia Jiang"]
    ],
    biography: [
      ["Becoming", "Michelle Obama"],
      ["Educated", "Tara Westover", "A girl with no schooling reaches Cambridge. No excuses left."],
      ["Long Walk to Freedom", "Nelson Mandela"],
      ["The Diary of a Young Girl", "Anne Frank"],
      ["I Am Malala", "Malala Yousafzai"],
      ["Steve Jobs", "Walter Isaacson"],
      ["Elon Musk", "Walter Isaacson"],
      ["Leonardo da Vinci", "Walter Isaacson"],
      ["Einstein", "Walter Isaacson"],
      ["Shoe Dog", "Phil Knight", "Nike almost died a dozen times."],
      ["Open", "Andre Agassi"],
      ["Born a Crime", "Trevor Noah"],
      ["Greenlights", "Matthew McConaughey"],
      ["When Breath Becomes Air", "Paul Kalanithi"],
      ["The Autobiography of Malcolm X", "Malcolm X & Alex Haley"],
      ["Dreams from My Father", "Barack Obama"],
      ["A Promised Land", "Barack Obama"],
      ["Bossypants", "Tina Fey"],
      ["Total Recall", "Arnold Schwarzenegger"],
      ["Will", "Will Smith"]
    ],
    business: [
      ["The Lean Startup", "Eric Ries"],
      ["Zero to One", "Peter Thiel"],
      ["Good to Great", "Jim Collins"],
      ["Built to Last", "Jim Collins"],
      ["The E-Myth Revisited", "Michael Gerber"],
      ["Start With Why", "Simon Sinek"],
      ["The Hard Thing About Hard Things", "Ben Horowitz"],
      ["$100M Offers", "Alex Hormozi", "The clearest thing written on pricing."],
      ["$100M Leads", "Alex Hormozi"],
      ["The 4-Hour Workweek", "Tim Ferriss"],
      ["Company of One", "Paul Jarvis"],
      ["Rework", "Jason Fried & DHH"],
      ["Blitzscaling", "Reid Hoffman"],
      ["Traction", "Gabriel Weinberg & Justin Mares"],
      ["Crossing the Chasm", "Geoffrey Moore"],
      ["The Mom Test", "Rob Fitzpatrick", "How to ask about your idea without being lied to."],
      ["Hooked", "Nir Eyal"],
      ["Purple Cow", "Seth Godin"],
      ["This Is Marketing", "Seth Godin"],
      ["Building a StoryBrand", "Donald Miller"]
    ],
    fantasy: [
      ["A Court of Thorns and Roses", "Sarah J. Maas", "17+. The book that made romantasy a global category."],
      ["Fourth Wing", "Rebecca Yarros", "17+. Dragons and a war college. Enormous."],
      ["Throne of Glass", "Sarah J. Maas"],
      ["The Way of Kings", "Brandon Sanderson"],
      ["Mistborn: The Final Empire", "Brandon Sanderson"],
      ["The Name of the Wind", "Patrick Rothfuss"],
      ["A Game of Thrones", "George R. R. Martin", "16+."],
      ["Six of Crows", "Leigh Bardugo", "A heist crew you will not forget."],
      ["Shadow and Bone", "Leigh Bardugo"],
      ["Eragon", "Christopher Paolini"],
      ["The Lightning Thief", "Rick Riordan"],
      ["The Hobbit", "J. R. R. Tolkien"],
      ["The Lion, the Witch and the Wardrobe", "C. S. Lewis"],
      ["Children of Blood and Bone", "Tomi Adeyemi", "West African myth, fully realised."],
      ["The Priory of the Orange Tree", "Samantha Shannon"],
      ["The Poppy War", "R. F. Kuang", "16+. Brutal, brilliant."],
      ["The Blade Itself", "Joe Abercrombie"],
      ["Assassin's Apprentice", "Robin Hobb"],
      ["The Lies of Locke Lamora", "Scott Lynch"],
      ["Piranesi", "Susanna Clarke"]
    ],
    scifi: [
      ["Project Hail Mary", "Andy Weir", "Problem-solving as a page-turner."],
      ["The Martian", "Andy Weir"],
      ["Dune", "Frank Herbert"],
      ["Ender's Game", "Orson Scott Card"],
      ["Ready Player One", "Ernest Cline"],
      ["The Hitchhiker's Guide to the Galaxy", "Douglas Adams"],
      ["Fahrenheit 451", "Ray Bradbury"],
      ["I, Robot", "Isaac Asimov"],
      ["Foundation", "Isaac Asimov"],
      ["Recursion", "Blake Crouch"],
      ["Dark Matter", "Blake Crouch"],
      ["The Three-Body Problem", "Cixin Liu"],
      ["Klara and the Sun", "Kazuo Ishiguro"],
      ["Snow Crash", "Neal Stephenson"],
      ["Neuromancer", "William Gibson"],
      ["Binti", "Nnedi Okorafor", "Afrofuturism, short and superb."],
      ["Lagoon", "Nnedi Okorafor"],
      ["Rosewater", "Tade Thompson"],
      ["Sea of Tranquility", "Emily St. John Mandel"],
      ["Station Eleven", "Emily St. John Mandel"]
    ],
    mystery: [
      ["The Silent Patient", "Alex Michaelides"],
      ["Gone Girl", "Gillian Flynn", "16+."],
      ["The Girl on the Train", "Paula Hawkins"],
      ["The Da Vinci Code", "Dan Brown"],
      ["Angels & Demons", "Dan Brown"],
      ["The Thursday Murder Club", "Richard Osman"],
      ["A Good Girl's Guide to Murder", "Holly Jackson", "Built for exactly your age group."],
      ["One of Us Is Lying", "Karen M. McManus"],
      ["The Inheritance Games", "Jennifer Lynn Barnes"],
      ["And Then There Were None", "Agatha Christie", "The best-selling mystery ever written."],
      ["Murder on the Orient Express", "Agatha Christie"],
      ["The Murder of Roger Ackroyd", "Agatha Christie"],
      ["The Girl with the Dragon Tattoo", "Stieg Larsson", "18+."],
      ["Big Little Lies", "Liane Moriarty"],
      ["The Woman in the Window", "A. J. Finn"],
      ["Verity", "Colleen Hoover", "18+."],
      ["The Guest List", "Lucy Foley"],
      ["Sharp Objects", "Gillian Flynn", "18+."],
      ["In the Woods", "Tana French"],
      ["The Hound of the Baskervilles", "Arthur Conan Doyle"]
    ],
    classics: [
      ["To Kill a Mockingbird", "Harper Lee"],
      ["1984", "George Orwell"],
      ["Animal Farm", "George Orwell"],
      ["Pride and Prejudice", "Jane Austen"],
      ["The Great Gatsby", "F. Scott Fitzgerald"],
      ["Jane Eyre", "Charlotte Brontë"],
      ["Wuthering Heights", "Emily Brontë"],
      ["Of Mice and Men", "John Steinbeck"],
      ["Lord of the Flies", "William Golding"],
      ["The Catcher in the Rye", "J. D. Salinger"],
      ["Frankenstein", "Mary Shelley"],
      ["Dracula", "Bram Stoker"],
      ["Crime and Punishment", "Fyodor Dostoevsky"],
      ["The Old Man and the Sea", "Ernest Hemingway"],
      ["Little Women", "Louisa May Alcott"],
      ["Great Expectations", "Charles Dickens"],
      ["A Tale of Two Cities", "Charles Dickens"],
      ["The Picture of Dorian Gray", "Oscar Wilde"],
      ["Brave New World", "Aldous Huxley"],
      ["The Grapes of Wrath", "John Steinbeck"]
    ],
    history: [
      ["Sapiens", "Yuval Noah Harari"],
      ["Homo Deus", "Yuval Noah Harari"],
      ["Guns, Germs, and Steel", "Jared Diamond"],
      ["A Short History of Nearly Everything", "Bill Bryson"],
      ["SPQR", "Mary Beard"],
      ["The Silk Roads", "Peter Frankopan"],
      ["1493", "Charles C. Mann"],
      ["The Rise and Fall of the Third Reich", "William Shirer"],
      ["Team of Rivals", "Doris Kearns Goodwin"],
      ["King Leopold's Ghost", "Adam Hochschild", "What the Congo actually cost."],
      ["How Europe Underdeveloped Africa", "Walter Rodney", "Required reading on this continent."],
      ["Africa: A Biography of the Continent", "John Reader"],
      ["Born in Blackness", "Howard W. French"],
      ["The Fate of Africa", "Martin Meredith"],
      ["Ghana: A Concise History", "Various"],
      ["Things Fall Apart", "Chinua Achebe"],
      ["The Wretched of the Earth", "Frantz Fanon"],
      ["A People's History of the United States", "Howard Zinn"],
      ["Postwar", "Tony Judt"],
      ["The Warmth of Other Suns", "Isabel Wilkerson"]
    ],
    philosophy: [
      ["Meditations", "Marcus Aurelius", "An emperor's private notes on staying sane."],
      ["Letters from a Stoic", "Seneca"],
      ["The Enchiridion", "Epictetus"],
      ["The Republic", "Plato"],
      ["Nicomachean Ethics", "Aristotle"],
      ["Beyond Good and Evil", "Friedrich Nietzsche"],
      ["Thus Spoke Zarathustra", "Friedrich Nietzsche"],
      ["The Myth of Sisyphus", "Albert Camus"],
      ["The Stranger", "Albert Camus"],
      ["Tao Te Ching", "Laozi"],
      ["The Analects", "Confucius"],
      ["Siddhartha", "Hermann Hesse"],
      ["The Consolations of Philosophy", "Alain de Botton"],
      ["Justice", "Michael Sandel"],
      ["Sophie's World", "Jostein Gaarder", "The whole of philosophy as a novel."],
      ["The Courage to Be Disliked", "Ichiro Kishimi & Fumitake Koga"],
      ["The Four Agreements", "Don Miguel Ruiz"],
      ["The Power of Now", "Eckhart Tolle"],
      ["A Guide to the Good Life", "William Irvine"],
      ["Ego Is the Enemy", "Ryan Holiday"]
    ],
    manga: [
      ["Solo Leveling", "Chugong / DUBU"],
      ["One Piece", "Eiichiro Oda"],
      ["Naruto", "Masashi Kishimoto"],
      ["Attack on Titan", "Hajime Isayama"],
      ["Demon Slayer", "Koyoharu Gotouge"],
      ["Jujutsu Kaisen", "Gege Akutami"],
      ["Death Note", "Tsugumi Ohba & Takeshi Obata"],
      ["Fullmetal Alchemist", "Hiromu Arakawa"],
      ["Dragon Ball", "Akira Toriyama"],
      ["My Hero Academia", "Kohei Horikoshi"],
      ["Chainsaw Man", "Tatsuki Fujimoto", "17+."],
      ["Tokyo Ghoul", "Sui Ishida", "16+."],
      ["Vagabond", "Takehiko Inoue", "Musashi's road to mastery, drawn."],
      ["Slam Dunk", "Takehiko Inoue"],
      ["Berserk", "Kentaro Miura", "18+."],
      ["Vinland Saga", "Makoto Yukimura"],
      ["Blue Lock", "Muneyuki Kaneshiro"],
      ["Haikyuu!!", "Haruichi Furudate"],
      ["Persepolis", "Marjane Satrapi"],
      ["Maus", "Art Spiegelman", "A graphic novel that won a Pulitzer."]
    ],
    adventure: [
      ["The Alchemist", "Paulo Coelho"],
      ["Life of Pi", "Yann Martel"],
      ["Into the Wild", "Jon Krakauer"],
      ["Into Thin Air", "Jon Krakauer"],
      ["Endurance", "Alfred Lansing", "Shackleton. The greatest survival story on record."],
      ["Touching the Void", "Joe Simpson"],
      ["The Hunger Games", "Suzanne Collins"],
      ["Hatchet", "Gary Paulsen"],
      ["Treasure Island", "Robert Louis Stevenson"],
      ["Robinson Crusoe", "Daniel Defoe"],
      ["The Count of Monte Cristo", "Alexandre Dumas", "Patience as a weapon. 1,200 pages, worth it."],
      ["Around the World in Eighty Days", "Jules Verne"],
      ["Twenty Thousand Leagues Under the Sea", "Jules Verne"],
      ["Unbroken", "Laura Hillenbrand"],
      ["The Boy Who Harnessed the Wind", "William Kamkwamba", "A Malawian teenager builds a windmill from scrap."],
      ["Wild", "Cheryl Strayed"],
      ["The Long Walk", "Sławomir Rawicz"],
      ["Alone on the Wall", "Alex Honnold"],
      ["Adrift", "Steven Callahan"],
      ["The Wager", "David Grann"]
    ],
    african: [
      ["Things Fall Apart", "Chinua Achebe", "The most-read African novel in the world."],
      ["Half of a Yellow Sun", "Chimamanda Ngozi Adichie"],
      ["Purple Hibiscus", "Chimamanda Ngozi Adichie"],
      ["Americanah", "Chimamanda Ngozi Adichie"],
      ["We Should All Be Feminists", "Chimamanda Ngozi Adichie"],
      ["Homegoing", "Yaa Gyasi", "Ghana to America across seven generations."],
      ["Transcendent Kingdom", "Yaa Gyasi"],
      ["The Beautyful Ones Are Not Yet Born", "Ayi Kwei Armah"],
      ["Changes: A Love Story", "Ama Ata Aidoo"],
      ["Our Sister Killjoy", "Ama Ata Aidoo"],
      ["No Longer at Ease", "Chinua Achebe"],
      ["Arrow of God", "Chinua Achebe"],
      ["Weep Not, Child", "Ngũgĩ wa Thiong'o"],
      ["Decolonising the Mind", "Ngũgĩ wa Thiong'o"],
      ["So Long a Letter", "Mariama Bâ"],
      ["Nervous Conditions", "Tsitsi Dangarembga"],
      ["Stay With Me", "Ayọ̀bámi Adébáyọ̀"],
      ["The Death of Vivek Oji", "Akwaeke Emezi"],
      ["Freshwater", "Akwaeke Emezi"],
      ["Born a Crime", "Trevor Noah"]
    ],
    science: [
      ["Cosmos", "Carl Sagan"],
      ["A Brief History of Time", "Stephen Hawking"],
      ["Astrophysics for People in a Hurry", "Neil deGrasse Tyson"],
      ["The Selfish Gene", "Richard Dawkins"],
      ["The Immortal Life of Henrietta Lacks", "Rebecca Skloot"],
      ["The Gene", "Siddhartha Mukherjee"],
      ["The Emperor of All Maladies", "Siddhartha Mukherjee"],
      ["Why We Sleep", "Matthew Walker", "Sleep is not laziness. It is the training."],
      ["Behave", "Robert Sapolsky"],
      ["Braiding Sweetgrass", "Robin Wall Kimmerer"],
      ["Silent Spring", "Rachel Carson"],
      ["The Sixth Extinction", "Elizabeth Kolbert"],
      ["Entangled Life", "Merlin Sheldrake"],
      ["The Hidden Life of Trees", "Peter Wohlleben"],
      ["Lab Girl", "Hope Jahren"],
      ["Packing for Mars", "Mary Roach"],
      ["Surely You're Joking, Mr. Feynman!", "Richard Feynman", "Curiosity as a personality."],
      ["Six Easy Pieces", "Richard Feynman"],
      ["The Elegant Universe", "Brian Greene"],
      ["What If?", "Randall Munroe"]
    ],
    tech: [
      ["Clean Code", "Robert C. Martin"],
      ["The Pragmatic Programmer", "Andrew Hunt & David Thomas"],
      ["Automate the Boring Stuff with Python", "Al Sweigart", "Free online. Start here if you're new."],
      ["Python Crash Course", "Eric Matthes"],
      ["Eloquent JavaScript", "Marijn Haverbeke"],
      ["You Don't Know JS Yet", "Kyle Simpson"],
      ["Grokking Algorithms", "Aditya Bhargava"],
      ["Cracking the Coding Interview", "Gayle Laakmann McDowell"],
      ["Designing Data-Intensive Applications", "Martin Kleppmann"],
      ["The Mythical Man-Month", "Fred Brooks"],
      ["Code", "Charles Petzold"],
      ["Structure and Interpretation of Computer Programs", "Abelson & Sussman"],
      ["Refactoring", "Martin Fowler"],
      ["The Phoenix Project", "Gene Kim"],
      ["Hackers & Painters", "Paul Graham"],
      ["Life 3.0", "Max Tegmark"],
      ["Superintelligence", "Nick Bostrom"],
      ["Weapons of Math Destruction", "Cathy O'Neil"],
      ["The Age of Surveillance Capitalism", "Shoshana Zuboff"],
      ["Chip War", "Chris Miller"]
    ],
    sports: [
      ["Mamba Mentality", "Kobe Bryant"],
      ["Relentless", "Tim Grover"],
      ["Legacy", "James Kerr", "15 lessons from the All Blacks."],
      ["The Inner Game of Tennis", "Timothy Gallwey", "Applies to exams more than to tennis."],
      ["Moneyball", "Michael Lewis"],
      ["Bounce", "Matthew Syed"],
      ["Black Box Thinking", "Matthew Syed"],
      ["Endure", "Alex Hutchinson"],
      ["Born to Run", "Christopher McDougall"],
      ["Can't Hurt Me", "David Goggins"],
      ["Open", "Andre Agassi"],
      ["The Champion's Mind", "Jim Afremow"],
      ["Chasing Excellence", "Ben Bergeron"],
      ["Rise of the Ultra Runners", "Adharanand Finn"],
      ["The Rise of Superman", "Steven Kotler"],
      ["Peak Performance", "Brad Stulberg & Steve Magness"],
      ["Do Hard Things", "Steve Magness"],
      ["I Am Zlatan", "Zlatan Ibrahimović"],
      ["My Turn", "Johan Cruyff"],
      ["Shoe Dog", "Phil Knight"]
    ],
    poetry: [
      ["Milk and Honey", "Rupi Kaur"],
      ["The Sun and Her Flowers", "Rupi Kaur"],
      ["The Prophet", "Kahlil Gibran"],
      ["Leaves of Grass", "Walt Whitman"],
      ["The Complete Poems of Emily Dickinson", "Emily Dickinson"],
      ["If — and Other Poems", "Rudyard Kipling"],
      ["Still I Rise / And Still I Rise", "Maya Angelou", "Read it out loud."],
      ["I Know Why the Caged Bird Sings", "Maya Angelou"],
      ["Selected Poems", "Langston Hughes"],
      ["The Waste Land and Other Poems", "T. S. Eliot"],
      ["Ariel", "Sylvia Plath"],
      ["Devotions", "Mary Oliver"],
      ["Selected Poems", "Pablo Neruda"],
      ["The Essential Rumi", "Rumi"],
      ["Song of Lawino", "Okot p'Bitek"],
      ["Labyrinths", "Christopher Okigbo"],
      ["Idanre and Other Poems", "Wole Soyinka"],
      ["Collected Poems", "Kofi Awoonor", "Ghana's own."],
      ["Teaching My Mother How to Give Birth", "Warsan Shire"],
      ["Call Us What We Carry", "Amanda Gorman"]
    ],
    romance: [
      ["It Ends With Us", "Colleen Hoover", "17+. Heavy themes — abuse. Go in knowing."],
      ["Pride and Prejudice", "Jane Austen"],
      ["The Notebook", "Nicholas Sparks"],
      ["Me Before You", "Jojo Moyes"],
      ["The Hating Game", "Sally Thorne", "17+."],
      ["Beach Read", "Emily Henry"],
      ["People We Meet on Vacation", "Emily Henry"],
      ["Book Lovers", "Emily Henry"],
      ["The Seven Husbands of Evelyn Hugo", "Taylor Jenkins Reid"],
      ["Red, White & Royal Blue", "Casey McQuiston", "17+."],
      ["The Kiss Quotient", "Helen Hoang", "18+."],
      ["Outlander", "Diana Gabaldon", "18+."],
      ["The Time Traveler's Wife", "Audrey Niffenegger"],
      ["One Day", "David Nicholls"],
      ["Persuasion", "Jane Austen"],
      ["Jane Eyre", "Charlotte Brontë"],
      ["The Bride Test", "Helen Hoang", "18+."],
      ["Get a Life, Chloe Brown", "Talia Hibbert"],
      ["Love & Other Words", "Christina Lauren"],
      ["The Wedding Date", "Jasmine Guillory"]
    ]
  };
  var NEW_GENRES = {
    yaromance: { label: "YA & Sweet Romance", books: [
      ["To All the Boys I've Loved Before", "Jenny Han", "The safest, sweetest entry point in the genre."],
      ["The Summer I Turned Pretty", "Jenny Han"],
      ["Anna and the French Kiss", "Stephanie Perkins"],
      ["Eleanor & Park", "Rainbow Rowell"],
      ["Fangirl", "Rainbow Rowell"],
      ["The Fault in Our Stars", "John Green"],
      ["Looking for Alaska", "John Green", "16+."],
      ["Love, Simon (Simon vs. the Homo Sapiens Agenda)", "Becky Albertalli"],
      ["Heartstopper", "Alice Oseman", "Graphic novel. Gentle and enormously loved."],
      ["Five Feet Apart", "Rachael Lippincott"],
      ["Everything, Everything", "Nicola Yoon"],
      ["The Sun Is Also a Star", "Nicola Yoon"],
      ["If He Had Been with Me", "Laura Nowlin"],
      ["Better Than the Movies", "Lynn Painter"],
      ["The Love Hypothesis", "Ali Hazelwood", "18+."],
      ["Instructions for Dancing", "Nicola Yoon"],
      ["Frankly in Love", "David Yoon"],
      ["When Dimple Met Rishi", "Sandhya Menon"],
      ["Tweet Cute", "Emma Lord"],
      ["I Kissed Shara Wheeler", "Casey McQuiston"],
      ["Ace of Spades", "Faridah Àbíké-Íyímídé"],
      ["Clap When You Land", "Elizabeth Acevedo"],
      ["The Poet X", "Elizabeth Acevedo"],
      ["Since You've Been Gone", "Morgan Matson"],
      ["P.S. I Still Love You", "Jenny Han"],
      ["Always and Forever, Lara Jean", "Jenny Han"],
      ["Punching the Air", "Ibi Zoboi & Yusef Salaam"],
      ["A Good Girl's Guide to Murder", "Holly Jackson"]
    ] },
    darkromance: { adult: true, warn: "18+ ONLY. This shelf contains adult sexual content and heavy themes — violence, coercion, obsession, captivity, non-consent. Titles are listed by name only; the System does not describe the content. Check a content-warning list (StoryGraph or the author's own page) before you open any of them. If you are under 18, this shelf is not for you and it is not a challenge.", label: "Dark Romance & Gothic (18+)", books: [
      ["Haunting Adeline", "H. D. Carlton", "18+. Heavy CW: stalking, non-consent."],
      ["Hunting Adeline", "H. D. Carlton", "18+."],
      ["Twisted Love", "Ana Huang", "18+."],
      ["Twisted Games", "Ana Huang", "18+."],
      ["Twisted Hate", "Ana Huang", "18+."],
      ["Twisted Lies", "Ana Huang", "18+."],
      ["King of Wrath", "Ana Huang", "18+."],
      ["Butcher & Blackbird", "Brynne Weaver", "18+. CW: graphic violence."],
      ["Credence", "Penelope Douglas", "18+. CW: taboo themes."],
      ["Punk 57", "Penelope Douglas", "18+."],
      ["Corrupt", "Penelope Douglas", "18+."],
      ["Icebreaker", "Hannah Grace", "18+. Lighter end of the shelf."],
      ["The Ritual", "Shantel Tessier", "18+."],
      ["Den of Vipers", "K. A. Knight", "18+. CW: extreme."],
      ["Lights Out", "Navessa Allen", "18+."],
      ["Zodiac Academy", "Caroline Peckham & Susanne Valenti", "18+."],
      ["From Blood and Ash", "Jennifer L. Armentrout", "18+."],
      ["A Court of Mist and Fury", "Sarah J. Maas", "18+."],
      ["Crescent City: House of Earth and Blood", "Sarah J. Maas", "18+."],
      ["The Serpent and the Wings of Night", "Carissa Broadbent", "18+."],
      ["Ninth House", "Leigh Bardugo", "18+. Literary end. CW: assault."],
      ["The Secret History", "Donna Tartt", "18+. The dark-academia original."],
      ["Rebecca", "Daphne du Maurier", "The gothic template. No explicit content."],
      ["Wuthering Heights", "Emily Brontë", "Obsession as literature. No explicit content."],
      ["Jane Eyre", "Charlotte Brontë", "The gothic romance that started the tradition."],
      ["Bunny", "Mona Awad", "18+."],
      ["My Dark Vanessa", "Kate Elizabeth Russell", "18+. CW: grooming, abuse."],
      ["Verity", "Colleen Hoover", "18+."]
    ] },
    horror: { label: "Horror & Suspense", books: [
      ["It", "Stephen King", "16+."],
      ["The Shining", "Stephen King", "16+."],
      ["Pet Sematary", "Stephen King", "16+."],
      ["Misery", "Stephen King", "16+."],
      ["Carrie", "Stephen King", "16+."],
      ["Dracula", "Bram Stoker"],
      ["Frankenstein", "Mary Shelley"],
      ["The Haunting of Hill House", "Shirley Jackson"],
      ["We Have Always Lived in the Castle", "Shirley Jackson"],
      ["Mexican Gothic", "Silvia Moreno-Garcia"],
      ["Bird Box", "Josh Malerman"],
      ["The Exorcist", "William Peter Blatty", "18+."],
      ["House of Leaves", "Mark Z. Danielewski"],
      ["The Only Good Indians", "Stephen Graham Jones", "18+."],
      ["My Best Friend's Exorcism", "Grady Hendrix"],
      ["The Southern Book Club's Guide to Slaying Vampires", "Grady Hendrix"],
      ["Coraline", "Neil Gaiman", "Genuinely creepy, safe for younger readers."],
      ["The Graveyard Book", "Neil Gaiman"],
      ["Something Wicked This Way Comes", "Ray Bradbury"],
      ["The Turn of the Screw", "Henry James"],
      ["Rosemary's Baby", "Ira Levin", "18+."],
      ["The Call of Cthulhu", "H. P. Lovecraft"],
      ["Tender Is the Flesh", "Agustina Bazterrica", "18+. Deeply disturbing."],
      ["Ring", "Koji Suzuki"],
      ["Uzumaki", "Junji Ito", "Manga. Nightmare fuel."],
      ["Gyo", "Junji Ito"],
      ["The Fisherman", "John Langan"],
      ["Horrorstör", "Grady Hendrix"]
    ] },
    dystopian: { label: "Dystopian & Post-Apocalyptic", books: [
      ["The Hunger Games", "Suzanne Collins"],
      ["Catching Fire", "Suzanne Collins"],
      ["Mockingjay", "Suzanne Collins"],
      ["The Ballad of Songbirds and Snakes", "Suzanne Collins"],
      ["Divergent", "Veronica Roth"],
      ["The Maze Runner", "James Dashner"],
      ["1984", "George Orwell", "The book every other dystopia is answering."],
      ["Brave New World", "Aldous Huxley"],
      ["Fahrenheit 451", "Ray Bradbury"],
      ["The Handmaid's Tale", "Margaret Atwood", "16+."],
      ["The Giver", "Lois Lowry"],
      ["The Road", "Cormac McCarthy", "16+. Bleak and beautiful."],
      ["Station Eleven", "Emily St. John Mandel"],
      ["Never Let Me Go", "Kazuo Ishiguro"],
      ["The Testaments", "Margaret Atwood"],
      ["Legend", "Marie Lu"],
      ["Scythe", "Neal Shusterman"],
      ["Unwind", "Neal Shusterman"],
      ["World War Z", "Max Brooks"],
      ["Oryx and Crake", "Margaret Atwood"],
      ["Parable of the Sower", "Octavia Butler", "Written in 1993 and reads like the news."],
      ["Kindred", "Octavia Butler"],
      ["The Fifth Season", "N. K. Jemisin"],
      ["Red Rising", "Pierce Brown", "16+."],
      ["Wool", "Hugh Howey"],
      ["Ready Player One", "Ernest Cline"],
      ["Children of Men", "P. D. James"],
      ["The Power", "Naomi Alderman", "17+."]
    ] },
    crime: { label: "Crime & True Crime", books: [
      ["In Cold Blood", "Truman Capote", "The book that invented true crime."],
      ["I'll Be Gone in the Dark", "Michelle McNamara", "18+."],
      ["Mindhunter", "John Douglas", "18+."],
      ["The Devil in the White City", "Erik Larson"],
      ["Killers of the Flower Moon", "David Grann"],
      ["Say Nothing", "Patrick Radden Keefe"],
      ["Empire of Pain", "Patrick Radden Keefe"],
      ["Bad Blood", "John Carreyrou", "Silicon Valley's biggest fraud, told properly."],
      ["Catch Me If You Can", "Frank Abagnale"],
      ["The Sixth Man / Black Edge", "Sheelah Kolhatkar"],
      ["American Kingpin", "Nick Bilton"],
      ["Billion Dollar Whale", "Tom Wright & Bradley Hope"],
      ["The Big Short", "Michael Lewis"],
      ["Going Infinite", "Michael Lewis"],
      ["Number Go Up", "Zeke Faux"],
      ["Con/Artist", "Tony Tetro"],
      ["The Confidence Game", "Maria Konnikova", "How scams work on smart people."],
      ["Talking to Strangers", "Malcolm Gladwell"],
      ["Homicide", "David Simon", "18+."],
      ["The Godfather", "Mario Puzo", "18+. Fiction, but the standard."],
      ["Gomorrah", "Roberto Saviano", "18+."],
      ["Narconomics", "Tom Wainwright"],
      ["McMafia", "Misha Glenny"],
      ["Dark Money", "Jane Mayer"],
      ["The Feather Thief", "Kirk Wallace Johnson"],
      ["Furious Hours", "Casey Cep"],
      ["Green River, Running Red", "Ann Rule", "18+."],
      ["We Were Liars", "E. Lockhart", "YA, twisty, safe."]
    ] },
    health: { label: "Health, Fitness & Nutrition", books: [
      ["Why We Sleep", "Matthew Walker", "Fix sleep before you fix anything else."],
      ["Outlive", "Peter Attia"],
      ["Breath", "James Nestor"],
      ["How Not to Die", "Michael Greger"],
      ["In Defense of Food", "Michael Pollan"],
      ["The Omnivore's Dilemma", "Michael Pollan"],
      ["Bigger Leaner Stronger", "Michael Matthews"],
      ["Starting Strength", "Mark Rippetoe"],
      ["Overcoming Gravity", "Steven Low", "The calisthenics bible."],
      ["Convict Conditioning", "Paul Wade"],
      ["You Are Your Own Gym", "Mark Lauren"],
      ["Becoming a Supple Leopard", "Kelly Starrett"],
      ["Anatomy for Strength and Fitness Training", "Mark Vella"],
      ["The Sports Gene", "David Epstein"],
      ["Endure", "Alex Hutchinson"],
      ["Spark", "John Ratey", "What exercise does to the studying brain."],
      ["The Body", "Bill Bryson"],
      ["Gut", "Giulia Enders"],
      ["Lifespan", "David Sinclair"],
      ["Atomic Habits", "James Clear"],
      ["The Comfort Crisis", "Michael Easter"],
      ["Move Your DNA", "Katy Bowman"],
      ["Roar", "Stacy Sims"],
      ["Next Level", "Stacy Sims"],
      ["Eat & Run", "Scott Jurek"],
      ["The New Rules of Lifting", "Lou Schuler"],
      ["Peak Performance", "Brad Stulberg & Steve Magness"],
      ["Rest", "Alex Soojung-Kim Pang"]
    ] },
    faith: { label: "Faith, Meaning & Stoicism", books: [
      ["The Purpose Driven Life", "Rick Warren"],
      ["Mere Christianity", "C. S. Lewis"],
      ["The Screwtape Letters", "C. S. Lewis"],
      ["Man's Search for Meaning", "Viktor Frankl"],
      ["The Alchemist", "Paulo Coelho"],
      ["The Seven Storey Mountain", "Thomas Merton"],
      ["The Case for Christ", "Lee Strobel"],
      ["Battlefield of the Mind", "Joyce Meyer"],
      ["The Bait of Satan", "John Bevere"],
      ["Boundaries", "Henry Cloud & John Townsend"],
      ["Jesus Calling", "Sarah Young"],
      ["The Ragamuffin Gospel", "Brennan Manning"],
      ["Meditations", "Marcus Aurelius"],
      ["The Daily Stoic", "Ryan Holiday"],
      ["Letters from a Stoic", "Seneca"],
      ["A Guide to the Good Life", "William Irvine"],
      ["The Prophet", "Kahlil Gibran"],
      ["The Book of Joy", "Dalai Lama & Desmond Tutu"],
      ["No Mud, No Lotus", "Thich Nhat Hanh"],
      ["The Miracle of Mindfulness", "Thich Nhat Hanh"],
      ["Wherever You Go, There You Are", "Jon Kabat-Zinn"],
      ["10% Happier", "Dan Harris"],
      ["When Things Fall Apart", "Pema Chödrön"],
      ["The Road Less Traveled", "M. Scott Peck"],
      ["Tuesdays with Morrie", "Mitch Albom"],
      ["The Five People You Meet in Heaven", "Mitch Albom"],
      ["Ikigai", "Héctor García & Francesc Miralles"],
      ["Four Thousand Weeks", "Oliver Burkeman", "You get about 4,000 weeks. Spend them awake."]
    ] },
    creativity: { label: "Art, Writing & Creativity", books: [
      ["Steal Like an Artist", "Austin Kleon", "Read in an hour. Changes how you start."],
      ["Show Your Work!", "Austin Kleon"],
      ["The Artist's Way", "Julia Cameron"],
      ["Big Magic", "Elizabeth Gilbert"],
      ["On Writing", "Stephen King"],
      ["Bird by Bird", "Anne Lamott"],
      ["The War of Art", "Steven Pressfield"],
      ["The Creative Act", "Rick Rubin"],
      ["Save the Cat! Writes a Novel", "Jessica Brody"],
      ["Story", "Robert McKee"],
      ["The Elements of Style", "Strunk & White"],
      ["Several Short Sentences About Writing", "Verlyn Klinkenborg"],
      ["Draw Your Day", "Samantha Dion Baker"],
      ["Drawing on the Right Side of the Brain", "Betty Edwards", "The book that teaches non-artists to draw."],
      ["Keys to Drawing", "Bert Dodson"],
      ["Color and Light", "James Gurney"],
      ["Imaginative Realism", "James Gurney"],
      ["Framed Ink", "Marcos Mateu-Mestre"],
      ["The Animator's Survival Kit", "Richard Williams"],
      ["Understanding Comics", "Scott McCloud"],
      ["Making Comics", "Scott McCloud"],
      ["The Design of Everyday Things", "Don Norman"],
      ["Thinking with Type", "Ellen Lupton"],
      ["Grid Systems in Graphic Design", "Josef Müller-Brockmann"],
      ["Refactoring UI", "Adam Wathan & Steve Schoger"],
      ["Music Theory for Dummies", "Michael Pilhofer"],
      ["How Music Works", "David Byrne"],
      ["Creative Selection", "Ken Kocienda"]
    ] },
    war: { label: "War, Conflict & Courage", books: [
      ["All Quiet on the Western Front", "Erich Maria Remarque"],
      ["The Book Thief", "Markus Zusak"],
      ["The Boy in the Striped Pyjamas", "John Boyne"],
      ["Night", "Elie Wiesel"],
      ["The Diary of a Young Girl", "Anne Frank"],
      ["Unbroken", "Laura Hillenbrand"],
      ["Band of Brothers", "Stephen Ambrose"],
      ["Black Hawk Down", "Mark Bowden"],
      ["The Things They Carried", "Tim O'Brien", "16+."],
      ["Catch-22", "Joseph Heller"],
      ["Slaughterhouse-Five", "Kurt Vonnegut"],
      ["A Long Way Gone", "Ishmael Beah", "A child soldier's own account. Hard, necessary."],
      ["Half of a Yellow Sun", "Chimamanda Ngozi Adichie"],
      ["Beasts of No Nation", "Uzodinma Iweala"],
      ["The Kite Runner", "Khaled Hosseini"],
      ["A Thousand Splendid Suns", "Khaled Hosseini"],
      ["I Am Malala", "Malala Yousafzai"],
      ["The Guns of August", "Barbara Tuchman"],
      ["SPQR", "Mary Beard"],
      ["Genghis Khan and the Making of the Modern World", "Jack Weatherford"],
      ["Shogun", "James Clavell"],
      ["The Art of War", "Sun Tzu"],
      ["On Killing", "Dave Grossman", "18+."],
      ["Lone Survivor", "Marcus Luttrell", "18+."],
      ["Extreme Ownership", "Jocko Willink", "Leadership rules from a SEAL commander."],
      ["Discipline Equals Freedom", "Jocko Willink"],
      ["Make Your Bed", "William H. McRaven"],
      ["Resistance, Rebellion, and Death", "Albert Camus"]
    ] },
    econ: { label: "Economics & the World", books: [
      ["Freakonomics", "Steven Levitt & Stephen Dubner"],
      ["Nudge", "Richard Thaler & Cass Sunstein"],
      ["Misbehaving", "Richard Thaler"],
      ["Poor Economics", "Banerjee & Duflo", "Nobel-winning field work on what actually lifts people out of poverty."],
      ["Good Economics for Hard Times", "Banerjee & Duflo"],
      ["Why Nations Fail", "Acemoglu & Robinson", "Institutions, not geography. Argue with it."],
      ["The Wealth of Nations", "Adam Smith"],
      ["Capital in the Twenty-First Century", "Thomas Piketty"],
      ["Dead Aid", "Dambisa Moyo", "An African economist's case against aid."],
      ["Africa's Business Revolution", "Acha Leke et al."],
      ["The Looting Machine", "Tom Burgis"],
      ["How Europe Underdeveloped Africa", "Walter Rodney"],
      ["The Bottom Billion", "Paul Collier"],
      ["Development as Freedom", "Amartya Sen"],
      ["Doughnut Economics", "Kate Raworth"],
      ["23 Things They Don't Tell You About Capitalism", "Ha-Joon Chang"],
      ["Economics: The User's Guide", "Ha-Joon Chang"],
      ["Basic Economics", "Thomas Sowell"],
      ["The Undercover Economist", "Tim Harford"],
      ["Factfulness", "Hans Rosling", "The world is better than the news suggests. With data."],
      ["Prisoners of Geography", "Tim Marshall"],
      ["The Power of Geography", "Tim Marshall"],
      ["The Ascent of Money", "Niall Ferguson"],
      ["Lords of Finance", "Liaquat Ahamed"],
      ["Debt: The First 5,000 Years", "David Graeber"],
      ["The Price of Time", "Edward Chancellor"],
      ["Chip War", "Chris Miller"],
      ["World Order", "Henry Kissinger"]
    ] },
    exams: { label: "Study Skills & Exams", books: [
      ["Make It Stick", "Brown, Roediger & McDaniel", "The evidence on how memory actually works. Non-negotiable."],
      ["A Mind for Numbers", "Barbara Oakley", "Written for people who think they're bad at maths."],
      ["Learning How to Learn", "Barbara Oakley & Terrence Sejnowski"],
      ["Ultralearning", "Scott Young"],
      ["How to Become a Straight-A Student", "Cal Newport"],
      ["Deep Work", "Cal Newport"],
      ["How to Win at College", "Cal Newport"],
      ["Moonwalking with Einstein", "Joshua Foer"],
      ["Unlimited Memory", "Kevin Horsley"],
      ["The Memory Book", "Harry Lorayne & Jerry Lucas"],
      ["Study Smarter, Not Harder", "Kevin Paul"],
      ["The Study Skills Handbook", "Stella Cottrell"],
      ["How to Take Smart Notes", "Sönke Ahrens"],
      ["Building a Second Brain", "Tiago Forte"],
      ["The Productivity Project", "Chris Bailey"],
      ["Peak", "Anders Ericsson"],
      ["Mindset", "Carol Dweck"],
      ["Grit", "Angela Duckworth"],
      ["Limitless", "Jim Kwik"],
      ["Range", "David Epstein"],
      ["The Talent Code", "Daniel Coyle"],
      ["The Little Book of Talent", "Daniel Coyle"],
      ["Barron's / Cambridge past-paper packs", "Exam boards", "Not a book — the single highest-return study material there is."],
      ["Thinking, Fast and Slow", "Daniel Kahneman"],
      ["The Art of Learning", "Josh Waitzkin"],
      ["Cracking the SAT", "The Princeton Review"],
      ["Official SAT Study Guide", "College Board"],
      ["Cambridge IGCSE past papers", "Cambridge International", "Ten years of them beats any revision guide."]
    ] },
    contemp: { label: "Contemporary Fiction", books: [
      ["The Seven Husbands of Evelyn Hugo", "Taylor Jenkins Reid"],
      ["Daisy Jones & The Six", "Taylor Jenkins Reid"],
      ["Where the Crawdads Sing", "Delia Owens"],
      ["A Little Life", "Hanya Yanagihara", "18+. Severe content warnings."],
      ["Normal People", "Sally Rooney", "17+."],
      ["The Midnight Library", "Matt Haig"],
      ["Klara and the Sun", "Kazuo Ishiguro"],
      ["Lessons in Chemistry", "Bonnie Garmus"],
      ["Tomorrow, and Tomorrow, and Tomorrow", "Gabrielle Zevin", "Friendship, games, and building things together."],
      ["Yellowface", "R. F. Kuang"],
      ["Babel", "R. F. Kuang"],
      ["Pachinko", "Min Jin Lee"],
      ["The Kite Runner", "Khaled Hosseini"],
      ["A Man Called Ove", "Fredrik Backman"],
      ["Anxious People", "Fredrik Backman"],
      ["Beartown", "Fredrik Backman"],
      ["Little Fires Everywhere", "Celeste Ng"],
      ["The Vanishing Half", "Brit Bennett"],
      ["Homegoing", "Yaa Gyasi"],
      ["Americanah", "Chimamanda Ngozi Adichie"],
      ["Circe", "Madeline Miller"],
      ["The Song of Achilles", "Madeline Miller"],
      ["Shuggie Bain", "Douglas Stuart", "18+."],
      ["Convenience Store Woman", "Sayaka Murata"],
      ["Before the Coffee Gets Cold", "Toshikazu Kawaguchi"],
      ["Norwegian Wood", "Haruki Murakami", "18+."],
      ["Kafka on the Shore", "Haruki Murakami"],
      ["The Remains of the Day", "Kazuo Ishiguro"]
    ] },
    comedy: { label: "Humour & Feel-Good", books: [
      ["The Hitchhiker's Guide to the Galaxy", "Douglas Adams"],
      ["Good Omens", "Terry Pratchett & Neil Gaiman"],
      ["Guards! Guards!", "Terry Pratchett"],
      ["Mort", "Terry Pratchett"],
      ["Born a Crime", "Trevor Noah", "Funny and devastating in the same paragraph."],
      ["Bossypants", "Tina Fey"],
      ["Yes Please", "Amy Poehler"],
      ["Is Everyone Hanging Out Without Me?", "Mindy Kaling"],
      ["Diary of a Wimpy Kid", "Jeff Kinney"],
      ["Bridget Jones's Diary", "Helen Fielding", "16+."],
      ["Me Talk Pretty One Day", "David Sedaris"],
      ["Calypso", "David Sedaris"],
      ["The Rosie Project", "Graeme Simsion"],
      ["A Man Called Ove", "Fredrik Backman"],
      ["Anxious People", "Fredrik Backman"],
      ["The Thursday Murder Club", "Richard Osman"],
      ["Legends & Lattes", "Travis Baldree", "Cosy fantasy. Nothing bad happens."],
      ["The House in the Cerulean Sea", "TJ Klune"],
      ["Three Men in a Boat", "Jerome K. Jerome"],
      ["Catch-22", "Joseph Heller"],
      ["Nothing to See Here", "Kevin Wilson"],
      ["Where'd You Go, Bernadette", "Maria Semple"],
      ["Wodehouse: Right Ho, Jeeves", "P. G. Wodehouse"],
      ["How to Be a Bawse", "Lilly Singh"],
      ["Everything Is F*cked", "Mark Manson", "17+."],
      ["We Are Never Meeting in Real Life", "Samantha Irby", "18+."],
      ["Furiously Happy", "Jenny Lawson"],
      ["Adulthood Is a Myth", "Sarah Andersen"]
    ] },
    leadership: { label: "Leadership & Speaking", books: [
      ["How to Win Friends and Influence People", "Dale Carnegie"],
      ["Leaders Eat Last", "Simon Sinek"],
      ["Start With Why", "Simon Sinek"],
      ["The Infinite Game", "Simon Sinek"],
      ["Dare to Lead", "Brené Brown"],
      ["Daring Greatly", "Brené Brown"],
      ["Extreme Ownership", "Jocko Willink"],
      ["The 21 Irrefutable Laws of Leadership", "John C. Maxwell"],
      ["Developing the Leader Within You", "John C. Maxwell"],
      ["Radical Candor", "Kim Scott"],
      ["Crucial Conversations", "Patterson, Grenny, McMillan & Switzler"],
      ["Difficult Conversations", "Stone, Patton & Heen"],
      ["Never Split the Difference", "Chris Voss"],
      ["Getting to Yes", "Fisher & Ury"],
      ["Talk Like TED", "Carmine Gallo"],
      ["TED Talks", "Chris Anderson", "The official guide to giving one."],
      ["Steal the Show", "Michael Port"],
      ["The Quick and Easy Way to Effective Speaking", "Dale Carnegie"],
      ["Made to Stick", "Chip & Dan Heath"],
      ["Words Like Loaded Pistols", "Sam Leith"],
      ["Thank You for Arguing", "Jay Heinrichs", "Rhetoric, from Aristotle to your group chat."],
      ["Multipliers", "Liz Wiseman"],
      ["The Five Dysfunctions of a Team", "Patrick Lencioni"],
      ["Turn the Ship Around!", "L. David Marquet"],
      ["Good to Great", "Jim Collins"],
      ["Principles", "Ray Dalio"],
      ["No Rules Rules", "Reed Hastings & Erin Meyer"],
      ["The Culture Map", "Erin Meyer", "Essential if you plan to work across borders."]
    ] }
  };
  var MORE_SCREEN = {
    s_action: [
      ["John Wick", "film", "17+."],
      ["Gladiator", "film", "16+."],
      ["Mad Max: Fury Road", "film", "16+."],
      ["The Matrix", "film", "16+."],
      ["Casino Royale", "film"],
      ["Skyfall", "film"],
      ["Kill Bill: Vol. 1", "film", "18+."],
      ["The Bourne Identity", "film"],
      ["Guardians of the Galaxy", "film"],
      ["Spider-Man: No Way Home", "film"],
      ["Dune: Part Two", "film"],
      ["Extraction", "film", "17+."],
      ["The Raid", "film", "18+."],
      ["Crouching Tiger, Hidden Dragon", "film"],
      ["Ip Man", "film"],
      ["Rush Hour", "film"],
      ["Mad Hot / Warrior", "film", "16+."],
      ["The Old Guard", "film", "16+."]
    ],
    s_anime_act: [
      ["Bleach: Thousand-Year Blood War", "anime"],
      ["Vinland Saga", "anime", "16+."],
      ["Black Clover", "anime"],
      ["Fire Force", "anime"],
      ["Dr. Stone", "anime"],
      ["Blue Lock", "anime", "Football as a war of egos."],
      ["Mob Psycho 100", "anime"],
      ["Sword Art Online", "anime"],
      ["Re:Zero", "anime", "16+."],
      ["Tokyo Revengers", "anime", "16+."],
      ["The Rising of the Shield Hero", "anime"],
      ["Kaiju No. 8", "anime"],
      ["Dandadan", "anime", "17+."],
      ["Frieren: Beyond Journey's End", "anime", "Quiet, patient, and one of the best-reviewed ever."],
      ["Gurren Lagann", "anime"],
      ["Dragon Ball Z", "anime"],
      ["Bleach", "anime"],
      ["Chainsaw Man", "anime", "17+."]
    ],
    s_anime_mind: [
      ["Monster", "anime", "17+. A surgeon hunts the boy he saved."],
      ["Psycho-Pass", "anime", "17+."],
      ["Erased", "anime"],
      ["Terror in Resonance", "anime"],
      ["Kaiji", "anime", "Gambling, debt, and desperate maths."],
      ["Akagi", "anime"],
      ["No Game No Life", "anime"],
      ["Ranking of Kings", "anime"],
      ["Baccano!", "anime", "17+."],
      ["Great Pretender", "anime", "16+."],
      ["Odd Taxi", "anime"],
      ["Vivy: Fluorite Eye's Song", "anime"],
      ["86 EIGHTY-SIX", "anime"],
      ["Ergo Proxy", "anime"],
      ["Serial Experiments Lain", "anime"],
      ["Summertime Rendering", "anime"],
      ["Zankyou / Parasyte", "anime", "17+."],
      ["Bakuman", "anime", "Two teenagers try to become manga artists. Pure work ethic."]
    ],
    s_scifi: [
      ["Blade Runner 2049", "film", "16+."],
      ["Everything Everywhere All at Once", "film", "16+."],
      ["Ex Machina", "film", "17+."],
      ["Her", "film", "16+."],
      ["Gravity", "film"],
      ["Minority Report", "film"],
      ["District 9", "film", "17+."],
      ["Edge of Tomorrow", "film"],
      ["Tenet", "film"],
      ["Oppenheimer", "film", "16+."],
      ["Black Mirror", "series", "18+. Watch one episode a week, not six."],
      ["Westworld", "series", "18+."],
      ["Severance", "series", "A workplace nightmare, beautifully made."],
      ["Foundation", "series"],
      ["The Expanse", "series", "16+."],
      ["Silo", "series"],
      ["Love, Death + Robots", "series", "18+."],
      ["3 Body Problem", "series", "16+."]
    ],
    s_mystery: [
      ["Se7en", "film", "18+."],
      ["Zodiac", "film", "17+."],
      ["Shutter Island", "film", "16+."],
      ["Gone Girl", "film", "18+."],
      ["Prisoners", "film", "17+."],
      ["Parasite", "film", "16+. Best Picture, and deserved it."],
      ["Glass Onion", "film"],
      ["The Girl with the Dragon Tattoo", "film", "18+."],
      ["Nightcrawler", "film", "18+."],
      ["Mare of Easttown", "series", "18+."],
      ["True Detective", "series", "18+."],
      ["Broadchurch", "series", "16+."],
      ["The Night Of", "series", "18+."],
      ["Only Murders in the Building", "series"],
      ["The Sinner", "series", "18+."],
      ["Bodyguard", "series", "16+."],
      ["Line of Duty", "series", "16+."],
      ["Dark Winds", "series", "16+."]
    ],
    s_fantasy: [
      ["Harry Potter and the Philosopher's Stone", "film"],
      ["The Lord of the Rings: The Return of the King", "film"],
      ["Avatar: The Last Airbender", "series", "The best-written children's show ever made. Not a children's show."],
      ["Game of Thrones", "series", "18+."],
      ["House of the Dragon", "series", "18+."],
      ["The Witcher", "series", "18+."],
      ["Shadow and Bone", "series"],
      ["Percy Jackson and the Olympians", "series"],
      ["His Dark Materials", "series"],
      ["The Chronicles of Narnia", "film"],
      ["Pan's Labyrinth", "film", "18+."],
      ["Spirited Away", "film", "Miyazaki's masterpiece."],
      ["Princess Mononoke", "film", "13+."],
      ["Howl's Moving Castle", "film"],
      ["Castle in the Sky", "film"],
      ["The Rings of Power", "series"],
      ["Stardust", "film"],
      ["Coraline", "film"]
    ],
    s_true: [
      ["The Pursuit of Happyness", "film", "The one to watch when you want to quit."],
      ["Hidden Figures", "film"],
      ["12 Years a Slave", "film", "18+."],
      ["Schindler's List", "film", "18+."],
      ["The Imitation Game", "film"],
      ["A Beautiful Mind", "film"],
      ["Rush", "film", "16+."],
      ["Ford v Ferrari", "film"],
      ["Catch Me If You Can", "film"],
      ["Spotlight", "film", "16+."],
      ["Erin Brockovich", "film", "16+."],
      ["Selma", "film"],
      ["Invictus", "film"],
      ["The Blind Side", "film"],
      ["Chernobyl", "series", "18+. What lies cost."],
      ["When They See Us", "series", "18+."],
      ["The Crown", "series"],
      ["Queen's Gambit", "series", "16+. Chess as obsession."]
    ],
    s_biz: [
      ["The Social Network", "film", "16+. How Facebook was built, and what it cost."],
      ["The Founder", "film"],
      ["The Big Short", "film", "17+."],
      ["Moneyball", "film"],
      ["Jobs / Steve Jobs", "film"],
      ["Wall Street", "film", "16+."],
      ["Margin Call", "film", "16+."],
      ["Joy", "film"],
      ["Air", "film"],
      ["Silicon Valley", "series", "17+."],
      ["Billions", "series", "18+."],
      ["Succession", "series", "18+."],
      ["Suits", "series", "16+."],
      ["Shark Tank / Dragons' Den", "series", "Watch how they answer 'what are your numbers'."],
      ["WeCrashed", "series", "16+."],
      ["The Dropout", "series", "16+."],
      ["Super Pumped", "series", "17+."],
      ["Industry", "series", "18+."]
    ],
    s_sport: [
      ["Rocky", "film"],
      ["Creed", "film"],
      ["Coach Carter", "film", "Grades before games."],
      ["Remember the Titans", "film"],
      ["Million Dollar Baby", "film", "16+."],
      ["Warrior", "film", "16+."],
      ["McFarland, USA", "film"],
      ["Bend It Like Beckham", "film"],
      ["The Last Dance", "series", "Jordan's standard, in his own words."],
      ["Formula 1: Drive to Survive", "series"],
      ["Sunderland 'Til I Die", "series"],
      ["Break Point", "series"],
      ["Haikyuu!!", "anime", "Volleyball. Better than it sounds — far better."],
      ["Kuroko's Basketball", "anime"],
      ["Hajime no Ippo", "anime"],
      ["Ping Pong the Animation", "anime"],
      ["Ashita no Joe", "anime"],
      ["Yuri!!! on Ice", "anime"]
    ],
    s_comedy: [
      ["The Grand Budapest Hotel", "film"],
      ["Superbad", "film", "18+."],
      ["Coming to America", "film", "16+."],
      ["Home Alone", "film"],
      ["Mrs. Doubtfire", "film"],
      ["The Truman Show", "film"],
      ["School of Rock", "film"],
      ["Jumanji: Welcome to the Jungle", "film"],
      ["Brooklyn Nine-Nine", "series"],
      ["The Office (US)", "series", "16+."],
      ["Parks and Recreation", "series"],
      ["Ted Lasso", "series", "16+. Kindness as a strategy."],
      ["Modern Family", "series"],
      ["Friends", "series"],
      ["Abbott Elementary", "series"],
      ["Never Have I Ever", "series", "16+."],
      ["Spy x Family", "anime"],
      ["Gintama", "anime", "16+."]
    ],
    s_africa: [
      ["Black Panther: Wakanda Forever", "film"],
      ["The Woman King", "film", "16+."],
      ["Queen of Katwe", "film", "A Ugandan girl becomes a chess champion. True."],
      ["Beasts of No Nation", "film", "18+."],
      ["The Boy Who Harnessed the Wind", "film"],
      ["Rafiki", "film", "16+."],
      ["Tsotsi", "film", "16+."],
      ["Sarafina!", "film"],
      ["Azali", "film", "Ghanaian."],
      ["The Burial of Kojo", "film", "Ghanaian, and visually stunning."],
      ["Keteke", "film", "Ghanaian comedy."],
      ["Sidechick Gang", "film", "Ghanaian."],
      ["The Wedding Party", "film", "Nigerian."],
      ["King of Boys", "film", "17+. Nigerian."],
      ["Blood Sisters", "series", "17+. Nigerian."],
      ["Blood & Water", "series", "16+. South African."],
      ["Queen Sono", "series", "16+."],
      ["Iwájú", "series", "Nigerian sci-fi animation from Disney and Kugali."]
    ],
    s_docs: [
      ["Free Solo", "film", "Preparation as the whole story."],
      ["The Social Dilemma", "film", "Watch it, then check your screen time."],
      ["13th", "film", "16+."],
      ["Icarus", "film", "16+."],
      ["My Octopus Teacher", "film"],
      ["Jiro Dreams of Sushi", "film", "Mastery, quietly."],
      ["Man on Wire", "film"],
      ["Won't You Be My Neighbor?", "film"],
      ["The Act of Killing", "film", "18+."],
      ["Planet Earth II", "series"],
      ["Our Planet", "series"],
      ["Cosmos: A Spacetime Odyssey", "series"],
      ["Explained", "series"],
      ["Abstract: The Art of Design", "series"],
      ["Chef's Table", "series"],
      ["Inside Bill's Brain", "series"],
      ["Making a Murderer", "series", "16+."],
      ["Seaspiracy", "film", "16+."]
    ]
  };
  var NEW_SCREEN = {
    s_anime_life: { label: "Anime — Slice of Life & Growth", picks: [
      ["Your Name", "film", "The highest-grossing anime film of its era, and it earns it."],
      ["A Silent Voice", "film", "Bullying, guilt and repair. Bring tissues."],
      ["Weathering with You", "film"],
      ["Suzume", "film"],
      ["The Garden of Words", "film"],
      ["Violet Evergarden", "anime", "Learning what feelings are, letter by letter."],
      ["Clannad: After Story", "anime"],
      ["Anohana", "anime"],
      ["March Comes In Like a Lion", "anime", "Depression, shogi, and slowly getting better."],
      ["Barakamon", "anime"],
      ["Silver Spoon", "anime", "From the Fullmetal Alchemist author. Farming school."],
      ["Horimiya", "anime"],
      ["Toradora!", "anime"],
      ["Kaguya-sama: Love Is War", "anime"],
      ["My Dress-Up Darling", "anime", "16+."],
      ["Wotakoi", "anime"],
      ["Skip and Loafer", "anime"],
      ["Laid-Back Camp", "anime"],
      ["Sound! Euphonium", "anime"],
      ["Your Lie in April", "anime", "Music, grief, and playing anyway."],
      ["Hyouka", "anime"],
      ["K-On!", "anime"],
      ["Nichijou", "anime"],
      ["Given", "anime", "16+."],
      ["Blue Period", "anime", "A top student discovers art and starts from zero."]
    ] },
    s_anime_dark: { label: "Anime — Dark & Psychological (16+)", picks: [
      ["Death Note", "anime", "16+."],
      ["Attack on Titan: The Final Season", "anime", "17+."],
      ["Tokyo Ghoul", "anime", "17+."],
      ["Elfen Lied", "anime", "18+."],
      ["Berserk (1997)", "anime", "18+."],
      ["Devilman Crybaby", "anime", "18+. Extremely graphic."],
      ["Made in Abyss", "anime", "17+. Looks cute. Is not."],
      ["Higurashi", "anime", "18+."],
      ["Another", "anime", "17+."],
      ["Perfect Blue", "film", "18+."],
      ["Paprika", "film", "17+."],
      ["Akira", "film", "17+."],
      ["Ghost in the Shell", "film", "16+."],
      ["Neon Genesis Evangelion", "anime", "16+."],
      ["Puella Magi Madoka Magica", "anime", "16+."],
      ["Monster", "anime", "17+."],
      ["Psycho-Pass", "anime", "17+."],
      ["Parasyte -the maxim-", "anime", "17+."],
      ["Hell's Paradise", "anime", "17+."],
      ["Jigokuraku / Dorohedoro", "anime", "18+."],
      ["Vinland Saga Season 2", "anime", "16+. A warrior who refuses to fight."],
      ["Terror in Resonance", "anime", "16+."],
      ["Death Parade", "anime", "17+."],
      ["Shiki", "anime", "17+."],
      ["Kaiji: Ultimate Survivor", "anime", "16+."]
    ] },
    s_romance: { label: "Romance", picks: [
      ["The Notebook", "film"],
      ["Titanic", "film"],
      ["Pride & Prejudice (2005)", "film"],
      ["La La Land", "film"],
      ["Notting Hill", "film"],
      ["10 Things I Hate About You", "film"],
      ["To All the Boys I've Loved Before", "film"],
      ["The Half of It", "film"],
      ["Crazy Rich Asians", "film"],
      ["Me Before You", "film"],
      ["A Walk to Remember", "film"],
      ["Love, Rosie", "film", "16+."],
      ["The Fault in Our Stars", "film"],
      ["Purple Hearts", "film", "16+."],
      ["Anyone But You", "film", "17+."],
      ["Bridgerton", "series", "18+."],
      ["Heartstopper", "series", "Gentle, and hugely loved."],
      ["Never Have I Ever", "series", "16+."],
      ["Modern Love", "series"],
      ["Normal People", "series", "18+."],
      ["Emily in Paris", "series", "16+."],
      ["Virgin River", "series", "16+."],
      ["Ginny & Georgia", "series", "16+."],
      ["Maid", "series", "18+."],
      ["One Day", "series", "16+."]
    ] },
    s_kdrama: { label: "K-Drama & Asian Series", picks: [
      ["Squid Game", "series", "18+."],
      ["Crash Landing on You", "series"],
      ["Goblin (Guardian)", "series"],
      ["Itaewon Class", "series", "16+. A boy rebuilds after losing everything."],
      ["Start-Up", "series", "Founders, funding, and failure."],
      ["Descendants of the Sun", "series"],
      ["Vincenzo", "series", "16+."],
      ["Reply 1988", "series"],
      ["Hospital Playlist", "series"],
      ["Sky Castle", "series", "16+. Education pressure taken to its logical end."],
      ["Extraordinary Attorney Woo", "series"],
      ["Business Proposal", "series"],
      ["Alchemy of Souls", "series"],
      ["My Mister", "series", "16+."],
      ["Signal", "series", "16+."],
      ["Stranger (Secret Forest)", "series", "16+."],
      ["Move to Heaven", "series"],
      ["Weak Hero Class 1", "series", "17+."],
      ["The Glory", "series", "18+."],
      ["Parasite", "film", "16+."],
      ["Train to Busan", "film", "17+."],
      ["Alice in Borderland", "series", "18+. Japanese."],
      ["Midnight Diner", "series", "Japanese. Quiet and kind."],
      ["The Untamed", "series", "Chinese."],
      ["Nirvana in Fire", "series", "Chinese. Strategy at the level of Death Note."]
    ] },
    s_horror: { label: "Horror & Thriller (16+)", picks: [
      ["Get Out", "film", "17+. Horror as social commentary."],
      ["A Quiet Place", "film", "16+."],
      ["The Conjuring", "film", "17+."],
      ["It", "film", "17+."],
      ["Hereditary", "film", "18+."],
      ["Midsommar", "film", "18+."],
      ["The Shining", "film", "18+."],
      ["Sinister", "film", "18+."],
      ["Us", "film", "17+."],
      ["The Babadook", "film", "17+."],
      ["The Sixth Sense", "film", "13+."],
      ["Train to Busan", "film", "17+."],
      ["The Ring", "film", "17+."],
      ["28 Days Later", "film", "18+."],
      ["Bird Box", "film", "17+."],
      ["Talk to Me", "film", "18+."],
      ["Nope", "film", "16+."],
      ["The Haunting of Hill House", "series", "18+."],
      ["Stranger Things", "series", "14+."],
      ["The Walking Dead", "series", "18+."],
      ["From", "series", "17+."],
      ["Yellowjackets", "series", "18+."],
      ["The Last of Us", "series", "18+."],
      ["Wednesday", "series", "13+."],
      ["Fear Street", "film", "18+."]
    ] },
    s_crime: { label: "Crime, Law & Heist", picks: [
      ["The Godfather", "film", "18+."],
      ["Goodfellas", "film", "18+."],
      ["The Departed", "film", "18+."],
      ["Catch Me If You Can", "film"],
      ["Ocean's Eleven", "film"],
      ["The Italian Job", "film"],
      ["Heat", "film", "18+."],
      ["A Few Good Men", "film", "16+."],
      ["12 Angry Men", "film", "One room. Twelve men. The best argument ever filmed."],
      ["The Lincoln Lawyer", "film", "16+."],
      ["Just Mercy", "film", "16+."],
      ["Breaking Bad", "series", "18+."],
      ["Better Call Saul", "series", "18+."],
      ["Money Heist", "series", "17+."],
      ["Peaky Blinders", "series", "18+."],
      ["Narcos", "series", "18+."],
      ["Ozark", "series", "18+."],
      ["Lupin", "series", "16+."],
      ["The Wire", "series", "18+."],
      ["Suits", "series", "16+."],
      ["How to Get Away with Murder", "series", "18+."],
      ["Prison Break", "series", "16+."],
      ["Mindhunter", "series", "18+."],
      ["The Night Agent", "series", "17+."],
      ["Kaleidoscope", "series", "17+."]
    ] },
    s_war: { label: "War & History", picks: [
      ["Saving Private Ryan", "film", "18+."],
      ["Dunkirk", "film", "14+."],
      ["1917", "film", "16+."],
      ["Hacksaw Ridge", "film", "18+. A medic who refused to carry a rifle."],
      ["Schindler's List", "film", "18+."],
      ["The Pianist", "film", "18+."],
      ["Braveheart", "film", "18+."],
      ["Gladiator", "film", "16+."],
      ["Hotel Rwanda", "film", "16+."],
      ["Blood Diamond", "film", "17+."],
      ["Lincoln", "film"],
      ["Darkest Hour", "film"],
      ["The King's Speech", "film"],
      ["All Quiet on the Western Front (2022)", "film", "18+."],
      ["The Zone of Interest", "film", "16+."],
      ["Band of Brothers", "series", "18+."],
      ["The Pacific", "series", "18+."],
      ["Chernobyl", "series", "18+."],
      ["Vikings", "series", "18+."],
      ["Rome", "series", "18+."],
      ["Shogun (2024)", "series", "18+."],
      ["Masters of the Air", "series", "17+."],
      ["Apocalypse Now", "film", "18+."],
      ["Full Metal Jacket", "film", "18+."],
      ["Black Hawk Down", "film", "18+."]
    ] },
    s_animation: { label: "Animation & Family", picks: [
      ["Toy Story", "film"],
      ["The Lion King", "film"],
      ["Finding Nemo", "film"],
      ["Up", "film", "The first ten minutes are a whole film."],
      ["Inside Out", "film", "The best explanation of emotions ever animated."],
      ["Coco", "film"],
      ["Soul", "film", "On finding your 'spark' — and what it isn't."],
      ["Wall-E", "film"],
      ["Ratatouille", "film"],
      ["Encanto", "film"],
      ["Moana", "film"],
      ["Zootopia", "film"],
      ["How to Train Your Dragon", "film"],
      ["Kung Fu Panda", "film"],
      ["Shrek", "film"],
      ["Spider-Man: Across the Spider-Verse", "film"],
      ["The Mitchells vs. the Machines", "film"],
      ["Klaus", "film"],
      ["Wolfwalkers", "film"],
      ["My Neighbor Totoro", "film"],
      ["Kiki's Delivery Service", "film", "A teenager moves to a new city and starts a business. Truly."],
      ["The Boy and the Heron", "film"],
      ["Arcane", "series", "16+. The best-looking animation on television."],
      ["Avatar: The Last Airbender", "series"],
      ["Iwájú", "series"]
    ] },
    s_music: { label: "Music, Dance & Performance", picks: [
      ["Whiplash", "film", "16+. Is greatness worth that? The film refuses to answer."],
      ["La La Land", "film"],
      ["Bohemian Rhapsody", "film", "13+."],
      ["A Star Is Born", "film", "18+."],
      ["The Greatest Showman", "film"],
      ["Sing Street", "film", "13+."],
      ["Step Up", "film"],
      ["Black Swan", "film", "18+."],
      ["Rocketman", "film", "18+."],
      ["Elvis", "film", "16+."],
      ["Straight Outta Compton", "film", "18+."],
      ["8 Mile", "film", "18+."],
      ["Amadeus", "film"],
      ["Soul", "film"],
      ["Coda", "film", "13+."],
      ["Hamilton", "film", "13+."],
      ["Homecoming (Beyoncé)", "film", "What preparation looks like at the top."],
      ["This Is It (Michael Jackson)", "film"],
      ["Your Lie in April", "anime"],
      ["Carole & Tuesday", "anime"],
      ["Blue Giant", "film", "Jazz, drawn."],
      ["Nana", "anime", "17+."],
      ["The Get Down", "series", "16+."],
      ["Pose", "series", "18+."],
      ["Rhythm + Flow", "series", "17+."]
    ] },
    s_dark: { adult: true, warn: "18+ ONLY. Adult content and heavy themes throughout — obsession, coercion, violence. Titles listed by name only.", label: "Dark Romance & Erotic Thriller (18+)", picks: [
      ["365 Days", "film", "18+. Widely criticised for its depiction of coercion."],
      ["Fifty Shades of Grey", "film", "18+."],
      ["After", "film", "18+."],
      ["Purple Hearts", "film", "16+."],
      ["The Idea of You", "film", "18+."],
      ["Gone Girl", "film", "18+."],
      ["Basic Instinct", "film", "18+."],
      ["Fatal Attraction", "film", "18+."],
      ["Eyes Wide Shut", "film", "18+."],
      ["Original Sin", "film", "18+."],
      ["You", "series", "18+. A stalker's inner monologue. Read it as a warning, not a romance."],
      ["Bridgerton", "series", "18+."],
      ["Outlander", "series", "18+."],
      ["Tell Me Lies", "series", "18+."],
      ["Obsession", "series", "18+."],
      ["Dark Desire", "series", "18+."],
      ["Elite", "series", "18+."],
      ["Sex/Life", "series", "18+."],
      ["The Idol", "series", "18+."],
      ["Killing Eve", "series", "18+."]
    ] }
  };
  var HOBBIES = [
    /* ── Music ── */
    { k: "guitar", n: "Guitar", c: "Music", w: "Four chords buys you a hundred songs and a room's attention.", s: "Learn G, C, D, Em. Play them until the change is clean, not fast." },
    { k: "piano", n: "Piano / Keyboard", c: "Music", w: "The instrument that teaches you music theory whether you meant to learn it or not.", s: "Major scale, both hands, one octave. Then one simple song." },
    { k: "produce", n: "Music Production", c: "Music", w: "Beats sell. BandLab and FL Studio Mobile run on a phone.", s: "Make one 30-second loop in BandLab. Finish it badly rather than not at all." },
    { k: "sing", n: "Singing", c: "Music", w: "Breath control and pitch are trainable. Almost nobody trains them.", s: "Ten minutes of daily scales. Record yourself weekly — you'll hate it, then you won't." },
    { k: "drums", n: "Drums / Percussion", c: "Music", w: "Timing is the one skill every other musician needs from you.", s: "Practise a single 4/4 pattern to a metronome for 10 minutes." },
    { k: "dj", n: "DJing", c: "Music", w: "Reading a crowd is a business skill disguised as a party skill.", s: "Learn beatmatching in a free app. Build one 20-minute set." },
    /* ── Code & Tech ── */
    { k: "python", n: "Python", c: "Code & Tech", w: "The most employable single skill on this list.", s: "Automate one boring thing — rename 100 files, scrape one page." },
    { k: "webdev", n: "Web Development", c: "Code & Tech", w: "HTML, CSS and JavaScript turn ideas into things strangers can use.", s: "Build a one-page site about yourself. Host it free on GitHub Pages." },
    { k: "appbuild", n: "App Building", c: "Code & Tech", w: "You are holding the device your customers use. Build for it.", s: "Ship one tiny PWA. This app is one — read its source." },
    { k: "gamedev", n: "Game Development", c: "Code & Tech", w: "Games teach systems thinking better than any textbook.", s: "Make Pong in Godot or Scratch. Finish it. Then make it worse on purpose to learn why." },
    { k: "data", n: "Data Analysis", c: "Code & Tech", w: "Everyone has data. Almost nobody can read it.", s: "Take any public CSV, load it in Google Sheets, answer three questions with it." },
    { k: "cyber", n: "Cybersecurity Basics", c: "Code & Tech", w: "Defence is a career. Attack is a crime. Learn the first.", s: "Do the free picoCTF beginner set. Never test on systems you don't own." },
    { k: "ai", n: "AI & Automation Building", c: "Code & Tech", w: "Not 'using ChatGPT'. Building tools with it that do work while you sleep.", s: "Automate one homework-adjacent task end to end. Document how." },
    /* ── Art & Design ── */
    { k: "sketch", n: "Sketching & Drawing", c: "Art & Design", w: "Drawing is seeing. It upgrades every visual skill after it.", s: "30 days, one page a day. Draw your own hand until it stops being wrong." },
    { k: "digitalart", n: "Digital Illustration", c: "Art & Design", w: "Commissions are the fastest teenage income on the internet.", s: "Krita is free on desktop, Ibis Paint on phone. Copy one piece you love, then change it." },
    { k: "graphic", n: "Graphic Design", c: "Art & Design", w: "Every business needs flyers, logos and decks. Most pay badly for bad ones.", s: "Rebuild one ugly local poster in Canva or Figma. Post the before/after." },
    { k: "3d", n: "3D Modelling", c: "Art & Design", w: "Blender is free and the industry uses it.", s: "Do the Blender donut tutorial. Everyone starts there for a reason." },
    { k: "photo", n: "Photography", c: "Art & Design", w: "Composition and light — a phone is enough to learn both.", s: "One subject, 30 photos, one keeper. Repeat weekly." },
    { k: "video", n: "Video Editing", c: "Art & Design", w: "The single most in-demand freelance skill for under-20s right now.", s: "CapCut on phone or DaVinci Resolve free on desktop. Cut a 60-second story." },
    { k: "animate", n: "Animation & Motion", c: "Art & Design", w: "Motion holds attention where a still image loses it.", s: "Animate a bouncing ball. Get the weight right before anything else." },
    /* ── Writing & Voice ── */
    { k: "write", n: "Creative Writing", c: "Writing & Voice", w: "Whoever tells the clearest story wins the room, the grant and the client.", s: "500 words a day for 14 days. Quality is not the target yet." },
    { k: "copy", n: "Copywriting", c: "Writing & Voice", w: "Writing that sells is a skill with a price list attached.", s: "Rewrite three product descriptions from a local shop. Send them free." },
    { k: "blog", n: "Blogging / Newsletter", c: "Writing & Voice", w: "A public body of work beats a CV nobody asked for.", s: "Publish once a week for a month on Substack or Medium. Same day, same time." },
    { k: "speak", n: "Public Speaking", c: "Writing & Voice", w: "The most reliable way to be over-estimated by adults.", s: "Record a 3-minute talk on your phone. Watch it. Do it again." },
    { k: "debate", n: "Debate", c: "Writing & Voice", w: "Trains you to argue the side you disagree with — which is how you find out what you actually think.", s: "Join or start a school club. Argue one motion from both sides in writing." },
    { k: "poetry", n: "Poetry & Spoken Word", c: "Writing & Voice", w: "Compression. Say it in twelve words instead of eighty.", s: "Write one poem a week. Perform one out loud, even alone." },
    /* ── Body & Mind ── */
    { k: "calis", n: "Calisthenics", c: "Body & Mind", w: "No gym fee, no equipment, no excuse.", s: "Push-ups, squats, plank. Add one rep per set per day." },
    { k: "run", n: "Running", c: "Body & Mind", w: "The clearest proof that boring repetition produces visible results.", s: "Couch-to-5K. Three runs a week, no heroics in week one." },
    { k: "martial", n: "Martial Arts", c: "Body & Mind", w: "Discipline you can feel. Also the fastest fix for posture and confidence.", s: "One trial class this month. Judo, boxing, taekwondo — whatever is walkable." },
    { k: "chess", n: "Chess", c: "Body & Mind", w: "Pattern recognition under pressure. Free, global, endless.", s: "Play 3 games a day on lichess.org and review every loss." },
    { k: "yoga", n: "Yoga & Mobility", c: "Body & Mind", w: "Protects the body that has to carry the career.", s: "15 minutes daily. Follow one free series start to finish." },
    { k: "swim", n: "Swimming", c: "Body & Mind", w: "A survival skill first, a training tool second.", s: "If you can't swim, that's the priority. Book lessons." },
    /* ── Money & Business ── */
    { k: "sell", n: "Selling Online", c: "Money & Business", w: "Nothing teaches business faster than one stranger paying you.", s: "List one thing this week. Price it. Handle the delivery yourself." },
    { k: "freelance", n: "Freelancing", c: "Money & Business", w: "Turns a hobby into an income without needing permission or capital.", s: "Pick one skill from this list. Do three free jobs, collect three testimonials, then charge." },
    { k: "content", n: "Content Creation", c: "Money & Business", w: "Attention is distribution, and distribution is leverage.", s: "Post 30 times in 30 days on one platform. Volume first, polish later." },
    { k: "invest", n: "Investing Literacy", c: "Money & Business", w: "Understanding compounding at 15 is worth more than earning at 25. Learning ≠ trading.", s: "Paper-trade only. Read one investing book before risking one cedi." },
    { k: "product", n: "Digital Product Design", c: "Money & Business", w: "Make it once, sell it a thousand times.", s: "Build one template, planner or preset pack. Sell it on Selar or Gumroad." },
    { k: "organise", n: "Event & Community Organising", c: "Money & Business", w: "The person who gathers people is never short of opportunities.", s: "Run one small event — study group, tournament, showcase. Twenty people is plenty." },
    /* ── Making & Craft ── */
    { k: "sew", n: "Sewing & Fashion Design", c: "Making & Craft", w: "Ghana's fashion market is real money and a real export.", s: "Learn to hand-sew a straight seam. Then alter one garment you own." },
    { k: "cook", n: "Cooking & Baking", c: "Making & Craft", w: "Feeds you, saves money, and sells at every school gate.", s: "Master five dishes properly rather than twenty badly." },
    { k: "wood", n: "Woodwork & DIY", c: "Making & Craft", w: "Physical making trains patience that screens erode.", s: "Build one small useful thing — a shelf, a stool, a phone stand." },
    { k: "electronics", n: "Electronics & Arduino", c: "Making & Craft", w: "Where code meets the physical world. Robotics starts here.", s: "Blink an LED. Then make it respond to something." },
    { k: "jewel", n: "Beadwork & Jewellery", c: "Making & Craft", w: "Low capital, high margin, and a craft with deep local roots.", s: "Make ten pieces. Give five away, sell five." },
    { k: "garden", n: "Gardening & Growing", c: "Making & Craft", w: "Patience with a visible scoreboard. Also food.", s: "Grow one pot of something edible from seed." },
    /* ── Language & Culture ── */
    { k: "lang", n: "A New Language", c: "Language & Culture", w: "French, Mandarin, Arabic or Spanish opens continents of scholarships and work.", s: "15 minutes daily on Duolingo or Anki. Same time every day." },
    { k: "sign", n: "Sign Language", c: "Language & Culture", w: "Rare, useful, and it makes you the person who can include someone.", s: "Learn the alphabet and 50 signs in Ghanaian or American Sign Language." },
    { k: "calligraphy", n: "Calligraphy & Lettering", c: "Language & Culture", w: "Trains precision and a steady hand — and it sells as art.", s: "One drill sheet a day for two weeks." },
    { k: "cultural", n: "Traditional Drumming & Dance", c: "Language & Culture", w: "Rhythm, fitness and a heritage worth carrying forward.", s: "Learn one traditional rhythm properly from someone who knows it." },
    { k: "mun", n: "Model UN & Diplomacy", c: "Language & Culture", w: "Research, argument and negotiation — plus it looks serious on applications.", s: "Join one conference. Read your country's position paper twice." },
    { k: "teach", n: "Tutoring & Teaching", c: "Language & Culture", w: "You do not understand a subject until you have taught it badly once.", s: "Teach one younger student one topic, free, for a month." }
  ];
  var COMPETITIONS = [
    /* ── Mathematics ── */
    { n: "International Mathematical Olympiad (IMO)", c: "Mathematics", o: "Pre-university, via national team", d: "The oldest and most prestigious school science olympiad in the world. You qualify through your country's national olympiad.", u: "imo-official.org" },
    { n: "Pan-African Mathematics Olympiad (PAMO)", c: "Mathematics", o: "African secondary students, national teams", d: "Africa's continental olympiad and the main route to IMO selection for many countries.", u: "africamathunion.org" },
    { n: "National Science & Maths Quiz (NSMQ)", c: "Mathematics", o: "Ghanaian SHS students", d: "Ghana's own televised contest. Winning it is a national profile and a scholarship magnet.", u: "primetimeltd.com" },
    { n: "Math Kangaroo (Kangourou sans Frontières)", c: "Mathematics", o: "Ages 7–18, 90+ countries", d: "The largest maths competition on earth by participation. Fun, accessible, a good first contest.", u: "aksf.org" },
    { n: "American Mathematics Competitions (AMC 8/10/12)", c: "Mathematics", o: "School-age, international sites available", d: "The entry point to the US olympiad pipeline. Recognised by admissions offices worldwide.", u: "maa.org/maa-invitational-competitions" },
    { n: "American Invitational Mathematics Examination (AIME)", c: "Mathematics", o: "Top AMC scorers", d: "The second round. Qualifying at all is a credential.", u: "maa.org" },
    { n: "Harvard-MIT Mathematics Tournament (HMMT)", c: "Mathematics", o: "High school teams, international", d: "Run by students at Harvard and MIT. November and February editions.", u: "hmmt.org" },
    { n: "Princeton University Mathematics Competition (PUMaC)", c: "Mathematics", o: "High school teams", d: "Team-based, high difficulty, strong international field.", u: "pumac.princeton.edu" },
    { n: "Stanford Math Tournament (SMT)", c: "Mathematics", o: "High school, in person and online", d: "Individual and team rounds hosted at Stanford.", u: "sumo.stanford.edu" },
    { n: "International Youth Math Challenge (IYMC)", c: "Mathematics", o: "Ages 14+, fully online", d: "Online rounds from anywhere, no national team required. Genuinely open entry.", u: "iymc.info" },
    { n: "Purple Comet! Math Meet", c: "Mathematics", o: "Middle and high school teams", d: "Free, online, team-based, worldwide.", u: "purplecomet.org" },
    { n: "Australian Mathematics Competition", c: "Mathematics", o: "Years 3–12, many countries", d: "One of the largest school maths competitions in the southern hemisphere.", u: "amt.edu.au" },
    { n: "UK Mathematics Trust Challenges", c: "Mathematics", o: "Junior, Intermediate, Senior", d: "Feeds the British Mathematical Olympiad. Open to international schools.", u: "ukmt.org.uk" },
    { n: "Singapore & Asian Schools Math Olympiad (SASMO)", c: "Mathematics", o: "Grades 2–12", d: "Widely used across Asia and Africa as a gateway contest.", u: "sasmo.sg" },
    { n: "CEMC Contests (Waterloo)", c: "Mathematics", o: "Grades 7–12 worldwide", d: "Cayley, Fermat, Euclid and more. Euclid results carry weight for Canadian admissions.", u: "cemc.uwaterloo.ca" },
    { n: "Alibaba Global Mathematics Competition", c: "Mathematics", o: "Open, all ages", d: "Free online qualifier with substantial prize money.", u: "damo.alibaba.com" },
    { n: "International Mathematical Modeling Challenge (IM2C)", c: "Mathematics", o: "School teams", d: "Teams model a real-world problem over several days. Closest thing to actual applied maths work.", u: "immchallenge.org" },
    { n: "Bebras International Challenge", c: "Mathematics", o: "Ages 8–19", d: "Computational thinking puzzles, no coding required. Runs in 50+ countries.", u: "bebras.org" },
    /* ── Science & Research ── */
    { n: "International Physics Olympiad (IPhO)", c: "Science & Research", o: "Pre-university, national teams", d: "Five students per country. Theory and experimental exams.", u: "ipho-unofficial.org" },
    { n: "International Chemistry Olympiad (IChO)", c: "Science & Research", o: "Pre-university, national teams", d: "Theory plus a full laboratory practical.", u: "ichosc.org" },
    { n: "International Biology Olympiad (IBO)", c: "Science & Research", o: "Pre-university, national teams", d: "Four students per country. Heavy on practical lab skill.", u: "ibo-info.org" },
    { n: "International Junior Science Olympiad (IJSO)", c: "Science & Research", o: "Under 16", d: "Physics, chemistry and biology combined. The best early start there is.", u: "ijsoweb.org" },
    { n: "International Olympiad on Astronomy & Astrophysics (IOAA)", c: "Science & Research", o: "Pre-university", d: "Theory, data analysis and a night observation round.", u: "ioaastrophysics.org" },
    { n: "International Earth Science Olympiad (IESO)", c: "Science & Research", o: "Secondary students", d: "Geology, meteorology, oceanography and astronomy.", u: "ieso-info.org" },
    { n: "International Geography Olympiad (iGeo)", c: "Science & Research", o: "Ages 16–19", d: "Written, multimedia and fieldwork exercises.", u: "geoolympiad.org" },
    { n: "International Linguistics Olympiad (IOL)", c: "Science & Research", o: "Secondary students", d: "You solve languages you have never seen using logic alone. No prior knowledge needed.", u: "ioling.org" },
    { n: "International Philosophy Olympiad (IPO)", c: "Science & Research", o: "Secondary students", d: "A four-hour essay in a language that is not your first.", u: "philosophy-olympiad.org" },
    { n: "International Economics Olympiad (IEO)", c: "Science & Research", o: "Secondary students", d: "Economics, finance and a business case round.", u: "ecolymp.org" },
    { n: "Regeneron International Science and Engineering Fair (ISEF)", c: "Science & Research", o: "Ages 14–18, via affiliated fairs", d: "The world's largest pre-college science competition. Millions in prizes; qualify through a national or regional affiliated fair.", u: "societyforscience.org/isef" },
    { n: "Stockholm Junior Water Prize", c: "Science & Research", o: "Ages 15–20", d: "National winners compete in Sweden with water and environment research.", u: "siwi.org" },
    { n: "EU Contest for Young Scientists (EUCYS)", c: "Science & Research", o: "Ages 14–20", d: "Europe's flagship young researcher contest; non-EU countries participate as guests.", u: "eucys.eu" },
    { n: "BT Young Scientist & Technology Exhibition", c: "Science & Research", o: "Second-level students", d: "Ireland's national fair with international guest entries.", u: "btyoungscientist.com" },
    { n: "Genius Olympiad", c: "Science & Research", o: "Ages 13–18", d: "Environment-focused across science, art, writing, business and robotics. Often carries university scholarship offers.", u: "geniusolympiad.org" },
    { n: "Breakthrough Junior Challenge", c: "Science & Research", o: "Ages 13–18", d: "Explain a big idea in physics, maths or life science in a video under three minutes. Prize includes a university scholarship.", u: "breakthroughjuniorchallenge.org" },
    { n: "MILSET Expo-Sciences International", c: "Science & Research", o: "Ages 12–25", d: "A global science expo rather than a ranked contest. Excellent first international exposure.", u: "milset.org" },
    { n: "The Earth Prize", c: "Science & Research", o: "Ages 13–19, teams", d: "Environmental innovation competition with mentoring built in.", u: "theearthprize.org" },
    { n: "iGEM Competition", c: "Science & Research", o: "High school and university teams", d: "Synthetic biology at the highest student level.", u: "igem.org" },
    /* ── Coding & Robotics ── */
    { n: "International Olympiad in Informatics (IOI)", c: "Coding & Robotics", o: "Pre-university, national teams", d: "The IMO of programming. Algorithms under exam conditions.", u: "ioinformatics.org" },
    { n: "FIRST Robotics Competition (FRC)", c: "Coding & Robotics", o: "Ages 14–18, school teams", d: "Six weeks to build a competition robot. Over $80m in scholarships is attached to the FIRST network.", u: "firstinspires.org" },
    { n: "FIRST Tech Challenge (FTC)", c: "Coding & Robotics", o: "Ages 12–18", d: "Smaller robots, smaller budget, same pipeline.", u: "firstinspires.org" },
    { n: "FIRST LEGO League", c: "Coding & Robotics", o: "Ages 4–16", d: "The best entry point into competitive robotics anywhere.", u: "firstlegoleague.org" },
    { n: "World Robot Olympiad (WRO)", c: "Coding & Robotics", o: "Ages 8–19", d: "Runs national rounds in 90+ countries including across Africa.", u: "wro-association.org" },
    { n: "RoboCupJunior", c: "Coding & Robotics", o: "Under 19", d: "Soccer, rescue and onstage leagues feeding the main RoboCup.", u: "junior.robocup.org" },
    { n: "VEX Robotics World Championship", c: "Coding & Robotics", o: "Elementary through university", d: "One of the largest robotics championships by team count.", u: "roboticseducation.org" },
    { n: "Pan-African Robotics Competition (PARC)", c: "Coding & Robotics", o: "African students", d: "Continental robotics championship built specifically for African schools.", u: "parcrobotics.org" },
    { n: "Technovation Girls", c: "Coding & Robotics", o: "Girls ages 8–18", d: "Build an app that solves a community problem, with mentorship. Runs in 100+ countries.", u: "technovationchallenge.org" },
    { n: "NASA International Space Apps Challenge", c: "Coding & Robotics", o: "All ages, worldwide hackathon", d: "48 hours on real NASA open data. Local hubs across Africa.", u: "spaceappschallenge.org" },
    { n: "picoCTF", c: "Coding & Robotics", o: "Students, free", d: "Carnegie Mellon's beginner-friendly cybersecurity competition. The legal way to learn hacking.", u: "picoctf.org" },
    { n: "Meta Hacker Cup", c: "Coding & Robotics", o: "Open, all ages", d: "Global competitive programming championship, fully online qualifiers.", u: "facebook.com/codingcompetitions" },
    { n: "Codeforces Rounds", c: "Coding & Robotics", o: "Open, free, year-round", d: "Not a one-off event — the training ground where competitive programmers actually get good.", u: "codeforces.com" },
    { n: "Kaggle Competitions", c: "Coding & Robotics", o: "Open, free", d: "Real machine-learning problems with real prize money and public leaderboards.", u: "kaggle.com" },
    { n: "Samsung Solve for Tomorrow", c: "Coding & Robotics", o: "School students, country-specific", d: "STEM-for-community competition running in many countries.", u: "samsung.com/solvefortomorrow" },
    { n: "Huawei ICT Competition", c: "Coding & Robotics", o: "University and some secondary", d: "Global finals in China with certification and prizes; strong African participation.", u: "huawei.com/ict-competition" },
    /* ── Business & Innovation ── */
    { n: "Diamond Challenge", c: "Business & Innovation", o: "High school, teams of 2–4", d: "University of Delaware's global high-school venture competition. Cash prizes, no fee in most regions.", u: "diamondchallenge.org" },
    { n: "Blue Ocean Student Entrepreneur Competition", c: "Business & Innovation", o: "High school, worldwide", d: "Fully virtual, pitch-video based, free to enter.", u: "blueoceancompetition.org" },
    { n: "Wharton Global Youth Investment Competition", c: "Business & Innovation", o: "Ages 14–18, teams", d: "Manage a simulated portfolio for a fictional client. Finals at Wharton.", u: "globalyouth.wharton.upenn.edu" },
    { n: "Anzisha Prize", c: "Business & Innovation", o: "African entrepreneurs aged 15–22", d: "Africa's premier award for very young entrepreneurs already running a business.", u: "anzishaprize.org" },
    { n: "Global Student Entrepreneur Awards (GSEA)", c: "Business & Innovation", o: "Students running a business", d: "EO's worldwide competition with national then global rounds.", u: "gsea.org" },
    { n: "Hult Prize", c: "Business & Innovation", o: "University students", d: "The largest student social-enterprise competition; the winning team takes $1m in seed funding.", u: "hultprize.org" },
    { n: "Enactus World Cup", c: "Business & Innovation", o: "University teams", d: "Social entrepreneurship projects judged on real measured impact.", u: "enactus.org" },
    { n: "Tony Elumelu Foundation Entrepreneurship Programme", c: "Business & Innovation", o: "African entrepreneurs 18+", d: "Seed capital plus training for thousands of African founders every year.", u: "tefconnect.com" },
    { n: "Africa Business Heroes", c: "Business & Innovation", o: "African entrepreneurs 18+", d: "Jack Ma Foundation prize competition with a large grant pool.", u: "africabusinessheroes.org" },
    { n: "MIT Solve Global Challenges", c: "Business & Innovation", o: "Open, any age", d: "Solution-focused challenges with funding and MIT mentorship.", u: "solve.mit.edu" },
    { n: "Junior Achievement Company of the Year", c: "Business & Innovation", o: "Secondary students", d: "Run a real student company for a year, then compete nationally and continentally.", u: "jaafrica.org" },
    { n: "Seedstars World Competition", c: "Business & Innovation", o: "Early-stage founders", d: "Emerging-market startup competition with regional rounds across Africa.", u: "seedstars.com" },
    { n: "Startup World Cup", c: "Business & Innovation", o: "Startups, 18+", d: "Regional finals worldwide, $1m investment prize.", u: "startupworldcup.io" },
    { n: "Youth Citizen Entrepreneurship Competition", c: "Business & Innovation", o: "Ages 15–35", d: "Ideas and existing projects tracked separately; global online voting.", u: "entrepreneurship-campus.org" },
    /* ── Writing, Debate & Speaking ── */
    { n: "The King's Commonwealth Essay Competition", c: "Writing & Debate", o: "Under 18, Commonwealth countries", d: "The world's oldest international schools writing competition — and Ghana is eligible. Free to enter.", u: "royalcwsociety.org" },
    { n: "John Locke Institute Essay Competition", c: "Writing & Debate", o: "Under 19", d: "Serious academic essays in seven subjects. Prizes include scholarship money toward Oxford summer programmes.", u: "johnlockeinstitute.com" },
    { n: "The Concord Review", c: "Writing & Debate", o: "Secondary students", d: "Publishes history research papers by high-schoolers. Publication is a genuine admissions credential.", u: "tcr.org" },
    { n: "New York Times Student Contests", c: "Writing & Debate", o: "Ages 13–19 worldwide", d: "Editorial, review, podcast, profile and photo contests through the year. Free.", u: "nytimes.com/section/learning" },
    { n: "Scholastic Art & Writing Awards", c: "Writing & Debate", o: "Grades 7–12 (US and some international)", d: "The oldest US youth arts recognition programme; alumni include Warhol and Plath.", u: "artandwriting.org" },
    { n: "Goi Peace Foundation International Essay Contest", c: "Writing & Debate", o: "Under 25, worldwide", d: "UNESCO-linked, free entry, open to any country.", u: "goipeace.or.jp" },
    { n: "Bow Seat Ocean Awareness Contest", c: "Writing & Debate", o: "Ages 11–18", d: "Art, film, poetry and prose on ocean issues. Generous prize pool.", u: "bowseat.org" },
    { n: "Foyle Young Poets of the Year Award", c: "Writing & Debate", o: "Ages 11–17 worldwide", d: "Free, prestigious, and open to every country.", u: "poetrysociety.org.uk" },
    { n: "Write the World Competitions", c: "Writing & Debate", o: "Ages 13–19", d: "Monthly prompts with peer review built in. Excellent for building a habit.", u: "writetheworld.org" },
    { n: "World Scholar's Cup", c: "Writing & Debate", o: "Ages 9–18", d: "Debate, writing, quiz and team rounds. Global round then Tournament of Champions at Yale.", u: "scholarscup.org" },
    { n: "World Schools Debating Championships (WSDC)", c: "Writing & Debate", o: "Under 20, national teams", d: "The world championship of school debating.", u: "wsdcdebate.org" },
    { n: "THIMUN", c: "Writing & Debate", o: "Secondary students", d: "The Hague International Model United Nations — the largest and most established MUN.", u: "thimun.org" },
    { n: "Harvard Model United Nations (HMUN)", c: "Writing & Debate", o: "Secondary students", d: "Boston and international editions including HMUN China and Dubai.", u: "hmun.org" },
    { n: "Yale Model United Nations (YMUN)", c: "Writing & Debate", o: "Secondary students", d: "Runs in New Haven plus YMUN Africa and YMUN Taiwan.", u: "ymun.yira.org" },
    { n: "ESU International Public Speaking Competition", c: "Writing & Debate", o: "Ages 16–20", d: "National winners speak in London. One of the few global speaking championships.", u: "esu.org" },
    { n: "Immerse Education Essay Competition", c: "Writing & Debate", o: "Ages 13–18", d: "Winners receive scholarships toward Cambridge and Oxford summer programmes.", u: "immerse.education" },
    /* ── Arts & Music ── */
    { n: "International Chopin Piano Competition", c: "Arts & Music", o: "Pianists roughly 16–30", d: "Held every five years in Warsaw. The most famous piano competition in existence.", u: "chopincompetition.pl" },
    { n: "Van Cliburn International Piano Competition", c: "Arts & Music", o: "Ages 18–30, plus a junior edition", d: "Career-making, with a dedicated competition for ages 13–17.", u: "cliburn.org" },
    { n: "Menuhin Competition", c: "Arts & Music", o: "Violinists under 22", d: "The leading international competition for young violinists.", u: "menuhincompetition.org" },
    { n: "International Tchaikovsky Competition", c: "Arts & Music", o: "Young professional musicians", d: "Piano, violin, cello, voice, winds and brass.", u: "tchaikovskycompetition.com" },
    { n: "BBC Young Musician", c: "Arts & Music", o: "Under 19, UK-resident", d: "Televised, career-launching. Check residency rules carefully.", u: "bbc.co.uk/youngmusician" },
    { n: "Youth America Grand Prix", c: "Arts & Music", o: "Dancers ages 9–19", d: "The largest student ballet scholarship competition in the world.", u: "yagp.org" },
    { n: "World Choir Games", c: "Arts & Music", o: "Choirs of all ages", d: "The largest choral competition on the planet, hosted in a different country each cycle.", u: "interkultur.com" },
    { n: "Toyota Dream Car Art Contest", c: "Arts & Music", o: "Under 15", d: "One of the biggest children's art competitions globally, with national rounds everywhere.", u: "toyota.com/dreamcarusa" },
    { n: "Doodle for Google", c: "Arts & Music", o: "School students, country-specific", d: "Design the Google homepage doodle. Prize includes an education award.", u: "doodles.google.com" },
    { n: "UNEP International Children's Painting Competition", c: "Arts & Music", o: "Ages 5–14", d: "UN Environment Programme's global environment art contest.", u: "unep.org" },
    { n: "Wildlife Photographer of the Year — Young", c: "Arts & Music", o: "Under 18", d: "Run by the Natural History Museum, London. Categories from age 10 and under.", u: "nhm.ac.uk/wpy" },
    { n: "Sony World Photography Awards — Youth & Student", c: "Arts & Music", o: "Youth under 20, students", d: "Free to enter, exhibited in London.", u: "worldphoto.org" },
    { n: "Adobe Design Achievement Awards", c: "Arts & Music", o: "Students", d: "Global student design and media awards judged by working professionals.", u: "adaa.adobe.com" },
    { n: "Berklee World Scholarship Tour Auditions", c: "Arts & Music", o: "Musicians applying to Berklee", d: "Audition in cities worldwide; scholarship offers are made on the spot.", u: "berklee.edu" },
    /* ── Global, Leadership & Sport ── */
    { n: "FIDE World Youth Chess Championship", c: "Global & Sport", o: "Age groups under 8 to under 18", d: "National federations nominate. Titles and norms are on the line.", u: "fide.com" },
    { n: "Youth Olympic Games", c: "Global & Sport", o: "Ages 15–18, national teams", d: "The IOC's youth edition, summer and winter.", u: "olympics.com" },
    { n: "ISF Gymnasiade / World School Championships", c: "Global & Sport", o: "School athletes 14–18", d: "The world championships for school sport across many disciplines.", u: "isfsports.org" },
    { n: "IESF World Esports Championship", c: "Global & Sport", o: "National esports teams", d: "The recognised world championship for national esports federations.", u: "iesf.org" },
    { n: "Zayed Sustainability Prize — Global High Schools", c: "Global & Sport", o: "Secondary schools worldwide", d: "Up to $150,000 per winning school to build a sustainability project. Africa is a dedicated region.", u: "zayedsustainabilityprize.com" },
    { n: "Children's Climate Prize", c: "Global & Sport", o: "Ages 12–17", d: "Swedish prize for young people already running a climate project.", u: "childrensclimateprize.org" },
    { n: "The Diana Award", c: "Global & Sport", o: "Ages 9–25", d: "Not a competition but a nomination-based humanitarian award, and a serious credential.", u: "diana-award.org.uk" },
    { n: "UNFCCC Global Youth Video Competition", c: "Global & Sport", o: "Ages 18–30", d: "Winners are funded to attend the UN climate conference.", u: "unfccc.int" },
    { n: "Ashoka Young Changemakers", c: "Global & Sport", o: "Ages 12–20", d: "A global fellowship for young social innovators, not a one-off prize.", u: "ashoka.org" }
  ];
  var SCHOLARSHIPS = [
    /* ── Africa-focused ── */
    { n: "Mastercard Foundation Scholars Program", c: "Africa-focused", o: "Academically strong African students with financial need", d: "Full cost of attendance — tuition, accommodation, travel, stipend — at partner universities in Africa and abroad. The single largest funded route out of the continent.", u: "mastercardfdn.org" },
    { n: "African Leadership Academy", c: "Africa-focused", o: "Ages 16–19, all African countries", d: "Two-year pre-university programme in Johannesburg, needs-blind with substantial financial aid.", u: "africanleadershipacademy.org" },
    { n: "Ashinaga Africa Initiative", c: "Africa-focused", o: "Sub-Saharan students who have lost one or both parents", d: "Full undergraduate funding abroad plus a preparatory year. Ghana is eligible.", u: "ashinaga.org" },
    { n: "Mandela Rhodes Scholarship", c: "Africa-focused", o: "African graduates under 30", d: "Fully funded postgraduate study in South Africa with a leadership programme attached.", u: "mandelarhodes.org" },
    { n: "Canon Collins Trust Scholarships", c: "Africa-focused", o: "Southern and East African students", d: "Postgraduate funding in the UK and southern Africa.", u: "canoncollins.org" },
    { n: "Zawadi Africa Education Fund", c: "Africa-focused", o: "African girls", d: "Undergraduate scholarships for young African women at partner universities.", u: "zawadiafrica.org" },
    { n: "Ashesi University Scholarships", c: "Africa-focused", o: "African students, Ghana-based campus", d: "Need-based aid up to full cost at one of Africa's strongest liberal arts and engineering universities.", u: "ashesi.edu.gh" },
    { n: "African Leadership University Scholarships", c: "Africa-focused", o: "African students", d: "Partial to full funding in Rwanda and Mauritius.", u: "alueducation.com" },
    { n: "Ghana Scholarships Secretariat", c: "Africa-focused", o: "Ghanaian students", d: "Government local and foreign scholarship schemes. Apply directly — never through an agent charging a fee.", u: "scholarshipgh.com" },
    { n: "GETFund Scholarships", c: "Africa-focused", o: "Ghanaian students", d: "Ghana Education Trust Fund awards for tertiary study at home and abroad.", u: "getfund.gov.gh" },
    /* ── Fully funded, government programmes ── */
    { n: "MEXT Japanese Government Scholarship", c: "Government programmes", o: "Undergraduate and postgraduate, most countries", d: "Tuition, monthly stipend, flights and a Japanese language year. Apply through the Japanese embassy.", u: "studyinjapan.go.jp" },
    { n: "Chinese Government Scholarship (CSC)", c: "Government programmes", o: "Undergraduate to PhD", d: "Full tuition, accommodation, stipend and medical insurance at hundreds of Chinese universities.", u: "campuschina.org" },
    { n: "Korean Government Scholarship Program (GKS)", c: "Government programmes", o: "Undergraduate and graduate", d: "Full funding plus a year of Korean language training.", u: "studyinkorea.go.kr" },
    { n: "Türkiye Bursları", c: "Government programmes", o: "Undergraduate to PhD", d: "Tuition, accommodation, stipend, flights and Turkish language year. One application, many universities.", u: "turkiyeburslari.gov.tr" },
    { n: "Open Doors — Russian Government Scholarship", c: "Government programmes", o: "Masters and PhD", d: "Tuition-free places awarded through an online olympiad.", u: "od.globaluni.ru" },
    { n: "Stipendium Hungaricum", c: "Government programmes", o: "All levels", d: "Hungary's government scheme: tuition, stipend, accommodation and insurance.", u: "stipendiumhungaricum.hu" },
    { n: "Chevening Scholarships", c: "Government programmes", o: "One-year UK masters, work experience required", d: "Fully funded UK masters for future leaders. Ghana has a dedicated allocation.", u: "chevening.org" },
    { n: "Commonwealth Scholarships", c: "Government programmes", o: "Commonwealth citizens, masters and PhD", d: "Fully funded UK study, with distance-learning options.", u: "cscuk.fcdo.gov.uk" },
    { n: "Fulbright Foreign Student Program", c: "Government programmes", o: "Graduate study in the USA", d: "Fully funded, applied through the US embassy in your country.", u: "foreign.fulbrightonline.org" },
    { n: "DAAD Scholarships", c: "Government programmes", o: "Mostly masters and PhD", d: "Germany's academic exchange service. Many German public universities also charge no tuition at all.", u: "daad.de" },
    { n: "Eiffel Excellence Scholarship", c: "Government programmes", o: "Masters and PhD in France", d: "French government funding; you must be nominated by the French institution.", u: "campusfrance.org" },
    { n: "Swedish Institute Scholarships for Global Professionals", c: "Government programmes", o: "Masters, with work experience", d: "Tuition, living costs, insurance and travel.", u: "si.se" },
    { n: "Orange Knowledge Programme / Holland Scholarship", c: "Government programmes", o: "Dutch institutions", d: "Netherlands government and university funding for non-EU students.", u: "studyinnl.org" },
    { n: "VLIR-UOS Scholarships", c: "Government programmes", o: "Masters and training in Belgium", d: "Fully funded programmes aimed at students from partner countries including Ghana.", u: "vliruos.be" },
    { n: "Australia Awards Scholarships", c: "Government programmes", o: "Developing-country citizens", d: "Full tuition, travel, stipend and health cover for Australian study.", u: "australiaawards.gov.au" },
    { n: "Manaaki New Zealand Scholarships", c: "Government programmes", o: "Selected developing countries", d: "Full funding for study in New Zealand.", u: "nzscholarships.govt.nz" },
    { n: "Erasmus Mundus Joint Masters", c: "Government programmes", o: "Masters, any nationality", d: "Study in two or more European countries, fully funded including travel and a monthly allowance.", u: "erasmus-plus.ec.europa.eu" },
    { n: "Taiwan ICDF Scholarship", c: "Government programmes", o: "Undergraduate to PhD", d: "Tuition, accommodation, insurance, flights and stipend.", u: "icdf.org.tw" },
    { n: "Singapore SINGA (A*STAR)", c: "Government programmes", o: "PhD in science and engineering", d: "Full PhD funding with a monthly stipend at NUS, NTU and SUTD.", u: "a-star.edu.sg/singa" },
    { n: "Brunei Darussalam Government Scholarship", c: "Government programmes", o: "Undergraduate and postgraduate", d: "Fully funded including airfare and allowances.", u: "mfa.gov.bn" },
    /* ── University and foundation awards ── */
    { n: "Rhodes Scholarship", c: "University & foundation", o: "Postgraduate at Oxford", d: "The oldest international graduate scholarship. West Africa is a designated constituency — Ghanaians can apply.", u: "rhodeshouse.ox.ac.uk" },
    { n: "Gates Cambridge Scholarship", c: "University & foundation", o: "Postgraduate at Cambridge", d: "Full cost plus family and fieldwork allowances.", u: "gatescambridge.org" },
    { n: "Clarendon Fund", c: "University & foundation", o: "Graduate study at Oxford", d: "Around 200 fully funded awards a year, considered automatically with your course application.", u: "ox.ac.uk/clarendon" },
    { n: "Knight-Hennessy Scholars", c: "University & foundation", o: "Any graduate programme at Stanford", d: "Full funding plus a leadership development programme.", u: "knight-hennessy.stanford.edu" },
    { n: "Schwarzman Scholars", c: "University & foundation", o: "Masters at Tsinghua, ages 18–28", d: "One year in Beijing, fully funded including a stipend and travel.", u: "schwarzmanscholars.org" },
    { n: "Yenching Academy of Peking University", c: "University & foundation", o: "Masters in China studies", d: "Fully funded interdisciplinary masters in Beijing.", u: "yenchingacademy.pku.edu.cn" },
    { n: "Lester B. Pearson International Scholarship", c: "University & foundation", o: "Undergraduate, University of Toronto", d: "Tuition, books, incidental fees and residence for four years. School nomination required.", u: "future.utoronto.ca" },
    { n: "McCall MacBain Scholarships", c: "University & foundation", o: "Masters and professional degrees at McGill", d: "Full tuition, living stipend and a leadership programme.", u: "mccallmacbainscholars.org" },
    { n: "Vanier Canada Graduate Scholarships", c: "University & foundation", o: "PhD in Canada", d: "Substantial annual funding for three years; nominated by the university.", u: "vanier.gc.ca" },
    { n: "UBC International Scholars Programs", c: "University & foundation", o: "Undergraduate at UBC", d: "Includes the Donald A. Wehrung award aimed at students from difficult circumstances.", u: "you.ubc.ca" },
    { n: "ETH Zurich Excellence Masters Scholarship", c: "University & foundation", o: "Masters in Switzerland", d: "Study and living costs at one of the world's top engineering universities.", u: "ethz.ch" },
    { n: "EPFL Excellence Fellowships", c: "University & foundation", o: "Masters in Switzerland", d: "Substantial fellowships awarded on academic merit.", u: "epfl.ch" },
    { n: "Geneva Excellence Masters Fellowships", c: "University & foundation", o: "Masters in science", d: "Full fellowship plus living allowance.", u: "unige.ch" },
    { n: "Sciences Po Émile Boutmy Scholarship", c: "University & foundation", o: "Non-EU undergraduate and masters", d: "France's leading political science institution, with need-based awards.", u: "sciencespo.fr" },
    { n: "Bocconi Merit and International Awards", c: "University & foundation", o: "Undergraduate and masters in Italy", d: "Tuition waivers and full scholarships based on merit and need.", u: "unibocconi.eu" },
    { n: "KU Leuven Science@Leuven Scholarship", c: "University & foundation", o: "Masters in science, Belgium", d: "Tuition and living support for international students.", u: "kuleuven.be" },
    { n: "Wageningen Africa Scholarship Programme", c: "University & foundation", o: "African students, masters", d: "Agriculture, food and environment programmes in the Netherlands.", u: "wur.nl" },
    { n: "University of Twente Scholarship", c: "University & foundation", o: "Masters, non-EU", d: "Merit-based awards for excellent international applicants.", u: "utwente.nl" },
    { n: "Radboud Scholarship Programme", c: "University & foundation", o: "Masters, non-EU", d: "Reduces tuition to a nominal fee and covers insurance and visa costs.", u: "ru.nl" },
    { n: "KAIST International Student Scholarship", c: "University & foundation", o: "Undergraduate and graduate, Korea", d: "Tuition waiver plus monthly stipend at Korea's leading science institute.", u: "kaist.ac.kr" },
    { n: "University of Tokyo PEAK Programme", c: "University & foundation", o: "Undergraduate taught in English", d: "MEXT-linked funding available for admitted students.", u: "u-tokyo.ac.jp" },
    { n: "NUS / NTU Undergraduate Scholarships", c: "University & foundation", o: "Undergraduate in Singapore", d: "Merit awards covering tuition and living allowances for international students.", u: "nus.edu.sg" },
    /* ── Development bank and multilateral ── */
    { n: "Joint Japan/World Bank Graduate Scholarship", c: "Multilateral", o: "Development-related masters, work experience required", d: "Full funding for professionals from developing countries.", u: "worldbank.org/scholarships" },
    { n: "ADB-Japan Scholarship Program", c: "Multilateral", o: "Masters in Asia-Pacific institutions", d: "Tuition, stipend, books, insurance and travel.", u: "adb.org" },
    { n: "Islamic Development Bank Scholarship", c: "Multilateral", o: "Member and Muslim-community countries", d: "Undergraduate to postdoctoral funding, including for Ghana.", u: "isdb.org" },
    { n: "OPEC Fund (OFID) Scholarship", c: "Multilateral", o: "Masters, developing countries", d: "Full funding for one masters student per year, worldwide competition.", u: "opecfund.org" },
    { n: "Aga Khan Foundation International Scholarship", c: "Multilateral", o: "Postgraduate", d: "50% grant, 50% loan for outstanding students from selected countries.", u: "akdn.org" },
    { n: "Rotary Peace Fellowships", c: "Multilateral", o: "Masters and certificate, peace and development", d: "Fully funded study at Rotary Peace Centres worldwide.", u: "rotary.org" },
    { n: "UWC (United World Colleges)", c: "Multilateral", o: "Ages 16–19, IB Diploma", d: "National committees select students for heavily or fully funded places at 18 campuses; Davis Scholars funding can follow to US universities.", u: "uwc.org" },
    { n: "Google Africa Scholarships", c: "Multilateral", o: "African learners", d: "Funded certificate and developer training tracks. Free skills, no degree required.", u: "grow.google/africa" }
  ];

  // system/src/data-v11.js
  var NEW_SCREEN_V11 = {
    s_drama: { label: "TV — Drama", picks: [
      ["Breaking Bad", "series", "A chemistry teacher's slow ruin. Watch what ambition without values does."],
      ["The Wire", "series", "Institutions, not villains. The most honest show about how systems fail."],
      ["Mad Men", "series", "Ambition, reinvention and the cost of the mask."],
      ["This Is Us", "series", "Family across three timelines. Bring tissues."],
      ["Succession", "series", "Power inside a family business. Brutal and very funny."],
      ["The Crown", "series", "Duty versus self, one decade at a time."],
      ["Friday Night Lights", "series", "Small-town pressure and one very good coach."],
      ["Six Feet Under", "series", "A family of undertakers on how to actually live."],
      ["The Sopranos", "series", "The show that made television serious."],
      ["Rectify", "series", "Quiet, slow, devastating. Patience pays."],
      ["Anne with an E", "series", "An orphan who refuses to be small."],
      ["When They See Us", "series", "Four episodes on the Central Park Five. Hard, necessary watching."],
      ["Blood & Water", "series", "Cape Town teen drama with real teeth."]
    ] },
    s_thriller: { label: "TV — Thriller & Suspense", picks: [
      ["Prison Break", "series", "One engineer, one blueprint, one absurd plan."],
      ["Money Heist", "series", "Preparation as a superpower."],
      ["Ozark", "series", "Every clever fix creates two new problems."],
      ["Homeland", "series", "Obsession and intelligence work."],
      ["Bodyguard", "series", "Six hours, no slack."],
      ["The Night Manager", "series", "Le Carré, beautifully filmed."],
      ["Behind Her Eyes", "series", "Do not read anything about it first."],
      ["You", "series", "A study in how charm hides rot."],
      ["Squid Game", "series", "Debt, desperation and the games people accept."],
      ["Dark", "series", "Time travel that actually holds together. Take notes."],
      ["The Fall", "series", "A procedural with unusual moral weight."],
      ["Broadchurch", "series", "Grief in a small town."]
    ] },
    s_medical: { label: "TV — Medical & Science", picks: [
      ["House M.D.", "series", "Differential diagnosis as detective work. Great for science students."],
      ["Grey's Anatomy", "series", "The long-running one. Start at season one."],
      ["The Good Doctor", "series", "Competence, prejudice and patience."],
      ["Scrubs", "series", "Funny, then unexpectedly moving."],
      ["ER", "series", "The show that set the template."],
      ["The Knick", "series", "Surgery in 1900. Not for the squeamish."],
      ["Chernobyl", "series", "What it costs when the truth is inconvenient. Five hours, unforgettable."],
      ["Cosmos: A Spacetime Odyssey", "series", "Sagan's baton, carried well."],
      ["Planet Earth II", "series", "The best-shot nature series ever made."],
      ["Our Planet", "series", "The same beauty, with the bill attached."],
      ["The Blue Planet", "series", "Two thirds of the world, filmed properly."],
      ["Life Story", "series", "Every animal's journey from birth to breeding."]
    ] },
    s_legal: { label: "TV — Law, Politics & Power", picks: [
      ["Suits", "series", "Ambition, mentorship and a fake law degree."],
      ["Better Call Saul", "series", "How a decent man talks himself into something else."],
      ["The Good Wife", "series", "Reinvention after public humiliation."],
      ["Damages", "series", "Law as bare-knuckle strategy."],
      ["The West Wing", "series", "Government at its most idealistic. Aspirational, not documentary."],
      ["Yes, Minister", "series", "How bureaucracies really behave. Still accurate."],
      ["Borgen", "series", "Danish coalition politics. Better than it sounds."],
      ["House of Cards", "series", "Ambition without a floor."],
      ["The Newsroom", "series", "Idealism about journalism, argued loudly."],
      ["Silk", "series", "The barrister's grind."],
      ["Making a Murderer", "series", "What due process looks like when it bends."],
      ["13th", "film", "Ava DuVernay on the prison system and the amendment behind it."]
    ] },
    s_family: { label: "TV — Family & Growing Up", picks: [
      ["Avatar: The Last Airbender", "series", "Mastery, humility and war, in a children's show. Genuinely great."],
      ["Stranger Things", "series", "Friendship as the actual superpower."],
      ["The Mandalorian", "series", "Duty, quietly."],
      ["Gilmore Girls", "series", "Fast talk, small town, big ambitions."],
      ["Malcolm in the Middle", "series", "Chaos, affection and no money."],
      ["Modern Family", "series", "Three households, one long joke."],
      ["Young Sheldon", "series", "Being the odd, clever one."],
      ["Never Have I Ever", "series", "Grief, ambition and being sixteen."],
      ["Heartstopper", "series", "Gentle, and rare for being gentle."],
      ["Sex Education", "series", "Frank, funny and kinder than its title suggests. Older teens."],
      ["The Queen's Gambit", "series", "Obsession, chess and getting back up."],
      ["Derry Girls", "series", "Teenagers being idiots during the Troubles."]
    ] },
    s_history: { label: "TV — History & Biography", picks: [
      ["Band of Brothers", "series", "Easy Company, from training to Germany."],
      ["The Pacific", "series", "The other theatre, no less brutal."],
      ["Vikings", "series", "Ambition on longships."],
      ["Rome", "series", "The republic falling, from the ranks up."],
      ["Peaky Blinders", "series", "Strategy, family and postwar Birmingham."],
      ["The Last Kingdom", "series", "Divided loyalties, well told."],
      ["Shogun", "series", "Feudal Japan and the cost of being useful."],
      ["Roots", "series", "Still the standard."],
      ["The Men Who Built America", "series", "Ruthless industrialists, honestly framed."],
      ["Africa's Great Civilisations", "series", "Gates on a history schools skip."],
      ["Apollo 11", "film", "Only archive footage. Somehow that makes it bigger."],
      ["The Century of the Self", "series", "Curtis on how desire got engineered."]
    ] },
    s_espionage: { label: "TV — Spies & Investigation", picks: [
      ["Slow Horses", "series", "Failed spies, dry as sand."],
      ["The Americans", "series", "A marriage as cover, and then not."],
      ["Killing Eve", "series", "Two obsessions circling."],
      ["Spooks", "series", "Fast, disposable, addictive."],
      ["Tinker Tailor Soldier Spy", "film", "Patience as tradecraft."],
      ["Mindhunter", "series", "The birth of criminal profiling."],
      ["Sherlock", "series", "Deduction as performance art."],
      ["True Detective", "series", "Season one especially."],
      ["Line of Duty", "series", "Interview scenes as blood sport."],
      ["Unbelievable", "series", "Two detectives who actually listen."],
      ["The Sinner", "series", "Why, not who."],
      ["Luther", "series", "London, and a man losing the line."]
    ] },
    s_reality: { label: "TV — Competition & Craft", picks: [
      ["MasterChef", "series", "Skill under a clock."],
      ["The Great British Bake Off", "series", "Kindness as a format."],
      ["Chef's Table", "series", "Obsession, plated. Every episode is a masterclass in mastery."],
      ["Abstract: The Art of Design", "series", "How designers actually think."],
      ["The Last Dance", "series", "Jordan's final season, and what winning costs."],
      ["Drive to Survive", "series", "Engineering, ego and margins."],
      ["Shark Tank", "series", "Pitching, valuation and rejection in public."],
      ["The Apprentice (UK)", "series", "Watch for the mistakes, not the winners."],
      ["Making the Cut", "series", "Design under commercial pressure."],
      ["Blown Away", "series", "Glassblowing. Unexpectedly gripping."],
      ["The Repair Shop", "series", "Craft, patience and small kindnesses."],
      ["Is It Cake?", "series", "Nonsense. Watch it after exams."]
    ] }
  };
  var MORE_BOOKS_V11 = {
    study: [],
    discipline: [
      ["The 5 AM Club", "Robin Sharma"],
      ["Make It Stick", "Peter Brown, Henry Roediger & Mark McDaniel", "How learning actually sticks. Read this before your next revision cycle."],
      ["A Mind for Numbers", "Barbara Oakley", "Written for people who think they're bad at maths."],
      ["Ultralearning", "Scott Young", "How he did MIT's CS curriculum in twelve months."],
      ["How to Become a Straight-A Student", "Cal Newport"],
      ["Limitless", "Jim Kwik"],
      ["The Bullet Journal Method", "Ryder Carroll"],
      ["Four Thousand Weeks", "Oliver Burkeman", "The anti-productivity book. You will not get it all done."]
    ],
    psychology: [
      ["Emotional Intelligence", "Daniel Goleman"],
      ["Quiet", "Susan Cain", "For everyone told to speak up more."],
      ["Man's Search for Meaning", "Viktor Frankl", "Written by a survivor. Short, and it rearranges you."],
      ["The Body Keeps the Score", "Bessel van der Kolk"],
      ["Predictably Irrational", "Dan Ariely"],
      ["Nudge", "Richard Thaler & Cass Sunstein"],
      ["Stumbling on Happiness", "Daniel Gilbert"]
    ],
    tech: [
      ["Automate the Boring Stuff with Python", "Al Sweigart", "Free online. Start here if you have never coded."],
      ["Python Crash Course", "Eric Matthes"],
      ["Eloquent JavaScript", "Marijn Haverbeke", "Also free online."],
      ["Clean Code", "Robert C. Martin"],
      ["The Pragmatic Programmer", "Andrew Hunt & David Thomas"],
      ["Grokking Algorithms", "Aditya Bhargava", "Algorithms with pictures. Actually readable."],
      ["Code", "Charles Petzold", "How a computer works, from light switches up."]
    ],
    african: [
      ["Things Fall Apart", "Chinua Achebe"],
      ["Half of a Yellow Sun", "Chimamanda Ngozi Adichie"],
      ["Purple Hibiscus", "Chimamanda Ngozi Adichie"],
      ["Americanah", "Chimamanda Ngozi Adichie"],
      ["The Beautyful Ones Are Not Yet Born", "Ayi Kwei Armah", "Ghana after independence, unsparing."],
      ["Changes: A Love Story", "Ama Ata Aidoo"],
      ["Our Sister Killjoy", "Ama Ata Aidoo"],
      ["Faceless", "Amma Darko"],
      ["Homegoing", "Yaa Gyasi", "Two sisters, two continents, three hundred years."],
      ["Transcendent Kingdom", "Yaa Gyasi"],
      ["The Housemaid", "Amma Darko"],
      ["Nervous Conditions", "Tsitsi Dangarembga"],
      ["A Grain of Wheat", "Ngũgĩ wa Thiong'o"],
      ["So Long a Letter", "Mariama Bâ"],
      ["The Palm-Wine Drinkard", "Amos Tutuola"],
      ["Dear Ijeawele", "Chimamanda Ngozi Adichie"]
    ]
  };
  var MORE_SCREEN_V11 = {
    s_docs: [
      ["Free Solo", "film", "Preparation, fear and one wall."],
      ["Icarus", "film", "A cycling experiment that turns into a doping scandal."],
      ["My Octopus Teacher", "film", "Patience, filmed."],
      ["Jiro Dreams of Sushi", "film", "Sixty years on one skill."],
      ["The Social Dilemma", "film", "Watch it, then check your screen time."],
      ["Won't You Be My Neighbor?", "film", "On being kind, deliberately."],
      ["Searching for Sugar Man", "film", "An unbelievable true story, told carefully."],
      ["Man on Wire", "film", "Preparation as art."]
    ],
    s_biz: [
      ["The Founder", "film", "How McDonald's was actually taken."],
      ["The Big Short", "film", "2008, explained with jokes."],
      ["Moneyball", "film", "Data beating instinct."],
      ["Steve Jobs", "film", "Three product launches, one difficult man."],
      ["The Playlist", "series", "Spotify from six points of view."],
      ["WeCrashed", "series", "Charisma without accounting."],
      ["The Dropout", "series", "Theranos, and how far a story can travel."],
      ["Super Pumped", "series", "Uber's growth-at-all-costs years."]
    ]
  };

  // system/src/skills.js
  var SKILLS = [
    /* ───────────── TIER I — levels 2-9 ───────────── */
    {
      id: "sprint",
      name: "Sprint",
      lvl: 2,
      cost: 1,
      branch: "warrior",
      type: "passive",
      desc: "Every quest you clear pays 5% more XP. Small edge, applied a thousand times.",
      eff: { xp: { all: 1.05 } }
    },
    {
      id: "iron_will",
      name: "Iron Will",
      lvl: 3,
      cost: 1,
      branch: "warrior",
      type: "passive",
      desc: "Penalty XP losses are cut by 25%. The penalty quest still lands — you just bleed less.",
      eff: { penaltyCut: 0.25 }
    },
    {
      id: "bookworm",
      name: "Bookworm",
      lvl: 4,
      cost: 1,
      branch: "scholar",
      type: "passive",
      desc: "Finishing a book pays 50% more. Reading is the cheapest advantage on earth.",
      eff: { xp: { book: 1.5 } }
    },
    {
      id: "gate_open",
      name: "Gate Sense",
      lvl: 5,
      cost: 1,
      branch: "monarch",
      type: "unlock",
      desc: "The link is automatic from level 1. This widens it: instead of one shelf topped up per session, the System sweeps every shelf you have chosen, in one go.",
      eff: { feature: "online" }
    },
    {
      id: "early_riser",
      name: "Dawn Strike",
      lvl: 6,
      cost: 1,
      branch: "warrior",
      type: "passive",
      desc: "Any quest cleared before 08:00 pays 20% more. The morning is where the gap opens.",
      eff: { xpBefore: { hour: 8, mult: 1.2 } }
    },
    {
      id: "rewind",
      name: "Rewind",
      lvl: 8,
      cost: 2,
      branch: "monarch",
      type: "active",
      desc: "Restore a streak the System terminated. Once every 14 days — it is mercy, not a loophole.",
      eff: { active: { cooldownDays: 14, action: "restoreStreak" } }
    },
    /* ───────────── TIER II — levels 10-19 ───────────── */
    {
      id: "mana_flow",
      name: "Mana Flow",
      lvl: 10,
      cost: 2,
      branch: "monarch",
      type: "passive",
      desc: "All XP up 10%. The tide lifts everything.",
      eff: { xp: { all: 1.1 } }
    },
    {
      id: "night_owl",
      name: "Night Vigil",
      lvl: 11,
      cost: 1,
      branch: "scholar",
      type: "passive",
      desc: "Quests cleared after 20:00 pay 15% more. For the ones who study when the house goes quiet.",
      eff: { xpAfter: { hour: 20, mult: 1.15 } }
    },
    {
      id: "ward_deep",
      name: "Ward Protocol",
      lvl: 12,
      cost: 1,
      branch: "craft",
      type: "unlock",
      desc: "Unlocks deep inspection in the Ward — byte-level file checks, archive-bomb detection and quarantine controls.",
      eff: { feature: "warddeep" }
    },
    {
      id: "scholar",
      name: "Scholar",
      lvl: 14,
      cost: 2,
      branch: "scholar",
      type: "passive",
      desc: "Study quests pay 25% more. The System rewards the work that compounds.",
      eff: { xp: { study: 1.25 } }
    },
    {
      id: "overdrive",
      name: "Overdrive",
      lvl: 15,
      cost: 2,
      branch: "warrior",
      type: "active",
      desc: "Double XP for the next three hours. Once every 3 days. Fire it on a day you intend to destroy.",
      eff: { active: { cooldownDays: 3, action: "overdrive", hours: 3, mult: 2 } }
    },
    {
      id: "forge_master",
      name: "Forge Master",
      lvl: 16,
      cost: 1,
      branch: "craft",
      type: "passive",
      desc: "Hobby practice in the Forge pays 50% more. Skills you build for fun still make you dangerous.",
      eff: { xp: { hobby: 1.5 } }
    },
    {
      id: "steady_hand",
      name: "Steady Hand",
      lvl: 18,
      cost: 1,
      branch: "warrior",
      type: "passive",
      desc: "Training quests pay 20% more. The body carries the mind.",
      eff: { xp: { body: 1.2 } }
    },
    /* ───────────── TIER III — levels 20-39 ───────────── */
    {
      id: "ironclad",
      name: "Ironclad",
      lvl: 20,
      cost: 3,
      branch: "warrior",
      type: "passive",
      desc: "Your streak survives one missed day per week. One. Do not build a life on it.",
      eff: { shield: 1 }
    },
    {
      id: "archivist",
      name: "Archivist",
      lvl: 22,
      cost: 2,
      branch: "craft",
      type: "unlock",
      desc: "Unlocks Armory auto-sorting profiles: save a subject map, re-sort any new drop in seconds.",
      eff: { feature: "armoryprofiles" }
    },
    {
      id: "sanctuary",
      name: "Sanctuary",
      lvl: 24,
      cost: 3,
      branch: "monarch",
      type: "active",
      desc: "Clear every pending penalty at once. Once every 10 days. Use it to restart, not to escape.",
      eff: { active: { cooldownDays: 10, action: "clearPenalties" } }
    },
    {
      id: "deep_diver",
      name: "Deep Dive",
      lvl: 26,
      cost: 2,
      branch: "scholar",
      type: "passive",
      desc: "Completed focus sessions pay 30% more. Depth beats duration.",
      eff: { xp: { focus: 1.3 } }
    },
    {
      id: "domain",
      name: "Domain Expansion",
      lvl: 28,
      cost: 3,
      branch: "scholar",
      type: "active",
      desc: "For 60 minutes, focus-session XP is tripled. Once every 5 days.",
      eff: { active: { cooldownDays: 5, action: "domain", hours: 1, mult: 3 } }
    },
    {
      id: "polymath",
      name: "Polymath",
      lvl: 30,
      cost: 3,
      branch: "monarch",
      type: "passive",
      desc: "All XP up a further 15%. You are no longer specialising — you are stacking.",
      eff: { xp: { all: 1.15 } }
    },
    {
      id: "unbroken",
      name: "Unbroken",
      lvl: 34,
      cost: 3,
      branch: "warrior",
      type: "passive",
      desc: "Penalty XP losses cut by half. Failure costs you less because you fail less.",
      eff: { penaltyCut: 0.5 }
    },
    {
      id: "librarian",
      name: "Grand Librarian",
      lvl: 36,
      cost: 2,
      branch: "craft",
      type: "unlock",
      desc: "Raises the Online Gate fetch ceiling from 150 to 450 titles per shelf.",
      eff: { feature: "shelf450" }
    },
    /* ───────────── TIER IV — levels 40+ ───────────── */
    {
      id: "ruler",
      name: "Ruler's Authority",
      lvl: 40,
      cost: 4,
      branch: "monarch",
      type: "passive",
      desc: "All XP up a further 25%.",
      eff: { xp: { all: 1.25 } }
    },
    {
      id: "strategist",
      name: "Strategist",
      lvl: 45,
      cost: 3,
      branch: "scholar",
      type: "passive",
      desc: "Mind quests — planning, building, learning — pay 40% more.",
      eff: { xp: { mind: 1.4 } }
    },
    {
      id: "monarch",
      name: "Shadow Monarch",
      lvl: 50,
      cost: 5,
      branch: "monarch",
      type: "passive",
      desc: "All XP up a further 40%, and every level from here grants 2 skill points instead of 1.",
      eff: { xp: { all: 1.4 }, slots: 1 }
    },
    {
      id: "relentless",
      name: "Relentless",
      lvl: 60,
      cost: 4,
      branch: "warrior",
      type: "passive",
      desc: "Discipline quests pay 50% more. At this level the habit is the identity.",
      eff: { xp: { discipline: 1.5 } }
    },
    {
      id: "sovereign",
      name: "Sovereign",
      lvl: 70,
      cost: 5,
      branch: "monarch",
      type: "passive",
      desc: "All XP up a further 60%.",
      eff: { xp: { all: 1.6 } }
    },
    {
      id: "architect",
      name: "Architect",
      lvl: 80,
      cost: 5,
      branch: "craft",
      type: "passive",
      desc: "Hobby and focus XP doubled. You build things now, not just habits.",
      eff: { xp: { hobby: 2, focus: 2 } }
    },
    {
      id: "army",
      name: "Army of Shadows",
      lvl: 90,
      cost: 6,
      branch: "monarch",
      type: "passive",
      desc: "All XP doubled. The final passive. Nothing you do is small any more.",
      eff: { xp: { all: 2 } }
    }
  ];
  var BRANCHES = {
    scholar: { label: "Scholar", glyph: "✦", blurb: "Study, reading, focus." },
    warrior: { label: "Warrior", glyph: "⚔", blurb: "Training, streaks, resistance." },
    monarch: { label: "Monarch", glyph: "◈", blurb: "Raw XP, mercy skills, the gate." },
    craft: { label: "Craft", glyph: "⛭", blurb: "Hobbies, the Armory, the Ward." }
  };
  function skillById(id) {
    return SKILLS.find((s) => s.id === id) || null;
  }
  function nextSkillAfter(lvl) {
    return SKILLS.filter((s) => s.lvl > lvl).sort((a, b) => a.lvl - b.lvl)[0] || null;
  }
  function pointsEarned(lvl, learned) {
    let pts = Math.max(0, lvl - 1);
    (learned || []).forEach((id) => {
      const s = skillById(id);
      if (s && s.eff && s.eff.slots) pts += Math.max(0, lvl - s.lvl) * s.eff.slots;
    });
    return pts;
  }
  function pointsSpent(learned) {
    return (learned || []).reduce((n, id) => n + ((skillById(id) || {}).cost || 0), 0);
  }

  // system/src/entry.js
  var BRIDGE = {
    /* core */
    SYSTEM_EVENTS,
    Bus,
    Hooks,
    SCHEMA,
    Store: Store2,
    Log,
    /* kernel — 70 classic scripts still read these as bare globals */
    $,
    $$,
    pad,
    todayKey,
    dateFromKey,
    DEFAULT_AVATAR,
    load,
    save,
    H,
    SYSTEM_READY,
    Armory,
    /* seeds, quotes and the wall — only the names classic scripts still read.
       ALLD, QUOTES, WALL, wallI, wallTimer, wallStep and wallAuto are internal to
       their own modules now and are deliberately NOT republished: a name on the
       bridge that nothing consumes is a name that never comes off it. */
    WD,
    founderSeed,
    founderDeadlines,
    CURRICULA,
    seedQuests,
    uid,
    renderQuote,
    renderWall,
    /* domain — shared with the server */
    xpNeeded,
    planForBudget,
    estimateMinutes,
    TIER_RANK,
    /* content */
    BALANCE,
    GENRES,
    SCREEN,
    TOOLS,
    CAREERS,
    GATE,
    /* app */
    SYSTEM_VERSION,
    SYSTEM_CACHE,
    systemBuild,
    setTheme,
    /* data */
    LORE,
    MORE_BOOKS,
    NEW_GENRES,
    MORE_SCREEN,
    NEW_SCREEN,
    HOBBIES,
    COMPETITIONS,
    SCHOLARSHIPS,
    NEW_SCREEN_V11,
    MORE_BOOKS_V11,
    MORE_SCREEN_V11,
    SKILLS,
    BRANCHES,
    skillById,
    nextSkillAfter,
    pointsEarned,
    pointsSpent
  };
  for (const [name, value] of Object.entries(BRIDGE)) globalThis[name] = value;
  Object.defineProperty(globalThis, "DB", {
    configurable: true,
    get() {
      return DB2;
    }
  });
  globalThis.ASCEND = Object.freeze({
    replayProgression,
    version: SYSTEM_VERSION
  });
  globalThis.__ASCEND_BRIDGE__ = Object.keys(BRIDGE);
})();
