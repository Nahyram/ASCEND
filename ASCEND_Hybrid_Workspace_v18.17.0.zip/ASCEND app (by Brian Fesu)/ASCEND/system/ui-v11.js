/* ══════════════════════════════════════════════════════════════════
   THE SYSTEM — v11/v12 WIRING
   Loaded after the main script, so it can see $, esc, H(), save(),
   toast(), takeover(), grantXp, GENRES, SCREEN and the rest.

   Sections
     1  hunter state migration
     2  skill engine  (multipliers, unlocks, actives, respec)
     3  the Armory    (intake, index, browse, open)
     4  the Ward      (quarantine list, deep scan, self-test)
     5  the Gate      (v12: the automatic link, background shelf growth, cache)
   ══════════════════════════════════════════════════════════════════ */
(function(){
"use strict";
if(typeof H !== "function") return;

const A = window.Armory, N = window.Net;

/* ════════════════ 1 · STATE ════════════════ */

function migrate(h){
  if(!h) return null;
  h.skills      = Array.isArray(h.skills) ? h.skills : [];
  h.skillState  = h.skillState  || {};      /* id → {usedAt} */
  h.buffs       = h.buffs       || {};      /* action → {until, mult} */
  h.shieldWeek  = h.shieldWeek  || {};      /* isoWeek → uses */
  h.armory      = h.armory      || null;    /* small summary; full index in IndexedDB */
  h.gate        = h.gate        || { open:true, tmdb:"", guard:"auto" };
  /* v12: the link is automatic. A hunter created under v11 carried
     open:false and a guard value that meant "only when I press a button".
     Both are lifted once, and only once — if the hunter turns the link off
     after this, it stays off. */
  if(!h.gate.v12){
    h.gate.v12   = true;
    h.gate.open  = true;
    h.gate.guard = "auto";
  }
  h.shelfGrown  = h.shelfGrown  || {};
  return h;
}
migrate(H());

const isoWeek = (d = new Date()) => {
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  t.setUTCDate(t.getUTCDate() + 4 - (t.getUTCDay() || 7));
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return t.getUTCFullYear() + "-W" + Math.ceil(((t - y0) / 86400000 + 1) / 7);
};
const days = ms => ms / 86400000;

/* ════════════════ 2 · SKILL ENGINE ════════════════ */

function learned(){ const h = H(); return (h && h.skills) || []; }
function has(id){ return learned().includes(id); }
function available(){ const h = H(); return SKILLS.filter(s => h.level >= s.lvl); }

function pts(){
  const h = H();
  return { earned: pointsEarned(h.level, h.skills), spent: pointsSpent(h.skills) };
}
function free(){ const p = pts(); return p.earned - p.spent; }

/* — multipliers — */
function xpMult(ctx){
  const h = H(); if(!h) return 1;
  let m = 1;
  const now = new Date(), hr = now.getHours();
  learned().forEach(id => {
    const s = skillById(id); if(!s || !s.eff) return;
    const e = s.eff;
    if(e.xp){
      if(e.xp.all) m *= e.xp.all;
      if(ctx && e.xp[ctx]) m *= e.xp[ctx];
    }
    if(e.xpBefore && hr < e.xpBefore.hour) m *= e.xpBefore.mult;
    if(e.xpAfter  && hr >= e.xpAfter.hour) m *= e.xpAfter.mult;
  });
  /* timed actives */
  Object.entries(h.buffs || {}).forEach(([k, b]) => {
    if(!b || Date.now() > b.until) return;
    if(k === "domain" && ctx !== "focus") return;
    m *= b.mult;
  });
  return m;
}
window.skillPenaltyMult = function(){
  let cut = 0;
  learned().forEach(id => { const s = skillById(id); if(s && s.eff && s.eff.penaltyCut) cut = Math.max(cut, s.eff.penaltyCut); });
  return 1 - cut;
};
window.skillShieldAbsorbs = function(dayKey){
  const h = H(); if(!h) return false;
  let shield = 0;
  learned().forEach(id => { const s = skillById(id); if(s && s.eff && s.eff.shield) shield += s.eff.shield; });
  if(!shield) return false;
  const wk = isoWeek(typeof dateFromKey === "function" ? dateFromKey(dayKey) : new Date(dayKey));
  const used = h.shieldWeek[wk] || 0;
  if(used >= shield) return false;
  h.shieldWeek[wk] = used + 1;
  setTimeout(() => toast("Ironclad held", "One missed day absorbed. The streak stands. You get " + (shield - used - 1) + " more this week.", "gold"), 900);
  return true;
};

/* — wrap grantXp: multiplier in, unlock notice out — */
Hooks.wrap("grantXp", "skill multiplier", function(_grantXp, n, why, ctx){
  const h = H();
  const before = h ? h.level : 0;
  const mult = xpMult(ctx);
  const amt = Math.max(1, Math.round(n * mult));
  _grantXp(amt, why);
  if(h && h.level > before) announceUnlocks(before, h.level);
  if(mult > 1.001 && amt - n >= 5) toast("Skills active", "+" + (amt - n) + " bonus XP (×" + mult.toFixed(2) + ").");
});

function announceUnlocks(from, to){
  const fresh = SKILLS.filter(s => s.lvl > from && s.lvl <= to);
  if(!fresh.length) return;
  setTimeout(() => {
    takeover({
      kind:"unlock",
      title: fresh.length > 1 ? fresh.length + " SKILLS UNLOCKED" : "SKILL UNLOCKED",
      sub: fresh.map(s => "[" + s.name + "] — " + s.desc).join("\n\n"),
      reward: "Grow → Skills. You have " + free() + " skill point" + (free() === 1 ? "" : "s") + " to spend.",
      actions: [
        { label:"Open the tree", cls:"btn gold", fn: () => { closeTakeover(); gotoSkills(); } },
        { label:"Later", cls:"btn ghost", fn: closeTakeover }
      ]
    });
  }, 1400);
}
function closeTakeover(){ const t = $("#takeover"); if(t) t.classList.add("hidden"); }
/* v18: this used to be a second, stale gotoSkills declared inside this IIFE. It
   clicked #nav [data-tab="status"] and #tab-status .segbar — both renamed by the
   Phase 12 consolidation, so id="tab-status" appears zero times in index.html.
   app/wiring.js has carried the corrected version since v13, but a function
   declared inside this IIFE shadows the global at every call site in this file,
   so "Open the tree" in the skill-unlock takeover closed the modal and did
   nothing. The duplicate-global guard cannot see this: it is not a duplicate
   global, it is a local shadowing one. Removed, so the call falls through to
   app/wiring.js. */

/* — actives — */
function cooldownLeft(s){
  const h = H(), st = h.skillState[s.id];
  if(!st || !st.usedAt) return 0;
  const left = s.eff.active.cooldownDays - days(Date.now() - st.usedAt);
  return left > 0 ? left : 0;
}
async function useActive(s){
  const h = H();
  const left = cooldownLeft(s);
  if(left > 0) return toast("Still recharging", s.name + " comes back in " + Math.ceil(left) + " day" + (Math.ceil(left) === 1 ? "" : "s") + ".", "blood");
  const act = s.eff.active;
  if(act.action === "restoreStreak"){
    const n = Number(await sysPrompt("Rewind the streak",
      {msg:"What was the streak before it broke? The System takes your word for it once.", inputType:"number", value:String(h.lastStreak || 0), ok:"Restore"}));
    if(!n || n < 1) return;
    h.streak = Math.min(999, Math.round(n));
    toast("Rewind", "Streak restored to " + h.streak + ". Do not need it again.", "gold");
  } else if(act.action === "clearPenalties"){
    const c = (h.penalties || []).filter(p => !p.done).length;
    h.penalties = (h.penalties || []).map(p => ({ ...p, done:true }));
    toast("Sanctuary", c + " penalt" + (c === 1 ? "y" : "ies") + " dissolved. The slate is clean, not the habit.", "gold");
  } else {
    h.buffs[act.action] = { until: Date.now() + act.hours * 3600000, mult: act.mult };
    toast(s.name + " active", act.mult + "× XP for the next " + act.hours + " hour" + (act.hours === 1 ? "" : "s") + ". Do not waste it scrolling.", "gold");
  }
  h.skillState[s.id] = { usedAt: Date.now() };
  save(); renderSkills(); renderAll();
}

/* — tree UI — */
let skBranch = "all";
function renderSkills(){
  const h = H(); if(!h || !$("#skList")) return;
  migrate(h);
  const p = pts(), f = p.earned - p.spent;
  const nxt = nextSkillAfter(h.level);
  $("#skPoints").textContent = f + " point" + (f === 1 ? "" : "s") + " unspent · " + p.spent + " spent · " +
    learned().length + " of " + SKILLS.length + " learned" +
    (nxt ? "  ·  next unlock: " + nxt.name + " at level " + nxt.lvl : "  ·  every skill unlocked");

  /* branch chips */
  const chips = $("#skBranchChips"); chips.innerHTML = "";
  const mk = (k, label) => {
    const b = document.createElement("button");
    b.className = "chip" + (skBranch === k ? " on" : "");
    b.textContent = label;
    b.onclick = () => { skBranch = k; renderSkills(); };
    chips.appendChild(b);
  };
  mk("all", "All");
  Object.entries(BRANCHES).forEach(([k, v]) => mk(k, v.glyph + " " + v.label));

  /* actives */
  const ab = $("#skActives"); ab.innerHTML = "";
  const acts = SKILLS.filter(s => s.type === "active" && has(s.id));
  if(!acts.length){
    ab.innerHTML = '<p class="tiny muted">None learned yet. Active skills are the ones you fire on purpose — Rewind at level 8 is the first.</p>';
  } else acts.forEach(s => {
    const left = cooldownLeft(s);
    const el = document.createElement("div");
    el.className = "sk owned";
    el.innerHTML = '<div class="skg">' + BRANCHES[s.branch].glyph + '</div><div class="skb">' +
      '<div class="skn">' + esc(s.name) + '</div>' +
      '<div class="skm">' + (left > 0 ? "recharging · " + Math.ceil(left) + "d" : "ready") + '</div>' +
      '<div class="skd">' + esc(s.desc) + '</div></div>';
    const b = document.createElement("button");
    b.className = "btn sm " + (left > 0 ? "ghost" : "gold");
    b.textContent = left > 0 ? "…" : "Use";
    b.disabled = left > 0;
    b.onclick = () => useActive(s);
    el.appendChild(b);
    ab.appendChild(el);
  });

  /* the tree */
  const box = $("#skList"); box.innerHTML = "";
  const groups = skBranch === "all" ? Object.keys(BRANCHES) : [skBranch];
  groups.forEach(bk => {
    const rows = SKILLS.filter(s => s.branch === bk);
    if(!rows.length) return;
    const wrap = document.createElement("div"); wrap.className = "panel";
    const head = document.createElement("div"); head.className = "sk-branch";
    head.textContent = BRANCHES[bk].glyph + "  " + BRANCHES[bk].label + " — " + BRANCHES[bk].blurb;
    wrap.appendChild(head);

    rows.sort((a, b) => a.lvl - b.lvl).forEach(s => {
      const own = has(s.id), open = h.level >= s.lvl;
      const el = document.createElement("div");
      el.className = "sk" + (own ? " owned" : open ? "" : " locked");
      el.innerHTML = '<div class="skg">' + (own ? "◆" : open ? BRANCHES[s.branch].glyph : "🔒") + '</div>' +
        '<div class="skb"><div class="skn">' + esc(s.name) + '</div>' +
        '<div class="skm">Lv ' + s.lvl + ' · ' + s.cost + ' pt' + (s.cost === 1 ? "" : "s") + ' · ' + s.type +
        (own ? " · learned" : open ? "" : " · locked") + '</div>' +
        '<div class="skd">' + esc(s.desc) + '</div></div>';
      const b = document.createElement("button");
      b.className = "btn sm skcta " + (own ? "ghost" : "gold");
      b.textContent = own ? "✓" : !open ? "Lv " + s.lvl : s.cost > f ? "Need " + s.cost : "Learn";
      b.disabled = own || !open || s.cost > f;
      b.onclick = async () => {
        if(!await sysConfirm("Learn [" + s.name + "]?",
          s.desc + "\n\nCost: " + s.cost + " point" + (s.cost === 1 ? "" : "s") + ".", {ok:"Learn it"})) return;
        h.skills.push(s.id); save(); renderSkills(); renderAll();
        toast("Skill learned", "[" + s.name + "] is active.", "gold");
        if(s.eff && s.eff.feature) refreshFeatureGates();
      };
      el.appendChild(b);
      wrap.appendChild(el);
    });
    box.appendChild(wrap);
  });
}
if($("#skReset")) $("#skReset").onclick = async () => {
  const h = H();
  if(!h.skills.length) return toast("Nothing to reset", "You have not learned a skill yet.");
  if(!await sysConfirm("Respec everything?", "All " + h.skills.length + " skills are unlearned and every point returns to you.", {ok:"Respec", danger:true})) return;
  h.skills = []; h.buffs = {}; save(); renderSkills(); renderAll();
  toast("Respec complete", "Every point is back in your hands.", "gold");
};

function hasFeature(f){ return learned().some(id => { const s = skillById(id); return s && s.eff && s.eff.feature === f; }); }
function refreshFeatureGates(){
  /* v12: connecting is no longer skill-locked — every hunter links from
     level 1. [Gate Sense] now decides how WIDE the automatic sweep is:
     one shelf a session without it, the whole set with it. */
  if($("#wardDeepBtn")) $("#wardDeepBtn").disabled = !hasFeature("warddeep");
  renderCodexPanel();
  paintLink();
}

/* ════════════════ 3 · THE ARMORY ════════════════ */

let AR = null;            /* live index */
let zipFile = null;       /* the File the current index came from, this session only */
let dirHandle = null;
let sessionFiles = null;  /* Map path → File, for the input fallback */
let amSubject = null, amOldest = false, pendingIndex = null;

const idxKey = () => "idx:" + (DB.active || "draft");
const dirKey = () => "dir:" + (DB.active || "draft");

/* — intake widget, used in onboarding and in the Armory tab — */
function buildIntake(host){
  if(!host) return;
  host.innerHTML =
    '<div class="drop" data-drop>' +
      '<div class="dt">DROP A .ZIP HERE</div>' +
      '<p class="tiny muted">or use a button below · nothing uploads · 7 GB is fine</p>' +
    '</div>' +
    '<div class="row" style="flex-wrap:wrap">' +
      '<button class="btn sm" data-act="zip">Choose a .zip</button>' +
      '<button class="btn sm" data-act="dir">Choose a folder</button>' +
      '<button class="btn sm ghost" data-act="files">Choose files</button>' +
    '</div>' +
    '<div class="prog hidden" data-prog><i></i></div>' +
    '<div class="scanline" data-line></div>' +
    '<input type="file" accept=".zip,application/zip" data-in="zip" class="hidden">' +
    '<input type="file" multiple webkitdirectory data-in="dir" class="hidden">' +
    '<input type="file" multiple data-in="files" class="hidden">';

  const q = sel => host.querySelector(sel);
  const line = t => { q("[data-line]").textContent = t || ""; };
  const bar = (pct) => {
    const p = q("[data-prog]");
    p.classList.toggle("hidden", pct == null);
    if(pct != null) p.querySelector("i").style.width = Math.min(100, pct) + "%";
  };

  const drop = q("[data-drop]");
  ["dragenter","dragover"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("hot"); }));
  ["dragleave","drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("hot"); }));
  drop.addEventListener("drop", e => {
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if(f) takeZip(f, line, bar);
  });

  q('[data-act="zip"]').onclick = () => q('[data-in="zip"]').click();
  q('[data-act="files"]').onclick = () => q('[data-in="files"]').click();
  q('[data-act="dir"]').onclick = async () => {
    if(window.showDirectoryPicker){
      try{
        const dh = await A.pickDirectory();
        await takeDir(dh, line, bar);
      }catch(e){ if(e && e.name !== "AbortError") toast("Folder not read", e.message, "blood"); }
    } else q('[data-in="dir"]').click();
  };
  q('[data-in="zip"]').onchange = e => { if(e.target.files[0]) takeZip(e.target.files[0], line, bar); };
  q('[data-in="dir"]').onchange = e => takeList(e.target.files, line, bar, "folder");
  q('[data-in="files"]').onchange = e => takeList(e.target.files, line, bar, "files");
}

async function takeZip(file, line, bar){
  if(!/\.zip$/i.test(file.name)){
    return toast("Not a zip", "The browser can only read .zip. A .rar or .7z has to be converted first.", "blood");
  }
  line("Reading the archive index — not unpacking it…"); bar(8);
  try{
    const t0 = performance.now();
    const idx = await A.readZipIndex(file, (n, total) => {
      line("Indexed " + n.toLocaleString() + " entries…");
      bar(total ? 8 + (n / total) * 70 : 40);
    });
    bar(85); line("Sorting by subject and running the Ward…");
    const built = A.buildIndex(idx.entries, { kind:"zip", name:file.name, size:file.size, zip64:idx.zip64 });
    zipFile = file; dirHandle = null; sessionFiles = null;
    await commitIndex(built);
    bar(100);
    line("Done in " + Math.round(performance.now() - t0) + " ms — " +
         built.stats.count.toLocaleString() + " files, " + A.fmtBytes(built.stats.bytes) +
         " across " + built.stats.subjects + " subjects.");
    setTimeout(() => bar(null), 900);
  }catch(e){
    bar(null); line("");
    toast("Archive not read", e.message || String(e), "blood");
  }
}

async function takeDir(dh, line, bar){
  line("Walking the folder…"); bar(10);
  try{
    const rows = await A.walkDirectory(dh, n => { line("Found " + n.toLocaleString() + " files…"); bar(Math.min(80, 10 + n / 60)); });
    bar(85); line("Sorting by subject and running the Ward…");
    const built = A.buildIndex(rows, { kind:"dir", name:dh.name });
    dirHandle = dh; zipFile = null; sessionFiles = null;
    try{ await A.kvSet(dirKey(), dh); }catch(e){}
    await commitIndex(built);
    bar(100);
    line("Linked " + built.stats.count.toLocaleString() + " files (" + A.fmtBytes(built.stats.bytes) +
         "). The System kept a handle, so this folder stays reachable next time without re-picking it.");
    setTimeout(() => bar(null), 900);
  }catch(e){ bar(null); line(""); toast("Folder not read", e.message || String(e), "blood"); }
}

async function takeList(list, line, bar, kind){
  if(!list || !list.length) return;
  line("Reading " + list.length.toLocaleString() + " files…"); bar(30);
  const rows = A.fromFileList(list);
  const built = A.buildIndex(rows, { kind:"files", name: kind === "folder" ? (rows[0].name.split("/")[0] || "folder") : list.length + " files" });
  sessionFiles = new Map(rows.map(r => [r.name, r.file]));
  zipFile = null; dirHandle = null;
  await commitIndex(built);
  bar(100);
  line(built.stats.count.toLocaleString() + " files sorted. Note: chosen this way, the files are only openable until you close the app — pick the folder instead for a permanent link.");
  setTimeout(() => bar(null), 1200);
}

async function commitIndex(built){
  AR = built;
  const h = H();
  const summary = {
    source: built.source, created: built.created, stats: built.stats,
    subjects: Object.keys(built.bySubject)
  };
  if(h){ migrate(h); h.armory = summary; save(); }
  else { pendingIndex = built; }
  try{ await A.kvSet(idxKey(), built); }catch(e){ toast("Index not saved", "It will work this session but won't survive a restart.", "blood"); }
  renderArmory(); renderWard();
  if(h && built.stats.count){
    grantXp(Math.min(120, 20 + Math.round(built.stats.count / 40)), "Armory stocked", "study");
  }
}

async function loadIndex(){
  try{
    const saved = await A.kvGet(idxKey());
    if(saved && saved.files){ AR = saved; }
    const dh = await A.kvGet(dirKey());
    if(dh) dirHandle = dh;
  }catch(e){}
  renderArmory(); renderWard();
}

/* — browse — */
function renderArmory(){
  if(!$("#amList")) return;
  const box = $("#amList"), chips = $("#amSubjChips");
  box.innerHTML = ""; chips.innerHTML = "";

  if(!AR || !AR.files || !AR.files.length){
    $("#amSummary").textContent = "Nothing indexed yet";
    box.innerHTML = '<div class="panel"><p class="tiny muted">The Armory is empty. Go to <b>Intake</b> and hand the System a zip or a folder — it does the sorting.</p></div>';
    return;
  }

  const st = AR.stats;
  $("#amSummary").textContent = st.count.toLocaleString() + " files · " + A.fmtBytes(st.bytes) + " · " +
    st.subjects + " subjects · " + (st.blocked ? st.blocked + " quarantined" : "nothing quarantined") +
    " · from " + (AR.source && AR.source.name ? AR.source.name : "unknown source");
  $("#amHint").classList.add("hidden");

  const q = (($("#amSeek") && $("#amSeek").value) || "").trim().toLowerCase();
  const subjects = Object.keys(AR.bySubject).sort((a, b) => {
    if(a === "unsorted") return 1; if(b === "unsorted") return -1;
    return (A.SUBJ_LABEL[a] || a).localeCompare(A.SUBJ_LABEL[b] || b);
  });
  if(!amSubject || !AR.bySubject[amSubject]) amSubject = subjects[0];

  subjects.forEach(k => {
    const n = Object.values(AR.bySubject[k]).reduce((t, r) => t + r.length, 0);
    const b = document.createElement("button");
    b.className = "chip" + (amSubject === k && !q ? " on" : "");
    b.textContent = (A.SUBJ_LABEL[k] || k) + " · " + n;
    b.onclick = () => { amSubject = k; if($("#amSeek")) $("#amSeek").value = ""; renderArmory(); };
    chips.appendChild(b);
  });

  /* search runs across everything; otherwise show the chosen subject */
  if(q){
    const hits = AR.files.filter(f => !f.quarantine && f.name.toLowerCase().includes(q)).slice(0, 400);
    const wrap = document.createElement("div"); wrap.className = "panel";
    const hd = document.createElement("div"); hd.className = "am-grp";
    hd.textContent = hits.length + " match" + (hits.length === 1 ? "" : "es") + " across every subject";
    wrap.appendChild(hd);
    hits.forEach(f => wrap.appendChild(fileRow(f, true)));
    if(!hits.length) wrap.innerHTML += '<p class="tiny muted">Nothing matches that.</p>';
    box.appendChild(wrap);
    return;
  }

  const groups = AR.bySubject[amSubject] || {};
  const wrap = document.createElement("div"); wrap.className = "panel";
  const title = document.createElement("div"); title.className = "panel-title";
  title.textContent = A.SUBJ_LABEL[amSubject] || amSubject;
  wrap.appendChild(title);

  A.TYPE_ORDER.forEach(t => {
    let rows = groups[t];
    if(!rows || !rows.length) return;
    const hd = document.createElement("div"); hd.className = "am-grp";
    hd.textContent = A.TYPE_LABEL[t] + "  ·  " + rows.length;
    wrap.appendChild(hd);

    if(t === "past"){
      rows = A.sortPapers(rows, amOldest);
      let year = "\u0000";
      rows.slice(0, 500).forEach(f => {
        const y = f.meta.year ? String(f.meta.year) + (f.meta.session ? " · " + A.SESSION[f.meta.session] : "") : "Year not detected";
        if(y !== year){
          year = y;
          const yh = document.createElement("div"); yh.className = "am-yr"; yh.textContent = "▸ " + y;
          wrap.appendChild(yh);
        }
        wrap.appendChild(fileRow(f));
      });
    } else {
      rows.slice(0, 500).forEach(f => wrap.appendChild(fileRow(f)));
    }
    if(rows.length > 500){
      const more = document.createElement("p"); more.className = "tiny muted";
      more.textContent = "…and " + (rows.length - 500) + " more. Use the search box to reach them.";
      wrap.appendChild(more);
    }
  });
  box.appendChild(wrap);
}

const ICON = { notes:"▤", past:"◈", video:"▶", audio:"♪", book:"▣", syllabus:"⌘", flash:"✦", other:"·" };

function fileRow(f, showSubject){
  const el = document.createElement("div");
  el.className = "am-f" + (f.ward === "warn" ? " warned" : "");
  const bits = [];
  if(showSubject) bits.push(A.SUBJ_LABEL[f.subject] || f.subject);
  bits.push(A.TYPE_LABEL[f.type]);
  if(f.meta.kind && A.PAPER_KIND[f.meta.kind]) bits.push(A.PAPER_KIND[f.meta.kind]);
  if(f.meta.paper) bits.push("Paper " + f.meta.paper);
  bits.push(A.fmtBytes(f.size));
  el.innerHTML = '<div class="fi">' + (ICON[f.type] || "·") + '</div>' +
    '<div class="fb"><div class="fn">' + esc(f.base) + '</div>' +
    '<div class="fm">' + esc(bits.join(" · ")) +
    (f.ward === "warn" ? '<span class="badge b-warn">CHECK</span>' : "") + '</div></div>';
  el.onclick = () => openFile(f);
  return el;
}

/* — opening a file — */
async function openFile(f){
  if(f.quarantine) return toast("Blocked", "The Ward will not open this file.", "blood");
  if(f.ward === "warn" && !await sysConfirm("The Ward flagged this file",
      f.flags.map(x => "\u2022 " + x.msg).join("\n") + "\n\nOpen it anyway?", {ok:"Open anyway", danger:true, kick:"The Ward"})) return;

  try{
    let blob = null;
    if(AR.source.kind === "zip"){
      if(!zipFile) return toast("Source not linked", "The zip isn't attached to this session. Tap “Re-link source” and pick the same file — the index and your sorting stay exactly as they are.", "blood");
      const bytes = await A.extractEntry(zipFile, f);
      blob = new Blob([bytes]);
    } else if(AR.source.kind === "dir"){
      if(!dirHandle) return toast("Folder not linked", "Tap “Re-link source” and pick the folder again.", "blood");
      const perm = await dirHandle.queryPermission({ mode:"read" });
      if(perm !== "granted"){
        const req = await dirHandle.requestPermission({ mode:"read" });
        if(req !== "granted") return toast("Permission refused", "The System cannot read the folder without it.", "blood");
      }
      let dh = dirHandle;
      const parts = f.name.split("/");
      for(let i = 0; i < parts.length - 1; i++) dh = await dh.getDirectoryHandle(parts[i]);
      const fh = await dh.getFileHandle(parts[parts.length - 1]);
      blob = await fh.getFile();
    } else {
      const file = sessionFiles && sessionFiles.get(f.name);
      if(!file) return toast("Source not linked", "Files chosen one-by-one only last for the session. Re-pick them, or use the folder option for a permanent link.", "blood");
      blob = file;
    }
    const url = URL.createObjectURL(blob);
    const w = window.open(url, "_blank", "noopener,noreferrer");
    if(!w) toast("Popup blocked", "Allow popups for the System, or long-press to open in a new tab.", "blood");
    setTimeout(() => URL.revokeObjectURL(url), 90000);
    if(!f.opened){ f.opened = true; grantXp(3, "Opened study material", "study"); }
  }catch(e){
    toast("Could not open", e.message || String(e), "blood");
  }
}

if($("#amSeek")) $("#amSeek").addEventListener("input", () => renderArmory());
if($("#amOrder")) $("#amOrder").onclick = () => {
  amOldest = !amOldest;
  $("#amOrder").textContent = "Papers: " + (amOldest ? "oldest first" : "newest first");
  renderArmory();
};
if($("#amRelink")) $("#amRelink").onclick = async () => {
  if(!AR) return toast("Nothing to re-link", "Index a zip or folder first.");
  if(AR.source.kind === "dir"){
    try{ const dh = await A.pickDirectory(); dirHandle = dh; await A.kvSet(dirKey(), dh);
      toast("Re-linked", "Folder attached. Your sorting was never lost."); }
    catch(e){ if(e && e.name !== "AbortError") toast("Not linked", e.message, "blood"); }
  } else {
    const inp = document.createElement("input");
    inp.type = "file"; inp.accept = ".zip";
    inp.onchange = () => {
      const f = inp.files[0]; if(!f) return;
      zipFile = f;
      toast("Re-linked", "Archive attached — " + f.name + ". Files open again.");
    };
    inp.click();
  }
};

/* ════════════════ 4 · THE WARD ════════════════ */

function renderWard(){
  const box = $("#wardList"); if(!box) return;
  box.innerHTML = "";
  if(!AR){ $("#wardState").textContent = "Idle — nothing indexed"; box.innerHTML = '<p class="tiny muted">Nothing to scan yet.</p>'; return; }

  const bad = AR.files.filter(f => f.ward === "block");
  const warn = AR.files.filter(f => f.ward === "warn");
  $("#wardState").textContent = AR.stats.count.toLocaleString() + " files checked · " +
    bad.length + " quarantined · " + warn.length + " flagged for a look";

  if(!bad.length && !warn.length){
    box.innerHTML = '<p class="tiny muted">Clean. Nothing in this drop looks like it is pretending to be something else.</p>';
    return;
  }
  [...bad, ...warn].slice(0, 200).forEach(f => {
    const el = document.createElement("div");
    el.className = "wardrow";
    if(f.ward === "warn"){ el.style.background = "rgba(30,24,6,.5)"; el.style.borderColor = "rgba(255,196,60,.35)"; el.style.borderLeftColor = "#ffc43c"; }
    el.innerHTML = '<div class="wn">' + esc(f.name) + ' <span class="badge ' + (f.ward === "block" ? "b-block\">QUARANTINED" : "b-warn\">CHECK") + '</span></div>' +
      f.flags.map(x => '<div class="wr">— ' + esc(x.msg) + '</div>').join("");
    box.appendChild(el);
  });
}

if($("#wardDeepBtn")) $("#wardDeepBtn").onclick = async () => {
  if(!hasFeature("warddeep")) return toast("Locked", "Deep scanning unlocks with [Ward Protocol] at level 12.", "blood");
  if(!AR) return toast("Nothing indexed", "Index something first.");
  const btn = $("#wardDeepBtn"); btn.disabled = true;
  const targets = AR.files.filter(f => !f.quarantine && f.size > 0 && f.size < 200 * 1024 * 1024).slice(0, 600);
  let found = 0, done = 0;
  for(const f of targets){
    try{
      let head = null;
      if(AR.source.kind === "zip" && zipFile && f.size < 4 * 1024 * 1024){
        head = (await A.extractEntry(zipFile, f)).subarray(0, 8192);
      } else if(AR.source.kind === "files" && sessionFiles && sessionFiles.get(f.name)){
        head = new Uint8Array(await sessionFiles.get(f.name).slice(0, 8192).arrayBuffer());
      } else if(AR.source.kind === "dir" && dirHandle){
        let dh = dirHandle; const parts = f.name.split("/");
        for(let i = 0; i < parts.length - 1; i++) dh = await dh.getDirectoryHandle(parts[i]);
        const file = await (await dh.getFileHandle(parts[parts.length - 1])).getFile();
        head = new Uint8Array(await file.slice(0, 8192).arrayBuffer());
      }
      if(head){
        const d = A.deepCheck(f.name, head);
        if(d.flags.length){
          f.flags = [...(f.flags || []), ...d.flags];
          const sev = d.flags.some(x => x.sev === "block") ? "block" : "warn";
          if(sev === "block"){ f.ward = "block"; f.quarantine = true; }
          else if(f.ward === "clean") f.ward = "warn";
          found++;
        }
      }
    }catch(e){}
    done++;
    if(done % 25 === 0) $("#wardState").textContent = "Deep scan: " + done + " / " + targets.length + " · " + found + " findings";
  }
  AR.stats.blocked = AR.files.filter(f => f.ward === "block").length;
  AR.stats.warned = AR.files.filter(f => f.ward === "warn").length;
  try{ await A.kvSet(idxKey(), AR); }catch(e){}
  btn.disabled = false;
  renderWard(); renderArmory();
  toast("Deep scan finished", done + " files read at byte level. " + found + " new finding" + (found === 1 ? "" : "s") + ".", found ? "blood" : "gold");
};

if($("#wardTestBtn")) $("#wardTestBtn").onclick = () => {
  const cases = [
    { name:"Physics notes.pdf.exe", size:1000, csize:900 },
    { name:"revision\u202Egnp.exe", size:1000, csize:900 },
    { name:"../../etc/passwd", size:10, csize:10 },
    { name:"lecture.docm", size:20000, csize:9000 },
    { name:"papers.zip", size:5e8, csize:2e5 },
    { name:"0580_s23_qp_22.pdf", size:800000, csize:700000 }
  ];
  const lines = cases.map(c => {
    const r = A.wardCheck(c);
    return "• " + c.name + "\n   → " + r.sev.toUpperCase() + (r.flags.length ? ": " + r.flags.map(f => f.msg).join(" ") : " — nothing wrong with it");
  }).join("\n\n");
  takeover({ kind:"unlock", title:"WARD SELF-TEST", sub: lines,
    reward:"Six deliberately nasty filenames. The last one is a real past paper — it should pass clean." });
};

/* ════════════════ 5 · THE ONLINE GATE — THE AUTOMATIC LINK ════════════════

   v12. The Gate no longer waits to be opened by hand. If the device has a
   connection, the System links itself when the hunter enters, holds that
   link across network changes, sleeps when the signal dies, wakes when it
   comes back, and tops up the hunter's own shelves in the background while
   they work. Nothing to press.

   Five things stay locked down, automatic or not:
     · 18+ shelves are never fetched for. No catalogue is mapped to them,
       the picker leaves them out, the queue skips them, and online.js
       refuses them outright.
     · Films still need the hunter's own TMDB key. No key, no film calls.
     · The data guard rules. Save-Data on the device, or "Wi-Fi only" on a
       cellular connection, stops the background sync dead.
     · The host allowlist and the hourly request budget in online.js are
       untouched. Automatic does not mean unlimited.
     · Nothing about the hunter is ever sent. These are read-only, keyless,
       account-free public catalogues; the requests carry no cookies, no
       credentials and no referrer.
   ═══════════════════════════════════════════════════════════════════════════ */

const nap = ms => new Promise(r => setTimeout(r, ms));

/* IndexedDB and fetch can both reject with null in some browsers, and a
   background job that dies inside its own catch block is worse than one
   that fails loudly. Everything here reads errors through this. */
const errMsg = e => (e && e.message) || String(e == null ? "unknown error" : e);

const LINK = { status:"idle", ping:0, at:0, tries:0, timer:0, heart:0,
               syncing:false, note:"", added:0, lastErr:"" };

const BACKOFF = [8000, 20000, 60000, 180000, 600000];
/* tries is incremented on failure, so the first retry is the first rung */
const backoff = () => BACKOFF[Math.min(Math.max(LINK.tries - 1, 0), BACKOFF.length - 1)];

function linkOn(){ const h = H(); return !!(h && h.gate && h.gate.open !== false); }
function guardMode(){ const h = H(); return (h && h.gate && h.gate.guard) || "auto"; }
function tmdbKey(){ const h = H(); return ((h && h.gate && h.gate.tmdb) || "").trim(); }

/* kept for anything still asking the old question */
function gateOpen(){ return linkOn(); }

/* May the System reach out on its own, right now, without being asked? */
function autoAllowed(){
  if(!linkOn()) return false;
  if(guardMode() === "manual") return false;
  const c = N.conn();
  if(c.saveData) return false;                       /* the device asked for less */
  if(guardMode() === "wifi" && c.metered) return false;
  return true;
}
function guardReason(){
  if(!linkOn()) return "the link is off";
  if(guardMode() === "manual") return "the data guard is set to manual";
  const c = N.conn();
  if(c.saveData) return "this device has Save-Data switched on";
  if(guardMode() === "wifi" && c.metered) return "you are on mobile data and the guard is Wi-Fi only";
  return "";
}

/* How many shelves one background run will take.
   [Gate Sense] at level 5 turns a trickle into a full sweep. */
function shelfCap(){ return hasFeature("online") ? 24 : 1; }
function shelfTarget(){ return hasFeature("shelf450") ? 450 : 150; }

/* ── status text ── */
function linkText(){
  if(!linkOn())    return "Link off — the System is running fully offline";
  if(!N.online())  return "No network on this device · the link resumes on its own";
  if(LINK.syncing) return "Linked · " + (LINK.note || "syncing…");
  switch(LINK.status){
    case "linking": return "Linking…";
    case "linked":  return "Linked · catalogues answered in " + LINK.ping + " ms";
    case "down":    return "Linked but no answer — retrying in " + Math.round(backoff()/1000) + "s";
    default:        return "Standing by — linking automatically";
  }
}
function paintLink(){
  if($("#gateState")) $("#gateState").textContent = linkText();
  if($("#gateBtn"))   $("#gateBtn").textContent = linkOn() ? "Turn the link off" : "Turn the link on";
  if($("#codexSub"))  $("#codexSub").textContent = codexSubText();
  if($("#codexLine") && LINK.syncing && LINK.note) $("#codexLine").textContent = "◆ " + LINK.note;
}

/* ── the link itself ── */
async function linkNow(){
  if(!linkOn()){ LINK.status = "idle"; paintLink(); return false; }
  if(!N.online()){ LINK.status = "offline"; paintLink(); return false; }
  if(LINK.status === "linking") return false;
  LINK.status = "linking"; paintLink();
  try{
    LINK.ping = await N.probe();
    LINK.at = Date.now(); LINK.tries = 0; LINK.status = "linked"; LINK.lastErr = "";
    paintLink();
    if(autoAllowed()) runSync(false);
    return true;
  }catch(e){
    LINK.status = "down"; LINK.tries++; LINK.lastErr = errMsg(e);
    paintLink(); relink();
    return false;
  }
}
function relink(){
  clearTimeout(LINK.timer);
  if(!linkOn()) return;
  LINK.timer = setTimeout(linkNow, backoff());
}
function heartbeat(){
  clearInterval(LINK.heart);
  LINK.heart = setInterval(() => {
    if(!linkOn() || LINK.syncing || !N.online()) return;
    if(Date.now() - LINK.at < 25 * 60000) return;
    linkNow();
  }, 30 * 60000);                                     /* a quiet half-hourly top-up */
}

/* ── which shelves want feeding ── */
function fetcherFor(kind, key){
  if(kind === "book") return N.OL_SUBJECTS[key] ? "book" : null;
  if(N.MAL_GENRE[key])    return "anime";
  if(N.TVMAZE_GENRE[key]) return "series";
  if(N.TMDB_GENRE[key])   return "film";
  return null;
}
function shelfCount(v){
  const [kind, key] = String(v).split(":");
  return kind === "book" ? (GENRES[key] ? GENRES[key].books.length : 0)
                         : (SCREEN[key] ? SCREEN[key].picks.length : 0);
}
function buildQueue(force){
  const h = H(); if(!h) return [];
  const target = shelfTarget(), grown = h.shelfGrown || {}, out = [];

  (h.genres || []).forEach(k => {
    const g = GENRES[k];
    if(!g || N.adultShelf("book", k) || !N.OL_SUBJECTS[k]) return;
    if(g.books.length >= target) return;
    out.push({ v:"book:" + k, key:k, label:g.label, have:g.books.length });
  });
  (h.screenGenres || []).forEach(k => {
    const s = SCREEN[k];
    if(!s || N.adultShelf("screen", k)) return;
    const f = fetcherFor("screen", k); if(!f) return;
    if(f === "film" && !tmdbKey()) return;             /* no key, no film calls */
    if(s.picks.length >= target) return;
    out.push({ v:f + ":" + k, key:k, label:s.label, have:s.picks.length });
  });

  /* don't pester a shelf that was just fed — unless it is still starving */
  const ready = o => {
    if(force) return true;
    const age = Date.now() - (grown[o.key] || 0);
    return age > (o.have < target / 2 ? 12 * 3600000 : 3 * 86400000);
  };
  return out.filter(ready)
            .sort((a, b) => a.have - b.have)           /* emptiest shelf eats first */
            .slice(0, force ? 99 : shelfCap());
}

/* ── the background sync ── */
async function runSync(force){
  if(LINK.syncing) return;
  if(!force && !autoAllowed()) return;
  const q = buildQueue(force);
  if(!q.length){
    if(force) toast("Nothing to fetch", "Every shelf you chose is already at its ceiling.", "");
    return;
  }
  LINK.syncing = true; LINK.added = 0;
  try{
    for(const item of q){
      if(!N.online()) break;
      if(!force && !autoAllowed()) break;
      const b = N.budget();
      if(b.used > b.cap * 0.8) break;                  /* leave room for the hunter */
      LINK.note = "topping up " + item.label + "…"; paintLink();
      const before = shelfCount(item.v);
      await growOne(item.v, true, true);
      LINK.added += Math.max(0, shelfCount(item.v) - before);
      if(q.length > 1) await nap(force ? 4000 : 20000); /* breathe between shelves */
    }
  }catch(e){ LINK.lastErr = errMsg(e); }        /* a background job records, never shouts */
  finally{
    LINK.syncing = false; LINK.note = "";
    paintLink(); renderCodexPanel();
    if(LINK.added) toast("Codex topped up", LINK.added + " new real titles arrived while you worked.", "gold");
    else if(force) toast("Nothing new", "The catalogues had nothing this shelf doesn't already hold.", "");
  }
}

/* ── settings panel ── */
function renderGateUI(){
  const h = H(); if(!h || !$("#gateState")) return;
  migrate(h);
  paintLink();
  if($("#gateTmdb"))  $("#gateTmdb").value = h.gate.tmdb || "";
  if($("#gateGuard")) $("#gateGuard").value = h.gate.guard || "auto";
  N.cacheKeys().then(k => {
    if($("#gateCacheInfo")) $("#gateCacheInfo").textContent =
      k.length ? k.length + " shelf pull" + (k.length === 1 ? "" : "s") + " cached on this device"
               : "Nothing cached yet";
  }).catch(() => {});
}
if($("#gateBtn")) $("#gateBtn").onclick = () => {
  const h = H();
  h.gate.open = !linkOn(); save();
  renderGateUI(); renderCodexPanel();
  if(h.gate.open){
    toast("Link on", "The System will connect by itself from now on.", "gold");
    LINK.tries = 0; linkNow();
  }else{
    clearTimeout(LINK.timer); clearInterval(LINK.heart);
    LINK.status = "idle"; paintLink();
    toast("Link off", "Fully offline. Everything already cached stays on the shelves.", "");
  }
};
if($("#gateTest")) $("#gateTest").onclick = async () => {
  if(!linkOn()) return toast("Link off", "Turn it on first.", "blood");
  $("#gateState").textContent = "Testing…";
  LINK.tries = 0;
  const ok = await linkNow();
  toast(ok ? "Connection good" : "No connection",
        ok ? "Round trip " + LINK.ping + " ms." : (LINK.lastErr || "The network did not answer."),
        ok ? "" : "blood");
};
if($("#gateSync")) $("#gateSync").onclick = async () => {
  if(!linkOn()) return toast("Link off", "Turn it on first.", "blood");
  if(LINK.syncing) return toast("Already syncing", LINK.note || "One shelf at a time.");
  const c = N.conn();
  if((c.metered || c.saveData) && !await sysConfirm("You are on mobile data",
      "A full sweep of your shelves is a few megabytes, once. Cached afterwards.", {ok:"Continue"})) return;
  if(LINK.status !== "linked") await linkNow();
  runSync(true);
};
if($("#gateTmdb"))  $("#gateTmdb").onchange  = () => { const h = H(); h.gate.tmdb = $("#gateTmdb").value.trim().slice(0, 120); save(); };
if($("#gateGuard")) $("#gateGuard").onchange = () => {
  const h = H(); h.gate.guard = $("#gateGuard").value; save(); renderGateUI();
  if(autoAllowed() && LINK.status === "linked") runSync(false);
};
if($("#gateClear")) $("#gateClear").onclick = async () => {
  if(!await sysConfirm("Clear the online cache?", "Every title pulled from the internet is deleted. Your shelves drop back to what shipped with the app.", {ok:"Clear", danger:true})) return;
  await N.cacheClear();
  const h = H(); h.shelfGrown = {}; save();
  toast("Cache cleared", "Reopen the app to see the shelves reset.");
  renderGateUI();
};

/* — Codex Sync panel, injected into the Library — */
function ensureCodexPanel(){
  if($("#codexPanel")) return;
  const host = document.querySelector('[data-pane="l-books"]');
  if(!host) return;
  const p = document.createElement("div");
  p.className = "panel"; p.id = "codexPanel";
  p.innerHTML =
    '<div class="panel-title">Codex Sync</div>' +
    '<div class="panel-sub" id="codexSub">Standing by</div>' +
    '<p class="tiny muted" style="margin-bottom:10px">The shelves that ship with the app are hand-picked and real. The System now tops them up by itself whenever it has a connection, pulling hundreds more real titles from public catalogues and keeping them on this device forever. You can also push a shelf ahead of the queue here. Books, series and anime need no key; films need your own free TMDB key.</p>' +
    '<div class="row" style="flex-wrap:wrap;align-items:center">' +
      '<select id="codexShelf" style="flex:1;min-width:180px"></select>' +
      '<button class="btn sm" id="codexGo">Grow this shelf</button>' +
      '<button class="btn sm ghost" id="codexAll">Grow all my shelves</button>' +
    '</div>' +
    '<div class="prog hidden" id="codexProg"><i></i></div>' +
    '<div class="scanline" id="codexLine"></div>';
  host.appendChild(p);
  $("#codexGo").onclick = () => growOne($("#codexShelf").value);
  $("#codexAll").onclick = growAll;
}

function codexSubText(){
  if(!linkOn()) return "Link off — Settings → The Online Gate";
  if(!N.online()) return "Waiting for a network. The System will pick this up by itself.";
  const why = guardReason();
  if(why) return "Automatic top-up paused — " + why;
  return "Automatic · ceiling " + shelfTarget() + " titles a shelf" +
    (hasFeature("shelf450") ? "" : " — [Grand Librarian] at 36 raises it to 450") +
    (hasFeature("online") ? "" : " · [Gate Sense] at 5 sweeps every shelf instead of one at a time");
}

function renderCodexPanel(){
  ensureCodexPanel();
  if(!$("#codexShelf")) return;
  const h = H(); if(!h) return;
  $("#codexSub").textContent = codexSubText();
  $("#codexGo").disabled = $("#codexAll").disabled = !linkOn();

  const sel = $("#codexShelf");
  const cur = sel.value;
  sel.innerHTML = "";
  const add = (k, label, n, kind) => {
    const o = document.createElement("option");
    o.value = kind + ":" + k;
    o.textContent = label + "  (" + n + ")";
    sel.appendChild(o);
  };
  Object.keys(GENRES).forEach(k => {
    if(N.adultShelf("book", k)) return;                /* 18+ shelves are never listed here */
    if(N.OL_SUBJECTS[k]) add(k, "📖 " + GENRES[k].label, GENRES[k].books.length, "book");
  });
  Object.keys(SCREEN).forEach(k => {
    if(N.adultShelf("screen", k)) return;
    const f = fetcherFor("screen", k);
    if(f) add(k, "▶ " + SCREEN[k].label + " — " + (f === "film" ? "films" : f), SCREEN[k].picks.length, f);
  });
  if(cur) sel.value = cur;
}

let growing = false;
async function growOne(val, quiet, bg){
  if(!val) return;
  if(!linkOn()){ if(!bg) toast("Link off", "Turn it on in Settings first.", "blood"); return; }
  if(growing){ if(!bg) toast("Already fetching", "One shelf at a time."); return; }
  growing = true;
  const [kind, key] = val.split(":");
  const h = H();
  const bar = $("#codexProg"), line = $("#codexLine");
  const target = shelfTarget();
  const say = t => { if(line) line.textContent = t; };
  const pct = (n) => { if(bar){ bar.classList.remove("hidden"); bar.querySelector("i").style.width = Math.min(100, n / target * 100) + "%"; } };

  try{
    if(N.adultShelf(kind === "book" ? "book" : "screen", key))
      throw new Error("The Gate does not fetch for 18+ shelves.");
    let rows = [], label = "";
    if(kind === "book"){
      label = GENRES[key].label;
      say("Reaching Open Library for " + label + "…");
      rows = await N.fetchBooks(key, GENRES[key].books, target, (n) => { pct(n); say(n + " / " + target + " titles…"); });
      GENRES[key].books = GENRES[key].books.concat(rows);
      await N.cacheSet("book:" + key, GENRES[key].books);
    } else {
      label = SCREEN[key].label;
      const ex = SCREEN[key].picks;
      if(kind === "anime"){ say("Reaching Jikan for " + label + "…"); rows = await N.fetchAnime(key, ex, target, (n) => { pct(n); say(n + " / " + target + "…"); }); }
      else if(kind === "series"){ say("Reaching TVMaze for " + label + "…"); rows = await N.fetchSeries(key, ex, target, (n) => say("scanned " + n + " shows…")); }
      else { say("Reaching TMDB for " + label + "…"); rows = await N.fetchFilms(key, ex, target, tmdbKey(), (n) => { pct(n); say(n + " / " + target + "…"); }); }
      SCREEN[key].picks = SCREEN[key].picks.concat(rows);
      await N.cacheSet("screen:" + key, SCREEN[key].picks);
    }
    h.shelfGrown[key] = Date.now(); save();
    say(label + ": " + rows.length + " new real titles added. Total " +
        (kind === "book" ? GENRES[key].books.length : SCREEN[key].picks.length) + ". Cached — you never pay for it twice.");
    if(bar) setTimeout(() => bar.classList.add("hidden"), 1200);
    if(!quiet && rows.length) grantXp(10, "Codex expanded");
    renderLibrary(); renderScreen(); renderCodexPanel();
  }catch(e){
    if(bar) bar.classList.add("hidden");
    say("");
    if(bg) LINK.lastErr = errMsg(e);
    else toast("Fetch stopped", errMsg(e), "blood");
  }finally{ growing = false; }
}

async function growAll(){
  const h = H();
  const opts = [...$("#codexShelf").options].map(o => o.value);
  const mine = opts.filter(v => {
    const [kind, key] = v.split(":");
    return kind === "book" ? (h.genres || []).includes(key) : (h.screenGenres || []).includes(key);
  });
  if(!mine.length) return toast("No shelves chosen", "Pick some genres first — the System won't guess.");
  if(!await sysConfirm("Grow " + mine.length + " shelves?", "Toward " + shelfTarget() + " titles each. Roughly " + Math.round(mine.length * 1.5) + " MB of data, once \u2014 cached afterwards.", {ok:"Grow them"})) return;
  for(const v of mine){ await growOne(v, true); }
  toast("Codex synced", mine.length + " shelves grown.", "gold");
}

/* — apply the cache at boot, so growth survives restarts — */
async function applyCache(){
  try{
    const keys = await N.cacheKeys();
    for(const k of keys){
      const rec = await N.cacheGet(k);
      if(!rec || !Array.isArray(rec.rows)) continue;
      const [kind, key] = String(k).split(":");
      if(kind === "book" && GENRES[key]) GENRES[key].books = rec.rows;
      if(kind === "screen" && SCREEN[key]) SCREEN[key].picks = rec.rows;
    }
    if(keys.length){ renderLibrary(); renderScreen(); }
  }catch(e){}
}

/* — the link comes up on its own, a beat after the app has drawn itself — */
function linkBoot(){
  const h = H(); if(!h) return;
  migrate(h);
  paintLink();
  if(!linkOn()) return;
  heartbeat();
  clearTimeout(LINK.timer);
  LINK.timer = setTimeout(linkNow, 2500);
}

/* ════════════════ BOOT ════════════════ */

Hooks.wrap("renderAll", "v11 panels", function(next){
  try{ migrate(H()); }catch(e){}
  try{ return next(); }
  finally{
    /* v11 panels render even if an older panel throws — a broken shelf
       should never take the Armory and the skill tree down with it. */
    try{ renderSkills(); renderGateUI(); renderCodexPanel(); refreshFeatureGates(); }catch(e){ console.warn("v11 render", e); }
  }
});

/* onboarding intake + carrying a pre-activation index onto the new hunter */
buildIntake($("#obIntake"));
buildIntake($("#amIntake"));

const _obFinish = $("#obFinish") && $("#obFinish").onclick;
if($("#obFinish")) $("#obFinish").onclick = async function(e){
  await _obFinish.call(this, e);
  const h = H(); if(!h) return;
  migrate(h);
  if(pendingIndex){
    h.armory = { source: pendingIndex.source, created: pendingIndex.created,
                 stats: pendingIndex.stats, subjects: Object.keys(pendingIndex.bySubject) };
    save();
    try{ await A.kvSet(idxKey(), pendingIndex); }catch(err){}
    AR = pendingIndex; pendingIndex = null;
    renderArmory(); renderWard();
  }
  save();
};

Hooks.wrap("enterSystem", "v11 boot", function(next){
  try{ migrate(H()); }catch(e){}
  try{ return next(); }
  finally{ try{ loadIndex(); applyCache(); refreshFeatureGates(); linkBoot(); }catch(e){ console.warn("v11 boot", e); } }
});

/* ── the System notices the network for itself ── */
window.addEventListener("online", () => {
  LINK.tries = 0; LINK.status = "idle"; renderGateUI();
  if(linkOn()) setTimeout(linkNow, 1200);        /* let the radio settle */
});
window.addEventListener("offline", () => {
  clearTimeout(LINK.timer);
  LINK.status = "offline"; renderGateUI();
});
document.addEventListener("visibilitychange", () => {
  if(document.visibilityState !== "visible" || !linkOn() || LINK.syncing) return;
  if(Date.now() - LINK.at > 300000) linkNow();    /* stale after five minutes away */
});
N.onConnChange(() => { renderGateUI(); if(linkOn() && autoAllowed() && LINK.status !== "linked") linkNow(); });

if(!$("#app").classList.contains("hidden")){
  migrate(H());
  renderSkills(); renderGateUI(); renderCodexPanel(); refreshFeatureGates();
  loadIndex(); applyCache(); linkBoot();
}
})();
