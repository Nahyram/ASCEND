/* THE SYSTEM v13 — ui/dialog.js
   The System does not use the browser's grey boxes. It opens a window of its own.
   sysAlert / sysConfirm / sysPrompt are promises — await them. */
"use strict";

let dlgOpen = null;

function dialogHost(){
  let host = document.getElementById("dialogs");
  if(!host){
    host = document.createElement("div");
    host.id = "dialogs";
    document.body.appendChild(host);
  }
  return host;
}

/* opts: {kick,title,msg,ok,cancel,danger,input,placeholder,value} */
function sysDialog(opts){
  return new Promise(resolve => {
    const host = dialogHost();
    const wants = !!opts.input;
    host.innerHTML = `
      <div class="dlg${opts.danger ? " danger" : ""}" role="dialog" aria-modal="true" aria-labelledby="dlgTtl">
        <div class="kick">${esc(opts.kick || "System")}</div>
        <div class="ttl" id="dlgTtl">${esc(opts.title || "")}</div>
        ${opts.msg ? `<div class="msg">${esc(opts.msg)}</div>` : ""}
        ${wants ? `<input type="${opts.inputType || "text"}" id="dlgIn" placeholder="${esc(opts.placeholder || "")}" value="${esc(opts.value || "")}">` : ""}
        <div class="acts">
          ${opts.cancel === null ? "" : `<button class="btn sm ghost" id="dlgNo">${esc(opts.cancel || "Cancel")}</button>`}
          <button class="btn sm${opts.danger ? " blood" : ""}" id="dlgYes">${esc(opts.ok || "Confirm")}</button>
        </div>
      </div>`;
    host.classList.add("on");

    const input = document.getElementById("dlgIn");
    const done = val => {
      host.classList.remove("on");
      host.innerHTML = "";
      document.removeEventListener("keydown", onKey, true);
      dlgOpen = null;
      resolve(val);
    };
    const yes = () => done(wants ? (input.value || "") : true);
    const no  = () => done(wants ? null : false);

    function onKey(e){
      if(e.key === "Escape"){ e.stopPropagation(); no(); }
      else if(e.key === "Enter" && (wants || document.activeElement !== document.getElementById("dlgNo"))){ e.preventDefault(); yes(); }
    }
    document.addEventListener("keydown", onKey, true);
    document.getElementById("dlgYes").onclick = yes;
    const nob = document.getElementById("dlgNo"); if(nob) nob.onclick = no;
    host.onclick = e => { if(e.target === host) no(); };
    dlgOpen = { close:no };
    setTimeout(() => (input || document.getElementById("dlgYes")).focus(), 30);
  });
}

const sysAlert = (title, msg, kick) =>
  sysDialog({ title, msg, kick, ok:"Understood", cancel:null });

const sysConfirm = (title, msg, opts = {}) =>
  sysDialog(Object.assign({ title, msg, ok:"Confirm", cancel:"Cancel" }, opts));

const sysPrompt = (title, opts = {}) =>
  sysDialog(Object.assign({ title, input:true, ok:"Save", cancel:"Cancel" }, opts));

/* Nothing in the app should reach for the grey box. If a stray call slips
   through, route it somewhere with the System's face on it. */
window.alert = (m) => { sysAlert("System", String(m)); };
