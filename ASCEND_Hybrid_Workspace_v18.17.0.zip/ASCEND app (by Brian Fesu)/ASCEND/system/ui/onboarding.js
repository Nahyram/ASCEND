/* THE SYSTEM v13 — ui/onboarding.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ REGISTER → ONBOARD ══════════════ */
let draft = null;
$("#regGo").onclick = () => {
  const name = $("#regName").value.trim();
  if(!name) return toast("Name required","The System needs something to call you.","blood");
  const pin = $("#regPin").value.trim();
  if(pin && !/^\d{4,6}$/.test(pin)) return toast("PIN invalid","Use 4 to 6 digits, or leave it blank.","blood");
  draft = {
    id: uid(), name, title: $("#regTitle").value.trim() || "Newly Awakened", pin, avatar: regAvatarData || DEFAULT_AVATAR,
    level:1, xp:0, totalXp:0, rank:"E", stats:{STR:5,VIT:5,INT:5,PER:5,DIS:5},
    quests: seedQuests("igcse"), mode:"student", curriculum:"igcse", workout:"calisthenics", diff:"2", restDay:0, reroll:0,
    done:{}, penalties:[], deadlines:[], streak:0, lastActive:null, totalCleared:0,
    spotify:"", penaltyMode:"on", alarmMode:"on", workoutDone:{}, unlocked:false, created: todayKey()
  };
  $("#scr-register").classList.add("hidden");
  $("#scr-onboard").classList.remove("hidden");
  renderObQuests();
};
$$("#obWorkout .chip").forEach(c => c.onclick = () => {
  $$("#obWorkout .chip").forEach(x=>x.classList.remove("on")); c.classList.add("on"); draft.workout = c.dataset.w;
});
function obReseed(){
  draft.curriculum = $("#obCur").value;
  draft.quests = draft.mode === "founder" ? founderSeed() : seedQuests(draft.curriculum);
  renderObQuests();
}
$$("#obMode .chip").forEach(c => c.onclick = () => {
  $$("#obMode .chip").forEach(x=>x.classList.remove("on")); c.classList.add("on");
  draft.mode = c.dataset.m;
  obReseed();
  toast("Path set", draft.mode === "founder" ? "Founder quest board loaded — Learn, Build, Share." : `${(CURRICULA[draft.curriculum]||CURRICULA.igcse).label} student board loaded.`);
});
$("#obCur").onchange = () => {
  if(draft.mode === "founder"){ draft.curriculum = $("#obCur").value; return; }
  obReseed();
  toast("Curriculum set", `${(CURRICULA[draft.curriculum]||CURRICULA.igcse).label} study quests loaded. Rename any placeholders to your real subjects.`);
};
$("#setCurLoad").onclick = async () => {
  const h = H(); if(!h) return;
  const cur = $("#setCur").value, lab = (CURRICULA[cur]||CURRICULA.igcse).label;
  if(!await sysConfirm("Rebuild the quest board?",
      `Every current quest is replaced with the ${lab} study template.\n\nXP, level, streak and deadlines are kept.`,
      {ok:"Rebuild", danger:true})) return;
  h.curriculum = cur; h.quests = seedQuests(cur); save(); renderAll();
  toast("Quest board rebuilt", `${lab} study quests loaded. Rename placeholders to your real subjects.`, "gold");
};
$$("[data-next]").forEach(b => b.onclick = () => {
  const n = b.dataset.next;
  OB_STEPS.forEach(i => $("#ob"+i).classList.toggle("hidden", i!==n));
  $("#obStep").textContent = n;
});

/* ══════════════ v18: GOAL CAPTURE (step 2) ══════════════
   The gap map called this "the single highest-leverage remaining item", and it
   was right for a blunt reason: the product's whole loop is
   GOAL → PLAN → EXECUTE → MASTER, and setup never asked for the goal. A student
   finished calibration with a generated timetable and no answer to "what is
   this for". activationFunnel() has listed "Set a goal" since v15, measuring a
   step no screen offered.

   Two rules this implementation follows:

   1. **It reuses the real engines rather than re-implementing them.** The
      preview below is proposeBreakdown() — the same pure function the Goals
      view calls. This project has shipped the same logic twice in two files
      five times now, and every time the copies drifted. proposeBreakdown() is
      pure and needs no hunter, so it can run mid-onboarding; addGoal() and
      scheduleStepAsQuest() are not, because they read H() and write the record,
      so they run at finish, once the hunter exists. Nothing is duplicated to
      work around that ordering — it is just sequenced.

   2. **A goal is not captured until a step is scheduled.** A goal with no dated
      action is a wish, and counting wishes as activation is how a funnel starts
      lying. The draft holds the choice; obFinish does the writing. */
const OB_STEPS = ["1","2","3","4","5"];

function obGoalDraft(){
  draft.firstGoal = draft.firstGoal || null;
  return draft.firstGoal;
}

/* Renders the proposal and lets the hunter choose which step becomes quest one.
   Nothing here writes to the record. */
function renderObGoalPlan(){
  const out = $("#obGoalPlan" + "Out"); if(!out) return;
  const g = obGoalDraft();
  out.innerHTML = "";
  if(!g || !g.proposal) return;

  const head = document.createElement("p");
  head.className = "tiny muted";
  head.textContent = g.proposal.why;
  out.appendChild(head);

  const pick = document.createElement("div");
  pick.className = "field";
  const lab = document.createElement("label");
  lab.textContent = "Which step becomes your first quest?";
  pick.appendChild(lab);

  const sel = document.createElement("select");
  sel.id = "obGoalStep";
  g.proposal.targets.forEach((t, ti) => {
    const grp = document.createElement("optgroup");
    grp.label = t.name;
    t.steps.forEach((st, si) => {
      const o = document.createElement("option");
      o.value = ti + ":" + si;
      o.textContent = st;
      if(g.pick && g.pick.target === ti && g.pick.step === si) o.selected = true;
      grp.appendChild(o);
    });
    sel.appendChild(grp);
  });
  sel.onchange = () => {
    const [ti, si] = sel.value.split(":").map(Number);
    g.pick = { target: ti, step: si };
  };
  if(!g.pick) g.pick = { target: 0, step: 0 };
  pick.appendChild(sel);
  out.appendChild(pick);

  const note = document.createElement("p");
  note.className = "tiny";
  note.style.color = "var(--gold)";
  note.textContent = "This becomes a real quest on your board, weekdays at the time above, worth 20 XP. Clearing it ticks the step off the goal \u2014 that link is what makes the progress ring mean anything.";
  out.appendChild(note);
}

$("#obGoalPlan").onclick = () => {
  const name = $("#obGoalName").value.trim();
  if(!name) return toast("Goal required", "Write it in your own words \u2014 even roughly. You can edit it later.", "blood");
  if(typeof proposeBreakdown !== "function"){
    return toast("Planner unavailable", "The goal engine did not load. You can still add this goal from Grow \u203a Goals.", "blood");
  }
  draft.firstGoal = {
    name,
    horizon: $("#obGoalHorizon").value,
    proposal: proposeBreakdown(name),
    pick: { target: 0, step: 0 },
  };
  renderObGoalPlan();
  toast("Broken down", "Three targets, each with steps. Pick the one you will actually start with.", "gold");
};

/* Written after the hunter is saved, because every function it calls reads H(). */
function obCommitGoal(){
  const g = draft.firstGoal;
  if(!g || !g.name) return null;
  if(typeof addGoal !== "function" || typeof applyBreakdown !== "function") return null;

  const goal = addGoal({ name: g.name, horizon: g.horizon || "month" });
  if(!goal) return null;
  applyBreakdown(goal.id, g.proposal);

  const t = (goal.targets || [])[(g.pick && g.pick.target) || 0];
  if(!t || typeof scheduleStepAsQuest !== "function") return { goal, quest:null };

  const si = (g.pick && g.pick.step) || 0;
  const time = /^\d{2}:\d{2}$/.test($("#obGoalTime").value) ? $("#obGoalTime").value : "18:00";
  const res = scheduleStepAsQuest(goal.id, t.id, si, { time, cat:"study", xp:20 });
  return { goal, quest: res && res.quest ? res.quest : null };
}

function renderObQuests(){
  const box = $("#obQuests"); box.innerHTML = "";
  draft.quests.sort((a,b)=>a.time.localeCompare(b.time)).forEach(q => box.appendChild(questEditor(q, draft, renderObQuests)));
}
function questEditor(q, owner, rerender){
  const el = document.createElement("div");
  el.className = "quest";
  const DNAMES = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  const DL = ["S","M","T","W","T","F","S"];
  el.innerHTML = `<span class="q-time">${fmt12(q.time)}</span>
    <div class="q-body"><span class="q-name">${esc(q.name)}</span>
      <span class="q-meta"><span class="tag t-${q.cat}">${q.cat}</span> · ${q.xp} XP</span>
      <span class="dayset">${DL.map((d,i)=>`<button type="button" class="dayt ${q.days.includes(i)?"on":""}" data-d="${i}" title="${DNAMES[i]}" aria-pressed="${q.days.includes(i)}">${d}</button>`).join("")}</span></div>
    <button class="btn sm ghost" title="Mandatory quests trigger penalties">${q.mand?"★":"☆"}</button>
    <button class="btn sm danger">✕</button>`;
  el.querySelectorAll(".dayt").forEach(b => b.onclick = () => {
    const d = Number(b.dataset.d);
    if(q.days.includes(d)){
      if(q.days.length === 1) return toast("At least one day","A quest needs at least one active day.","blood");
      q.days = q.days.filter(x => x !== d);
    } else {
      q.days = [...q.days, d].sort((a,b)=>a-b);
    }
    rerender();
  });
  const [star, del] = el.querySelectorAll("button.btn");
  star.onclick = () => { q.mand = !q.mand; q.xp = q.mand ? Math.max(q.xp,25) : q.xp; rerender(); };
  del.onclick = () => { owner.quests = owner.quests.filter(x=>x.id!==q.id); rerender(); };
  return el;
}
$("#nqAdd").onclick = () => {
  const t = $("#nqTime").value, n = $("#nqName").value.trim();
  if(!t || !n) return toast("Incomplete","A quest needs a time and a name.","blood");
  draft.quests.push({id:uid(), time:t, name:n, cat:$("#nqCat").value, days:WD, mand:false, xp:15});
  $("#nqName").value=""; renderObQuests();
};
$("#obFinish").onclick = async () => {
  draft.diff = $("#obDiff").value; draft.restDay = Number($("#obRest").value);
  draft.spotify = $("#obSpotify").value.trim();
  draft.penaltyMode = $("#obPenalty").value; draft.alarmMode = $("#obAlarm").value;
  if(draft.pin) await setPinFor(draft, draft.pin);
  if(draft.mode === "founder" && !draft.deadlines.length) draft.deadlines = founderDeadlines();
  DB.hunters[draft.id] = draft; DB.active = draft.id; save();

  /* The hunter exists from this line on, so the goal services will work. If the
     student skipped step 2, committed is null and nothing is invented — the
     activation check will say the goal is missing, which is true. */
  let committed = null;
  try{ committed = obCommitGoal(); }
  catch(err){
    /* A goal that fails to save must not cost the student their whole setup. */
    console.warn("[onboarding] goal capture failed:", err && err.message);
    toast("Goal not saved", "Setup is complete, but the goal did not save. Add it from Grow \u203a Goals.", "blood");
  }

  $("#scr-onboard").classList.add("hidden");
  enterSystem();

  const wsub = committed && committed.quest
    ? `Welcome, ${draft.name}. Your first quest is set: “${committed.quest.name}” at ${fmt12(committed.quest.time)}. Clear it and the goal moves.`
    : draft.mode === "founder"
      ? `Welcome, ${draft.name}. Your business quest board is live — Learn, Build, Share. Every day. Foundation deadlines are counting down.`
      : `Welcome, ${draft.name}. Your daily quests are live. Clear them, or accept the penalty.`;
  setTimeout(()=> takeover({
    kind:"welcome", title:"THE SYSTEM IS ACTIVE", sub:wsub,
    reward: committed && committed.quest ? "Rank E · Level 1 · 1 goal live" : "Rank E · Level 1",
  }), 700);
};

