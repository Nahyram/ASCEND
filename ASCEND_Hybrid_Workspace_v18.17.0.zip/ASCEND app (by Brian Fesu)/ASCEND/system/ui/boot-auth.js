/* ASCEND — ui/boot-auth.js
   Loaded as a classic script; shared global scope. */
/* ══════════════ BOOT ══════════════ */
const BOOT = ["> initialising system core…","> loading hunter registry…","> verifying local storage…","> network: NOT REQUIRED","> the system is ready."];
(function boot(){
  const log = $("#bootlog");
  BOOT.forEach((l,i)=>{ const d = document.createElement("div"); d.textContent = l; d.style.animationDelay = (i*0.16)+"s"; log.appendChild(d); });
  setTimeout(async ()=>{
    /* The boot animation runs about 1.3s and hydration takes tens of
       milliseconds, so this almost always resolves instantly. Almost always is
       not a guarantee, and "the hunter list was empty on a cold start" is
       exactly the kind of race that reaches a student and not a test. */
    try{ await SYSTEM_READY; }catch(e){}

    /* 18.14 — guardedSave() stashes what could not be written, and until now
       nothing ever offered it back. A recovery copy nobody is shown is the same
       as no recovery copy: the student saw a toast, closed the tab, and the work
       went with it.

       Retried here rather than announced: on the overwhelmingly common path the
       storage problem is gone by the next load and the student never needs to
       know there was one. They are only told when it is still broken. */
    try{
      if(typeof recoverUnsaved === "function"){
        const held = recoverUnsaved();
        if(held){
          const ok = save();
          if(ok && typeof toast === "function")
            toast("Recovered", "Work that could not be saved last time has been written now.", "gold");
          else if(typeof toast === "function")
            toast("Still cannot save", "A copy of your last change is held for this session. Export a backup and free some space.", "blood");
        }
      }
    }catch(e){}

    $("#scr-boot").classList.add("hidden");
    if(DB.active && DB.hunters[DB.active]) enterSystem();
    else showLogin();
  }, BOOT.length*160 + 500);
})();

/* ══════════════ LOGIN ══════════════ */
function showLogin(){
  $("#scr-login").classList.remove("hidden");
  const list = $("#hunterList"); list.innerHTML = "";
  const ids = Object.keys(DB.hunters);
  if(!ids.length){ list.innerHTML = `<p class="tiny muted">No hunters on this device yet. Awaken one below.</p>`; }
  ids.forEach(id=>{
    const h = DB.hunters[id];
    const el = document.createElement("div");
    el.className = "hunter-card";
    el.innerHTML = `<img class="avatar" src="${h.avatar||DEFAULT_AVATAR}" alt="">
      <div style="flex:1"><div class="disp" style="font-size:15px">${esc(h.name)}</div>
      <div class="tiny muted">${rankName(h.rank)} · Level ${h.level}</div></div>
      <div class="rank-badge" style="width:40px;height:40px;font-size:20px">${h.rank}</div>`;
    el.onclick = () => tryLogin(id);
    list.appendChild(el);
  });
}
let pendingLogin = null;
function tryLogin(id){
  const h = DB.hunters[id];
  if(h.pin || h.pinHash){ pendingLogin = id; $("#pinFor").textContent = h.name; $("#hunterList").classList.add("hidden");
    $("#btnNewHunter").classList.add("hidden"); $("#pinPrompt").classList.remove("hidden"); $("#pinInput").focus(); }
  else { DB.active = id; save(); $("#scr-login").classList.add("hidden"); enterSystem(); }
}
$("#pinGo").onclick = async () => {
  const id = pendingLogin, h = DB.hunters[id], v = $("#pinInput").value;
  const wait = lockLeft(id);
  if(wait) return toast("Locked", `Too many wrong attempts. Try again in ${wait}s.`, "blood");
  const ok = await verifyPin(h, v);
  if(ok){ clearFails(id); DB.active = id; save(); $("#scr-login").classList.add("hidden"); enterSystem(); }
  else {
    noteFail(id);
    $("#pinInput").value = "";
    const w2 = lockLeft(id);
    toast("Denied", w2 ? `Wrong PIN. Login locked for ${w2}s.` : `Wrong PIN. ${5-(DB.sec.fails[id]||0)} attempts before lockout.`, "blood");
  }
};
$("#pinInput").addEventListener("keydown", e => { if(e.key==="Enter") $("#pinGo").click(); });
$("#pinBack").onclick = () => { $("#pinPrompt").classList.add("hidden"); $("#hunterList").classList.remove("hidden"); $("#btnNewHunter").classList.remove("hidden"); };
$("#btnNewHunter").onclick = () => { $("#scr-login").classList.add("hidden"); $("#scr-register").classList.remove("hidden"); };
$("#regBack").onclick = () => { $("#scr-register").classList.add("hidden"); showLogin(); };

/* ---------- photo import ---------- */
function readPhoto(file, cb){
  const fr = new FileReader();
  fr.onload = () => {
    const img = new Image();
    img.onload = () => { // downscale so localStorage doesn't choke
      const s = 320, c = document.createElement("canvas"); c.width = c.height = s;
      const ctx = c.getContext("2d");
      const m = Math.min(img.width, img.height);
      ctx.drawImage(img, (img.width-m)/2, (img.height-m)/2, m, m, 0, 0, s, s);
      cb(c.toDataURL("image/jpeg", .85));
    };
    img.src = fr.result;
  };
  fr.readAsDataURL(file);
}
let regAvatarData = "";
$("#regPhoto").onchange = e => { if(e.target.files[0]) readPhoto(e.target.files[0], d => { regAvatarData = d; $("#regAvatar").src = d; }); };

