/* THE SYSTEM v13 — ui/toast.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- toast ---------- */
function toast(title, msg, cls=""){
  const el = document.createElement("div");
  el.className = "toast " + cls;
  el.innerHTML = `<b>${esc(title)}</b><span class="tiny">${esc(msg||"")}</span>`;
  $("#toasts").appendChild(el);
  setTimeout(()=>{ el.style.opacity = 0; el.style.transition = ".4s"; setTimeout(()=>el.remove(), 400); }, 3200);
}


