/* THE SYSTEM v13 — ui/palette.js
   Ctrl+K. Everything the app can do, reachable by typing. */
"use strict";

let palIndex = [], palSel = 0, palRows = [];

const SEGLABEL = {
  "q-today":"Today's quests", "q-focus":"Focus session", "q-timed":"Deadlines & timed quests", "q-goals":"Goals",
  "st-skills":"Skill tree", "st-why":"Why you level up", "st-rec":"90-day record",
  "tr-quest":"Training quest", "tr-forge":"The Forge", "tr-wall":"Motivation wall",
  "l-books":"Books", "l-screen":"Screen", "l-tools":"Learning tools", "l-archive":"The Archive", "l-tutor":"AI tutor",
  "w-vault":"The Vault", "w-academy":"Wealth Academy", "w-careers":"Hall of Paths", "w-arena":"The Arena", "w-gate":"Open Gate",
  "am-mat":"Study materials", "am-in":"Import materials", "am-ward":"The Ward",
  "c-groups":"Study groups", "c-pacts":"Accountability pacts", "c-report":"Report for a teacher",
  "c-class":"Class work in", "c-limits":"What Circle deliberately omits",
  "s-perf":"Performance", "s-biz":"The business model", "s-launch":"Launch readiness",
  "bo-apply":"Applications & funding", "p-verify":"Evidence & personal boards", "g-health":"Device, record health & security",
  "bo-recommended":"Opportunities for you", "bo-all":"All opportunities", "bo-activities":"Activities & leadership",
  "bo-challenges":"System challenges", "b-projects":"Projects", "b-portfolio":"My portfolio", "b-journey":"Growth journey",
  "g-status":"Online Gate status", "g-sync":"Sync settings", "g-services":"External services", "g-data":"Your data",
  "ac-home":"Academy overview", "ac-subjects":"Subjects & syllabus", "ac-study":"Study session",
  "ac-practice":"Practice questions", "ac-cards":"Spaced review", "ac-errors":"Error log", "ac-exams":"Exam centre",
  "p-standing":"Standing & next milestone", "p-bosses":"Boss quests", "p-ach":"Achievements",
  "p-world":"The world map", "p-records":"Personal bests",
  "in-brief":"Today's briefing", "in-coach":"Patterns detected", "in-plan":"Proposed changes & recovery",
  "in-review":"Weekly review", "in-record":"Record & log",
};

function buildPalette(){
  palIndex = [];
  for(const v of VIEWS) palIndex.push({ grp:"Go", ic:v.ic, lab:v.label, sub:v.purpose, run:() => go(v.k) });

  $$(".tabpane").forEach(pane => {
    const key = (VIEWS.find(v => v.id === pane.id) || {}).k;
    if(!key) return;
    pane.querySelectorAll(":scope > .segbar:not(.sub) button").forEach(b => {
      const seg = b.dataset.seg;
      palIndex.push({ grp:"Open", ic:"▸", lab:SEGLABEL[seg] || b.textContent.trim(),
        sub:(VIEW[key] || {}).label, run:() => go(key, seg) });
    });
  });

  palIndex.push(
    { grp:"Do", ic:"◷", lab:"Start a focus session", sub:"The Enforcer, with breach detection", run:() => { go("quests","q-focus"); const b = $("#btnSession"); if(b) b.click(); } },
    { grp:"Do", ic:"♪", lab:"Toggle focus audio",    sub:"Offline tone generator",             run:() => { go("quests","q-focus"); const b = $("#btnFocusTone"); if(b) b.click(); } },
    { grp:"Do", ic:"◎", lab:"Start 50/10 pomodoro",  sub:"Fifty on, ten off",                  run:() => { const b = $("#btnPomo"); if(b) b.click(); } },
    { grp:"Do", ic:"✚", lab:"Add a goal",            sub:"Goal, targets, action steps",        run:() => { go("quests","q-goals"); const b = $("#btnAddGoal"); if(b) b.click(); } },
    { grp:"Do", ic:"▤", lab:"Clear every quest today", sub:"Only if you actually did them",    run:() => { const b = $("#btnAllDone"); if(b) b.click(); } },
    { grp:"Do", ic:"↺", lab:"Reset today",           sub:"Wipe today's ticks and start over",  run:() => { const b = $("#btnResetDay"); if(b) b.click(); } },
    { grp:"Do", ic:"◆", lab:"Access & keys",         sub:"Support the build, or enter a key",  run:() => { const b = $("#btnAccess"); if(b) b.click(); } },
    { grp:"Do", ic:"⬇", lab:"Export hunter file",    sub:"Encrypted backup of everything",     run:() => { go("set"); const b = $("#btnExport"); if(b) b.click(); } },
    { grp:"Do", ic:"◑", lab:"Change theme",          sub:"Void · Abyss · Daylight",            run:() => { go("set"); const s = $("#setTheme"); if(s){ s.scrollIntoView({block:"center"}); s.focus(); } } },
    { grp:"Do", ic:"⏻", lab:"Lock the System",       sub:"Back to the hunter list",            run:() => { const b = $("#btnLogout"); if(b) b.click(); } },
  );

  const h = typeof H === "function" ? H() : null;
  if(h) for(const q of (h.quests || [])){
    palIndex.push({ grp:"Quest", ic:"·", lab:q.name, sub:`${fmt12(q.time)} · ${q.cat}${q.mand ? " · mandatory" : ""}`,
      run:() => go("quests","q-today") });
  }
}

/* subsequence match — "fofs" finds "Focus session" */
function palScore(needle, hay){
  if(!needle) return 0;
  const n = needle.toLowerCase(), s = hay.toLowerCase();
  const direct = s.indexOf(n);
  if(direct === 0) return 1000;
  if(direct > 0) return 700 - direct;
  let i = 0, score = 0, streak = 0;
  for(const ch of s){
    if(ch === n[i]){ i++; streak++; score += 8 + streak * 2; }
    else streak = 0;
    if(i === n.length) return score;
  }
  return -1;
}

function palRender(q){
  const list = $("#palList"); if(!list) return;
  let items = palIndex;
  if(q.trim()){
    items = palIndex
      .map(it => ({ it, s: Math.max(palScore(q, it.lab), palScore(q, it.grp + " " + it.lab) - 40) }))
      .filter(x => x.s > -1).sort((a, b) => b.s - a.s).slice(0, 40).map(x => x.it);
  } else {
    items = palIndex.filter(it => it.grp === "Go" || it.grp === "Do").slice(0, 14);
  }
  palRows = items;
  palSel = Math.min(palSel, Math.max(0, items.length - 1));
  list.innerHTML = items.length
    ? items.map((it, i) => `<button class="pal-item${i === palSel ? " sel" : ""}" data-pal="${i}">
        <span class="ic">${esc(it.ic)}</span>
        <span class="lab">${esc(it.lab)}<em>${esc(it.sub || "")}</em></span>
        <span class="grp">${esc(it.grp)}</span></button>`).join("")
    : `<div class="pal-empty">Nothing matches that. Try a view name, a quest, or "focus".</div>`;
  $$("[data-pal]").forEach(b => b.onclick = () => palRun(Number(b.dataset.pal)));
}

function palRun(i){
  const it = palRows[i]; if(!it) return;
  closePalette();
  setTimeout(() => it.run(), 20);
}

function openPalette(seed = ""){
  if($("#palette")) return;
  const el = document.createElement("div");
  el.id = "palette";
  el.innerHTML = `<div class="pal-box" role="dialog" aria-modal="true" aria-label="Command palette">
      <input class="pal-in" id="palIn" placeholder="Search views, quests and commands…" autocomplete="off" spellcheck="false">
      <div class="pal-list" id="palList"></div>
      <div class="pal-foot"><span>↑↓ move</span><span>↵ open</span><span>esc close</span></div>
    </div>`;
  document.body.appendChild(el);
  el.onclick = e => { if(e.target === el) closePalette(); };
  const inp = $("#palIn");
  inp.value = seed.startsWith("go ") ? "" : seed;
  palSel = 0; palRender(inp.value);
  inp.oninput = () => { palSel = 0; palRender(inp.value); };
  inp.onkeydown = e => {
    if(e.key === "ArrowDown"){ e.preventDefault(); palSel = Math.min(palSel + 1, palRows.length - 1); palRender(inp.value); scrollSel(); }
    else if(e.key === "ArrowUp"){ e.preventDefault(); palSel = Math.max(palSel - 1, 0); palRender(inp.value); scrollSel(); }
    else if(e.key === "Enter"){ e.preventDefault(); palRun(palSel); }
    else if(e.key === "Escape"){ e.preventDefault(); closePalette(); }
  };
  setTimeout(() => inp.focus(), 20);
}
function scrollSel(){ const s = $(".pal-item.sel"); if(s) s.scrollIntoView({ block:"nearest" }); }
function closePalette(){ const el = $("#palette"); if(el) el.remove(); }

document.addEventListener("keydown", e => {
  if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k"){
    e.preventDefault();
    $("#palette") ? closePalette() : openPalette();
    return;
  }
  /* "/" opens search when you aren't typing in something */
  if(e.key === "/" && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)){
    const app = $("#app");
    if(app && !app.classList.contains("hidden")){ e.preventDefault(); openPalette(); }
  }
});
