/* THE SYSTEM v13 — content/merge.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════════════════════════════════════════════════════════
   v10 — LIBRARY EXPANSION · THE FORGE · THE ARENA
   ══════════════════════════════════════════════════════════════════ */

/* ---------- merge the data pack, then de-duplicate every shelf ---------- */
(function mergePacks(){
  try{
    if(typeof MORE_BOOKS === "object") Object.entries(MORE_BOOKS).forEach(([k,arr]) => {
      if(GENRES[k] && Array.isArray(arr)) GENRES[k].books = GENRES[k].books.concat(arr);
    });
    if(typeof NEW_GENRES === "object") Object.entries(NEW_GENRES).forEach(([k,g]) => { if(!GENRES[k]) GENRES[k] = g; });
    if(typeof MORE_SCREEN === "object") Object.entries(MORE_SCREEN).forEach(([k,arr]) => {
      if(SCREEN[k] && Array.isArray(arr)) SCREEN[k].picks = SCREEN[k].picks.concat(arr);
    });
    if(typeof NEW_SCREEN === "object") Object.entries(NEW_SCREEN).forEach(([k,g]) => { if(!SCREEN[k]) SCREEN[k] = g; });
    /* v11 pack */
    if(typeof MORE_BOOKS_V11 === "object") Object.entries(MORE_BOOKS_V11).forEach(([k,arr]) => {
      if(GENRES[k] && Array.isArray(arr)) GENRES[k].books = GENRES[k].books.concat(arr);
    });
    if(typeof MORE_SCREEN_V11 === "object") Object.entries(MORE_SCREEN_V11).forEach(([k,arr]) => {
      if(SCREEN[k] && Array.isArray(arr)) SCREEN[k].picks = SCREEN[k].picks.concat(arr);
    });
    if(typeof NEW_SCREEN_V11 === "object") Object.entries(NEW_SCREEN_V11).forEach(([k,g]) => { if(!SCREEN[k]) SCREEN[k] = g; });
    const dedupe = (rows) => {
      const seen = new Map();
      rows.forEach(r => {
        const key = String(r[0]).toLowerCase().replace(/[^a-z0-9]/g,"");
        const prev = seen.get(key);
        if(!prev) seen.set(key, r);
        else if(!prev[2] && r[2]) seen.set(key, r);   /* keep the version that carries a note */
      });
      return [...seen.values()];
    };
    Object.values(GENRES).forEach(g => { g.books = dedupe(g.books); });
    Object.values(SCREEN).forEach(g => { g.picks = dedupe(g.picks); });
  }catch(e){ console.warn("data pack merge failed", e); }
})();

const PAGE = 15;                       /* titles shown per shelf before "show more" */
let bookOpen = {}, screenOpen = {};    /* which shelves are expanded */

function matureOn(){ const h = H(); return !!(h && h.mature); }

async function askMature(){
  const h = H(); if(!h) return;
  if(h.mature){
    h.mature = false; save(); renderLibrary(); renderScreen(); renderMatBtn();
    toast("Mature shelves locked", "Hidden again. The System does not ask why.");
    return;
  }
  const ok = await sysConfirm("Mature shelves — 18+ only",
    "These shelves list adult titles: explicit sexual content, graphic violence, coercion, obsession and abuse themes.\n\n" +
    "This app was built for students aged 14\u201318. If that is you, close this box. It is not a challenge, and there is nothing on the other side worth lying for.\n\n" +
    "Are you 18 or older?", {ok:"I am 18 or older", cancel:"Close", danger:true, kick:"Age gate"});
  if(!ok) return;
  const sure = await sysConfirm("Confirm again",
    "Titles appear by name with content warnings and no descriptions. Read a content-warning list before opening any of them.",
    {ok:"Unlock", danger:true, kick:"Age gate"});
  if(!sure) return;
  h.mature = true; save(); renderLibrary(); renderScreen(); renderMatBtn();
  toast("Mature shelves unlocked", "Two shelves added. Content warnings are on every entry — read them.", "gold");
}

function renderMatBtn(){
  const b = $("#matBtn"); if(!b) return;
  const on = matureOn();
  b.textContent = on ? "Mature shelves: unlocked" : "Mature shelves: locked";
  b.className = "btn sm " + (on ? "gold" : "ghost");
}
if($("#matBtn")) $("#matBtn").onclick = askMature;

