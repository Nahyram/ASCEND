# THE SYSTEM v18 — architecture notes

Written after the v18 production-hardening pass. It records what changed, and —
more usefully for whoever picks this up next — what is still wrong and in what
order it should be fixed.

---

## The shape of the app

87 classic `<script>` tags in `index.html`, sharing one global scope. No modules,
no bundler, no build step. Opening `index.html` runs the app.

That is a real property, not only a limitation: this product's audience is
students on low-end Android phones in Ghana, and a build step is one more thing
between a change and a working app. But it has a cost, and the cost is now
measured rather than estimated.

    npm run test:arch

    87 classic scripts · 1 self-scoped
    734 top-level names: 494 functions · 197 const · 43 mutable (let/var)
    no load-order hazards

**Load order is the dependency graph.** Nothing declares what it needs. Every
dependency is satisfied by the accident of sequence in `index.html`, and the
only reason that works is that almost every cross-file reference happens inside
a function body, which does not run until the page has finished loading.

The two failure modes this produces have both shipped here:

1. **Two files declaring the same global.** The later one silently wins. No
   error, no log; the older feature just stops working. This happened five
   times (`renderGate`, `renderRecords`, `renderJourney`, `gotoSkills`, and one
   more) before a guard existed.
2. **Something used at load time that a later file declares.** For a `const` or
   `let` this is a TDZ error, which kills the rest of that script — again
   silently. `arch-check.js` now parses for this and reports zero.

Both guards are static and run in `npm test`. They are a floor, not a fix.

---

## What v18 changed

### The network has one door per concern

| layer | owns |
|---|---|
| `services/ai.js` | model requests: entitlement, daily cap, cache, timeout, context minimisation |
| `services/api.js` | external catalogues: timeouts, rate limit, TTL cache, stale-beats-nothing |
| `online.js` | the Open Gate's allowlisted, budgeted catalogue sweeps |

Nothing else calls `fetch()`, and `brain-test.js` fails if a view does. Before
v18, the single feature in the app that actually talked to a model —
`views/tutor.js` — went around all of it: no timeout, no cap, no cache, no
privacy filter, no entitlement check.

### Business logic left the views

`services/tutor.js` and `services/settings.js` are new. Both were extracted from
view files, and both extractions surfaced a defect that the mixed shape had been
hiding — a tutor with no timeout, and a settings save that deleted an invalid AI
endpoint and then reported success.

That is the argument for the separation, stated concretely: logic inside a
render function is logic nobody can test without a DOM, and logic nobody tests
is where this project's defects have lived.

**Still mixed:** `views/core-views.js` (13 remaining `save()` calls),
`views/v9-views.js`, `views/growth.js`, `views/forge.js`, `views/shelves.js`.
Most are one-line toggles where extraction would add indirection without adding
a testable rule. They should move when a rule appears, not on principle.

### Licensing says what it is

`services/entitlements.js` separates three answers that were one:

- `policy` — free by rule, enforced in code, cannot be sold
- `device` — granted here, unverifiable, `verified: false`
- `server` — the seam. **Refuses**, and does not fall back to `device` quietly.

A stub returning `allowed: true` would have made every log and screenshot look
server-backed while being exactly as unverified as the device path. When a
billing server exists, `ServerEntitlements` gets an implementation and no call
site changes.

### Offline is verified, not assumed

See `README-TESTING.md`. The short version: the service worker is now actually
executed by a test, all 107 precached files are confirmed to serve with the
network off, and `offlineAudit()` refuses to say "works offline" unless it has
checked the right cache, every asset class, and whether a worker is controlling
the page.

---

## Debt, in the order it should be paid

### 1. ES modules and a build step — the big one

**Why it is first:** every other structural problem in this file is a symptom of
734 names in one scope. With real `import`/`export`, both static guards become
unnecessary because the compiler enforces them, and the five collision defects
in this project's history become impossible rather than merely detected.

**Why it has not been done:** it touches all 87 files, and doing it before the
P0 wiring would have delayed every user-visible gain behind a refactor with no
user-visible gain of its own. That was the right call twice. It is getting less
right each release.

**How to approach it, given the constraints:**

- Do it leaf-first. `content/*.js` are pure data with no dependencies — convert
  those, and nothing else has to change on the same day.
- `core/` and `services/` next; `views/` last, because they depend on everything.
- Keep `index.html` runnable throughout by shipping a bundle. Anything that
  needs `npm run build` before it opens is a regression for this audience.
- `arch-check.js` already produces the dependency data a migration order can be
  derived from.

### 2. The 43 mutable globals

`let`/`var` at top level, mutated from anywhere. `DB` is the significant one —
it is the entire record and every file can write to it. `core/store.js` exists
as a storage seam but does not own `DB`; it should.

### 3. `views/core-views.js` is 251 lines doing five jobs

Status, training, deadlines, settings and the access key. It has been the site
of two shipped defects. Split by concern.

### 4. ~~Cloud sync has no server~~ — closed in 18.6/18.7

The server was built in 18.6 and connected in 18.7. `services/cloud.js` now ships
a `rest` driver alongside `local` and `loopback`, and `sync-test.js` runs the real
client against the real server rather than proving a shape.

What 18.6 taught, and what is worth keeping: for one release both halves were
complete, both suites were green, and they had never spoken. `cloud.js` carried a
comment describing the adapter instead of containing one, and no suite could tell,
because every suite tested one side. **A seam nothing crosses is a seam nothing
tests.**

Still open here: `entitlements.js` and `cloud.js` both hold a notion of what an
account includes. `cloud.js` now gets the real answer from `/me`; `entitlements.js`
has not been pointed at it yet.

### 5. `renderFrontier` still wraps three renderers in `try{}catch(e){}`

Three empty catches. A view that fails silently is how the Open Gate lessons
went missing for two releases.

---

## Rules this codebase has earned

Each of these came from a defect that shipped.

1. **Assert on the result, never on the intent.** A precache generator that
   reported success without reading its own output; a `SKIP_WAITING` check that
   passed on a string thirty lines from the handler; an `offlineAudit()` that
   reported readiness from a cache it found by guessing.
2. **A fix is not durable until a check fails without it.** Three v15 fixes
   returned in v16 because nothing failed in their absence.
3. **Prose is the wrong place to hold a guarantee.** A check asserting on one
   phrase in a note broke when the note was reworded to say something stronger.
   Assert on structured fields.
4. **A guard that cannot tell a comment from code trains people to ignore it.**
   Strip comments before matching — the v18 offline suite failed its own
   version check on the comment explaining the rule.
5. **Never report a success that did not happen.** The settings save that
   deleted an invalid endpoint and said "Saved" is the same class of error as an
   offline audit that says "works offline" without checking.
