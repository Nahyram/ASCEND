# THE SYSTEM — setup, install, publish

A Solo Leveling style daily quest system built from your timetable.

It runs entirely on the device: no account, no server and no internet needed after the first load, with everything stored in the browser's local storage on that device only. That is the default and it is not a degraded mode — every quest, subject, mastery record and project works this way forever.

As of 18.7 it can also connect to an ASCEND server, which is entirely optional and adds four things and nothing else: backup, the same account across laptop/phone/tablet, the AI tutor, and server-held entitlements. Set the address in **System → Gate → Set server**. When the connection drops the app keeps working and queues the changes; when it returns they sync. Losing the server never costs a student their record — that rule is enforced in code and checked in `sync-test.js`.

---

## New in v18 — the hardening pass

No new features. v18 is the release where several things the app *said* were
true became true, and where the boundaries it claimed became boundaries a test
enforces.

**The tutor now goes through the AI service.** It had been calling the network
directly for four releases while `services/ai.js` sat beside it holding the
timeout, the daily request cap, the response cache, the privacy filter and the
entitlement check. On a school phone that mattered most for the timeout: a
tutor endpoint that accepted the connection and never answered used to hang the
Ask button until the operating system gave up. No view reaches the network now,
and a test fails if one tries.

**Setup asks what you are actually trying to do.** A goal, in your own words, is
broken into targets and steps, and the step you pick becomes a real quest on
your board before you finish calibration. Clearing it moves the goal. Previously
the app had a whole goal engine and never asked.

**Offline is verified rather than assumed.** The service worker is executed by a
test against a mock cache with the network switched off, and all 107 precached
files are confirmed to serve. The readiness check inside the app was rewritten
too: it used to inspect whichever cache happened to sort last and look only at
scripts, so a build missing every stylesheet reported "works offline".

**The cache is versioned.** It was still named `system-v17` in a v18 build,
which means it never invalidated — a release could ship and the old files keep
being served.

**Access keys say what they are.** Redeeming one used to announce FULL ACCESS
GRANTED / All features unlocked. Both halves were wrong: nothing was verified
(the check runs on your own device against a list in the page), and nothing was
locked (every learning feature is free by rule, enforced in code). It now says
the key was recorded on this device, and explains that this is a receipt rather
than a lock. See **Honest limits** below — that section was already right; the
app just wasn't matching it.

**A settings save that rejects something says so.** An AI endpoint that wasn't
https used to be deleted in silence and the save reported as successful.

**A panel that fails to draw now says it failed** and is listed in
Settings › Studio, instead of leaving a gap that looks like an empty section.

Running the checks: `npm ci && npm test`. See `README-TESTING.md` for what each
suite refuses to take on trust, and `ARCHITECTURE-v18.md` for the debt that is
still outstanding — chiefly that this is 87 classic scripts sharing one global
scope, and the conversion to real modules is the next significant piece of work.

---

## New in v14 — the System reads you back

The System stopped being a place you record your day and started being something
that reads the record and argues with you about it. All of it is computed on your
own device from quests you have already cleared or missed. Nothing is uploaded and
no AI service is required — with no endpoint configured, which is the default,
every feature below still works.

- **Insight → Brief.** What to do first today, and the sentence explaining why it
  was picked. Then the rest, ranked, each with its own reason.
- **Focus rating.** One tap, 1–5, on Home. A low rating changes *what* is
  suggested — review instead of new material — never whether you are asked.
- **Insight → Patterns.** The weekday your week falls apart on. The hours where
  your follow-through is cheapest. The quest that is on the board but not in your
  life. Each one prints how many observations it came from, and the engine stays
  quiet when the record has nothing real in it.
- **Insight → Plan.** Proposed changes to your board — pause quests you never do,
  move one into your strongest hours, demote a mandatory quest you miss most
  weeks. Accept, snooze, or refuse. Nothing is applied unless you say so, and
  every answer is logged.
- **Recovery.** Two collapsed days in a row and the System offers a shorter board
  for a few days with penalties suspended. A bad week should not cost a good month.
- **Insight → Review.** Sunday's numbers, and one change for next week.
- **The goal ladder.** Year → six months → 90 days → month → week, so a step you
  clear tonight is traceable to something you actually want. "Break this down for
  me" turns a sentence into three targets and about ten concrete steps.

### And the Path — where progression finally lives in one place

- **Standing.** Level, title, rank, and what the next rank is actually waiting for.
  Rank is no longer just level: it needs quests cleared, a streak held and bosses
  put down, so it cannot be reached by waiting.
- **Bosses.** Summon the thing you have been avoiding — a topic that keeps costing
  marks, a paper you have not sat, a project stuck at 70% — and it becomes five or
  six stages with checkboxes. Stages pay; finishing pays properly.
- **Achievements and titles.** 27 achievements across progression, consistency,
  learning, milestones and exploration, plus three secret ones. Titles are earned
  from them, equipped by choice, and change nothing except what you are called.
- **The world.** Eight areas that open as you progress. Nothing is locked away —
  every one is already reachable from the menu on day one. Opening an area is the
  System explaining what that part of it is for.
- **Personal bests.** You against yourself, recorded as they happen, so a bad month
  cannot erase a good one.

Clearing a quest twice in a day pays once. That is deliberate.

### And the Academy — where the actual studying lives

- **Subjects and syllabus.** Paste an outline and it builds the tree. Every topic
  starts at "not started", which is accurate rather than discouraging.
- **Mastery you cannot fake.** Marking a topic studied twenty times leaves it at
  25%. Getting questions right — including a harder one — moves it. Reaching
  *mastered* also needs recall after a real gap. Re-reading feels like progress and
  is not, and the bar refuses to pretend otherwise.
- **Mastery fades.** A topic untouched for four months drops back, but never below
  halfway. Forgetting is not the same as never having learnt it.
- **Practice.** Your own questions, drawn weakest-topic-first. Wrong answers go to
  the error log with a *cause* — careless and didn't-know-it need opposite fixes.
- **Mistakes become bosses.** Three unresolved errors on one topic and the System
  offers to turn it into a five-stage recovery chain on your Path.
- **Spaced review.** Cards come back at widening gaps, shortening when you miss.
- **Exam centre.** Register a date and the revision plan is rebuilt every time you
  open it, from days left and what you actually know. If the hours genuinely do not
  add up, it tells you, and tells you what to drop.
- **Grades.** Recorded and compared to your own target. The System will not predict
  a final grade — it does not know your board's boundaries and says so.

### Beyond — competitions, programmes and activities

THE SYSTEM ships **no list of opportunities**, on purpose. It cannot check whether
a deadline is still real, and showing you last year's would be worse than showing
you nothing. Add the ones you find and it handles the rest: deadline countdowns, a
checklist, a preparation plan on your Path, and a match that always shows its
reasoning. A passed deadline outranks everything else, however good the fit looks.

It also flags the shapes that get students taken advantage of — a fee to apply, a
shortened link, a guaranteed outcome, an application by direct message — as
questions to ask, not accusations. And it never tells you to send money, share a
password or send ID.

### Build — projects and a portfolio worth showing

Projects with weighted milestones, evidence as links you control, and a reflection
that takes ten minutes and is the part that lasts. Nothing reaches your portfolio on
its own: a project has to be finished, evidenced and reflected on, and then chosen
by you. A skill claim without evidence is refused — "Programming +50" means nothing
to anybody.

### The Gate — an account, if you ever want one

Everything above works with no account and no connection. Signing in adds a backup
and a second device, and nothing else. Sign out and every byte stays where it is. If
a sync fails it says so calmly and retries — your local copy is always the one that
matters.

### Applications — and funding you can actually read

Scholarships and programmes get an application package that points at projects,
results and activities you already have, so nothing is typed twice. Funding is
itemised line by line, and "not specified" never quietly becomes "free" — the two
costs most often left out are travel and accommodation, and they are the expensive
ones. Eligibility comes back with five possible answers, and the strongest thing the
System will ever say is *"nothing you have told me contradicts this"*. It cannot see
your passport or your transcript and will not pretend to.

It also notices when a recommendation letter is outstanding with two weeks left —
that is the item that depends on somebody else's calendar, so it is the one to start
first.

### Evidence — and no fake leaderboard

Six verification states, and you cannot mark your own achievement verified. That
would make the word mean nothing. There is no global leaderboard either, because
there is no user network yet, and a ranking built from a population of one would be
an invention rather than a feature. What you get instead is you against your own
record — which the design brief says should be the main comparison anyway.

### Six areas instead of thirteen tabs

Home, Learn, Grow, Quests, Progress, System. Everything that was there is still
there, every bookmark still works, and you now navigate by what you are trying to do
rather than by the order the app was built in.

### Built for a phone on a real data bundle

Data saver actually stops the lookups rather than just dimming pictures. A slow
connection skips them instead of leaving you watching a spinner. Install is offered
after a few days of real use, never on your first visit. And a new version waits
until you say so instead of reloading over whatever you were writing.

### Circle — and what is deliberately not in it

Study groups, accountability pacts, and a progress report **you** generate and hand
to a teacher or parent. There is no messaging, no student directory, no public
profiles and no photo sharing — not because they were hard, but because each one
needs somebody moderating it, and there is nobody. The app says so plainly under
"What is not here" rather than pretending they are coming.

The report gives an adult your study consistency, subject progress, exam dates and
weak areas. It never includes your reflections, your notes, or anything you marked
private. That is on purpose: someone who can read everything you write changes what
you are willing to write.

You can also paste homework straight from the board or a group chat and it becomes
deadlines.

### Studio — the honest back office

How fast each section renders on *your* device, what your record is costing in
storage, and a list of the things that have **not** been tested and why. It also
holds the business model: 34 features are marked never-paid — the Academy,
practice, revision, quests, projects, offline, export — and the code physically
refuses to put any of them behind a payment. And the launch checklist, which
currently says not ready and has no override button.

### The loop, on your Home screen

LEARN → DEVELOP → DISCOVER → BUILD → ACHIEVE → CONNECT → GROW → FUTURE, filled in
from your own record. It points at the **earliest** gap, not the furthest thing you
have reached — three projects and no mastered topic means you skipped the start.

### The Circle — studying with people, without the risks

Study groups, an accountability pact, and homework you paste in that becomes
deadlines. There is **no messaging, no student directory, no public profiles and no
photo sharing** — those need somebody moderating reports and handling it when an
adult contacts a child, and there is no such operation behind this app. Building
them anyway would be a hazard with a study app around it.

Teachers and parents get a report **you generate and hand over**. No account reads
your device. Your reflections, notes, money records and AI conversations are never
in it, and the report says so at the bottom.

### Studio — what it costs, what it can't do, and whether it's ready

Honest instrumentation rather than a dashboard: how fast each section renders on
*your* device, how big your record is, and a permanent list of what has **not** been
tested and why — load, soak and real-device testing all need something deployed,
and inventing those numbers would be worse than admitting they're missing.

The launch checklist has no override. It currently says not ready for a public
launch, and lists exactly why.

And the money rule is enforced in code, not in a promise: **nothing that helps you
learn can ever be put behind a paywall.** The Academy, practice, the error log, the
revision planner, quests, projects, the Archive, offline — the function that
registers a paid feature *refuses* anything on that list. What's paid is what
actually costs money to run: sync, cloud backup and online AI.

### The loop, on your Home screen

LEARN → DEVELOP → DISCOVER → BUILD → ACHIEVE → CONNECT → GROW → FUTURE, filled in
from your own record. It points at your *earliest* empty stage, not your furthest —
three projects with no finished topic means you skipped LEARN, and a system that
congratulated you for that would be flattering you.

Old saves open untouched — same storage key, same fields, nothing removed.

---

## 1. Use it right now (laptop, no internet)

Double-click **index.html**. That's it. It opens in your browser and works offline forever.

Everything works from a plain file: login, profile photo, quests, alarms and screen takeover, XP, ranks, penalties, workouts, deadlines, records, export/import.

## 2. Install it as a real app (phone, watch face, laptop dock)

To get a home-screen icon that opens fullscreen with no browser bars, the files need to be served over `https`. Free, takes about three minutes:

1. Go to **app.netlify.com/drop**
2. Drag this whole folder onto the page.
3. It gives you a link like `the-system-xyz.netlify.app`.
4. Open that link on your phone.
   - **Android / Chrome:** menu → *Add to Home screen* → *Install*
   - **iPhone / Safari:** Share → *Add to Home Screen*
5. It now behaves like a native app, fullscreen, and works with the phone in airplane mode.

Alternatives: GitHub Pages, Vercel, Cloudflare Pages. Same drag-and-drop idea.

## 3. Move your hunter between devices

Settings → **Export hunter file** → gives you a `.json`. Open the app on the other device → Settings → **Import hunter file**. Level, XP, quests, streak and photo all travel with it.

## 4. Getting paid

Settings → **Creator console**:

- Paste your payment link. In Ghana, **Paystack** (paystack.com) is the fastest route — it takes Mobile Money and cards, and gives you a hosted payment page link. Outside Ghana: Stripe Payment Links, Gumroad, or Lemon Squeezy (Lemon Squeezy handles VAT/tax for you, which matters once you sell abroad).
- Save it. Every user now sees a **Support / unlock full access** button pointing at your page.
- When someone pays, ask for their hunter name, type it into **Generate key**, send them the key. They paste it into *Have an access key?* and unlock.

**Be honest with yourself about this key system.** It is offline, so it is checkable but not enforceable — a determined person can open the file and bypass it. That's the trade you make for "works with no internet." If you later want real enforcement you need a server to verify keys, which means the app is no longer fully offline. My advice: sell it as a one-time purchase, keep the price low enough that paying is easier than cheating, and put your energy into the product rather than the lock.

Also: nothing in the app is currently gated behind `unlocked`. Decide what you want free and what you want paid, then gate those features. Sensible split — free: quests, XP, ranks, penalties. Paid: multiple hunters, custom quest packs, deadline tracking, records export.

## 5. Publishing to the app stores

- **Google Play:** use **PWABuilder.com** — paste your Netlify link, it packages the PWA into an Android app you can upload. One-time $25 developer fee.
- **Apple App Store:** same tool can generate an iOS wrapper, but Apple is stricter about "just a website" submissions. $99/year. Add real native value (background alarms, widgets) before trying.
- **Smart watch:** be aware — this is where the honest wall is. See below.

---

## What this can and cannot do

I built everything that a device will actually let a web app do, and I want you to know where the edges are rather than discover them later.

**It does:**
- v3 System-window UI: double-framed glowing panels, centred window headers, a pulsing alert icon on every takeover, red WARNING styling for penalties, gold [ COMPLETE ] tags on cleared quests, and drifting mana particles — all pure CSS, still fully offline.
- Per-quest day selection: tap the S M T W T F S letters under any quest (onboarding or Settings) to choose exactly which days it runs, weekends included. Every quest keeps at least one active day.
- Full screen takeover for a quest when its time hits, while the app is open — glowing system window, sound, vibration, snooze, complete.
- OS notifications when the app is backgrounded (Android/desktop, if you grant permission).
- Penalties, XP loss, rank demotion pressure, streaks, records.
- Daily generated workout quests from your chosen path (calisthenics / gym / home / martial arts / mixed) at three difficulty levels, with a rest day.
- Deadlines with countdowns for exams and submissions.
- Offline focus tone generator plus your Spotify playlist when you're online.

**It does not, and no web app can:**
- **Take over a locked phone screen like an alarm clock.** Real alarms are an OS-level privilege. A web app can only seize the screen while it's running, and fire a notification otherwise. To get a true alarm that wakes a sleeping phone, the app has to be native (Android: `AlarmManager` + a full-screen intent; iOS: essentially not allowed at all outside Apple's own Clock).
- **Control the device like JARVIS.** Nothing in a browser can lock your other apps, block Instagram, or run the phone. Even native apps need heavy special permissions for a fraction of that, and iOS refuses most of it. If blocking distractions matters, pair the System with your phone's built-in Focus / Digital Wellbeing rules — the System tells you what to do, the OS enforces it.
- **Run on a smartwatch as a real app.** Wear OS and watchOS apps must be built natively (Kotlin/Compose, or SwiftUI + Xcode). What you *do* get free: if you install the PWA on your Android phone and grant notifications, quest alerts appear on a paired Wear OS watch, with vibration. That covers most of what you'd actually use a watch for here. A true watch app is a separate build, and it's the one thing in your list I can't hand you as a file.

**One more thing, said once.** The schedule this is built on is 5:20am to 9:30pm with almost no unstructured time. That's fine as an ambition; it is unforgiving as a daily standard, and a system that punishes every miss can turn into a machine for feeling like a failure. So the penalties in here are deliberately study, reflection and effort based — never food, never sleep, never anything physically harmful. If the penalty list starts feeling like a stick you're beating yourself with, turn penalties off in Settings and let the streak do the work. Consistency is the goal. Self-punishment isn't.


## Founder Playbook (from the 90-day plan)

The Founder path's deadlines follow this arc — here's the thinking behind them:

**Days 1–14 — tools.** Get fluent with an AI chat assistant (writing, brainstorming), Canva (design), Google Docs/Drive (editing, storage). Output: you can produce a clean, professional PDF.

**Days 15–28 — first 10 products.** Small, niche, curriculum-specific: revision planners, exam countdown calendars, formula sheets, AI prompt packs, flashcard templates, essay planners. Priced $3–9. Avoid generic planners — crowded market. Build for the curriculum you actually study.

**Days 29–60 — catalog to ~25 quality products + one bundle.** Bundles ($29–49) raise average order value: notes + planners + prompt pack + trackers in one purchase.

**Days 61–90 — distribution.** Short videos (TikTok / YouTube Shorts / Reels): "3 mistakes [IGCSE] students make", one free tip per video, store link in bio. Consistency beats virality.

**Where to sell, honestly ranked for Ghana:**
1. **Selar** — built for West Africa, pays out to Mobile Money, easiest first store.
2. **Paystack storefront/payment links** — direct sales to Ghanaian buyers.
3. **Payhip / Gumroad** — great for international buyers, BUT payouts run through PayPal/Stripe/Payoneer, which are limited in Ghana. Set up Payoneer with a trusted adult before listing here.
4. **Etsy / Teachers Pay Teachers** — real buyer traffic, but both require 18+, fees, and international payout rails. Adult-run, later stage.

**Reality check:** first sale typically takes weeks, not days. 10 sales/month at ~$10 ≈ $100/month is a strong first milestone. Nobody can guarantee income — the deadlines above are the work that gives the numbers a chance.


## Security (v4)

What this build now protects against:
- **Malicious hunter files.** Imports are strictly validated — every field is type-checked, length-capped and rebuilt before it touches storage. A tampered "hacked hunter" file shared around school can no longer inject junk or scripts.
- **Script injection.** A Content-Security-Policy blocks remote scripts, plugins and form exfiltration even if something slips through. Keep the app as one file; don't add remote <script> tags.
- **PIN snooping.** PINs are no longer stored as plain text — they're salted and SHA-256 hashed. Existing hunters upgrade automatically on next login.
- **Key extraction.** The old access keys could be computed from the source code. Now the source holds only SHA-256 hashes (`KEY_HASHES` in index.html). To generate sellable keys, run this in any browser console, give the KEY to the buyer, paste the HASH into KEY_HASHES and redeploy:

```js
(async () => {
  const k = "SYS-" + crypto.getRandomValues(new Uint32Array(2))
    .reduce((s,n)=>s + n.toString(36).toUpperCase().slice(0,4) + "-","").slice(0,-1).replace("-","-");
  const h = [...new Uint8Array(await crypto.subtle.digest("SHA-256",
    new TextEncoder().encode(k)))].map(b=>b.toString(16).padStart(2,"0")).join("");
  console.log("KEY (send to buyer):", k, "\nHASH (paste into KEY_HASHES):", '"'+h+'"');
})();
```

**Honest limits — read this.** This is a client-side app: a determined person with DevTools can still flip `unlocked` on their own device. The hashes stop key sharing and source-reading, not local tampering. Real licensing needs a server — that's a Phase 2 problem, not a launch blocker at GHS 15 a copy. Also: the app can't protect your *business* from fraudsters. Rules that do: only accept payment through Paystack/Selar (never gift cards, never "pay via DM"), verify the payment reference in your Paystack/Selar dashboard before sending a key, and never share OTPs or your MoMo PIN with anyone claiming to be "support".

## AI Tutor (v4)

The Tutor tab is curriculum-aware — subjects come from the hunter's chosen curriculum.

**Offline mode (default, free):** instant study cards for high-value topics (quadratics, PEEL essays, spaced repetition, past-paper method, exam-day protocol, timed pacing…) plus a Master Prompt builder — it writes an expert tutor prompt tuned to the student's curriculum and subject, ready to paste into any free AI chat app. No account, no cost, works with zero network.

**Online mode (optional, adult required):** true in-app AI answers. Never put an API key in this app — it would be stolen from the source. Instead an adult deploys this free Cloudflare Worker as a proxy, puts the API key in the Worker's environment variables, and the student pastes the Worker URL into Settings → AI tutor endpoint:

```js
export default {
  async fetch(req, env) {
    const cors = { "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS" };
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    if (req.method !== "POST") return new Response("POST only", { status: 405, headers: cors });
    const { system, messages } = await req.json();
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json",
        "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-haiku-4-5", max_tokens: 700,
        system, messages: (messages || []).slice(-10) })
    });
    const d = await r.json();
    const reply = (d.content || []).filter(c => c.type === "text").map(c => c.text).join("\n") || "No reply.";
    return new Response(JSON.stringify({ reply }), {
      headers: { "content-type": "application/json", ...cors } });
  }
};
```



### Free-tier Worker variant (Gemini — no card needed)

Same app, same Settings field. This Worker calls Google's Gemini free tier instead, so no payment method is required anywhere. In the Worker's Settings → Variables, add `GEMINI_API_KEY` (from aistudio.google.com). Includes a shared daily cap so a stranger can't drain your quota:

```js
export default {
  async fetch(req, env) {
    const cors = { "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS" };
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    if (req.method !== "POST") return new Response("POST only", { status: 405, headers: cors });
    const { system, messages } = await req.json();
    const contents = (messages || []).slice(-10).map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: String(m.content).slice(0, 4000) }]
    }));
    const r = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + env.GEMINI_API_KEY,
      { method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: system || "" }] },
          contents,
          generationConfig: { maxOutputTokens: 700 }
        }) });
    const d = await r.json();
    const reply = d?.candidates?.[0]?.content?.parts?.map(p => p.text).join("\n")
      || "No reply (check quota or key).";
    return new Response(JSON.stringify({ reply }), {
      headers: { "content-type": "application/json", ...cors } });
  }
};
```

Deploy steps: dash.cloudflare.com → Workers & Pages → Create → Worker → paste code → Deploy → Settings → Variables → add GEMINI_API_KEY → copy the workers.dev URL → paste into the app's Settings → AI tutor endpoint → press **Test endpoint**.

Why not just put the key in the app? Because the site's source is public — anyone can view it and steal the key within minutes, burning your quota or the account owner's money and killing the Tutor for every paying customer. The key must live server-side. Always.

Costs (Anthropic variant) are per message and billed to the adult's API account — this is the "AI features are premium-only" rule from the business plan. Add a per-day cap in the Worker before giving it to paying users.


## v5 — Goals, Vault, Codex

- **Goal planning** (Deadlines tab): digitized from the classic worksheet — one goal, up to 3 targets, action steps under each. Steps pay +10 XP.
- **The Vault** (Records tab): pay-yourself-first money jars. Every amount received splits automatically: 10% Freedom (invest only — the app literally refuses to let you spend it), 10% Learn, 10% Long-term, 10% Play, 10% Give, 50% Needs. Splitting pays +15 XP.
- **Codex**: a rotating daily principle on the Status window, and new mindset cards in the Tutor (money blueprint, pay-yourself-first, path to mastery).

Reading list that inspired the Codex and Vault (worth owning legally — support the authors): *Secrets of the Millionaire Mind* — T. Harv Eker; *Mastery* — Robert Greene; *The Diary of a CEO: The 33 Laws of Business & Life* — Steven Bartlett. The app contains only short original summaries of ideas, never the books' text — do not bundle book PDFs with the app; distributing them is piracy and would sink the store accounts you're building.

Note on the aesthetic boards: routine and phrases were folded into the Codex and quest templates, but the artworks themselves (anime characters, manga panels) are other people's IP — never embed them in the app or marketing.


## v6 — The Archive (level-gated story)

The Status tab now carries **The Mastermind's Winter Arc** — the creator's original 17-chapter story (pen name Nelykeh) — as sealed academy records. The Prologue is open to everyone; each further chapter unlocks at a rising Level (2, 3, 4, 6, 8 … 30). Reading happens in an in-app reader; the story ships in `lore.js` and works fully offline.

Why it matters commercially: the story is now a retention engine (level up to read on) and a second product (sell the full arc as an ebook to readers who don't want to grind). If any part of this story is not your original work, remove lore.js before selling.

## v7 — Motivation wall + Combatant path

- **Motivation wall** (Training tab): your four saved images, tap to view full screen. They live in `assets/` — replace the files (same names) any time to change the wall.
- **Formidable Combatant** training path: the classic daily quest, built natively — Push-ups / Sit-ups / Squats / Run. Novice 30·30·30·3km, Standard 60·60·60·6km, Brutal is the full 100·100·100·10km. Work up the tiers; jumping straight to Brutal every day is how real hunters get injured.
- Both new Codex lines rotate on the Status window.

**v18 — resolved.** The wall's four third-party images (an anime screenshot and two quote cards carrying another page's logo) were replaced with original typographic cards generated for this product. `brand-poster.jpg` and `brand-logo.jpg` are your own artwork and were kept. The whole `assets/` folder now ships as-is, so this is no longer something to remember before a launch. If you add new images, the v5 rule still applies to those.

## v8 — The rebuild: nothing crammed, nothing sugar-coated

The whole interface was reorganised so every screen does one job:

- **7 tabs** — Status · Quests · Train · Wealth · Library · Tutor · Settings — and inside a tab, **segmented sub-tabs** (e.g. Quests → Today / Focus / Timed / Goals) instead of one long scroll of stacked panels.
- **Status** now holds only identity + today: the Daily Transmission (quote of the day + codex line), the status window, penalties, next quest. Records moved to its own segment. **The Archive was removed from Status** and lives in Library → Archive.
- **Motivation Wall rebuilt** as a full-width carousel (arrows, dots, auto-advance every 8s, tap for fullscreen) under Train → The Wall. Swap images in `assets/`, same filenames.
- **Payment moved out of Settings.** Buyers now find "Support / unlock" under the **◆ Access** button in the top bar. The Creator console (payment link, pitch, counter endpoint, key generator) stays in Settings — that part is yours, not theirs.

### Daily Transmission
One serious quote per day — Sun Tzu, Marcus Aurelius, Musashi, Machiavelli, anime strategists (Lelouch, Itachi-tier lines), movie and book characters, plus Kael Orion from the Archive. All quotes are single short lines with attribution; several are original System directives. Rotates on the calendar date.

### Wealth tab
- **Vault** — the jars from v5, unchanged, plus **The Ledger Speaks**: a blunt advisor that reads the user's actual money log (income vs outflow over 30 days, Play-vs-Learn spending, untouched Freedom jar) and tells them the truth about it. No soft language, no shame-spirals either — behaviour, numbers, and what to change.
- **Academy** — 12 sequential lessons on how large fortunes are actually built: ownership vs wages, pay-yourself-first, compounding, assets vs liabilities, skill stacking, leverage (code & media), selling, the earn/keep/multiply ladder with Ghana-specific notes (T-bills and licensed funds yes; "double your money", betting and recruitment schemes are named as the scams they are), delayed gratification, pricing/negotiation, systems, reputation. Each lesson pays +15 XP, next unlocks after the previous.

### Library tab
- **Books** — the user picks genres (13 available, choose as many as you like — no cap), and the System recommends 5 titles per chosen genre with a one-line blunt pitch. "Finished it" pays +30 XP after a confirm ("The System takes your word — don't make it worthless").
- **Archive** — the level-gated novella, moved here from Status.

### Focus, honestly enforced
- **Focus audio** now has three synthesised modes — Deep Drone (brown noise + 55 Hz sine), Pulse 40 (200/240 Hz split L/R for a 40 Hz beat — headphones), Rainfall (wandering band-passed noise) — with a volume slider and hot-swapping.
- **Focus Session (the Enforcer):** pick 25/50/90 min, keep a blacklist of sites/apps, begin. The app goes fullscreen, starts the audio, and **watches the door**: leaving the tab/app during a live session is logged as a breach — on return the user gets a red System window, −10 XP off the session reward, and the count on their record. Clean sessions pay XP + Discipline.
- **Important honesty:** a web page **cannot** force other apps closed or block other sites at the OS level — any web app claiming otherwise is lying. The System says so in the UI and ships an **Enforcement Guide** instead: Android Focus Mode/Digital Wellbeing, iOS Screen Time (+passcode held by someone trusted), Windows Focus Sessions, LeechBlock, and DNS-level filtering (e.g. NextDNS) for real blocking. Keep that honesty when you sell this — it's a feature, not a gap.

### Hunter counter (real server, no fake numbers)
The top-bar chip "◈ N" shows how many devices run the System — but **only from a real endpoint you deploy**. No endpoint (or offline) = the chip shows the last real cached number or stays hidden. It never invents a figure; a fake counter is fraud and buyers eventually find out.

Deploy this free Cloudflare Worker (Workers → Create → paste; add a KV namespace binding named `COUNTS`):

```js
export default {
  async fetch(req, env) {
    const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type",
                   "Access-Control-Allow-Methods": "POST, OPTIONS", "Content-Type": "application/json" };
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST only" }), { status: 405, headers: cors });
    let id = "";
    try { id = String((await req.json()).id || "").slice(0, 32); } catch (e) {}
    if (/^[a-f0-9]{16,32}$/.test(id)) {
      const seen = await env.COUNTS.get("id:" + id);
      if (!seen) {
        await env.COUNTS.put("id:" + id, "1");
        const n = parseInt(await env.COUNTS.get("total") || "0", 10) + 1;
        await env.COUNTS.put("total", String(n));
      }
    }
    const count = parseInt(await env.COUNTS.get("total") || "0", 10);
    return new Response(JSON.stringify({ count }), { headers: cors });
  }
};
```

Paste the Worker URL into Settings → Creator console → "Hunter-count endpoint". Each install sends only a random anonymous id — no names, no data, nothing personal.

### Security (v8)
- **PINs upgraded to PBKDF2-SHA256, 150,000 iterations, 16-byte random salt.** Old v4 salted-SHA256 PINs verify once and are silently re-hashed to the new scheme on the next successful login.
- **Login lockout:** 5 wrong attempts locks that hunter's login with a doubling cooldown (60 s → capped at 30 min).
- **Auto-lock:** optional — 5/15/30 minutes of inactivity returns to the login screen (only when a PIN is set). Set or change the PIN any time in Settings → Security.
- **Encrypted export:** tick "Encrypt" and the hunter file is sealed with AES-256-GCM, key derived from a passphrase via PBKDF2. Wrong passphrase = file refuses to open. There is no recovery — that's the point.
- **Access keys fixed:** the Creator console now generates cryptographically random keys (`SYS-XXXX-XXXX-XXXX`) and prints the SHA-256 hash to paste into `KEY_HASHES` before shipping a build. (v7 had a dead reference here — key generation crashed. v8 repairs it.)
- `<meta name="referrer" content="no-referrer">` added; import sanitiser extended to every new field (genres, books, lessons, money log, blocklist, auto-lock, pin record) with strict bounds.

### Tone (v8)
The System now speaks plainly everywhere: streaks of 3+ days that break trigger a red **STREAK TERMINATED** window naming the number of days erased; missed focus sessions are called compromised, not "almost!"; the money advisor states what the ledger shows. Deliberate line the app does not cross: it attacks behaviour and numbers, never the person — "you left, it's recorded" yes, insults no. Keep it that way; cruelty doesn't retain users, standards do.


---

## v9 — the rebuilt System

**New skin, same soul.** The interface was rebuilt: panels now materialise with staggered reveals, tabs and sub-tabs transition instead of snapping, the XP bar carries a live shine, the rank badge breathes, buttons sweep on hover, and the bottom nav is a floating command dock. Everything still respects the phone's reduced-motion setting and still works fully offline.

**Library, tripled.**
- **Books** — 20 genres (up from 13), 13 recommendations each: 260 titles including African Literature, Science & Mathematics, Tech & Code, Sports, Poetry, Adventure and clean YA Romance. Finishing a book still pays +30 XP.
- **Screen** — new: 12 genres of films, series and anime, 10 picks each, selectable by taste. +10 XP per title watched.
- **Arsenal** — new: the best free learning tools online, grouped (exam prep · free university-level · code & build · skills that pay), with direct links.
- **Archive** — unchanged, still level-gated.

**Wealth, completed.**
- **Academy** grew from 12 to 16 lessons. The new final arc: *The Millions Equation* (the honest compound-growth maths), *The Four Roads to Millions* (skill+investing, business, equity, real assets — and the traps that pretend to be roads), *Trusts — How Old Money Guards Itself* (settlor/trustee/beneficiary, why the wealthy use them, Ghana context, and the warning that structure protects wealth but never creates it), and *The Billionaire Blueprint* (equity, scale, leverage, decades — with the odds stated plainly).
- **Careers** — new: the Hall of Paths. 24 high-income professions plus the Owner's Path (the founder/billionaire route, honestly framed). Hunters can choose **any number of paths** — the app explicitly encourages skill-stacking — and each dossier carries an honest global pay range, what the job is, and a start-this-week step for a teenager.
- **Open Gate** — new: nine cards for hunters outside school. Ghana's WASSCE private-candidate way back in, the free-university stack, skills and trades that pay without certificates, the paths that legally *do* require school, certificates with real weight (Google, ALX, NVTI), the apprenticeship road, a first-income playbook, and the Trap List (betting apps, forex "mentors", pyramids).

**The Why Engine** — new, on the Status tab. Hunters carve up to ten reasons they level up. The reasons rotate under the Daily Transmission, and the System re-transmits them on a schedule from once a day up to **every hour** (07:00–21:00 quiet-hour guard). Honesty note, also shown in-app: a web app can only fire reminders while open or backgrounded — no honest web app can wake a fully closed phone. Install to home screen + allow notifications for best effect; one real phone alarm labelled with the №1 WHY is the recommended fail-safe.

**Integrity notes.** Pay figures in Careers are labelled as rough global ranges, not promises. The money content teaches mechanisms (compounding, ownership, leverage) and names scams; it promises nothing. All book/screen entries are titles + original one-line notes only — no copyrighted text is reproduced. The v5 image rule was **resolved in v18** — the four third-party wall images were replaced with original cards, and `assets/` now ships as-is (see the v18 note above). The rule itself still applies to any image you add later.

**Wall additions.** The two brand images supplied with v8 (the SYSTEM poster and the gold logo) are now in `assets/` as `brand-poster.jpg` and `brand-logo.jpg`, compressed for offline use, and lead the Motivation Wall carousel. As with all wall images: swap the files, keep the names.

**Storage** — new per-hunter fields: `whys`, `whyFreq`, `whyLast`, `careers`, `gateDone`, `screenGenres`, `watched`. All previous hunter files import cleanly; nothing was renamed.

---

## v10 — the Library expansion, the Forge and the Arena

### What changed

**The Library got much bigger, and honest about ranking.**

| | v9 | v10 |
|---|---|---|
| Book shelves | 20 | **34** |
| Books | 260 | **926** |
| Screen genres | 12 | **22** |
| Films / series / anime | 120 | **542** |

Every list is ordered **most-widely-read / most-watched first**, and each entry shows its rank (`#1`, `#2`…). Popularity means global reach — sales, borrows, ratings volume, cultural footprint — not the System's opinion. The System's opinion is the note underneath the title.

New book shelves: YA & Sweet Romance · Dark Romance & Gothic (18+) · Horror & Suspense · Dystopian & Post-Apocalyptic · Crime & True Crime · Health, Fitness & Nutrition · Faith, Meaning & Stoicism · Art, Writing & Creativity · War, Conflict & Courage · Economics & the World · Study Skills & Exams · Contemporary Fiction · Humour & Feel-Good · Leadership & Speaking.

New screen genres: Anime — Slice of Life & Growth · Anime — Dark & Psychological · Romance · K-Drama & Asian Series · Horror & Thriller · Crime, Law & Heist · War & History · Animation & Family · Music, Dance & Performance · Dark Romance & Erotic Thriller (18+).

Each shelf shows 15 titles with a **SHOW ALL** button, and there is a search box that looks across every shelf at once.

### The 18+ gate — read this before you sell a copy

Two shelves are marked `adult: true` in `data.js`: **Dark Romance & Gothic** (books) and **Dark Romance & Erotic Thriller** (screen). They are **hidden by default** and do not appear in the genre chips at all until the reader unlocks them under Library → Books → *Mature shelves*, which takes two separate confirmations.

This app's stated audience is students aged 14–18. Dark romance as a commercial category contains explicit sexual content and, in several of its best-selling titles, stalking, captivity and non-consent. Those titles are listed **by name and author only**, with content warnings and no descriptions, and only behind the gate.

If you are selling this app to schools or to parents, you have three options and you should pick one deliberately:

1. **Ship as-is.** The gate is on, the warnings are explicit, the default experience for a 14-year-old never shows those titles.
2. **Remove the shelves entirely.** Delete the `darkromance` block from `NEW_GENRES` and the `s_dark` block from `NEW_SCREEN` in `data.js`. Nothing else breaks.
3. **Add a parent PIN.** If you want the unlock to require an adult, gate `askMature()` behind the existing PIN check rather than a confirm box.

Age ratings on individual titles elsewhere in the Library (`16+`, `17+`, `18+` in the note field) are the System's rough guidance, not a certification body's.

### The Forge — 50 skills, pick 4

New segment under **Train**. Fifty productive skill hobbies across eight categories: Music, Code & Tech, Art & Design, Writing & Voice, Body & Mind, Money & Business, Making & Craft, Language & Culture.

The hunter picks **exactly four** and the app refuses the fifth. Each chosen skill gets a *this week* first step and a **Practised · +15 XP** button that can be logged once per day per skill. Filling a slot pays +10 XP.

Four is a hard cap on purpose. It is the number a person can actually practise weekly for years, and it is small enough that an empty slot is obviously a decision rather than an accident.

### The Arena — 106 competitions + 60 funded scholarships

New segment under **Wealth**.

- **106 international competitions** across Mathematics, Science & Research, Coding & Robotics, Business & Innovation, Writing & Debate, Arts & Music, and Global & Sport — including the ones that matter locally (National Science & Maths Quiz, Pan-African Mathematics Olympiad, Pan-African Robotics Competition, Anzisha Prize, Tony Elumelu Foundation).
- **60 fully or heavily funded scholarships**, grouped into Africa-focused, Government programmes, University & foundation, and Multilateral. Mastercard Foundation Scholars, Ashinaga, MEXT, CSC, GKS, Türkiye Bursları, Chevening, Commonwealth, Erasmus Mundus, DAAD, Rhodes, Gates Cambridge, Knight-Hennessy, Schwarzman, Joint Japan/World Bank, UWC and more.
- Search, category filters, and a **star** system with a *Starred* view so a hunter builds a short list they will actually act on. Starring pays +5 XP.

**The System stores no deadlines, and that is deliberate.** Dates, fees and eligibility change every year, and a stale date inside an offline app is worse than no date. Every entry carries the official domain — confirm there, then put the deadline in the hunter's own calendar.

There is a permanent warning on the panel: **nobody legitimate charges a fee to apply for a funded scholarship.** Agents who ask for money to "submit on your behalf" are the single most common scam aimed at exactly this audience.

### About the "600 per genre" target

600 books per genre across 34 shelves is 20,400 titles, and the same again for screen. There is no honest way to produce that by hand — past a few hundred per genre you are inventing books that do not exist, and one fake title in a study app destroys trust in all the real ones.

So v10 ships **926 real books and 542 real films, series and anime**, every one checked, ordered by reach, and structured so the lists can keep growing without touching a line of app code. To extend a shelf toward 600, open `data.js` and append to the relevant array:

```js
// inside MORE_BOOKS or NEW_GENRES
["Title", "Author"],                    // no note
["Title", "Author", "One honest line"], // with note
```

Screen entries take `["Title", "film|series|anime", "note?"]`. The app de-duplicates by title on load, so appending a title that already exists is harmless. Good sources for bulk lists that are real: Goodreads "Best of" shelves, the StoryGraph, Open Library, IMDb and MyAnimeList top-rated lists.

### Files

`data.js` is new and holds all of the above. It must sit next to `index.html`. It is already added to the service worker cache list (`system-v10`), so the app still works fully offline.

---

# v11 — the Skill Tree, the Armory, the Ward and the Online Gate

Four things were asked for. Three arrived as asked. One arrived reshaped, and the reshaping is the honest part — read the two "read this" sections below before you sell or hand out a copy.

## What changed

| Area | v10 | v11 |
|---|---|---|
| Skills | none | 28 skills, four branches, levels 2–90, with real XP effects |
| Study material | nothing | The Armory — zip or folder intake, sorted by subject → type → year |
| Security | input sanitising, PBKDF2 PINs | all of that, plus The Ward file scanner |
| Internet | tutor proxy only | The Online Gate — four public catalogues, off by default |
| Book shelves | 34 shelves / 926 titles | 34 shelves / **940 titles offline**, growable to 450 each |
| Screen shelves | 22 genres / 542 picks | **30 genres / 641 picks**, eight of them television-first |
| Tabs | 7 | 8 (Armory added) |
| Files | index.html, data.js, lore.js | + data-v11.js, skills.js, armory.js, online.js, ui-v11.js |

---

## The Skill Tree — Status → Skills

Skills **unlock** by level automatically. **Learning** one costs skill points, and you earn one point per level (two per level once you take Shadow Monarch at 50). You will never have enough points for all 28. That is deliberate — a tree you can max is a list, not a build.

Four branches:

- **Scholar** ✦ — study, reading, focus. *Bookworm, Night Vigil, Scholar, Deep Dive, Domain Expansion, Strategist.*
- **Warrior** ⚔ — training, streaks, resistance. *Sprint, Iron Will, Dawn Strike, Overdrive, Steady Hand, Ironclad, Unbroken, Relentless.*
- **Monarch** ◈ — raw XP and the mercy skills. *Gate Sense, Rewind, Mana Flow, Sanctuary, Polymath, Ruler's Authority, Shadow Monarch, Sovereign, Army of Shadows.*
- **Craft** ⛭ — hobbies, the Armory, the Ward. *Ward Protocol, Forge Master, Archivist, Grand Librarian, Architect.*

These are not decorative. They are wired into the XP engine:

- **Passives** multiply XP — globally, by quest category (study / body / mind / discipline / rest), or by source (books, focus sessions, Forge practice). They stack multiplicatively, so a level-50 build genuinely pays several times what a level-2 one does.
- **Time-of-day passives** — Dawn Strike pays +20% before 08:00, Night Vigil +15% after 20:00. Pick the one that matches when you actually work.
- **Ironclad** (level 20) absorbs one missed day per week before the streak dies. One. The app tells you how many you have left when it fires.
- **Iron Will** and **Unbroken** cut the XP a penalty takes off you, by 25% and 50%. The penalty quest still lands — you just bleed less.
- **Actives** are fired by hand and go on cooldown: **Rewind** restores a broken streak (14 days), **Overdrive** doubles XP for three hours (3 days), **Sanctuary** dissolves every pending penalty (10 days), **Domain Expansion** triples focus-session XP for an hour (5 days).
- **Unlock skills** open features rather than paying XP: **Gate Sense** (5) opens the internet, **Ward Protocol** (12) unlocks byte-level scanning, **Grand Librarian** (36) raises the shelf ceiling from 150 to 450.

**Respec is free.** Status → Skills → Reset all skills gives every point back. The System would rather you experiment than sit in a build you regret.

When you level into a new skill, the System window takes the screen and tells you what unlocked, with a button straight into the tree.

---

## The Armory — your own study material, sorted

New tab, ⛨. Three panes: **Materials**, **Intake**, **The Ward**.

### How the 7 GB problem is actually solved

A browser cannot hold a 7 GB file in memory, and it should not try. So the System does not unpack your archive.

**Zip:** it seeks to the last few kilobytes of the file, finds the End Of Central Directory record, and parses the archive's own index — every filename, size and offset — without decompressing a single byte. Zip64 is handled, so archives over 4 GB and over 65,535 entries work. A 7 GB zip is read as a few hundred kilobytes of directory data, in seconds. Individual files are decompressed only when you tap one to open it.

**Folder:** on Chrome, Edge and Android Chrome, "Choose a folder" uses the File System Access API. Nothing is copied anywhere. The System stores a *handle* to the folder, so your material is still reachable next session without picking it again. This is the best option if your material lives loose on the device rather than in a zip.

**Files:** the fallback, works everywhere. Its limit is honest and stated in the app — files picked this way are only openable until you close the app.

Intake is **optional**, offered as step 4 of hunter creation and available any time from the Armory tab. Drag-and-drop works. Nothing is uploaded anywhere — there is no server in this app.

### How it sorts

**Subject** comes from folder names, filenames and exam-board codes. It knows 33 subjects and the codes that identify them — 0580 and 9709 for Maths, 9702 for Physics, 0620 for Chemistry, 0500 for English Language, 0417 for ICT, and so on across IGCSE, GCSE, A-Level and WASSCE, including Ghanaian languages, RME and Technical Drawing. A code is stronger evidence than a word, so `9702_s21_qp_42.pdf` is Physics even if it is sitting in a folder called "misc".

**Inside each subject**, in this order:

1. **Notes** — PDFs, docs, slides, images
2. **Past papers** — grouped by year, **newest first**, then session (Feb/March → May/June → Oct/Nov), then paper number, then question paper before insert before mark scheme before examiner report. Tap "Papers: newest first" to flip to oldest first.
3. **Videos** — every common format
4. **Audio**, 5. **Textbooks**, 6. **Syllabus**, 7. **Flashcards & quizzes**, 8. **Other**

Anything it cannot place goes to **Unsorted** rather than being guessed at. Search runs across every file in every subject.

Stocking the Armory pays XP once, scaled to how much you brought.

### Where the index lives

The file index goes into IndexedDB, not localStorage — a 20,000-file index is several megabytes and would blow the localStorage cap. It survives restarts. If you indexed a **zip**, the browser cannot hold onto the file itself between sessions, so tap **Re-link source** and pick the same zip again — your sorting, subjects and year-ordering are untouched, only the ability to open files is re-attached. Folders re-attach themselves.

---

## The Ward — read this before you believe the word "antimalware"

**The Ward is a file-hygiene scanner. It is not an antivirus, and nothing in a web browser can be one.**

Here is what that sentence means, concretely. A real antivirus has a signature database of millions of known malware samples, updated several times a day, and it runs with permission to inspect memory, intercept system calls and quarantine files on disk. A web page has none of that. It cannot see your filesystem, it cannot stop a program running, and it has no signature feed. Anyone selling you a browser app that claims to be antivirus is lying to you. **Keep real antivirus on the device.**

What the Ward *does* do is catch the specific tricks that actually travel inside shared "past papers" folders, and it does that well:

- **Executables and scripts** — 40+ extensions (`.exe`, `.apk`, `.jar`, `.bat`, `.vbs`, `.ps1`, `.hta`, `.lnk`…). Study material is never an executable. Blocked outright.
- **Disguised names** — `notes.pdf.exe`, `paper.docx.js`. Blocked.
- **Right-to-left override tricks** — the Unicode characters that make `exe.gnp` display as `png.exe`. Blocked.
- **Zip-slip / path traversal** — archive entries whose paths escape the folder (`../../`). Blocked.
- **Decompression bombs** — a large entry with an absurd compression ratio. Blocked.
- **Macro-bearing Office files** — `.docm`, `.xlsm`, `.xlsb`. Flagged, with the advice to ask for a plain `.docx`.
- **Password-protected entries** — flagged, because encrypted contents cannot be inspected by anything.
- **Nested archives** — flagged, because the Ward cannot see inside them. Unpack and re-scan.

Blocked files are **quarantined**: never listed in the Armory, never previewed, never opened. They are not deleted — the System does not touch your device's files, it just refuses to handle them.

### Deep scan (needs Ward Protocol, level 12)

Reads the first 8 KB of each file and compares the **actual bytes** to the name:

- **Magic-byte sniffing** — a file starting `MZ` is a Windows program, `\x7fELF` is a Linux binary, `#!` is a shell script. If any of those is wearing a `.pdf` name, it is blocked regardless of what the extension says.
- **PDF active content** — `/JavaScript`, `/OpenAction`, `/Launch`, embedded files. Flagged.
- **HTML and SVG** — `<script>` and `onload=` handlers. Flagged; the System renders these as plain text only.
- **EICAR** — the industry-standard harmless antivirus test string. Detected, and useful as proof the byte-reading works.

**Self-test the Ward** runs six deliberately nasty filenames through it and shows you the verdicts. The sixth is a real past paper, and should pass clean. Use it when you doubt the thing is actually running.

---

# v12 — the automatic link

One change, and it is the one you asked for: **the System connects on its own.**

Nothing to press, nothing to unlock. When the hunter enters, the System waits a beat for the app to draw itself, then reaches for the network. If it finds one, it links, and it keeps the shelves growing in the background while the hunter works. If it finds nothing, it says so plainly and stays out of the way — the app has always been offline-first and still is.

### What "automatic" actually does

| Moment | What the System does |
|---|---|
| Hunter enters | Links itself ~2.5s after boot, silently |
| Link succeeds | Starts topping up the emptiest shelf the hunter actually reads |
| Link fails | Retries at 8s → 20s → 60s → 3min → 10min, then holds at 10min |
| Phone loses signal | Stops instantly, shows "no network", cancels the retry timer |
| Signal comes back | Waits 1.2s for the radio to settle, then links itself again |
| App comes back to the foreground | Re-links if the last check was over five minutes ago |
| App left open for hours | A quiet half-hourly heartbeat keeps the shelves fed |
| Wi-Fi ↔ mobile data switch | Notices, re-checks the data guard, decides again |

Level 1 hunters get the link. **Gate Sense** at level 5 no longer unlocks connecting at all — it now widens the sweep: one shelf topped up per session without it, every chosen shelf with it. **Grand Librarian** at 36 still raises the ceiling from 150 to 450 per shelf.

### What stops it, on purpose

The link is automatic, not unconditional. It halts for any of these, and the Codex Sync panel says which one:

- **Data guard → Manual.** Nothing happens until *Sync now* is pressed.
- **Data guard → Wi-Fi only** on a cellular connection.
- **The phone's own Data Saver is on.** Obeyed in every mode, including Automatic — if the owner of the device asked every app to use less, the System is not an exception.
- **No network,** or the catalogues are not answering.
- **The hourly request budget is 80% spent** — the background job stands down and leaves the rest for the hunter.
- **The shelf was fed recently** — 12 hours if it is under half full, 3 days if it is nearly full. No shelf gets hammered.

Automatic top-ups are silent and pay **no XP**. One quiet toast lands at the end — "*N new real titles arrived while you worked*". Growing a shelf by hand still pays, because that was a decision.

Settings → The Online Gate now reads: **Turn the link off · Sync now · Test connection**. Turning it off is permanent until turned back on — the System will not quietly re-enable itself.

### Upgrading a v11 hunter

A hunter created under v11 carried `open:false` and a guard that meant "only when I press a button". Both are lifted **once**, on first load of v12. After that the hunter's own choice rules — if they switch the link off, it stays off through every future launch.

---

## The Online Gate — how the shelves reach 450

On by default from v12, and no longer skill-locked. The app still works forever with no network; the link is depth, not a dependency.

### Why it exists

450 books per genre across 34 shelves is 15,300 titles. There is no honest way to write that by hand — past a few hundred per genre you are inventing books, and one fake title in a study app poisons every real one next to it.

So v11 ships **940 real books and 641 real screen picks offline**, and then reaches real catalogues for the rest. Every title the Gate adds is a book or show that actually exists, with a real author, pulled from a public database.

### The four sources

| Source | Gives you | Key needed |
|---|---|---|
| **Open Library** (Internet Archive) | Books, by subject, ranked by editions in print | No |
| **TVMaze** | Series and TV shows, by genre, ranked by popularity weight | No |
| **Jikan** (MyAnimeList) | Anime, by genre, ranked by MAL popularity | No |
| **TMDB** | **Films only** | **Yes — your own free key** |

Books, series and anime need nothing. Films are the exception: there is no keyless film catalogue that a browser is allowed to call. Make a free account at themoviedb.org, open Settings → API, copy the key, paste it into Settings → The Online Gate. It stays on your device and is sent only to TMDB.

### How to use it

Mostly: don't. The System tops your shelves up by itself, emptiest first, using only the genres you actually selected. Library → Books → **Codex Sync** is there for when you want to push one shelf ahead of the queue: pick it and press **Grow this shelf**, or **Grow all my shelves** for every genre you have selected. Settings → **Sync now** forces a full sweep on demand, ignoring the per-session limit and the per-shelf cooldown.

A full shelf pull is roughly 1–3 MB and is **cached permanently in IndexedDB** — you pay for the data once, ever, and the titles are there offline afterwards.

The ceiling is 150 titles per shelf until **Grand Librarian** at level 36, which raises it to 450.

**Clear the online cache** in Settings drops every fetched title and returns the shelves to what shipped.

### Security posture of the Gate

Reaching the internet is where an app gets dangerous, so this was built defensively:

- **Hard allowlist.** Five hostnames. A request anywhere else is refused before `fetch()` is called, even if something inside the app asks for it.
- **HTTPS only, GET only.** No cookies, no credentials, referrer stripped, `cache: no-store`.
- **Everything that comes back is treated as hostile text** — control characters and direction-override characters stripped, length-capped, then rendered through the app's HTML escaper. A catalogue that returned `<script>` would display as literal characters.
- **Request budget** — 600 requests an hour, with timeouts, so a bad network cannot silently drain a data bundle.
- **The service worker refuses to cache cross-origin responses**, so a stale or poisoned API answer cannot outlive the app.

### The 18+ shelves are deliberately not wired — and v12 tightened it

The two 18+ dark-romance shelves have **no internet source**. Everything else can grow; those cannot. Automatically pulling 450 unvetted titles into an adult shelf, in an app whose stated audience is 14–18, is not something the System will do. If you want them longer, add titles by hand in `data.js` — that way a person has looked at each one.

v11 had a gap here worth naming: the books shelf `darkromance` was unmapped as intended, but the screen shelf `s_dark` was still listed in the TVMaze and TMDB maps, so a hunter past the maturity gate could grow it. Now that fetching happens on its own, that gap mattered more. v12 closes it with four independent locks:

1. `s_dark` and `darkromance` are removed from every catalogue map — there is nothing to fetch *with*.
2. `NEVER_FETCH` in `online.js` names both keys explicitly.
3. `adultShelf()` refuses **any** shelf flagged `adult:true` in `data.js` — so a future 18+ shelf is covered without touching this code, and a shelf whose data has not loaded yet is treated as adult rather than assumed safe.
4. Every fetcher calls `guardShelf()` before its first request, the background queue skips adult shelves before it starts, and Codex Sync never lists them.

The maturity gate still controls whether those shelves are *visible*. The link never touches them either way.

---

## Files in v12

```
index.html      the app
lore.js         the Archive story
data.js         v10 data pack — books, screen, hobbies, competitions, scholarships
data-v11.js     v11 data pack — eight TV genres and shelf top-ups
skills.js       the skill tree — data and pure helpers
armory.js       zip/folder intake, subject classifier, the Ward engine
online.js       the Online Gate — allowlist, catalogue fetchers, cache, adult-shelf refusal
ui-v11.js       wiring: skill engine, Armory UI, Ward UI, and the automatic link
sw.js           service worker — cache "system-v12" (bumped, so the update lands)
manifest.json   PWA manifest
assets/         images
```

All new files are in the service worker's cache list, so the app still installs and runs fully offline. **They must sit next to `index.html`** — the app will load without them but the new tabs will be empty.

## Adding your own titles, still

The append path from v10 is unchanged and still the right way to add titles you have personally vetted:

```js
// data.js or data-v11.js
["Title", "Author"],                    // no note
["Title", "Author", "One honest line"], // with note
```

Screen entries take `["Title", "film|series|anime", "note?"]`. The app de-duplicates by title on load, so appending something that already exists is harmless.

## Browser support, honestly

| Feature | Chrome / Edge | Safari | Firefox |
|---|---|---|---|
| Everything except the below | ✅ | ✅ | ✅ |
| Zip intake | ✅ | ✅ 16.4+ | ✅ |
| Folder intake with a saved handle | ✅ desktop + Android | ❌ falls back to file picking | ❌ falls back |
| Online Gate (automatic link) | ✅ | ✅ | ✅ |
| Wi-Fi vs mobile-data detection | ✅ | ❌ treated as unmetered — the hourly budget still caps it | ❌ same |
| Deep byte scan | ✅ | ✅ 16.4+ | ✅ |

Chrome or Edge gives the full experience. On iPhone, use the zip route.
