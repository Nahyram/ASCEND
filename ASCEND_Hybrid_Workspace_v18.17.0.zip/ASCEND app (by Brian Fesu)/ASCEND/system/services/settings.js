/* THE SYSTEM v18 — services/settings.js
   Validating and writing settings. views/core-views.js now only reads the form.

   ## Why this moved

   The Settings save handler was thirteen lines of DOM reads interleaved with
   validation rules, clamping and defaulting, ending in save(). That is business
   logic living in a view, and it had the consequence that shape usually has:
   **an invalid AI endpoint was silently deleted.** Typing `htp://…` or an
   http:// URL cleared the field, saved, and reported "Saved · The System has
   been updated." The student was told the opposite of what happened, and had no
   way to tell a typo from a rejected scheme.

   Rules are stated once here and the caller is told what was refused, so a view
   cannot decide to stay quiet about it. The https requirement itself stays:
   an endpoint over plain http carries the student's questions in clear text.

   Nothing here renders. Nothing here reads the DOM. */
"use strict";

const SETTINGS_LIMITS = {
  name: 40,
  title: 60,
  url: 300,
  blurb: 400,
  autoLockMax: 240,
};

/* One rule per field. `set` receives an already-trimmed string. Each returns
   either { ok:true, value } or { ok:false, why } — and a refusal always carries
   a reason a student can act on. */
const SETTINGS_FIELDS = {
  name: v => v ? { ok:true, value: v.slice(0, SETTINGS_LIMITS.name) }
                : { ok:false, why:"A name cannot be empty, so the previous one was kept." },
  title: v => ({ ok:true, value: v.slice(0, SETTINGS_LIMITS.title) }),
  curriculum: v => (typeof CURRICULA !== "undefined" && CURRICULA[v])
    ? { ok:true, value:v }
    : { ok:false, why:"Unknown curriculum — the previous one was kept." },
  aiEndpoint: v => {
    if(!v) return { ok:true, value:"" };                       /* clearing is deliberate */
    if(/^http:\/\//i.test(v)) return { ok:false, why:"Rejected: that endpoint is http, not https. Your questions would travel in clear text. The previous endpoint was kept." };
    if(!/^https:\/\/.+/.test(v)) return { ok:false, why:"Rejected: that is not a valid https URL. The previous endpoint was kept." };
    return { ok:true, value: v.slice(0, SETTINGS_LIMITS.url) };
  },
  spotify: v => {
    if(!v) return { ok:true, value:"" };
    if(!/^https:\/\//.test(v)) return { ok:false, why:"Rejected: a playlist link must start with https://. The previous link was kept." };
    return { ok:true, value: v.slice(0, SETTINGS_LIMITS.url) };
  },
  penaltyMode: v => ["on","off"].includes(v) ? { ok:true, value:v } : { ok:false, why:"Unrecognised penalty setting." },
  alarmMode:   v => ["on","off"].includes(v) ? { ok:true, value:v } : { ok:false, why:"Unrecognised alarm setting." },
  autoLockMin: v => {
    const n = Number(v);
    if(!Number.isFinite(n) || n < 0) return { ok:false, why:"Auto-lock must be a number of minutes." };
    return { ok:true, value: Math.min(Math.round(n), SETTINGS_LIMITS.autoLockMax) };
  },
};

/* applyHunterSettings({field: rawString, ...})
   Writes only what validates. Returns { changed, rejected, saved } so the caller
   can report the refusals rather than pretending everything landed. */
function applyHunterSettings(patch){
  const h = typeof H === "function" ? H() : null;
  if(!h) return { changed:[], rejected:[], saved:false };

  const changed = [], rejected = [];
  for(const [k, raw] of Object.entries(patch || {})){
    const rule = SETTINGS_FIELDS[k];
    if(!rule){ rejected.push({ field:k, why:"Not a setting this build knows about." }); continue; }
    const res = rule(typeof raw === "string" ? raw.trim() : raw);
    if(!res.ok){ rejected.push({ field:k, why:res.why }); continue; }
    if(h[k] !== res.value){ h[k] = res.value; changed.push(k); }
  }
  if(changed.length && typeof save === "function") save();
  if(changed.includes("curriculum") && typeof invalidateModel === "function") invalidateModel();
  return { changed, rejected, saved: changed.length > 0 };
}

/* The creator's storefront. Same contract, different record — DB.store is
   device-wide rather than per-hunter, which is why it is a separate call
   instead of a flag on the one above. */
function applyStorefront(patch){
  if(typeof DB === "undefined" || !DB.store) return { changed:[], rejected:[], saved:false };
  const changed = [], rejected = [];
  const urlField = (k, raw, label) => {
    const v = String(raw || "").trim();
    if(!v){ if(DB.store[k] !== ""){ DB.store[k] = ""; changed.push(k); } return; }
    if(!/^https:\/\/.+/.test(v)){ rejected.push({ field:k, why:`${label} must be an https URL. The previous value was kept.` }); return; }
    const next = v.slice(0, SETTINGS_LIMITS.url);
    if(DB.store[k] !== next){ DB.store[k] = next; changed.push(k); }
  };

  if("payLink" in patch) urlField("payLink", patch.payLink, "The payment link");
  if("countEndpoint" in patch) urlField("countEndpoint", patch.countEndpoint, "The counter endpoint");
  if("blurb" in patch){
    const b = String(patch.blurb || "").trim().slice(0, SETTINGS_LIMITS.blurb);
    /* An empty blurb keeps the previous one: the Access panel renders it, and a
       blank panel reads as a broken app rather than as a choice. */
    if(b && DB.store.blurb !== b){ DB.store.blurb = b; changed.push("blurb"); }
  }
  if(changed.length && typeof save === "function") save();
  return { changed, rejected, saved: changed.length > 0 };
}

/* One sentence describing what happened, for the toast. The view should not be
   composing this either — it is the difference between "Saved" and the truth. */
function settingsOutcome(res){
  if(!res) return { title:"Nothing to save", body:"", tone:"" };
  if(res.rejected.length && !res.changed.length)
    return { title:"Nothing saved", body: res.rejected.map(r => r.why).join(" "), tone:"blood" };
  if(res.rejected.length)
    return { title:`Saved ${res.changed.length} change${res.changed.length===1?"":"s"} — ${res.rejected.length} rejected`,
             body: res.rejected.map(r => r.why).join(" "), tone:"blood" };
  if(!res.changed.length) return { title:"No changes", body:"Nothing on this screen differed from what was already saved.", tone:"" };
  return { title:"Saved", body:"The System has been updated.", tone:"gold" };
}
