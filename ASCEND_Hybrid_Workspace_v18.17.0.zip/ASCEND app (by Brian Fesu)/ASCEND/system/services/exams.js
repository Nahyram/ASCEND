/* THE SYSTEM v14 — services/exams.js
   The Exam Centre, the revision planner, and grades.

   The planner is the part of this file that had a real design decision in it.
   §31 says do not schedule impossible workloads and §32 says if the student falls
   behind, recalculate rather than shifting everything forward by a day. Those two
   together rule out the obvious implementation — a fixed calendar written once
   when the exam is created — because that is exactly the design that produces a
   plan showing eleven hours of revision on a Tuesday in week three.

   So the plan is *derived on every read* from three things that are true right
   now: days remaining, current mastery per topic, and the hours the student said
   they have. Falling behind changes the inputs, so the plan changes with them.
   There is no stored schedule to fall out of sync with reality, and no guilt trip
   about a plan made by a more optimistic version of you three weeks ago.

   §35 and §36: grades are recorded, gaps are shown, and nothing here predicts a
   final grade. The System does not know the paper, the marker or the day. */
"use strict";

/* ---------- exams (§29) ---------- */
function addExam({ subjectId, name, date, target = "", topicIds = null }){
  const a = academy(); if(!a) return null;
  const s = getSubject(subjectId); if(!s) return null;
  const e = {
    id: uid(), subjectId,
    name: String(name || (s.name + " exam")).slice(0, 80),
    date, target: String(target || s.target || "").slice(0, 12),
    topicIds: topicIds || null,        /* null = the whole subject */
    hoursPerWeek: 5, created: todayKey(),
  };
  if(!e.date) return null;
  a.exams.push(e); save(); invalidateAcademy();
  return e;
}
function removeExam(id){
  const a = academy(); if(!a) return false;
  a.exams = a.exams.filter(e => e.id !== id); save(); invalidateAcademy(); return true;
}
function upcomingExams(){
  const a = academy(); if(!a) return [];
  const today = todayKey();
  return (a.exams || [])
    .map(e => ({ ...e,
      subject: getSubject(e.subjectId),
      in: Math.round((new Date(e.date+"T00:00:00") - new Date(today+"T00:00:00")) / 86400000) }))
    .filter(e => e.subject && e.in >= 0)
    .sort((x, y) => x.in - y.in);
}
function setExamHours(id, hours){
  const a = academy(); if(!a) return false;
  const e = (a.exams || []).find(x => x.id === id); if(!e) return false;
  e.hoursPerWeek = Math.max(1, Math.min(40, Math.round(Number(hours) || 5)));
  save(); return true;
}

/* ---------- readiness ----------
   §35 forbids claiming to predict a grade, so this is stated as coverage of the
   syllabus by evidence, and labelled as exactly that. */
function examReadiness(examId){
  const a = academy(); if(!a) return null;
  const e = (a.exams || []).find(x => x.id === examId); if(!e) return null;
  const all = allTopics(e.subjectId);
  const scope = e.topicIds ? all.filter(t => e.topicIds.includes(t.id)) : all;
  if(!scope.length) return null;
  const m = scope.map(t => ({ t, m:masteryOf(t) }));
  const avg = m.reduce((s, x) => s + x.m.pct, 0) / m.length;
  const untouched = m.filter(x => x.m.state === "new").length;
  const weak = m.filter(x => x.m.pct < 0.5).sort((x, y) => x.m.pct - y.m.pct);
  const days = Math.round((new Date(e.date+"T00:00:00") - new Date(todayKey()+"T00:00:00")) / 86400000);
  return {
    exam:e, days, topics:m, coverage:avg,
    untouched, weak: weak.slice(0, 8), weakCount: weak.length,
    /* stated as coverage, never as a predicted grade */
    verdict: untouched === scope.length ? "Nothing recorded yet — the plan below is a starting order, not an assessment."
      : avg >= 0.8 ? `${Math.round(avg*100)}% of this syllabus has evidence behind it. That is coverage, not a predicted grade.`
      : avg >= 0.5 ? `${Math.round(avg*100)}% coverage, with ${weak.length} topic${weak.length===1?"":"s"} still weak.`
      : `${Math.round(avg*100)}% coverage. ${untouched} topic${untouched===1?"":"s"} have no evidence at all yet.`,
  };
}

/* ══════════════ the revision plan (§30, §31, §32) ══════════════
   Four phases, sized by how much time is left. The split is deliberate: with six
   weeks you can afford foundation work; with six days you cannot, and a plan that
   pretends otherwise wastes the days that are left. */
const PLAN_PHASES = [
  { k:"foundation", label:"Foundation",  blurb:"Learn what has no evidence yet. New material only." },
  { k:"mastery",    label:"Topic work",  blurb:"Practise the weak topics until accuracy moves." },
  { k:"practice",   label:"Practice",    blurb:"Mixed questions across the whole syllabus, timed." },
  { k:"final",      label:"Final review",blurb:"Error log and flashcards only. No new material." },
];

function revisionPlan(examId){
  const r = examReadiness(examId); if(!r) return null;
  const days = Math.max(0, r.days);
  const hoursPerWeek = r.exam.hoursPerWeek || 5;
  const hoursTotal = Math.round(days / 7 * hoursPerWeek * 10) / 10;

  /* phase weights shift as the window closes — this is §32's "recalculate, don't
     shift" expressed as a function of days rather than a stored calendar */
  let weights;
  if(days > 42)      weights = { foundation:0.35, mastery:0.35, practice:0.2,  final:0.1 };
  else if(days > 21) weights = { foundation:0.2,  mastery:0.4,  practice:0.25, final:0.15 };
  else if(days > 10) weights = { foundation:0.05, mastery:0.4,  practice:0.35, final:0.2 };
  else if(days > 3)  weights = { foundation:0,    mastery:0.3,  practice:0.35, final:0.35 };
  else               weights = { foundation:0,    mastery:0.1,  practice:0.2,  final:0.7 };

  /* topics ordered by what actually needs the time: weakest first, but anything
     with no evidence at all comes ahead of a topic that is merely shaky, because
     you cannot practise what you have not learnt */
  const ordered = [...r.topics].sort((a, b) => {
    const an = a.m.state === "new" ? 0 : 1, bn = b.m.state === "new" ? 0 : 1;
    return an - bn || a.m.pct - b.m.pct;
  });

  const phases = PLAN_PHASES.map(p => {
    const share = weights[p.k];
    const hours = Math.round(hoursTotal * share * 10) / 10;
    const dayCount = Math.max(0, Math.round(days * share));
    let focus = [];
    if(p.k === "foundation") focus = ordered.filter(x => x.m.state === "new").slice(0, 6);
    if(p.k === "mastery")    focus = ordered.filter(x => x.m.pct < 0.7 && x.m.state !== "new").slice(0, 6);
    if(p.k === "practice")   focus = ordered.slice(0, 5);
    if(p.k === "final")      focus = ordered.filter(x => x.m.pct < 0.8).slice(0, 5);
    return { ...p, share, hours, days:dayCount, focus, skipped: share === 0 };
  });

  /* §31 — say so when the arithmetic does not work, rather than printing a plan
     that quietly assumes twelve-hour days */
  const topicsNeedingWork = ordered.filter(x => x.m.pct < 0.7).length;
  const hoursNeeded = topicsNeedingWork * 1.5;
  const feasible = hoursTotal >= hoursNeeded;

  return {
    ...r, hoursPerWeek, hoursTotal, phases, feasible,
    hoursNeeded: Math.round(hoursNeeded * 10) / 10,
    topicsNeedingWork,
    warning: feasible ? null
      : `At ${hoursPerWeek} hours a week you have about ${hoursTotal} hours before this exam, and ${topicsNeedingWork} topics still need work — roughly ${Math.round(hoursNeeded)} hours at a realistic pace. Either the hours go up, or the plan covers the ${Math.max(1, Math.floor(hoursTotal / 1.5))} topics that matter most and lets the rest go. Choosing deliberately beats running out of time by accident.`,
    /* what to do today, specifically */
    today: (() => {
      const phase = phases.find(p => !p.skipped && p.focus.length) || phases[phases.length - 1];
      const pick = phase.focus[0];
      if(!pick) return { text:"Add topics to this subject so the plan has something to work with.", go:["academy","ac-subjects"] };
      const act = phase.k === "foundation" ? "Learn" : phase.k === "final" ? "Review" : "Practise";
      return {
        text: `${act}: ${pick.t.name}`,
        why: `${phase.label} phase. ${pick.m.state === "new" ? "No evidence recorded on this topic yet" : `Currently at ${Math.round(pick.m.pct*100)}% — ${pick.m.why}`}. ${r.days} day${r.days===1?"":"s"} to the exam.`,
        topicId: pick.t.id, go:["academy","ac-study"],
      };
    })(),
  };
}

/* Turn an exam into a boss chain so it lives in the progression system too. */
function bossFromExam(examId){
  const r = examReadiness(examId); if(!r) return null;
  const plan = revisionPlan(examId);
  return createBoss({
    name: `${r.exam.name}`,
    template: "custom", difficulty: r.days <= 14 ? "epic" : "hard",
    stages: [
      `List every topic and mark it confident / shaky / unknown`,
      ...(plan.phases.filter(p => !p.skipped && p.focus.length)
        .map(p => `${p.label}: ${p.focus.slice(0,3).map(f => f.t.name).join(", ")}`)),
      `Sit one full paper under timed conditions`,
      `Work the error log until it is empty`,
    ].slice(0, 8),
  });
}

/* ══════════════ grades (§35, §36) ══════════════ */
function addGrade({ subjectId, name, date, score, max, grade = "", note = "" }){
  const a = academy(); if(!a) return null;
  const g = {
    id: uid(), subjectId,
    name: String(name || "Assessment").slice(0, 80),
    date: date || todayKey(),
    score: Number(score), max: Number(max) || 100,
    grade: String(grade).slice(0, 8), note: String(note).slice(0, 200),
  };
  if(!isFinite(g.score)) return null;
  a.grades.push(g); save(); invalidateAcademy();
  grantXp(BALANCE.xp.reflection, `Recorded a grade — ${g.name}`, { once:"grade:" + g.id });
  return g;
}
function gradeTrend(subjectId){
  const a = academy(); if(!a) return null;
  const list = (a.grades || []).filter(g => g.subjectId === subjectId)
    .sort((x, y) => String(x.date).localeCompare(String(y.date)));
  if(!list.length) return null;
  const pct = list.map(g => ({ ...g, pct: g.max ? g.score / g.max : 0 }));
  const first = pct[0], last = pct[pct.length - 1];
  const s = getSubject(subjectId);
  return {
    list: pct, latest: last, n: pct.length,
    delta: pct.length > 1 ? last.pct - first.pct : 0,
    best: pct.reduce((b, g) => g.pct > b.pct ? g : b, pct[0]),
    target: s ? s.target : "",
    /* §36 — a transparent gap, never a promise */
    gap: s && s.target
      ? `Recorded target: ${s.target}. Latest recorded score: ${Math.round(last.pct*100)}%. THE SYSTEM does not know your board's grade boundaries and will not guess at them — check the official ones.`
      : null,
  };
}

/* ---------- study sessions (§25–28) ---------- */
function startSession({ subjectId, topicId, minutes = 25, objective = "" }){
  const a = academy(); if(!a) return null;
  const s = {
    id: uid(), subjectId, topicId, minutes,
    objective: String(objective || "").slice(0, 160),
    start: Date.now(), date: todayKey(), done:false,
  };
  a.sessions.push(s);
  if(a.sessions.length > 300) a.sessions = a.sessions.slice(-300);
  save();
  return s;
}
function finishSession(id, { accomplished = "", confidence = 3, review = false } = {}){
  const a = academy(); if(!a) return null;
  const s = (a.sessions || []).find(x => x.id === id); if(!s) return null;
  s.done = true; s.end = Date.now();
  s.accomplished = String(accomplished).slice(0, 300);
  s.confidence = Math.max(1, Math.min(5, Number(confidence) || 3));
  s.review = !!review;
  const t = s.topicId ? findTopicRef(s.topicId) : null;
  if(t){
    t.ev.studied++; t.ev.lastStudied = todayKey(); t.ev.confidence = s.confidence;
  }
  save(); invalidateAcademy();
  grantXp(BALANCE.xp.focusSession, `Study session — ${s.minutes} min`, { once:"session:" + s.id });
  return s;
}
function studyMinutes(days = 7){
  const a = academy(); if(!a) return 0;
  const keys = []; for(let i = 0; i < days; i++){ const d = new Date(); d.setDate(d.getDate()-i); keys.push(todayKey(d)); }
  return (a.sessions || []).filter(s => s.done && keys.includes(s.date)).reduce((n, s) => n + (s.minutes || 0), 0);
}
