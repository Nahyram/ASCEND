/* THE SYSTEM v18 — services/evidence.js
   What has this student actually demonstrated?

   Two P0 gaps in the audit turned out to be the same question asked twice.

   The first: a project carries a `skills` array that nothing ever read, and the
   skill tree is a fixed ladder bought with points earned by levelling. So a
   "skill" in v17 meant *you spent a point*, never *you did the thing*. The
   specification is explicit — skills must not become arbitrary numbers without
   evidence.

   The second: matchOpportunity() scored a student on subject *names*, a
   playstyle leaning and whether the event was online. A finished, evidenced,
   milestone-complete project sitting in the same category counted for nothing.
   The opportunity engine could not see the build engine.

   Both need one honest ledger, so this file is it. Nothing here invents a
   number, and nothing here is a score pretending to be a measurement.

   ## The grades, and why they are words rather than points

     claimed        the skill is named on a project · no evidence attached
     demonstrated   ≥1 evidence item AND ≥1 completed milestone on that project
     verified       the above, and the evidence is not self-reported

   A three-word ladder cannot be inflated by doing more of the cheap thing,
   which is exactly what a points total invites. "Claimed" is not a failure
   state and is never presented as one — it is the honest name for work that
   has started.

   ## What this file will not do

   It will not upgrade a claim on its own. Adding a project called "Machine
   learning" does not demonstrate machine learning, and a student who has typed
   an ambition should not be shown it back as an achievement — that is the
   flattery failure the whole product is built against. Only evidence plus a
   completed milestone moves a skill up, and only non-self-reported evidence
   moves it to verified.

   It is a derivation, not a store. Nothing here writes to the record, so it
   cannot drift out of true with the projects it reads. */
"use strict";

const EVIDENCE_GRADES = Object.freeze({
  claimed:      { k:"claimed",      label:"Claimed",      rank:0,
                  blurb:"Named on a project. Nothing has been attached to back it up yet." },
  demonstrated: { k:"demonstrated", label:"Demonstrated", rank:1,
                  blurb:"A milestone was completed and evidence attached to the project carrying it." },
  verified:     { k:"verified",     label:"Verified",     rank:2,
                  blurb:"As demonstrated, and the evidence is not self-reported." },
});

/* True only for the states services/verification.js marks as unreachable from
   inside the app. If that table ever gains a state, this follows it. If the
   table is missing entirely, nothing is verified — the safe answer. */
function isExternallyVerified(state){
  try{
    const v = (typeof VS === "object" && VS) ? VS[state] : null;
    return !!v && v.inApp === false && (v.weight || 0) >= 2;
  }catch(e){ return false; }
}

/* ---------- reading ---------- */
function evidenceProjects(){
  try{
    const st = typeof projectStore === "function" ? projectStore() : null;
    return (st && Array.isArray(st.items)) ? st.items.filter(p => !p.archived) : [];
  }catch(e){ return []; }
}

/* A project's own standing, computed the same way for every caller. */
function projectEvidenceState(p){
  const evidence   = Array.isArray(p.evidence) ? p.evidence : [];
  const milestones = Array.isArray(p.milestones) ? p.milestones : [];
  const doneMs     = milestones.filter(m => m.done).length;
  /* services/verification.js already owns what a verification state means, and
     §15 there is the rule that matters: a student cannot promote their own
     achievement past the in-app ceiling. So "verified" here is not "anything
     other than self-reported" — addEvidence() moves a project to "evidence" the
     moment a link is attached, and reading that as verified would let a student
     verify themselves by typing a URL. It is the states that are *not* reachable
     from inside the app: verified and official. Reading the existing table
     rather than restating it means this cannot drift away from that rule. */
  const verified   = isExternallyVerified(p.verification);
  let grade = "claimed";
  if(evidence.length && doneMs) grade = verified ? "verified" : "demonstrated";
  return {
    id: p.id, title: p.title, category: p.category,
    evidence: evidence.length, milestonesDone: doneMs, milestones: milestones.length,
    complete: p.stage === "complete" || (milestones.length > 0 && doneMs === milestones.length),
    grade, since: p.completed || p.created || null,
  };
}

/* ---------- skills, from evidence only ----------
   A skill's grade is the best grade of any project claiming it. Best, not
   average: one properly evidenced project demonstrates the skill, and three
   abandoned ones alongside it do not make that less true. */
function demonstratedSkills(){
  const out = new Map();
  for(const p of evidenceProjects()){
    const st = projectEvidenceState(p);
    for(const raw of (Array.isArray(p.skills) ? p.skills : [])){
      const name = String(raw || "").trim(); if(!name) continue;
      const key = name.toLowerCase();
      const cur = out.get(key) || { name, grade:"claimed", projects:[], evidence:0, milestonesDone:0, since:null };
      cur.projects.push({ id:st.id, title:st.title, grade:st.grade });
      cur.evidence += st.evidence;
      cur.milestonesDone += st.milestonesDone;
      if(EVIDENCE_GRADES[st.grade].rank > EVIDENCE_GRADES[cur.grade].rank) cur.grade = st.grade;
      if(st.since && (!cur.since || st.since < cur.since)) cur.since = st.since;
      out.set(key, cur);
    }
  }
  return [...out.values()].sort((a,b) =>
    EVIDENCE_GRADES[b.grade].rank - EVIDENCE_GRADES[a.grade].rank ||
    b.evidence - a.evidence ||
    a.name.localeCompare(b.name));
}

function skillEvidenceFor(name){
  const key = String(name || "").trim().toLowerCase();
  return demonstratedSkills().find(s => s.name.toLowerCase() === key) || null;
}

/* ---------- the ledger, for Progress and the portfolio ---------- */
function evidenceLedger(){
  const states = evidenceProjects().map(projectEvidenceState);
  const skills = demonstratedSkills();
  return {
    projects: states.length,
    complete: states.filter(s => s.complete).length,
    evidenceItems: states.reduce((n,s) => n + s.evidence, 0),
    demonstrated: skills.filter(s => s.grade !== "claimed").length,
    verified: skills.filter(s => s.grade === "verified").length,
    claimedOnly: skills.filter(s => s.grade === "claimed").length,
    skills,
  };
}

/* ---------- matching, for the opportunity engine ----------
   Deliberately conservative. Matching is by whole word against the words the
   student typed, because a substring match turns "art" into a hit on "Machine
   Learning: Startup" and an opportunity engine that flatters is worse than one
   that stays quiet. Nothing here returns a verdict — it returns what was found,
   and the caller explains it. */
function evidenceMatching(text, category = ""){
  const hay = String(text || "").toLowerCase();
  const words = new Set(hay.split(/[^a-z0-9+#]+/).filter(w => w.length > 2));
  const hits = { skills:[], projects:[], mastery:[] };
  if(!hay) return hits;

  for(const s of demonstratedSkills()){
    if(s.grade === "claimed") continue;            /* a claim is not evidence */
    const parts = s.name.toLowerCase().split(/[^a-z0-9+#]+/).filter(Boolean);
    if(parts.some(w => words.has(w))) hits.skills.push(s);
  }

  for(const p of evidenceProjects()){
    const st = projectEvidenceState(p);
    if(st.grade === "claimed") continue;
    const parts = String(p.title).toLowerCase().split(/[^a-z0-9+#]+/).filter(w => w.length > 2);
    const titleHit = parts.some(w => words.has(w));
    const catHit = category && p.category && String(p.category).toLowerCase() === String(category).toLowerCase();
    if(titleHit || catHit) hits.projects.push({ ...st, why: titleHit ? "title" : "category" });
  }

  try{
    if(typeof subjects === "function" && typeof subjectSummary === "function"){
      for(const s of subjects()){
        const first = String(s.name || "").toLowerCase().split(/\s+/)[0];
        if(!first || !words.has(first)) continue;
        const sum = subjectSummary(s.id);
        if(sum && typeof sum.mastery === "number") hits.mastery.push({ name:s.name, mastery:sum.mastery });
      }
    }
  }catch(e){}

  return hits;
}

/* ---------- keeping derived reads fresh ---------- */
if(typeof Bus !== "undefined" && typeof SYSTEM_EVENTS !== "undefined"){
  Bus.on(SYSTEM_EVENTS.EVIDENCE_ADDED,      () => { try{ invalidateModel(); }catch(e){} });
  Bus.on(SYSTEM_EVENTS.MILESTONE_COMPLETED, () => { try{ invalidateModel(); }catch(e){} });
  Bus.on(SYSTEM_EVENTS.PROJECT_COMPLETED,   () => { try{ invalidateModel(); }catch(e){} });
}
