/* THE SYSTEM v14 — services/cloud.js
   The Online Gate: identity, change tracking, synchronisation, entitlements.

   The governing constraint is Phase 6 §54, and it is the reason this file is
   shaped the way it is: **the Gate must never become a barrier**. THE SYSTEM
   works with no account, no server and no connection, and everything below is
   additive. A hunter who never opens this section loses nothing.

   The transport is a driver, and three ship:

     local     — no server. Everything already works; sync is a no-op.
     loopback  — an in-memory server used by the test suite and the demo.
     rest      — the real ASCEND backend, over HTTPS.

   `loopback` is not a toy. It is a real second store with its own revisions and
   its own clock, so the change tracking, the queue, the backoff and the conflict
   rules are genuinely exercised rather than asserted. It stays because it runs
   with no server process at all, which keeps the merge rules testable in a
   browser tab.

   `rest` is new in 18.7 and is the one that matters. For four releases this file
   carried a comment describing the adapter it did not have, and the server built
   in 18.6 had no client — the two halves were each complete and never introduced.
   sync-test.js now boots the real backend and drives the real adapter against it,
   because an adapter that has only ever been described is an adapter that has
   never been run.

   What is NOT here, deliberately: password handling. §6 says passwords must never
   be stored by the frontend, so this file has no notion of one. Authentication is
   delegated to a provider that returns a token, and the token is all we hold. */
"use strict";

/* ---------- device identity (§20) ----------
   Used for sync bookkeeping and diagnostics only. §20 is explicit that a device
   ID is not a substitute for authentication, so nothing is ever authorised on the
   strength of it. */
function deviceId(){
  try{
    let id = Store.readJSON("system.device");
    if(!id){
      id = [...crypto.getRandomValues(new Uint8Array(8))].map(b => b.toString(16).padStart(2,"0")).join("");
      Store.writeJSON("system.device", id);
    }
    return id;
  }catch(e){ return "unknown"; }
}

/* ---------- the cloud record on the hunter ---------- */
function cloud(){
  const h = H(); if(!h) return null;
  if(!h.cloud) h.cloud = {
    mode:"local",            /* local | guest | account */
    account:null,            /* { id, displayName, provider, createdAt } — never a password */
    token:null,              /* opaque, provider-issued */
    apiBase:null,            /* the ASCEND server this device talks to; null = none */
    eventCursor:0,           /* how far through the account's event stream this device has read */
    serverProgression:null,  /* the server's replay of the log — displayed, never applied */
    progressionAgrees:null,  /* null = never checked */
    entitlements:null,       /* last server answer, cached; the server remains the authority */
    lastSync:null, lastError:null,
    queue:[], rev:0, serverRev:0,
    settings:{ auto:true, wifiOnly:false, include:{ progress:true, academy:true, projects:true } },
  };
  const c = h.cloud;
  if(!Array.isArray(c.queue)) c.queue = [];
  if(!c.settings) c.settings = { auto:true, wifiOnly:false, include:{ progress:true, academy:true, projects:true } };
  return c;
}

/* ══════════════ change tracking (§14) ══════════════
   §14 is the requirement that makes incremental sync possible: do not upload the
   whole database every time. Every mutation that matters enqueues a small record
   of *what* changed, and the queue is what travels. */
const SYNC_SCOPES = ["progress", "academy", "projects", "opportunities", "settings"];

function markChanged(scope, detail){
  const c = cloud(); if(!c) return;
  if(!SYNC_SCOPES.includes(scope)) return;
  c.rev++;
  const last = c.queue[c.queue.length - 1];
  /* collapse a run of edits to the same scope — a student ticking twenty quests
     should produce one pending change, not twenty */
  if(last && last.scope === scope && !last.sent){
    last.rev = c.rev; last.at = Date.now(); last.n = (last.n || 1) + 1;
  } else {
    c.queue.push({ id:uid(), scope, rev:c.rev, at:Date.now(), n:1, sent:false,
                   detail: String(detail || "").slice(0, 80), device: deviceId() });
  }
  if(c.queue.length > 200) c.queue = c.queue.slice(-200);
  save();
}
function pendingChanges(){ const c = cloud(); return c ? c.queue.filter(q => !q.sent) : []; }

/* ══════════════ server configuration ══════════════
   The base URL of the ASCEND backend. It is a setting rather than a constant so
   that one build serves a self-hosted server, a school's server and ours, and so
   that the test suite can point the real client at a real server on a random
   port instead of a mock. */
function cloudApiProblem(url){
  const s = String(url || "").trim();
  if(!s) return "Enter the address of your ASCEND server.";
  let u; try{ u = new URL(s); }catch(e){ return "That is not a valid web address."; }
  if(u.protocol !== "https:" && u.protocol !== "http:") return "The address must start with https://";
  const localhost = /^(localhost|127\.0\.0\.1|\[::1\])$/i.test(u.hostname);
  /* http is permitted only against your own machine. Over http a session token
     travels in clear text on the school Wi-Fi, and the student cannot tell. */
  if(u.protocol === "http:" && !localhost) return "Use https:// — over http anyone on the same Wi-Fi can read the session token.";
  if(u.search || u.hash) return "Just the address, with no query string.";
  return null;
}
function cloudApiBase(url){
  const c = cloud(); if(!c) return null;
  if(url !== undefined){
    if(url === null || url === ""){ c.apiBase = null; save(); return null; }
    if(cloudApiProblem(url)) return c.apiBase;
    c.apiBase = String(url).trim().replace(/\/+$/, "");
    save();
  }
  return c.apiBase;
}

/* One place that speaks HTTP, so timeouts, JSON handling, the bearer header and
   the 401 rule exist once rather than four times. */
const REST_TIMEOUT_MS = 20000;
async function restFetch(path, { method = "GET", body, auth = true, base, timeout = REST_TIMEOUT_MS, signal } = {}){
  const c = cloud();
  const root = base || (c && c.apiBase);
  if(!root) throw Object.assign(new Error("No ASCEND server is configured."), { status: 0 });

  const headers = { "accept": "application/json" };
  if(body !== undefined) headers["content-type"] = "application/json";
  const token = auth && c ? c.token : null;
  if(token) headers["authorization"] = "Bearer " + token;

  const ac = typeof AbortController !== "undefined" ? new AbortController() : null;
  const timer = setTimeout(() => ac && ac.abort(), timeout);
  /* A caller may already own a deadline (services/ai.js does). Chain rather than
     replace, so whichever fires first wins and neither is ignored. */
  if(signal && ac){
    if(signal.aborted) ac.abort();
    else if(typeof signal.addEventListener === "function") signal.addEventListener("abort", () => ac.abort(), { once:true });
  }
  let res;
  try{
    res = await fetch(root + path, {
      method, headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ac ? ac.signal : undefined,
      /* The token is in a header, not a cookie. Sending credentials would add a
         CSRF surface for no benefit. */
      credentials: "omit",
      cache: "no-store",
    });
  }catch(e){
    clearTimeout(timer);
    /* A failed fetch is the normal case on a school connection, so it gets a
       sentence a student can act on rather than "TypeError: Failed to fetch". */
    throw Object.assign(new Error(
      e && e.name === "AbortError"
        ? "The server did not answer in time."
        : "Could not reach the server. Your work is saved on this device."
    ), { status: 0 });
  }
  clearTimeout(timer);

  let data = null;
  try{ data = await res.json(); }catch(e){ data = null; }

  if(res.status === 401 && token){
    /* The session is gone — expired, revoked from another device, or the server
       was rebuilt. §47: this must cost the student nothing local.

       The server's own 401 text ("Authentication required.") is deliberately not
       passed through. It is accurate and useless: it describes the HTTP fact, not
       what happened to the student or what it costs them. */
    sessionLost();
    throw Object.assign(new Error("Signed out by the server."), { status: 401 });
  }
  if(!res.ok){
    const err = new Error((data && data.error) || ("The server refused the request (" + res.status + ")."));
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

/* Losing a session is not losing data, and the difference has to be visible in
   the code or it will not be visible in the product. Nothing here touches the
   hunter record. */
function sessionLost(reason){
  const c = cloud(); if(!c) return;
  c.token = null;
  c.mode = "local";
  c.entitlements = null;
  c.lastError = reason || "Your session ended. Everything on this device is untouched — sign in again to resume syncing.";
  save();
  if(typeof renderOnlineGate === "function"){ try{ renderOnlineGate(); }catch(e){} }
}

/* A reachability check that reports what the server says about itself. Used by
   the Gate before saving an address, so a typo is caught at the point it is made
   rather than at the first sync. */
async function cloudHealth(base){
  const problem = cloudApiProblem(base);
  if(problem) return { ok:false, text:problem };
  try{
    const h = await restFetch("/health", { auth:false, base:String(base).trim().replace(/\/+$/, ""), timeout:8000 });
    if(!h || h.service !== "ascend") return { ok:false, text:"Something answered, but it is not an ASCEND server." };
    return {
      ok: !!h.ok, health: h,
      text: h.ok
        ? `ASCEND server reachable. Database ${h.database}; AI ${h.ai}.`
        : `The server answered but reports a problem: database ${h.database}.`,
    };
  }catch(e){
    return { ok:false, text:e.message };
  }
}

/* ══════════════ transport drivers ══════════════ */
const CloudDrivers = {
  local: {
    name:"local", label:"This device only",
    available: () => true,
    async signIn(){ return { id:"local", displayName:"Guest", provider:"local" }; },
    async pull(){ return null; },
    async push(){ return { ok:true, rev:0 }; },
    async wipe(){ return { ok:true }; },
  },

  /* An in-memory server. The point is that the sync engine has a real second
     party with its own revision counter, so conflicts actually occur and the
     resolution rules are exercised instead of assumed. */
  loopback: (() => {
    const store = new Map();     /* accountId → { rev, payload, updatedAt, device } */
    let latency = 0, failNext = 0;
    return {
      name:"loopback", label:"Loopback (test server)",
      available: () => true,
      _reset(){ store.clear(); latency = 0; failNext = 0; },
      _failNext(n){ failNext = n; },
      _peek(id){ return store.get(id) || null; },
      async _wait(){ if(latency) await new Promise(r => setTimeout(r, latency)); if(failNext > 0){ failNext--; throw new Error("network"); } },
      async signIn({ id, displayName }){
        await this._wait();
        return { id: id || "acct-" + uid(), displayName: displayName || "Hunter", provider:"loopback", createdAt: todayKey() };
      },
      async pull(accountId){
        await this._wait();
        return store.get(accountId) || null;
      },
      async push(accountId, payload, baseRev){
        await this._wait();
        const cur = store.get(accountId);
        if(cur && baseRev != null && cur.rev > baseRev){
          /* somebody else moved first — the engine, not the server, decides */
          return { ok:false, conflict:true, server:cur };
        }
        const rec = { rev:(cur ? cur.rev : 0) + 1, payload, updatedAt:Date.now(), device: deviceId() };
        store.set(accountId, rec);
        return { ok:true, rev:rec.rev };
      },
      async wipe(accountId){ await this._wait(); store.delete(accountId); return { ok:true }; },
    };
  })(),

  /* ---------- the real one ----------
     Implements the contract at the bottom of this file against server/src/server.js.
     Two rules govern it:

       · The account id in a URL is a claim, not an identity. The server resolves
         who you are from the bearer token and compares. This client sends the id
         anyway because the route requires it, and gets a 403 if it lies.
       · A password is passed through and never kept. §6 — this file has no field
         to store one in, and adding one would be the bug. */
  rest: {
    name:"rest", label:"ASCEND server",
    available(){ const c = cloud(); return !!(c && c.apiBase); },

    async signIn({ email, password, displayName, register } = {}){
      const mail = String(email || "").trim();
      if(!mail || !password) throw new Error("An email and a password are needed to sign in.");

      if(register){
        try{
          await restFetch("/auth/register", { method:"POST", auth:false,
            body:{ email:mail, password, displayName: displayName || undefined } });
        }catch(e){
          /* Already registered is not a failure of intent — the student wanted an
             account and there is one. Fall through to signing in. */
          if(e.status !== 409) throw e;
        }
      }

      const s = await restFetch("/auth/session", { method:"POST", auth:false,
        body:{ email:mail, password, device: deviceId() } });
      if(!s || !s.token) throw new Error("The server did not issue a session.");

      return {
        account: { id:s.id, displayName:s.displayName, provider:s.provider || "ascend", createdAt: todayKey() },
        token: s.token,
        entitlements: s.entitlements || null,
      };
    },

    async signOut(){
      /* Revoke server-side so a lost phone stops syncing, and treat a failure as
         success locally: the student asked to sign out and must end up signed out
         whatever the network says. */
      try{ await restFetch("/auth/session", { method:"DELETE" }); }catch(e){}
      return { ok:true };
    },

    async pull(accountId){
      const r = await restFetch("/records/" + encodeURIComponent(accountId));
      /* 200 with a null body means "account exists, nothing stored yet" — which
         is different from an error, and the engine treats it as an empty server. */
      return r && r.payload !== undefined ? { rev:r.rev, payload:r.payload, updatedAt:r.updatedAt } : null;
    },

    async push(accountId, payload, baseRev){
      try{
        const r = await restFetch("/records/" + encodeURIComponent(accountId), {
          method:"PUT", body:{ payload, baseRev: Number(baseRev) || 0, device: deviceId() },
        });
        return { ok:true, rev:r.rev };
      }catch(e){
        /* 409 is not an error, it is the protocol: somebody pushed between our
           pull and our push. Hand the server's copy back and let the engine
           merge — the same shape loopback returns, so one code path serves both. */
        if(e.status === 409 && e.data && e.data.conflict)
          return { ok:false, conflict:true, server:e.data.server };
        throw e;
      }
    },

    async wipe(accountId){
      await restFetch("/records/" + encodeURIComponent(accountId), { method:"DELETE" });
      return { ok:true };
    },

    /* Not part of the driver contract; used by refreshEntitlements() and the
       Gate's account panel. */
    async me(){ return restFetch("/me"); },

    /* 18.11 — the event log. Separate from the record push on purpose: a record
       push is a snapshot and can conflict, whereas events only ever accumulate.
       Ids are device:seq and the server's primary key is (account, id), so
       sending the same batch twice is harmless by construction rather than by
       care taken at the call site. */
    async pushEvents(accountId, { events, base, claim }){
      return restFetch("/records/" + encodeURIComponent(accountId) + "/events", {
        method:"POST", body:{ events, base, claim },
      });
    },
    /* Recovery. Unauthenticated by design — a student who cannot sign in is
       exactly who needs these. */
    async resetRequest(email){
      return restFetch("/auth/reset/request", { method:"POST", auth:false, body:{ email } });
    },
    async resetConfirm(token, password){
      return restFetch("/auth/reset/confirm", { method:"POST", auth:false, body:{ token, password } });
    },

    async pullEvents(accountId, since){
      return restFetch("/records/" + encodeURIComponent(accountId) + "/events?since=" + (Number(since) || 0));
    },
  },
};

function cloudDriver(){
  const c = cloud();
  const name = (c && c.driver) || "local";
  return CloudDrivers[name] || CloudDrivers.local;
}
function setCloudDriver(name){
  const c = cloud(); if(!c || !CloudDrivers[name]) return false;
  c.driver = name; save(); return true;
}

/* Is this connection the kind a student pays for by the megabyte?

   Three answers, and the third one is the point: true, false, and null for "the
   browser will not say". Only Chromium exposes connection.type, and Save-Data is
   a user asking for less traffic rather than a statement about the link. Where
   the answer is unknown, sync proceeds — a switch that silently stops syncing on
   every iPhone would be a worse failure than one that occasionally syncs on
   cellular, and the Gate says which of the three it got. */
function meteredNetwork(){
  const nav = typeof navigator !== "undefined" ? navigator : null;
  const conn = nav && (nav.connection || nav.mozConnection || nav.webkitConnection);
  if(!conn) return null;
  if(conn.type === "wifi" || conn.type === "ethernet") return false;
  if(conn.type === "cellular") return true;
  if(conn.saveData) return true;
  return null;
}

/* ══════════════ connection state (§3) ══════════════ */
const CONN = { OFFLINE:"offline", ONLINE:"online", SYNCING:"syncing", ERROR:"error", DONE:"done" };
let _connState = CONN.ONLINE;
function connectionState(){
  if(typeof navigator !== "undefined" && navigator.onLine === false) return CONN.OFFLINE;
  return _connState;
}
function gateStatus(){
  const c = cloud(); if(!c) return null;
  const online = connectionState() !== CONN.OFFLINE;
  const pending = pendingChanges().length;
  return {
    mode: c.mode, online, driver: cloudDriver().label,
    account: c.account, pending, apiBase: c.apiBase, metered: meteredNetwork(),
    lastSync: c.lastSync, lastError: c.lastError,
    /* §18 — never frighten the user. Local data is safe; that is the headline. */
    text: !online ? `Offline. ${pending ? `${pending} change${pending===1?"":"s"} waiting — they are saved on this device and will go up when the connection returns.` : "Everything works. Nothing is waiting."}`
        : c.mode === "local" ? (c.apiBase
            ? "Local only. ASCEND is fully functional without an account — signing in adds backup, other devices and the AI tutor."
            : "Local only, with no server set. ASCEND is fully functional this way — everything below is additive.")
        : c.lastError ? `Sync paused — your local progress is safe. ${c.lastError}`
        : pending ? `${pending} change${pending===1?"":"s"} waiting to sync.`
        : c.lastSync ? `Up to date. Last synced ${new Date(c.lastSync).toLocaleString()}.`
        : "Signed in. Nothing synced yet.",
  };
}

/* ══════════════ account (§8, §9) ══════════════
   Guest first. §8 — a student should be able to use the whole system before being
   asked for anything, and §9 — converting a guest must never lose local progress. */
async function signIn({ displayName, id, email, password, register } = {}){
  const c = cloud(); if(!c) return null;
  const d = cloudDriver();
  try{
    const out = await d.signIn({ id, displayName, email, password, register });
    /* Drivers may return a bare account (local, loopback) or the full result the
       rest driver needs to hand back. Normalising here keeps the older two
       unchanged rather than making them pretend to issue tokens. */
    const acct = out && out.account ? out.account : out;
    if(!acct) throw new Error("Sign-in did not return an account.");
    c.account = acct;
    c.token = (out && out.token) || null;
    c.entitlements = (out && out.entitlements) || null;
    c.mode = "account"; c.lastError = null;
    save();
    /* §9 — local data is the source of truth at conversion. Everything already on
       the device is queued for upload rather than being replaced by an empty
       cloud record, which is the mistake that eats a term of work. */
    markChanged("progress", "account created — uploading local record");
    return acct;
  }catch(e){
    c.lastError = e.message; save();
    return null;
  }
}
async function signOut(){
  const c = cloud(); if(!c) return;
  const d = cloudDriver();
  /* Tell the server first, while we still hold the token. A session that is only
     forgotten by the client is still a session: a stolen phone would keep syncing
     until it expired on its own. */
  if(c.token && d && typeof d.signOut === "function"){
    try{ await d.signOut(); }catch(e){}
  }
  c.mode = "local"; c.token = null; c.entitlements = null;
  /* §47 — losing the connection or the session must never destroy local state.
     Signing out leaves every quest, note and project exactly where it was. */
  save();
}

/* ══════════════ the event log, over the wire ══════════════

   What this does and does not claim.

   The server is the authority on what the ACCOUNT says a student's progression
   is. The device stays free to compute its own at any moment, from its own log,
   with no connection — that is the whole point of the design and it does not
   change here. What syncing adds is a second opinion computed from the same
   events by the same reducer, which is what makes tampering detectable without
   making the student dependent on a network to level up.

   `c.serverProgression` records the server's answer. It is displayed, not
   applied: nothing here writes to the hunter record. If the two disagree that is
   a defect to investigate, and silently rewriting a student's level to match a
   server would turn a bug into a lost year. */
async function syncLog(){
  const c = cloud();
  if(!c || c.mode !== "account" || !c.token) return { ok:false, reason:"not-signed-in" };
  if(typeof Log === "undefined") return { ok:false, reason:"no-log" };
  const d = cloudDriver();
  if(!d || typeof d.pushEvents !== "function") return { ok:false, reason:"driver" };
  if(connectionState() === CONN.OFFLINE) return { ok:false, reason:"offline" };

  /* Two id spaces, and confusing them is silent data loss rather than an error.

     `account.id` identifies the ACCOUNT on the server and belongs in the URL.
     The log is stored per HUNTER, under DB.active, because one device can hold
     several hunters. Passing the account id to Log.export() asks for a hunter
     that does not exist, gets a fresh empty log, and pushes nothing — with the
     sync reporting success the whole way. That is exactly what happened the
     first time this ran, and it is why the end-to-end check exists rather than
     a unit test of syncLog's shape. */
  const accountId = c.account.id;
  try{
    /* Pull first. Absorbing another device's events before claiming a total
       means the claim covers the same set the server is about to replay —
       otherwise every multi-device sync would report a false divergence. */
    const incoming = await d.pullEvents(accountId, c.eventCursor || 0);
    if(incoming && Array.isArray(incoming.events) && incoming.events.length)
      Log.absorb(null, incoming.events);
    if(incoming && Number.isFinite(incoming.cursor)) c.eventCursor = incoming.cursor;

    const out = Log.export();
    if(!out) return { ok:false, reason:"no-hunter" };
    const res = await d.pushEvents(accountId, {
      events: out.events,
      base: out.base,
      claim: Log.progression(),
    });

    if(res && res.ok){
      /* Only now may the client compact past these. */
      Log.acknowledge(null, out.events.length);
      if(Number.isFinite(res.cursor)) c.eventCursor = res.cursor;
      c.serverProgression = res.progression || null;
      c.progressionAgrees = res.checked ? !!res.agrees : null;
      c.progressionDiffs = res.diffs || null;
      c.lastError = null;
      save();
      return { ok:true, accepted:res.accepted, duplicates:res.duplicates,
               agrees:c.progressionAgrees, progression:res.progression };
    }
    return { ok:false, reason:"refused" };
  }catch(e){
    if(e.status === 401) return { ok:false, reason:"signed-out" };
    c.lastError = e.message; save();
    return { ok:false, reason:"error", error:e.message };
  }
}

/* ══════════════ account recovery ══════════════
   Both of these deliberately return the server's own message rather than one
   composed here. The server is the only party that knows whether recovery is
   even configured, and a second sentence written on the client would drift out
   of step with it — telling a student to check their email on a server that
   cannot send one. */
async function requestPasswordReset(email){
  const d = cloudDriver();
  if(!d || typeof d.resetRequest !== "function") return { ok:false, error:"No ASCEND server is set." };
  try{
    const r = await d.resetRequest(String(email || "").trim());
    return { ok:true, message: (r && r.message) || "If that address has an account, a reset link is on its way." };
  }catch(e){ return { ok:false, error:e.message }; }
}
async function confirmPasswordReset(token, password){
  const d = cloudDriver();
  if(!d || typeof d.resetConfirm !== "function") return { ok:false, error:"No ASCEND server is set." };
  try{
    const r = await d.resetConfirm(String(token || "").trim(), password);
    /* Every session is revoked server-side, including this device's if it had
       one. Clearing it here keeps the app from holding a token it knows is dead. */
    const c = cloud();
    if(c && c.token){ c.token = null; c.mode = "local"; c.entitlements = null; save(); }
    return { ok:true, message: (r && r.message) || "Password changed. Sign in again." };
  }catch(e){ return { ok:false, error:e.message }; }
}

/* The server is the authority on what an account includes (§37). This asks it,
   caches the answer, and is the only thing permitted to write c.entitlements. */
async function refreshEntitlements(){
  const c = cloud(); if(!c || c.mode !== "account" || !c.token) return null;
  const d = cloudDriver();
  if(!d || typeof d.me !== "function") return null;
  try{
    const me = await d.me();
    if(me && me.entitlements){ c.entitlements = me.entitlements; save(); }
    return me;
  }catch(e){ return null; }
}

/* ══════════════ the payload ══════════════
   §46 — the hunter chooses what syncs. Anything excluded simply is not collected,
   rather than being collected and then filtered server-side. */
function buildPayload(){
  const h = H(); const c = cloud(); if(!h || !c) return null;
  const inc = c.settings.include || {};
  const out = { schema: SCHEMA, device: deviceId(), at: Date.now(), hunterId: h.id };
  if(inc.progress !== false){
    out.progress = {
      level:h.level, xp:h.xp, totalXp:h.totalXp, rank:h.rank, streak:h.streak,
      stats:h.stats, quests:h.quests, done:h.done, deadlines:h.deadlines,
      goals:h.goals, penalties:h.penalties, brain:h.brain, focusLog:h.focusLog,
    };
  }
  if(inc.academy !== false && h.academy) out.academy = h.academy;
  if(inc.projects !== false && h.projects) out.projects = h.projects;
  if(inc.projects !== false && h.opportunities) out.opportunities = h.opportunities;
  return out;
}

/* ══════════════ conflict resolution (§15) ══════════════
   §15 forbids silently overwriting. The rule set is deliberately boring, because
   clever merge logic is how data disappears:

     - a scope only one side touched      → take that side
     - counters that only ever grow       → take the larger
     - the done-record and any log        → union, never replace
     - anything genuinely contested       → keep both and ask

   Union-over-replace is doing most of the work. Two devices ticking different
   quests on the same day is the common case, and it must not be a conflict. */
function mergeRecords(localP, serverP){
  if(!serverP) return { merged: localP, conflicts: [] };
  if(!localP) return { merged: serverP, conflicts: [] };
  const conflicts = [];
  const merged = { ...serverP, ...localP };

  const L = localP.progress, S = serverP.progress;
  if(L && S){
    const p = { ...S, ...L };
    /* monotonic figures: the higher one is the true one */
    for(const k of ["totalXp", "level", "streak", "totalCleared"]) {
      p[k] = Math.max(Number(L[k]) || 0, Number(S[k]) || 0);
    }
    /* the done record is a union of days, and of quests within a day */
    p.done = {};
    for(const key of new Set([...Object.keys(S.done || {}), ...Object.keys(L.done || {})])){
      p.done[key] = { ...(S.done || {})[key], ...(L.done || {})[key] };
    }
    /* id-keyed lists merge by id, local winning a tie */
    for(const k of ["quests", "deadlines", "goals", "penalties"]){
      p[k] = mergeById((S[k] || []), (L[k] || []));
    }
    p.focusLog = { ...(S.focusLog || {}), ...(L.focusLog || {}) };
    merged.progress = p;
  }

  for(const scope of ["academy", "projects", "opportunities"]){
    const l = localP[scope], s = serverP[scope];
    if(l && s){
      const m = { ...s };
      for(const key of Object.keys(l)){
        if(Array.isArray(l[key]) && Array.isArray(s[key])) m[key] = mergeById(s[key], l[key]);
        else m[key] = l[key];
      }
      merged[scope] = m;
      /* one genuinely contested case worth surfacing rather than resolving:
         the same record edited on both sides with different content */
      const clash = contestedIds(s, l);
      if(clash.length) conflicts.push({ scope, ids: clash.slice(0, 5) });
    }
  }
  return { merged, conflicts };
}
function mergeById(serverList, localList){
  const out = new Map();
  for(const x of serverList || []) if(x && x.id) out.set(x.id, x);
  for(const x of localList || []) if(x && x.id) out.set(x.id, x);
  return [...out.values()];
}
function contestedIds(s, l){
  const ids = [];
  for(const key of Object.keys(l || {})){
    if(!Array.isArray(l[key]) || !Array.isArray(s[key])) continue;
    const sm = new Map((s[key] || []).filter(x => x && x.id).map(x => [x.id, JSON.stringify(x)]));
    for(const x of l[key] || []){
      if(!x || !x.id) continue;
      const other = sm.get(x.id);
      if(other && other !== JSON.stringify(x)) ids.push(x.id);
    }
  }
  return ids;
}

/* Applying a merged payload back onto the hunter. Additive by construction — no
   field present locally is ever removed by a sync. */
function applyPayload(p){
  const h = H(); if(!h || !p) return false;
  if(p.progress){
    for(const k of ["level","xp","totalXp","rank","streak","stats","quests","done",
                    "deadlines","goals","penalties","brain","focusLog"]){
      if(p.progress[k] !== undefined) h[k] = p.progress[k];
    }
  }
  if(p.academy) h.academy = p.academy;
  if(p.projects) h.projects = p.projects;
  if(p.opportunities) h.opportunities = p.opportunities;
  save();
  if(typeof invalidateModel === "function") invalidateModel();
  if(typeof invalidateAcademy === "function") invalidateAcademy();
  return true;
}

/* ══════════════ the sync engine (§13, §16, §17, §18) ══════════════ */
let _syncing = false;
async function syncNow({ force = false } = {}){
  const c = cloud(); if(!c) return { ok:false, reason:"no-record" };
  if(_syncing) return { ok:false, reason:"busy" };
  if(c.mode !== "account") return { ok:false, reason:"local-only" };
  /* v18: the entitlement layer had no call sites at all — services/business.js
     declared the rule and nothing asked it. Asking here means the day a billing
     server exists, this line changes and nothing else does. Today the answer is
     "allowed, on the device's authority", which is the honest answer. */
  if(typeof licenceCheck === "function"){
    const lic = licenceCheck("cloudsync");
    if(!lic.allowed) return { ok:false, reason:"not-entitled", note:lic.note };
  }
  if(connectionState() === CONN.OFFLINE) return { ok:false, reason:"offline" };
  /* "Wi-Fi only" has been a switch in the Gate since v14 and was read by nobody:
     a student on a Ghanaian data bundle could set it and still be synced over
     cellular. Same class of defect as the entitlement check that v18 found with
     no call sites, and the same fix — ask here, where it costs money. */
  if(!force && c.settings.wifiOnly && meteredNetwork() === true)
    return { ok:false, reason:"metered", note:"Waiting for Wi-Fi. Your changes are saved on this device." };
  if(!force && !pendingChanges().length && c.lastSync) return { ok:true, reason:"nothing-to-do", noop:true };
  /* The event log rides along with every sync. It is fire-and-forget: a failure
     here must not fail the record sync, because the record is what the student
     would notice losing. */
  const logPass = syncLog().catch(() => null);

  _syncing = true; _connState = CONN.SYNCING;
  const d = cloudDriver();
  try{
    const server = await d.pull(c.account.id);
    const local = buildPayload();
    const { merged, conflicts } = mergeRecords(local, server ? server.payload : null);

    const res = await d.push(c.account.id, merged, server ? server.rev : 0);
    if(!res.ok && res.conflict){
      /* somebody pushed between our pull and our push — merge again against what
         is actually there now rather than clobbering it */
      const re = mergeRecords(merged, res.server.payload);
      const second = await d.push(c.account.id, re.merged, res.server.rev);
      if(!second.ok) throw new Error("Could not settle a concurrent change. Nothing was lost — it will retry.");
      applyPayload(re.merged);
      c.serverRev = second.rev;
    } else if(res.ok){
      applyPayload(merged);
      c.serverRev = res.rev;
    } else {
      throw new Error("Server rejected the change");
    }

    for(const q of c.queue) q.sent = true;
    c.queue = c.queue.filter(q => !q.sent);
    try{ await logPass; }catch(e){}
    c.lastSync = Date.now(); c.lastError = null; c.backoff = 0;
    _connState = CONN.DONE;
    save();
    return { ok:true, conflicts, rev:c.serverRev };
  }catch(e){
    /* §18 — do not lose data, retry with backoff, and say something calm.

       A 401 is the exception on both counts. sessionLost() has already written
       the sentence that explains what happened and what it costs the student
       (nothing), and overwriting it with "Signed out by the server." replaced an
       explanation with a fact. Backoff is also wrong here: retrying a dead token
       on a schedule cannot succeed and only spends data. */
    if(e.status === 401){
      _connState = CONN.ERROR;
      return { ok:false, reason:"signed-out", error:c.lastError };
    }
    c.lastError = e.message;
    c.backoff = Math.min(8, (c.backoff || 0) + 1);
    _connState = CONN.ERROR;
    save();
    return { ok:false, reason:"error", error:e.message, retryInMs: Math.pow(2, c.backoff) * 1000 };
  }finally{
    _syncing = false;
  }
}

/* §47 — coming back online resumes quietly. It does not interrupt, log anyone out
   or throw a modal in front of what they were doing. */
function watchConnection(){
  if(typeof window === "undefined" || !window.addEventListener) return;
  window.addEventListener("online", () => {
    _connState = CONN.ONLINE;
    const c = cloud();
    if(c && c.mode === "account" && c.settings.auto) setTimeout(() => syncNow(), 1500);
    if(typeof renderOnlineGate === "function") renderOnlineGate();
  });
  window.addEventListener("offline", () => {
    _connState = CONN.OFFLINE;
    if(typeof renderOnlineGate === "function") renderOnlineGate();
  });
}

/* ══════════════ data ownership (§10) ══════════════ */
async function deleteCloudData(){
  const c = cloud(); if(!c || !c.account) return false;
  try{ await cloudDriver().wipe(c.account.id); c.serverRev = 0; c.lastSync = null; save(); return true; }
  catch(e){ c.lastError = e.message; save(); return false; }
}
function cloudSettings(patch){
  const c = cloud(); if(!c) return null;
  if(patch){
    if(patch.include) c.settings.include = { ...c.settings.include, ...patch.include };
    if("auto" in patch) c.settings.auto = !!patch.auto;
    if("wifiOnly" in patch) c.settings.wifiOnly = !!patch.wifiOnly;
    save();
  }
  return c.settings;
}

/* ══════════════ entitlements (§37, §38) ══════════════
   Phase 17 owns monetisation; Phase 6 owns the seam. The rule that matters is
   §37's: the frontend is never the authority on what someone has paid for. Until
   a server exists, everything is granted, and `source` says why — so the day a
   backend arrives, the call sites do not change. */
const ENTITLEMENTS = ["AI_COACH", "CLOUD_SYNC", "ADVANCED_ANALYTICS", "PREMIUM_THEMES", "ADVANCED_TUTOR", "UNLIMITED_PROJECTS"];
function entitlement(key){
  const c = cloud();
  const server = c && c.entitlements;      /* set only by a verified server response */
  if(server && key in server) return { allowed: !!server[key], source:"server" };
  return {
    allowed: true,
    source: "local",
    note: c && c.apiBase
      ? "Signed out, so this answer comes from the device and grants everything. The server's answer is the real one, and it replaces this on the next sign-in."
      : "No server is configured, so every capability is available. Connect one and this answer comes from it — never from the browser.",
  };
}
function hasEntitlement(key){ return entitlement(key).allowed; }

/* ---------- the contract, now implemented ----------
   CloudDrivers.rest above, against server/src/server.js:

     signIn({email,password,register}) → POST /auth/register (optional), POST /auth/session
                                       → { account, token, entitlements }
     pull(accountId)                   → GET    /records/:id → { rev, payload, updatedAt } | null
     push(accountId, payload, baseRev) → PUT    /records/:id → { ok, rev }
                                                  409        → { ok:false, conflict:true, server }
     wipe(accountId)                   → DELETE /records/:id → { ok }
     signOut()                         → DELETE /auth/session
     me()                              → GET    /me

   Authorisation is the server's job on every one of those (§30): the account id in
   the path is never trusted, only the token in the header — and server-test.js
   proves a second account gets a 403 rather than a record.

   Where the token lives: on the hunter record, therefore in localStorage. That is
   readable by any script that runs on this origin, so the real protection is not
   secrecy but revocability — DELETE /auth/session kills it server-side, sessions
   expire, and the app ships a CSP. A student's progress record is not worth a
   worse trade-off than that; a payment credential would be, and none is stored. */
