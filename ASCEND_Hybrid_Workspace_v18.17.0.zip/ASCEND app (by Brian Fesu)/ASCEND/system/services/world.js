/* THE SYSTEM v14 — services/world.js
   Boss quests and the world that opens as they fall.

   Two features, one file, because they are the same mechanic seen from two ends.
   A boss (§14) is a milestone expressed as a chain of smaller quests, so that
   "master algebra" stops being a wish and becomes five things with checkboxes.
   The world (§29–31) is what those milestones unlock — and the honest framing
   matters here: **nothing functional is ever locked**. Every area listed in
   BALANCE.world is already reachable from the navigation rail on a fresh install.
   Unlocking an area is the moment the System explains what that part of itself is
   for, not the moment it becomes usable. Gating real features behind grinding
   would be exactly the exploitative design Phase 4 §23 and §31 warn against.

   §15: bosses are symbolic. Procrastination, a hard subject, a big project. The
   "battle" is progress through the chain. Nothing here encourages a student to
   do anything unsafe to win. */
"use strict";

/* ══════════════ bosses ══════════════ */

/* Templates cover the cases a student actually faces. `custom` is always there
   for the ones they do not. */
const BOSS_TEMPLATES = [
  { k:"topic", name:"Master a topic", diff:"hard",
    blurb:"A subject area you keep losing marks on.",
    stages:["Re-learn the concept from one source","Work through ten practice questions",
            "Mark them and log every mistake by cause","Redo only the questions you got wrong",
            "Sit a timed set and beat your first score"] },
  { k:"paper", name:"Beat a past paper", diff:"hard",
    blurb:"One full paper, under real conditions.",
    stages:["Collect the paper and its mark scheme","Sit it timed, no notes",
            "Mark it honestly","Sort the lost marks into knowledge, method and carelessness",
            "Fix the biggest category","Sit a second paper and compare"] },
  { k:"project", name:"Finish a project", diff:"epic",
    blurb:"Something you are building that keeps not getting finished.",
    stages:["Write down what 'done' means, in one sentence","Build the ugliest version that works",
            "Use it yourself once","Fix the worst thing you found","Show it to three people","Publish it"] },
  { k:"habit", name:"Break a procrastination", diff:"moderate",
    blurb:"The thing you have avoided for weeks. This is the boss most people actually have.",
    stages:["Name it precisely — not 'study more'","Do two minutes of it today, badly",
            "Do it three days running","Do it for one full week","Do it on a day you do not want to"] },
  { k:"book", name:"Finish a hard book", diff:"moderate",
    blurb:"The one on the shelf you keep restarting.",
    stages:["Read the first chapter today","Reach a quarter","Reach halfway",
            "Write three sentences on what it is actually arguing","Finish it"] },
  { k:"custom", name:"Custom boss", diff:"hard",
    blurb:"Your own milestone, your own stages.",
    stages:["Stage one","Stage two","Stage three"] },
];

function allBosses(){
  const b = brain(); if(!b) return [];
  if(!Array.isArray(b.bosses)) b.bosses = [];
  return b.bosses;
}
function activeBosses(){ return allBosses().filter(x => !x.done); }
function getBoss(id){ return allBosses().find(x => x.id === id) || null; }

function createBoss({ name, template = "custom", stages, difficulty, goalId = null }){
  const b = brain(); if(!b) return null;
  const t = BOSS_TEMPLATES.find(x => x.k === template) || BOSS_TEMPLATES[BOSS_TEMPLATES.length - 1];
  const list = (stages && stages.length ? stages : t.stages).slice(0, 8);
  const boss = {
    id: uid(),
    name: String(name || t.name).slice(0, 90),
    template: t.k,
    difficulty: difficulty || t.diff,
    goalId,
    stages: list.map(s => ({ id:uid(), text:String(s).slice(0,140), done:false, at:null })),
    created: todayKey(), done:false, doneAt:null,
  };
  allBosses().push(boss);
  save(); invalidateStats(); invalidateModel();
  return boss;
}

function bossProgress(boss){
  const n = boss.stages.length, d = boss.stages.filter(s => s.done).length;
  return { n, done:d, pct: n ? d/n : 0, next: boss.stages.find(s => !s.done) || null };
}

/* Clearing a stage pays; finishing the boss pays properly. §17 — rewards
   proportional to what was actually done. */
function clearBossStage(bossId, stageId){
  const boss = getBoss(bossId); if(!boss || boss.done) return null;
  const st = boss.stages.find(s => s.id === stageId); if(!st || st.done) return null;
  st.done = true; st.at = todayKey();
  const mult = (BALANCE.difficulty.find(d => d.k === boss.difficulty) || { mult:1 }).mult;
  save();

  grantXp(Math.round(BALANCE.xp.bossStage * mult), `Boss stage — ${boss.name}`, { once:"boss:" + stageId });

  const p = bossProgress(boss);
  if(!p.next){
    boss.done = true; boss.doneAt = todayKey();
    save(); invalidateStats();
    grantXp(Math.round(BALANCE.xp.bossComplete * mult), `Boss defeated — ${boss.name}`, { once:"bossdone:" + boss.id });
    if(typeof takeover === "function") takeover({
      kind:"levelup", title:"BOSS DEFEATED",
      sub:`${boss.name} — ${p.n} stages, finished. This is the kind of thing rank is actually made of.`,
      reward:`+${Math.round(BALANCE.xp.bossComplete * mult)} XP`,
    });
    return { boss, completed:true };
  }
  return { boss, completed:false };
}

function undoBossStage(bossId, stageId){
  const boss = getBoss(bossId); if(!boss) return false;
  const st = boss.stages.find(s => s.id === stageId); if(!st) return false;
  st.done = false; st.at = null;
  if(boss.done){ boss.done = false; boss.doneAt = null; }
  save(); invalidateStats();
  return true;   /* XP already paid is not clawed back — see the ledger note below */
}

function deleteBoss(id){
  const b = brain(); if(!b) return false;
  b.bosses = allBosses().filter(x => x.id !== id);
  save(); invalidateStats();
  return true;
}

/* A goal can be promoted into a boss so the two systems do not hold separate
   copies of the same intention (§45 of Phase 9 makes the same point about
   duplicate data — the principle applies here already). */
function bossFromGoal(goalId){
  const g = typeof getGoal === "function" ? getGoal(goalId) : null;
  if(!g) return null;
  const steps = (g.targets || []).reduce((a,t) => a.concat((t.steps || []).map(s => s.text)), []);
  if(steps.length < 3) return null;
  return createBoss({ name:g.name, template:"custom", stages:steps.slice(0,8), goalId });
}

/* ══════════════ the world ══════════════ */

function areaUnlocked(k){
  const b = brain(); return !!(b && (b.areas || []).includes(k));
}
function areaMet(area, s){
  const a = area.at || {};
  if(a.level && s.level < a.level) return false;
  if(a.cleared && s.cleared < a.cleared) return false;
  if(a.bosses && s.bosses < a.bosses) return false;
  if(a.achievements && s.achievements < a.achievements) return false;
  return true;
}

/* Returns newly opened areas so they can be announced once. */
function checkWorld(){
  const b = brain(); if(!b) return [];
  b.areas = b.areas || [];
  const s = progressStats(true);
  const fresh = [];
  for(const area of BALANCE.world){
    if(b.areas.includes(area.k)) continue;
    if(!areaMet(area, s)) continue;
    b.areas.push(area.k);
    fresh.push(area);
  }
  if(fresh.length){ save(); invalidateStats(); }
  return fresh;
}

function worldMap(){
  const s = progressStats();
  const b = brain();
  const open = new Set((b && b.areas) || []);
  return BALANCE.world.map(a => ({
    ...a,
    unlocked: open.has(a.k),
    missing: open.has(a.k) ? [] : areaMissing(a, s),
  }));
}
function areaMissing(area, s){
  if(!s) return [];
  const a = area.at || {}, out = [];
  if(a.level && s.level < a.level) out.push({ what:"Level", have:s.level, need:a.level });
  if(a.cleared && s.cleared < a.cleared) out.push({ what:"Quests cleared", have:s.cleared, need:a.cleared });
  if(a.bosses && s.bosses < a.bosses) out.push({ what:"Bosses", have:s.bosses, need:a.bosses });
  if(a.achievements && s.achievements < a.achievements) out.push({ what:"Achievements", have:s.achievements, need:a.achievements });
  return out;
}

/* ══════════════ next milestone (§37) ══════════════
   The System should always be able to answer "what am I working toward?" with
   something specific. Nearest-first across every progression system, so the
   answer changes as the hunter changes rather than always being "next level". */
function nextMilestone(){
  const s = progressStats(); if(!s) return null;
  const h = H();
  const out = [];

  /* level */
  const need = xpNeeded(h.level);
  out.push({
    kind:"Level", label:`Reach level ${h.level + 1}`,
    have:h.xp, target:need, pct:Math.min(1, h.xp / need),
    detail:`${need - h.xp} XP to go. ${levelTitle(h.level + 1) !== levelTitle(h.level) ? `Level ${h.level+1} makes you ${levelTitle(h.level + 1)}.` : ""}`.trim(),
    go:["path"],
  });

  /* rank */
  const rp = rankProgress();
  if(rp && rp.next){
    const m = rp.next.missing[0];
    if(m) out.push({
      kind:"Rank", label:`${rp.next.name}`,
      have:m.have, target:m.need, pct:Math.min(1, m.have / m.need),
      detail:`${rp.next.missing.map(x => `${x.what} ${x.have}/${x.need}`).join(" · ")}`,
      go:["path"],
    });
  }

  /* the nearest unearned achievement */
  const near = achievementList()
    .filter(a => !a.earned && a.progress > 0 && a.progress < 1)
    .sort((a,b) => b.progress - a.progress)[0];
  if(near) out.push({
    kind:"Achievement", label:near.name, have:Math.round(near.progress*100), target:100,
    pct:near.progress, detail:near.blurb, go:["path"],
  });

  /* the nearest boss */
  const boss = activeBosses().map(b => ({ b, p:bossProgress(b) }))
    .sort((x,y) => y.p.pct - x.p.pct)[0];
  if(boss && boss.p.next) out.push({
    kind:"Boss", label:boss.b.name, have:boss.p.done, target:boss.p.n, pct:boss.p.pct,
    detail:`Next stage: ${boss.p.next.text}`, go:["path"],
  });

  /* the nearest locked area */
  const area = worldMap().filter(a => !a.unlocked)[0];
  if(area && area.missing.length) out.push({
    kind:"World", label:area.name, have:area.missing[0].have, target:area.missing[0].need,
    pct:Math.min(1, area.missing[0].have / area.missing[0].need),
    detail:area.missing.map(m => `${m.what} ${m.have}/${m.need}`).join(" · "), go:["path"],
  });

  /* closest to done wins — a milestone you can nearly touch is worth more than a
     distant one, and always showing "next level" makes the panel furniture */
  out.sort((a,b) => b.pct - a.pct);
  return { primary: out[0] || null, all: out };
}

/* ══════════════ seasons (§27) ══════════════ */
function currentSeason(){
  const md = todayKey().slice(5);
  return BALANCE.seasons.find(s => s.from <= s.to
    ? (md >= s.from && md <= s.to)
    : (md >= s.from || md <= s.to)) || null;
}

/* ══════════════ wiring quest clearing into the ledger ══════════════
   toggleQuest calls grantXp directly. Without a tag, un-ticking and re-ticking a
   quest prints XP forever — the exact exploit §41 names. Wrapping toggleQuest
   rather than editing services/day.js keeps the v12 file intact and puts the
   anti-farm rule where it can be read. */
/* v18.1: this used to reassign grantXp for the duration of the toggleQuest call
   and restore it in a finally, so that XP granted inside carried {once:tag}.
   That is dynamic scoping — the one pattern in this codebase that no module
   system can express, since an imported binding is read-only. The tag is now a
   module-local set for the same window and read by a registered grantXp wrap.
   Same effect, same window, no reassignment. */
let __questXpTag = null;

Hooks.wrap("grantXp", "quest once-per-day tag", function(next, n, why, ctx){
  if(__questXpTag && !(ctx && ctx.once)) return next(n, why, { once: __questXpTag });
  return next(n, why, ctx);
});

Hooks.wrap("toggleQuest", "anti-farm once-per-day", function(next, q){
  const h = H(); if(!h) return next(q);
  const key = todayKey();
  const wasDone = !!(h.done[key] || {})[q.id];
  if(wasDone) return next(q);   /* un-ticking never pays anything */

  /* pay once per quest per day, whatever happens afterwards */
  const b = brain();
  const led = b ? (b.xpLedger = b.xpLedger || { day:key, total:0, paid:{} }) : null;
  if(led && led.day !== key){ led.day = key; led.total = 0; led.paid = {}; }
  const tag = "q:" + q.id;
  const alreadyPaid = led && led.paid[tag];

  const prev = __questXpTag;
  __questXpTag = tag;
  try{ next(q); } finally { __questXpTag = prev; }

  if(alreadyPaid && typeof toast === "function"){
    toast("Already counted today", "This quest paid its XP earlier today. Clearing it again still counts for streaks and records — it just does not pay twice.", "gold");
  }
});
