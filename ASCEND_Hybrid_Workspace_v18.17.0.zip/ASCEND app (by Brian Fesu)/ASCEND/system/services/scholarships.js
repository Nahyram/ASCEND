/* THE SYSTEM v14 — services/scholarships.js
   Phase 10: scholarships, funded programmes, and the applications built from them.

   §116 says extend Phase 7's opportunity model rather than duplicating it, so this
   file adds three things to the record that already exists — funding, eligibility,
   and an application package — and nothing else. There is no second store, no
   second deadline engine and no second matcher.

   Two rules govern everything here, and both are about not lying to a student who
   is about to spend a week of their life on an application.

   **§5, §6, §52 — funding is itemised or it is unknown.** "Fully funded" is the
   single most damaging phrase in this domain: a student flies somewhere on the
   strength of it and discovers accommodation was never included. So funding is
   recorded per cost line, each line is covered / not covered / not specified, and
   "not specified" never quietly becomes "free".

   **§12, §56, §100 — eligibility has five states, not two.** The app cannot see a
   passport, a transcript or a bank statement. It can say "nothing you have told me
   contradicts this", which is a different and much weaker claim than "you are
   eligible", and the difference has to survive contact with the interface. */
"use strict";

/* ---------- funding (§5, §6, §52) ---------- */
const COST_LINES = [
  { k:"tuition",       label:"Tuition" },
  { k:"accommodation", label:"Accommodation" },
  { k:"meals",         label:"Meals" },
  { k:"travel",        label:"Travel" },
  { k:"visa",          label:"Visa costs" },
  { k:"materials",     label:"Materials" },
  { k:"applicationFee",label:"Application fee" },
  { k:"stipend",       label:"Stipend" },
];
const COVER = {
  covered:     { label:"Covered",       tone:"ok" },
  partial:     { label:"Partly covered",tone:"warn" },
  not:         { label:"Not covered",   tone:"bad" },
  unspecified: { label:"Not specified", tone:"unknown" },
};

function setFunding(oppId, lines){
  const rec = getOpp(oppId); if(!rec) return null;
  rec.funding = rec.funding || {};
  for(const [k, v] of Object.entries(lines || {})){
    if(COST_LINES.some(c => c.k === k) && COVER[v]) rec.funding[k] = v;
  }
  save(); markChanged("opportunities","funding");
  return rec.funding;
}

function fundingBreakdown(rec){
  const f = rec.funding || {};
  const lines = COST_LINES.map(c => ({ ...c, state: f[c.k] || "unspecified", ...COVER[f[c.k] || "unspecified"] }));
  const known = lines.filter(l => l.state !== "unspecified");
  const covered = lines.filter(l => l.state === "covered").length;
  const unspecified = lines.length - known.length;

  /* §5 — the headline is derived, and it refuses to overstate */
  let headline, caution = null;
  if(!known.length){
    headline = "Funding not recorded";
    caution = "Nothing here says this is free. It says nobody has written down what it covers.";
  } else if(unspecified > 0 && covered >= 3){
    headline = `${covered} cost${covered===1?"":"s"} covered, ${unspecified} not stated`;
    caution = "Do not read the unstated lines as covered. Travel and accommodation are the two most often left out, and the two most expensive.";
  } else if(covered === known.length && !unspecified){
    headline = "Every listed cost is covered";
  } else {
    headline = `${covered} of ${known.length} listed costs covered`;
  }
  return { lines, headline, caution, covered, unspecified, known: known.length };
}

/* ---------- eligibility (§11, §12) ----------
   The profile is whatever the student has already told the app elsewhere. §16 and
   §78 both say do not collect data on the chance it becomes useful later, so
   nothing new is asked for — this reads the Academy, the record and the profile. */
const ELIG_STATES = {
  confirmed: { k:"confirmed", label:"Meets the stated criteria", tone:"ok" },
  likely:    { k:"likely",    label:"Nothing contradicts it",    tone:"ok" },
  possible:  { k:"possible",  label:"Some requirements unknown", tone:"warn" },
  not:       { k:"not",       label:"A stated requirement is not met", tone:"bad" },
  unknown:   { k:"unknown",   label:"Not enough recorded to say", tone:"unknown" },
};

function studentProfile(){
  const h = H(); if(!h) return null;
  const subs = typeof subjects === "function" ? subjects() : [];
  const acts = typeof opps === "function" && opps() ? (opps().activities || []) : [];
  const projs = typeof projects === "function" ? projects().filter(p => !p.archived) : [];
  const comps = typeof oppList === "function" ? oppList().filter(o => o.kind === "competition" && o.result) : [];
  return {
    level: h.level, curriculum: h.curriculum || "", mode: h.mode || "student",
    subjects: subs.map(s => s.name),
    qualification: (typeof academy === "function" && academy()) ? academy().qualification : "",
    activities: acts.length, leadership: acts.filter(a => ACTIVITY_ROLES.indexOf(a.role) >= 2).length,
    projects: projs.length, completedProjects: projs.filter(p => p.stage === "completed").length,
    competitions: comps.length,
    /* deliberately absent: age, citizenship, residence, income. §78 — the app does
       not ask for them, so it does not pretend to check them. */
  };
}

/* Requirements are free text the student typed from the official page. We parse
   only what can be checked honestly and mark everything else unknown. */
function checkEligibility(rec){
  const p = studentProfile();
  const text = String(rec.eligibility || "");
  const factors = [];
  let worst = "likely";

  const demote = s => {
    const order = ["confirmed","likely","possible","unknown","not"];
    if(order.indexOf(s) > order.indexOf(worst)) worst = s;
  };

  const st = oppStatus(rec);
  if(st.k === "closed"){
    return { state: ELIG_STATES.not, factors:[{ k:"Deadline", state:"bad", text:"Applications have closed." }], profile:p };
  }

  if(!text.trim()){
    return {
      state: ELIG_STATES.unknown,
      factors: [{ k:"Requirements", state:"unknown",
        text:"No eligibility criteria recorded. Copy them from the official page — this is the single most useful thing you can add, because everything below depends on it." }],
      profile: p,
    };
  }

  /* subject requirements — checkable against the Academy */
  const subjHits = (p.subjects || []).filter(s => s && new RegExp(s.split(" ")[0], "i").test(text));
  if(/subject|studying|student of|maths|math|physics|chemistry|biology|comput|english/i.test(text)){
    if(subjHits.length) factors.push({ k:"Subjects", state:"ok", text:`You study ${subjHits.join(", ")}, which appears in the criteria.` });
    else { factors.push({ k:"Subjects", state:"warn", text:"Subject requirements are mentioned but none of your Academy subjects obviously match. Check the wording." }); demote("possible"); }
  }

  /* things the app genuinely cannot verify — named rather than assumed away */
  const UNCHECKABLE = [
    { re:/age|years old|under \d|over \d|born/i, k:"Age", why:"THE SYSTEM does not hold your date of birth and will not ask for it." },
    { re:/citizen|national|passport|residen/i,   k:"Citizenship", why:"Citizenship and residence are different things and the app knows neither." },
    { re:/grade|GPA|A\*|distinction|percentile|average of/i, k:"Grades", why:"Your recorded scores are your own entries, not a verified transcript." },
    { re:/income|financial need|means[- ]tested|bursary/i, k:"Financial need", why:"The app holds no financial information about you, deliberately." },
    { re:/recommend|reference letter|referee/i,  k:"Recommendation", why:"A person has to write this. Start asking early — it is the commonest reason an application misses its deadline." },
    { re:/english|IELTS|TOEFL|language test/i,   k:"Language", why:"A test score the app cannot see." },
  ];
  for(const u of UNCHECKABLE){
    if(u.re.test(text)){ factors.push({ k:u.k, state:"unknown", text:u.why }); demote("possible"); }
  }

  /* portfolio-style requirements, which the app CAN speak to */
  if(/portfolio|project|prior work|submission/i.test(text)){
    if(p.completedProjects) factors.push({ k:"Portfolio", state:"ok", text:`${p.completedProjects} completed project${p.completedProjects===1?"":"s"} on record, which you can point at.` });
    else { factors.push({ k:"Portfolio", state:"warn", text:"Work or a portfolio is asked for and you have no completed project recorded. That is a gap you can close, unlike most of the ones above." }); demote("possible"); }
  }
  if(/leadership|led|captain|president|organis/i.test(text)){
    if(p.leadership) factors.push({ k:"Leadership", state:"ok", text:`${p.leadership} activit${p.leadership===1?"y":"ies"} with a leadership role recorded.` });
    else { factors.push({ k:"Leadership", state:"warn", text:"Leadership is mentioned and none is recorded in your activities." }); demote("possible"); }
  }

  if(!factors.length){
    factors.push({ k:"Requirements", state:"unknown", text:"Criteria are recorded but nothing in them is something THE SYSTEM can check. Read them yourself — that is not a formality here." });
    demote("unknown");
  }

  /* §12, §56 — the top state is "nothing contradicts it", never "you are eligible" */
  return { state: ELIG_STATES[worst] || ELIG_STATES.unknown, factors, profile:p };
}

/* §16, §66 — name only the missing things that would actually change an answer */
function profileGaps(){
  const p = studentProfile(); if(!p) return [];
  const out = [];
  if(!p.subjects.length) out.push({ what:"Subjects", why:"Without them, no academic requirement can be checked at all.", go:["academy","ac-subjects"] });
  if(!p.completedProjects) out.push({ what:"A completed project", why:"Portfolio and evidence requirements are the most common thing you can actually do something about.", go:["build","b-projects"] });
  if(!p.activities) out.push({ what:"Activities", why:"Leadership and service criteria have nothing to match against.", go:["beyond","bo-activities"] });
  return out;
}

/* ══════════════ application packages (§31, §75, §107) ══════════════
   §30 and §107: reuse, never duplicate. A package holds *references* to projects,
   results and activities that already exist, so editing a project updates every
   application that points at it and nothing is copied out of sync.
   §76: each package is isolated — selecting something here never makes it public. */
function packages(){
  const o = opps(); if(!o) return [];
  if(!Array.isArray(o.packages)) o.packages = [];
  return o.packages;
}
function getPackage(id){ return packages().find(p => p.id === id) || null; }

function createPackage(oppId){
  const rec = getOpp(oppId); if(!rec) return null;
  const pk = {
    id: uid(), oppId, name: rec.name,
    projectIds: [], activityIds: [], resultIds: [],
    documents: DOC_REQUIREMENTS.map(d => ({ ...d, state:"required" })),
    essays: [], created: todayKey(), submitted:null, confirmation:"",
  };
  packages().push(pk); save(); markChanged("opportunities","package");
  return pk;
}
/* §28 — track the requirement, do not store the document */
const DOC_REQUIREMENTS = [
  { k:"transcript",  label:"Transcript" },
  { k:"reference",   label:"Recommendation letter" },
  { k:"essay",       label:"Personal statement" },
  { k:"portfolio",   label:"Portfolio or work sample" },
  { k:"id",          label:"Proof of identity" },
  { k:"eligibility", label:"Proof of eligibility" },
];
const DOC_STATES = ["required","preparing","ready","submitted","not needed"];

function setDocState(pkgId, docKey, state){
  const pk = getPackage(pkgId); if(!pk || !DOC_STATES.includes(state)) return false;
  const d = pk.documents.find(x => x.k === docKey); if(!d) return false;
  d.state = state; save();
  if(state === "ready") grantXp(15, "Application document ready", { once:"doc:" + pkgId + ":" + docKey });
  return true;
}
function togglePackageItem(pkgId, kind, id){
  const pk = getPackage(pkgId); if(!pk) return false;
  const key = kind === "project" ? "projectIds" : kind === "activity" ? "activityIds" : "resultIds";
  const i = pk[key].indexOf(id);
  if(i >= 0) pk[key].splice(i, 1); else pk[key].push(id);
  save(); return true;
}

/* §38 — readiness as a checklist, never as a probability of success */
function packageReadiness(pkgId){
  const pk = getPackage(pkgId); if(!pk) return null;
  const rec = getOpp(pk.oppId);
  const elig = rec ? checkEligibility(rec) : null;
  const docs = pk.documents.filter(d => d.state !== "not needed");
  const ready = docs.filter(d => d.state === "ready" || d.state === "submitted").length;
  const days = rec ? daysUntil(rec.deadline) : null;
  const outstanding = docs.filter(d => d.state === "required" || d.state === "preparing");

  return {
    pkg: pk, opp: rec, eligibility: elig,
    docs, ready, total: docs.length,
    pct: docs.length ? ready / docs.length : 0,
    days,
    evidence: pk.projectIds.length + pk.activityIds.length + pk.resultIds.length,
    /* §25 — deadline intelligence: name the real constraint, do not just count down */
    alert: (() => {
      if(days == null) return null;
      if(days < 0) return "The deadline has passed.";
      const slow = outstanding.some(d => d.k === "reference");
      if(slow && days <= 21) return `A recommendation letter is still outstanding and there are ${days} days left. That one depends on somebody else's calendar, not yours — ask today, before anything else on this list.`;
      if(outstanding.length >= 3 && days <= 10) return `${outstanding.length} items outstanding and ${days} days left. Decide now whether this is the application you are actually going to finish, rather than finding out on the last night.`;
      if(days <= 3 && outstanding.length) return `${days} day${days===1?"":"s"} left with ${outstanding.length} item${outstanding.length===1?"":"s"} outstanding.`;
      return null;
    })(),
    /* §39 — the final check before submitting, and it never says "you will win" */
    finalCheck: [
      { k:"Eligibility read on the official page", done: rec && rec.verify === "selfcheck" },
      { k:"Every required document ready", done: ready === docs.length },
      { k:"Evidence attached from your own record", done: (pk.projectIds.length + pk.activityIds.length + pk.resultIds.length) > 0 },
      { k:"Deadline and time zone confirmed", done: !!(rec && rec.deadline) },
    ],
  };
}
function markSubmitted(pkgId, confirmation){
  const pk = getPackage(pkgId); if(!pk) return false;
  pk.submitted = todayKey();
  pk.confirmation = String(confirmation || "").slice(0, 120);
  save();
  const rec = getOpp(pk.oppId);
  if(rec) setStage(rec.id, "applied");
  grantXp(BALANCE.xp.milestone, `Application submitted — ${pk.name}`, { once:"submit:" + pkgId });
  return true;
}

/* ---------- ranked applications (§26, §62) ---------- */
function applicationDashboard(){
  const all = packages().map(p => packageReadiness(p.id)).filter(Boolean);
  const urgent = all.filter(x => x.days != null && x.days >= 0 && x.days <= 14 && !x.pkg.submitted);
  return {
    urgent: urgent.sort((a,b) => a.days - b.days),
    inProgress: all.filter(x => !x.pkg.submitted && !urgent.includes(x)),
    submitted: all.filter(x => x.pkg.submitted && !(getOpp(x.pkg.oppId) || {}).result),
    results: all.filter(x => (getOpp(x.pkg.oppId) || {}).result),
    /* §92 — application wellbeing. The app should not encourage applying to
       everything, and this is where it says so out loud. */
    load: (() => {
      const open = all.filter(x => !x.pkg.submitted).length;
      const exams = typeof upcomingExams === "function" ? upcomingExams().filter(e => e.in <= 30).length : 0;
      if(open >= 5 && exams) return `${open} applications open with ${exams} exam${exams===1?"":"s"} inside a month. Applications are not free — each one costs evenings you were going to revise in. Two done properly beats five done at midnight.`;
      if(open >= 6) return `${open} applications open at once. The strongest ones are the ones you had time to make specific.`;
      return null;
    })(),
  };
}

/* §99 — patterns across applications, offered as planning, not judgement */
function applicationPatterns(){
  const all = packages();
  if(all.length < 3) return null;
  const late = all.filter(p => {
    const rec = getOpp(p.oppId);
    return rec && p.submitted && rec.deadline && daysUntil(rec.deadline) != null &&
           Math.abs(new Date(p.submitted) - new Date(rec.deadline)) / 86400000 <= 1;
  }).length;
  const refStuck = all.filter(p => (p.documents || []).some(d => d.k === "reference" && d.state === "required")).length;
  const out = [];
  if(late >= 2) out.push({ text:`${late} of your applications went in on the deadline itself.`,
    note:"That is a planning observation, not a criticism — but a submission written the night before is a different document from one written a week before, and readers can tell." });
  if(refStuck >= 2) out.push({ text:`${refStuck} applications are waiting on a recommendation.`,
    note:"This is the item that depends on somebody else, so it is the one to start first every time. Ask before the rest of the application exists." });
  return out.length ? out : null;
}
