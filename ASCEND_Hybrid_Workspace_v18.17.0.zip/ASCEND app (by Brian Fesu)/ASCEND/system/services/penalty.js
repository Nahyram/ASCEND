/* THE SYSTEM v13 — services/penalty.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- penalties (never physical harm, never food or sleep) ---------- */
const PENALTIES = [
  "Complete 30 minutes of revision on your weakest subject before any leisure.",
  "Write 200 words on why the quest was missed and what changes tomorrow.",
  "Clear the missed quest today, late, before bed. No exceptions.",
  "No screens for entertainment until tomorrow's first quest is cleared.",
  "Add 20 minutes to tomorrow's Deep Study block.",
  "Complete the training quest again at 60% volume.",
  "Read 15 pages before bed, on top of the day's reading.",
  "Plan tomorrow in writing, hour by hour, before you sleep.",
];
function issuePenalty(reason){ return Hooks.dispatch("issuePenalty", issuePenaltyBase, this, arguments); }
function issuePenaltyBase(reason){
  const h = H();
  if(h.penaltyMode === "off") return;
  const p = { id:uid(), text: PENALTIES[Math.floor(Math.random()*PENALTIES.length)], reason, date: todayKey(), done:false };
  h.penalties.push(p);
  h.xp = Math.max(0, h.xp - 20);
  save();
  takeover({ kind:"penalty", title:"PENALTY QUEST", sub:reason, reward:p.text, penalty:true });
}

