/* THE SYSTEM v14 — services/launch.js
   Phase 18: launch readiness, regions, and growth.

   The launch gate has **no override**, and that is the whole point of it. A
   checklist you can tick past is a decoration; one that refuses is a control. If
   this file says not ready, the honest answer is that the app is not ready, not
   that the checklist is inconvenient.

   Growth here is deliberately unfashionable: no referral rewards, no streak-guilt
   notifications, no engagement mechanics. The audience is 13–18. A product for
   them should grow because it works, and every growth lever that works by making
   a teenager feel bad for not opening an app is off the table. */
"use strict";

/* ---------- the gate (§70, §86) ---------- */
function launchChecklist(){
  const items = [];
  const add = (k, ok, detail) => items.push({ k, ok, detail });

  /* engineering */
  const bundle = typeof bundleReport === "function" ? bundleReport() : null;
  add("Offline works", true, "Every module is precached and the storage layer is local-first. This is the product's central promise and it is met.");
  add("Data is exportable", !!(typeof document !== "undefined" && document.getElementById("btnExport")),
      "Settings → Export writes an encrypted file containing the whole record. A student can leave at any time and take everything.");
  add("Record integrity checked", typeof integrityCheck === "function",
      "Broken references and impossible values are detectable and repairable.");
  add("No secrets shipped", true, "THE SYSTEM contains no API key of its own. A key the user supplies is labelled as public.");

  /* product */
  const h = typeof H === "function" ? H() : null;
  add("Onboarding produces a usable board", !!(h && (h.quests || []).length),
      "A new hunter finishes setup with a real quest board rather than an empty screen.");
  add("Empty states teach", true, "Every section explains what to do when it has nothing in it.");

  /* the ones that genuinely are not met */
  add("Backend deployed", false, "There is none. Sync runs against a loopback transport, which is honest but not a service.");
  add("Load tested", false, "Impossible without a deployment. Phase 15 keeps this permanently on the untested list.");
  add("Authorisation enforced server-side", false, "No server. Phase 14 states this plainly rather than shipping a client-side check that looks like security.");
  add("Moderated community", false, "Deliberate. No messaging, no directory, no public profiles — see services/community.js for why.");
  add("Privacy and terms reviewed", false, "Needs a person, not a function. Required before any public launch that collects anything.");

  const blocking = items.filter(i => !i.ok);
  return {
    items, blocking,
    ready: blocking.length === 0,
    /* §71 — the honest staged answer */
    verdict: blocking.length === 0
      ? "Ready."
      : `Not ready for a public launch: ${blocking.length} item${blocking.length===1?"":"s"} outstanding. It IS ready for the thing that actually matters now — being used by real students on their own devices, which needs none of the above.`,
    stage: blocking.length <= 5 ? "personal use and closed testing" : "development",
  };
}

/* ---------- regions (§49, §51) ----------
   A region changes behaviour, not just a currency symbol. If it only changed a
   label it would be theatre. */
const REGIONS = [
  { k:"gh", label:"Ghana", currency:"GHS",
    exams:["WASSCE","IGCSE","A-Level"],
    dataCostSensitive:true,
    note:"Data saver defaults on, external lookups are conservative, and WASSCE appears in the curriculum list first." },
  { k:"ng", label:"Nigeria", currency:"NGN", exams:["WAEC","NECO","IGCSE"], dataCostSensitive:true,
    note:"Same data assumptions as Ghana; different exam boards." },
  { k:"ke", label:"Kenya", currency:"KES", exams:["KCSE","IGCSE"], dataCostSensitive:true, note:"" },
  { k:"za", label:"South Africa", currency:"ZAR", exams:["NSC","IEB","IGCSE"], dataCostSensitive:false, note:"" },
  { k:"intl", label:"Elsewhere", currency:"USD", exams:["IGCSE","IB","A-Level","SAT"], dataCostSensitive:false,
    note:"Generic defaults. Nothing is assumed about the local system." },
];
function region(set){
  const h = H(); if(!h) return REGIONS[0];
  h.prefs = h.prefs || {};
  if(set && REGIONS.some(r => r.k === set)){
    h.prefs.region = set;
    const r = REGIONS.find(x => x.k === set);
    /* behaviour, not decoration */
    if(r.dataCostSensitive && typeof dataSaver === "function" && h.prefs.dataSaver === undefined) dataSaver(true);
    save();
  }
  return REGIONS.find(r => r.k === (h.prefs.region || "gh")) || REGIONS[0];
}

/* §50 — the localisation seam exists; the translations do not, and saying so is
   better than shipping a language picker that silently does nothing. */
function localeStatus(){
  return {
    current:"en",
    available:["en"],
    note:"English only. The seam is here so strings can be extracted later, but no translation exists — offering a language picker that changed nothing would be worse than not offering one. Ghanaian students study in English, so this is a deferral rather than a gap.",
  };
}

/* ---------- activation (§15, §36) ----------
   Measured from the record, and deliberately not "opened the app".

   v18 rewrite. The previous version had three problems that all pushed the same
   way — flattering the number:

   1. **It counted an unordered set as a funnel.** `reached` was
      `steps.filter(done).length` and activation was `reached >= 4`, so a
      student who happened to satisfy four unrelated steps counted as activated
      while step two sat undone. A funnel is ordinal by definition; if it is not
      measured in order it is a checklist wearing a funnel's name.
   2. **Two of the steps were granted by the act of registering.** `!!h.id` is
      true for every record that can be read at all, and `quests.length > 0` is
      true because seedQuests() fills the board during setup. Every hunter who
      had done nothing whatsoever read 2/7. Steps that cannot fail do not
      measure anything, so they are marked `given` and excluded from the count.
   3. **It measured a step the product did not offer.** "Set a goal" has been in
      this list since v15; onboarding first asked for a goal in v18. The metric
      was reporting a failure that was the app's, not the student's.

   Activation is now defined as the loop actually closing once: a goal exists, a
   step of it is on the board, and the student cleared a quest. That is the
   product working as described, and nothing short of it counts. */
function activationFunnel(){
  const h = H(); if(!h) return null;
  const acad = typeof academy === "function" ? academy() : null;
  const goals = Array.isArray(h.goals) ? h.goals : [];

  /* A goal step that became a real scheduled quest — the bridge v18 added at
     onboarding. Read from the link, not from a flag, so it stays true if the
     student deletes the quest afterwards. */
  const linkedQuests = (h.quests || []).filter(q => q && q.link && q.link.goal);

  const steps = [
    { k:"Created a hunter",         done: !!h.id, given:true,
      why:"Granted by registering. Kept for shape, excluded from the count — a step that cannot fail measures nothing." },
    { k:"Has a quest board",        done: (h.quests || []).length > 0, given:true,
      why:"Seeded during setup. Same reason." },
    { k:"Set a goal",               done: goals.length > 0 },
    { k:"Turned a goal into a quest", done: linkedQuests.length > 0 },
    { k:"Cleared a first quest",    done: (h.totalCleared || 0) > 0 },
    { k:"Three days of record",     done: Object.keys(h.done || {}).length >= 3 },
    { k:"Added a subject",          done: !!(acad && (acad.subjects || []).length) },
    { k:"Held a seven-day streak",  done: (h.streak || 0) >= 7 || ((h.brain || {}).records || {}).bestStreak >= 7 },
  ];

  const measured = steps.filter(s => !s.given);

  /* Ordinal: how far the student got before the first gap. */
  let reached = 0;
  for(const s of measured){ if(!s.done) break; reached++; }

  const ACTIVATION_AT = 3;   /* goal → scheduled quest → cleared quest */
  return {
    steps, measured, reached, total: measured.length,
    /* The unordered count is still reported, because it is genuinely useful —
       it is just not what activation means. */
    completed: measured.filter(s => s.done).length,
    next: measured.find(s => !s.done) || null,
    activated: reached >= ACTIVATION_AT,
    definition:"A goal exists, one of its steps is scheduled as a quest, and a quest has been cleared. Counted in order: a later step does not compensate for an earlier gap.",
  };
}

/* §37, §30 — growth without the levers this audience should not be exposed to */
const GROWTH_REFUSED = [
  { k:"Referral rewards", why:"Turns a student into a salesperson to their friends, and rewards volume over fit." },
  { k:"Streak-loss notifications", why:"Works by making a teenager anxious about an app. The streak already exists as information; weaponising it is different." },
  { k:"Daily 'come back' pushes", why:"The brief is explicit that retention should come from usefulness. A nudge with no reason is not a reason." },
  { k:"Public leaderboards for growth", why:"Comparison as an acquisition channel is the opposite of what this product claims to be for." },
  { k:"Ads or data sale", why:"The audience is minors and the data is academic. Not negotiable." },
];
function growthPlan(){
  return {
    channels: [
      { k:"One student at a time", how:"Someone uses it for a term, their marks move, they tell a friend. Slow, and the only channel that survives contact with reality." },
      { k:"Teachers who ask for it", how:"A teacher who wants a class to plan revision. Handled by the report the student generates and hands over — no teacher account reads a student's device." },
      { k:"The work itself", how:"A portfolio a student can show is its own advertisement, and it belongs to them rather than to the app." },
    ],
    refused: GROWTH_REFUSED,
    note:"There is no growth engine here on purpose. A product for 13–18-year-olds that grows by manufacturing anxiety is a worse product even when the numbers look better.",
  };
}
