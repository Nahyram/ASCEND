/* THE SYSTEM v18 — services/entitlements.js
   Where "is this student allowed to use this?" is answered, and who answered.

   ## The problem this file exists to make impossible to forget

   v17 shipped an access-key flow that hashed a typed key, compared it against a
   list baked into the page, set `h.unlocked = true`, and announced FULL ACCESS
   GRANTED. Every part of that runs on the student's own device, on code they
   can read, against a list they can read, writing a flag they can edit from the
   console in one line. It is not a licence check. It is a licence *request*
   that the client also answers.

   That is not automatically wrong — for a one-person product sold by link, a
   politeness gate is a legitimate business decision, and this project made it
   knowingly. What is wrong is *implying* it is secure, to the buyer or to the
   next person to work on the code. So this file draws one line:

     AUTHORITY.device  — granted here, on this device, unverifiable. Honest.
     AUTHORITY.server  — granted by a billing server. Does not exist yet, and
                         says so rather than falling back to `device` quietly.
     AUTHORITY.policy  — free by rule and enforced in code. Cannot be sold.

   Every consumer reads `.authority` alongside `.allowed`. When a billing server
   is built, `ServerEntitlements` gets an implementation and no call site
   changes — that is the entire point of the seam, and the reason it is worth
   having before the server exists rather than after.

   ## What must never be behind this

   NEVER_PAID in services/business.js. The check is there, not here, because
   that is where the list lives; this file delegates to it rather than keeping a
   second copy that could drift. Five features in this project's history have
   broken because the same rule was written in two files. */
"use strict";

const AUTHORITY = {
  policy: "policy",
  device: "device",
  server: "server",
};

/* ---------- the device source (what actually runs today) ---------- */
const DeviceEntitlements = {
  authority: AUTHORITY.device,

  /* The access key. Deliberately NOT called a licence anywhere in this file.

     Threat model, stated plainly so nobody has to reconstruct it:
       · Protects against: nothing, technically.
       · Actually achieves: a buyer who paid gets a key, feels ownership, and
         the honest majority pay. That is the whole mechanism.
       · Defeated by: reading index.html, editing localStorage, or one friend
         forwarding a key. All trivial, none of them worth engineering against
         client-side, because client-side cannot win this.
     Anyone who needs it to be enforceable needs a server. */
  unlocked(){
    const h = typeof H === "function" ? H() : null;
    return !!(h && h.unlocked);
  },

  grant(){
    const h = typeof H === "function" ? H() : null;
    if(!h) return false;
    h.unlocked = true;
    if(typeof save === "function") save();
    return true;
  },

  check(key){
    return {
      allowed: true,
      authority: AUTHORITY.device,
      verified: false,
      note: "Granted on this device. No server was asked, so this is a record of an intention to pay rather than proof of one \u2014 it is not enforceable and is not presented as if it were.",
    };
  },
};

/* ---------- the server source (the seam, unimplemented on purpose) ----------
   It refuses rather than approximating. A stub that returned `allowed:true`
   would make the app look server-backed in every log and screenshot while
   being exactly as unverified as the device path, which is the specific
   dishonesty this file was written to prevent. */
const ServerEntitlements = {
  authority: AUTHORITY.server,
  available: false,
  baseUrl: "",

  async check(key){
    return {
      allowed: false,
      authority: AUTHORITY.server,
      verified: false,
      unavailable: true,
      note: "No billing server exists. Nothing is granted from here, and nothing pretends to be.",
    };
  },
};

/* ---------- the resolver ----------
   One function the rest of the app calls. Synchronous, because every current
   consumer is synchronous and a server answer will arrive through
   entitlementRefresh() below rather than by making every call site async. */
function entitlementFor(key){
  const k = String(key || "").toLowerCase();

  /* Free by policy beats everything, including a server that says otherwise.
     Delegated to business.js so the never-paid list has exactly one home. */
  if(typeof NEVER_PAID !== "undefined" && NEVER_PAID.includes(k)){
    return {
      allowed: true,
      authority: AUTHORITY.policy,
      verified: true,
      note: "Free by policy and enforced in code \u2014 this feature cannot be put behind a paywall.",
    };
  }

  const paid = (typeof PAID_FEATURES !== "undefined") ? PAID_FEATURES[k] : null;
  if(!paid){
    return { allowed: true, authority: AUTHORITY.policy, verified: true, note: "Not a paid feature." };
  }

  if(ServerEntitlements.available){
    const cached = entitlementCache[k];
    if(cached) return cached;
  }
  return DeviceEntitlements.check(k);
}

/* Populated only when a server exists. Empty today, and empty is the honest
   state rather than a bug. */
const entitlementCache = Object.create(null);

async function entitlementRefresh(key){
  if(!ServerEntitlements.available) return entitlementFor(key);
  const res = await ServerEntitlements.check(key);
  if(res && !res.unavailable) entitlementCache[String(key).toLowerCase()] = res;
  return entitlementFor(key);
}

/* What the UI is allowed to say about access. The copy lives here so that a
   view cannot invent a stronger claim than the mechanism supports. */
function entitlementPosture(){
  return {
    source: ServerEntitlements.available ? "server" : "device",
    enforceable: ServerEntitlements.available,
    headline: ServerEntitlements.available
      ? "Access verified with the licence server."
      : "Access recorded on this device.",
    detail: ServerEntitlements.available
      ? "Checked against your account each time the app can reach the server."
      : "This build has no licence server, so an access key is recorded here and not verified anywhere. Treat it as a receipt, not a lock \u2014 anyone reading the page source can see how it works. Every learning feature is free regardless, by rule.",
    unverifiable: !ServerEntitlements.available,
  };
}
