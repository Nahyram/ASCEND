/* THE SYSTEM v14 — services/perf.js
   Phase 15: performance and production readiness.

   The honest scope first, because this phase is the easiest one in the whole
   roadmap to fake. Load testing, stress testing, soak testing and global latency
   measurement all require something deployed and a population hitting it. There is
   neither. Numbers invented for those would be worse than no numbers, because they
   would be quoted later as if they had been measured.

   So this file does two things and refuses a third:

     - measures what a browser can actually measure on the device it is running on:
       per-view render cost, storage footprint, bundle weight, offline readiness;
     - keeps a permanent, visible list of what has NOT been tested and why;
     - refuses to synthesise a load-test result.

   §2 of the phase brief is the rule: measure, find the bottleneck, fix it, measure
   again. Never optimise from a guess. */
"use strict";

/* §3 — budgets stated up front, and chosen for a mid-range Android on 3G rather
   than for a benchmark score. */
const PERF_BUDGET = {
  viewRender:   120,      /* ms — a section switch should feel instant */
  firstPaint:  2500,      /* ms on a mid-range phone */
  scriptBytes: 1_200_000, /* the whole app, uncompressed */
  styleBytes:    160_000,
  storageBytes: 4_000_000,/* localStorage dies somewhere near 5 MB */
};

/* ---------- per-view timing (§9) ---------- */
const _viewTimes = {};
function recordViewTime(view, ms){
  const t = _viewTimes[view] = _viewTimes[view] || { n:0, total:0, worst:0 };
  t.n++; t.total += ms; t.worst = Math.max(t.worst, ms);
}
function viewTimings(){
  return Object.entries(_viewTimes)
    .map(([view, t]) => ({ view, n:t.n, avg: t.total / t.n, worst: t.worst,
                           overBudget: (t.total / t.n) > PERF_BUDGET.viewRender }))
    .sort((a, b) => b.avg - a.avg);
}

/* The timing wrapper lives in app/wiring.js, not here: this file loads long before
   app/router.js declares go(), so wrapping it at load time silently did nothing and
   every timing read back as zero. Load order is the dependency graph in a
   classic-script build, and a wrapper that installs too early fails quietly — which
   is the worst way for it to fail. */

/* ---------- storage footprint (§57) ---------- */
function storageReport(){
  const h = typeof H === "function" ? H() : null;
  const bytes = typeof Store === "object" ? Store.bytes() : 0;
  const part = (label, obj) => ({ label, bytes: obj ? JSON.stringify(obj).length : 0 });
  const parts = h ? [
    part("Daily history", h.done),
    part("Academy", h.academy),
    part("Projects", h.projects),
    part("Opportunities", h.opportunities),
    part("Quests", h.quests),
    part("Intelligence", h.brain),
    part("Armory index", h.vault),
  ].filter(p => p.bytes > 0).sort((a, b) => b.bytes - a.bytes) : [];

  /* §57 asks for retention. The prune candidates are named rather than applied —
     history is the one thing a student cannot regenerate. */
  const days = h && h.done ? Object.keys(h.done) : [];
  const old = days.filter(k => k < (() => { const d = new Date(); d.setDate(d.getDate() - 365); return todayKey(d); })());
  return {
    bytes, budget: PERF_BUDGET.storageBytes,
    pct: bytes / PERF_BUDGET.storageBytes,
    overBudget: bytes > PERF_BUDGET.storageBytes,
    parts,
    pruneCandidates: old.length
      ? [{ what:`Daily history older than a year`, n:old.length,
           note:"Removing it would free space and permanently lose the heatmap and long-run trends for those days. Export first, and only do it if the record is actually near the ceiling." }]
      : [],
  };
}

/* ---------- bundle weight (§5) ----------
   Measured from what the document actually references, so it cannot drift out of
   date the way a hand-maintained figure would. */
function bundleReport(){
  if(typeof document === "undefined") return null;
  const scripts = [...document.querySelectorAll("script[src]")].map(s => s.getAttribute("src"));
  const styles  = [...document.querySelectorAll('link[rel="stylesheet"]')].map(l => l.getAttribute("href"));
  return {
    scripts: scripts.length, styles: styles.length,
    /* §6, §8 — every module loads on first paint. Stated as a known cost rather
       than described as if code-splitting existed. */
    splitting: false,
    note: `All ${scripts.length} scripts load on first paint. Classic scripts share one scope and load order is the dependency graph, so splitting them requires the ES-module conversion first — that is the honest prerequisite, not a scheduling choice.`,
  };
}

/* ---------- offline readiness (§88) ----------
   A runtime check, because the static one in the test suite cannot see what the
   service worker actually cached on this device. */
async function offlineAudit(){
  /* v18 rewrite. The previous version reported "Everything the page loads is
     cached. The app will open with no connection." on evidence that could not
     support it:

       · It opened `names[names.length - 1]` — whichever cache happened to sort
         last. With a stale system-v17 cache still present alongside a new one,
         it could audit the wrong cache and pass.
       · It compared only `script[src]`. Stylesheets, the manifest, the icons
         and index.html itself were never checked, so a build missing every
         stylesheet reported clean and opened offline unstyled.
       · Its path normalisation assumed the app is served from the domain root.
         At any sub-path every entry mismatched — or, worse, coincidentally
         matched.
       · It treated the existence of a registration as readiness. A registered
         worker that is still installing, or that failed to install, controls
         nothing. Until `navigator.serviceWorker.controller` is set, the next
         offline load gets nothing.

     Offline is this product's central promise. A check that guesses at it is
     worse than no check, because it produces a sentence the README then
     repeats. This version asserts on the actual cache, for the actual asset
     list, and refuses to say "works offline" unless every part is verified. */
  const out = {
    supported:false, registered:false, controlled:false, active:false,
    cacheName:null, expected:0, cached:0, missing:[], extra:[],
    version:null, precacheReport:null, ready:false, note:"",
  };

  if(typeof navigator === "undefined" || !navigator.serviceWorker || typeof caches === "undefined"){
    out.note = "This browser has no service worker support, so the app runs online-only. Everything still works \u2014 it just will not open without a connection.";
    return out;
  }
  out.supported = true;

  /* A registration that failed outright is the loudest possible answer. */
  if(typeof SW_REGISTRATION_ERROR !== "undefined" && SW_REGISTRATION_ERROR){
    out.error = SW_REGISTRATION_ERROR;
    out.note = "The service worker could not be registered, so nothing is cached and the app will not open offline: " + SW_REGISTRATION_ERROR;
    return out;
  }

  try{
    const reg = await navigator.serviceWorker.getRegistration();
    out.registered = !!reg;
    out.active = !!(reg && reg.active);
    /* The distinction that matters. A controller is what serves the next load. */
    out.controlled = !!navigator.serviceWorker.controller;

    if(!out.registered){
      out.note = "No service worker is registered, so nothing is cached and the app will not open offline. Reload once while online.";
      return out;
    }

    /* Ask the worker which release it is rather than inferring it from a cache
       name found by guessing. */
    if(out.active && typeof MessageChannel !== "undefined"){
      out.version = await new Promise(res => {
        const ch = new MessageChannel();
        const t = setTimeout(() => res(null), 1500);
        ch.port1.onmessage = e => { clearTimeout(t); res(e.data || null); };
        try{ reg.active.postMessage({ type:"VERSION" }, [ch.port2]); }
        catch(e){ clearTimeout(t); res(null); }
      });
    }

    /* The right cache, by name, not by position. */
    const names = await caches.keys();
    const want = (out.version && out.version.cache) ||
                 (typeof SYSTEM_CACHE !== "undefined" ? SYSTEM_CACHE : null);
    out.cacheName = (want && names.includes(want)) ? want : null;
    if(!out.cacheName){
      out.note = names.length
        ? `This release's cache (${want}) is not present. Caches found: ${names.join(", ")}. The app will not open offline until the new worker finishes installing.`
        : "No cache exists yet. The app will not open offline until it has been loaded online once.";
      return out;
    }
    /* A leftover cache from a previous release is not fatal, but it is wasted
       storage on a device that may not have much, so it is reported. */
    out.extra = names.filter(n => n !== out.cacheName);

    const cache = await caches.open(out.cacheName);
    const keys = await cache.keys();
    const have = new Set(keys.map(r => new URL(r.url).pathname));
    out.cached = keys.length;

    /* Everything the page needs, resolved against the page's own base URL so it
       is correct at any deploy path. */
    const need = [
      location.pathname,                       /* the document itself */
      "./",
      "manifest.json",
      ...[...document.querySelectorAll("script[src]")].map(s => s.getAttribute("src")),
      ...[...document.querySelectorAll('link[rel="stylesheet"]')].map(l => l.getAttribute("href")),
      ...[...document.querySelectorAll('link[rel="icon"], link[rel="apple-touch-icon"]')].map(l => l.getAttribute("href")),
    ].filter(Boolean);

    const resolved = [...new Set(need.map(n => {
      try{ return new URL(n, location.href).pathname; }catch(e){ return null; }
    }).filter(Boolean))];
    out.expected = resolved.length;
    out.missing = resolved.filter(p => !have.has(p));

    /* What the install handler itself recorded. If the worker knows the
       precache was partial, that beats anything inferred from the outside. */
    try{
      const rep = await cache.match("__precache-report");
      if(rep) out.precacheReport = await rep.json();
    }catch(e){ /* absent on a worker older than v18 */ }

    out.ready = out.controlled && out.active && out.missing.length === 0;

    if(out.missing.length){
      out.note = `${out.missing.length} of ${out.expected} required file(s) are not cached, so the app will not open offline. Missing: ${out.missing.slice(0,5).join(", ")}${out.missing.length>5 ? ", \u2026" : ""}`;
    } else if(!out.controlled){
      out.note = "Everything is cached, but this page is not yet being served by the worker \u2014 that starts on the next load. Reload once and offline is ready.";
    } else {
      out.note = `Verified: all ${out.expected} required files are in ${out.cacheName} and the worker is serving this page. The app will open with no connection.`;
      if(out.precacheReport && out.precacheReport.failed && out.precacheReport.failed.length){
        out.note += ` ${out.precacheReport.failed.length} optional file(s) failed to cache \u2014 the app opens, those assets will not appear offline.`;
      }
    }
  }catch(e){
    out.note = "Could not read the cache: " + e.message + ". Offline readiness is unknown, which is not the same as working.";
  }
  return out;
}

/* ---------- what has NOT been measured (§79, §80, §81, §82) ----------
   Permanent. It does not shrink until the thing it names actually happens. */
const PERF_UNTESTED = [
  { k:"Load testing",    why:"Requires a deployed backend and concurrent clients. There is no backend, so any figure would be invented." },
  { k:"Stress testing",  why:"Same. A breaking point cannot be found for something with no server to break." },
  { k:"Soak testing",    why:"Needs the app running for days against real traffic. Only a long-running deployment can produce this." },
  { k:"Global latency",  why:"Needs measurement from multiple regions. A developer machine measures one." },
  { k:"Real-device matrix", why:"Verified in one browser engine under jsdom. Actual low-end Android behaviour is unverified." },
  { k:"Scale claims",    why:"The brief says do not claim a user count unless testing demonstrates it. Nothing here demonstrates any." },
];
function perfReport(){
  const b = bundleReport(), s = storageReport(), v = viewTimings();
  return {
    budget: PERF_BUDGET, bundle: b, storage: s, views: v,
    slowest: v[0] || null,
    overBudget: v.filter(x => x.overBudget).map(x => x.view),
    untested: PERF_UNTESTED,
    verdict: v.length
      ? (v.some(x => x.overBudget)
          ? `${v.filter(x => x.overBudget).length} section${v.filter(x => x.overBudget).length===1?"":"s"} render slower than the ${PERF_BUDGET.viewRender}ms budget on this device.`
          : `Every section measured renders inside the ${PERF_BUDGET.viewRender}ms budget on this device.`)
      : "No sections measured yet — navigate around and the figures fill in.",
  };
}
