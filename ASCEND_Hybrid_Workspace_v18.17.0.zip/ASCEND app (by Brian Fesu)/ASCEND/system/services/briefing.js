/* THE SYSTEM v14 — services/briefing.js
   Two summaries: one for the morning, one for the week.

   Both are assembled locally from the record. That is not a limitation being
   worked around — it is the correct engineering answer. A daily brief is a
   selection and ordering problem over data the device already holds, and a
   language model adds latency, cost and the possibility of inventing a number,
   in exchange for nicer sentences. Phase 3 §35 is explicit that where a
   deterministic algorithm is better, the algorithm wins. services/ai.js can
   rephrase any of this on request; nothing here waits for it. */
"use strict";

function briefKey(){ return todayKey(); }

/* ══════════════ daily briefing (§12) ══════════════ */
function dailyBriefing(){
  const m = userModel(); if(!m) return null;
  const h = H();
  const recs = recommendations({ model:m, max:5 });
  const rec = recoveryState();
  const due = questsFor(), left = due.filter(q => !isDone(q));

  const priority = recs.find(r => r.tier === TIER.HIGH) || recs[0] || null;
  const secondary = recs.filter(r => r !== priority && r.tier !== TIER.OPT).slice(0, 2);

  /* the honest one-line state of play */
  let headline;
  if(!due.length) headline = "Nothing is scheduled today.";
  else if(!left.length) headline = "Today is already cleared.";
  else if(rec.active) headline = `Recovery — ${rec.daysLeft} day${rec.daysLeft===1?"":"s"} left, ${left.length} of ${due.length} open.`;
  else headline = `${due.length - left.length} of ${due.length} cleared · ${left.length} to go`;

  /* unfinished business from yesterday, which §12 asks for by name */
  const yKey = (() => { const d = new Date(); d.setDate(d.getDate()-1); return todayKey(d); })();
  const yDue = questsFor(new Date(Date.now() - 86400000));
  const yDone = h.done[yKey] || {};
  const yMissed = yDue.filter(q => q.mand && !yDone[q.id]);

  return {
    date: todayKey(),
    headline,
    focus: focusGuidance(),
    priority,
    secondary,
    optional: recs.filter(r => r.tier === TIER.OPT).slice(0, 2),
    recovery: rec.active ? rec : null,
    deadlines: m.within7.slice(0, 3),
    carryover: yMissed.length ? {
      count: yMissed.length,
      names: yMissed.map(q => q.name).slice(0, 3),
      text: `${yMissed.length} mandatory quest${yMissed.length===1?"":"s"} missed yesterday. Late is still cleared — but only today.`,
    } : null,
    sample: m.meta.sample,
    conf: m.meta.conf,
  };
}

function markBriefRead(){ const b = brain(); if(b){ b.lastBrief = todayKey(); save(); } }
function briefUnread(){ const b = brain(); return !b || b.lastBrief !== todayKey(); }

/* ══════════════ weekly review (§13) ══════════════
   Runs over the last seven complete days and compares them with the seven before.
   Every figure states what it was counted from, because a review that cannot be
   checked is just a mood. */
function weeklyReview(){
  const m = userModel(); if(!m) return null;
  const h = H();

  const range = (from, to) => {
    const keys = []; for(let i = from; i <= to; i++){ const d = new Date(); d.setDate(d.getDate()-i); keys.push(todayKey(d)); }
    return keys;
  };
  const thisKeys = range(1,7), lastKeys = range(8,14);
  const rowsIn = keys => m.rows.filter(r => keys.includes(r.key));
  const now = rowsIn(thisKeys), prev = rowsIn(lastKeys);

  const clearedIn = keys => keys.reduce((s,k) => s + Object.keys(h.done[k] || {}).length, 0);

  /* XP is not stored per day, so it is derived from what was actually cleared —
     stated as an estimate rather than dressed up as a ledger. */
  const xpIn = keys => {
    let xp = 0;
    for(const k of keys){
      const set = h.done[k] || {};
      for(const q of (h.quests || [])) if(set[q.id]) xp += (q.xp || 0);
    }
    return xp;
  };

  const catRows = {};
  for(const r of now){ (catRows[r.cat] = catRows[r.cat] || { n:0, hit:0 }); catRows[r.cat].n++; if(r.done) catRows[r.cat].hit++; }
  const cats = Object.entries(catRows).map(([cat,v]) => ({ cat, n:v.n, rate:v.hit/v.n })).sort((a,b) => b.rate - a.rate);

  const goalsMoved = m.goals.filter(g => g.done > 0);
  const patterns = detectPatterns({ model:m, max:3 });

  const rateNow = now.length ? now.filter(r => r.done).length / now.length : 0;
  const ratePrev = prev.length ? prev.filter(r => r.done).length / prev.length : 0;

  return {
    from: thisKeys[thisKeys.length-1], to: thisKeys[0],
    enough: now.length >= 10,
    cleared: clearedIn(thisKeys),
    clearedPrev: clearedIn(lastKeys),
    rate: rateNow, ratePrev, delta: ratePrev ? rateNow - ratePrev : 0,
    xp: xpIn(thisKeys), xpPrev: xpIn(lastKeys),
    scheduled: now.length,
    streak: h.streak || 0,
    strongest: cats[0] || null,
    weakest: cats.length > 1 ? cats[cats.length-1] : null,
    perfectDays: thisKeys.filter(k => {
      const d = new Date(k + "T00:00:00"), due = questsFor(d), set = h.done[k] || {};
      return due.length && due.every(q => set[q.id]);
    }).length,
    zeroDays: thisKeys.filter(k => {
      const d = new Date(k + "T00:00:00"), due = questsFor(d), set = h.done[k] || {};
      return due.length && !due.some(q => set[q.id]);
    }).length,
    goalsMoved: goalsMoved.length,
    booksRead: (h.booksRead || []).length,
    patterns,
    /* the one change worth making next week — a review with no decision in it
       is a report, and reports do not change behaviour */
    change: (() => {
      const p = patterns[0];
      if(!now.length) return "Not enough of a week to review. Start by clearing tomorrow's first quest.";
      if(rateNow >= 0.9) return "Nothing needs fixing. Add one quest with real weight rather than three small ones.";
      if(ratePrev && rateNow - ratePrev <= -0.15) return "Cut two optional quests for seven days. Protecting the streak is worth more than protecting the plan.";
      if(p && p.action) return p.action;
      return "Pick the quest you missed most this week and change its hour. Same effort, different slot.";
    })(),
  };
}

/* Sunday evening, or any time it has not been seen this week. */
function reviewDue(){
  const b = brain(); if(!b) return false;
  const wk = (() => { const d = new Date(); const day = (d.getDay() + 6) % 7; d.setDate(d.getDate() - day); return todayKey(d); })();
  return b.lastReview !== wk && new Date().getDay() === 0;
}
function markReviewRead(){
  const b = brain(); if(!b) return;
  const d = new Date(); const day = (d.getDay() + 6) % 7; d.setDate(d.getDate() - day);
  b.lastReview = todayKey(d); save();
}
