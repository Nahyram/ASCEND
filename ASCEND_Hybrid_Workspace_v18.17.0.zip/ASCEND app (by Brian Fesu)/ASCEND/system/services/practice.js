/* THE SYSTEM v14 — services/practice.js
   Practice, mistakes, and the review schedule that comes out of them.

   Two constraints shape this file more than anything in the phase document.

   First, copyright (§16, §33). THE SYSTEM does not ship exam questions and does
   not scrape them. Every question in the bank is one the student wrote, or one
   they typed in from material they legitimately hold. For real past papers the
   app records metadata and a link and sends them to the official source. That is
   not caution for its own sake — a study app that redistributes a board's papers
   is one that gets taken down, taking the student's notes with it.

   Second, §9's distinction has to be enforced here rather than merely stated in
   the curriculum file. Getting a question right is what moves a topic; opening a
   topic is not. So this is where mastery actually changes.

   The spaced-review scheduler is a deliberately small SM-2 variant. §22 is right
   that no single schedule fits everyone, and §15 of Phase 3 is right that the app
   must not claim to predict human memory — so intervals adapt from the student's
   own recall record and the UI says the interval is a suggestion. */
"use strict";

const QUESTION_TYPES = [
  { k:"mcq",   label:"Multiple choice" },
  { k:"short", label:"Short answer" },
  { k:"tf",    label:"True / false" },
  { k:"calc",  label:"Calculation" },
  { k:"open",  label:"Structured / essay" },
];

/* §19 — the categories a student can actually act on. "Careless" and "knowledge
   gap" need opposite responses, and lumping them together is why error logs
   usually get abandoned. */
const MISTAKE_KINDS = [
  { k:"gap",       label:"Knowledge gap",     fix:"You had not learnt it. Go back to the material, not to more questions." },
  { k:"misunder",  label:"Misunderstanding",  fix:"You learnt it wrong. Find the specific wrong idea before practising again." },
  { k:"method",    label:"Method error",      fix:"Right idea, wrong route. Write the steps out once, in order." },
  { k:"calc",      label:"Calculation slip",  fix:"Arithmetic, not understanding. Slow the working, do not re-study the topic." },
  { k:"misread",   label:"Misread question",  fix:"Underline what is actually being asked before starting." },
  { k:"incomplete",label:"Incomplete answer", fix:"You knew it and did not finish. Check the mark allocation." },
  { k:"time",      label:"Ran out of time",   fix:"A pacing problem, not a knowledge problem. Practise timed." },
];

/* ══════════════ the question bank (§16) ══════════════ */
function addQuestion({ topicId, text, type = "short", answer = "", options = [], explanation = "", difficulty = "moderate", source = "" }){
  const a = academy(); if(!a) return null;
  const q = {
    id: uid(), topicId, type,
    text: String(text || "").slice(0, 600).trim(),
    answer: String(answer || "").slice(0, 400),
    options: (options || []).slice(0, 6).map(o => String(o).slice(0, 200)),
    explanation: String(explanation || "").slice(0, 800),
    difficulty, source: String(source || "").slice(0, 120),
    stats: { attempts:0, correct:0 }, created: todayKey(),
  };
  if(!q.text) return null;
  a.questions.push(q); save(); invalidateAcademy();
  return q;
}
function questionsFor(topicId){ return (academy().questions || []).filter(q => q.topicId === topicId); }
function deleteQuestion(id){
  const a = academy(); if(!a) return false;
  a.questions = a.questions.filter(q => q.id !== id); save(); return true;
}

/* ══════════════ difficulty adaptation (§17) ══════════════
   Accuracy decides the tier of the next question, and the tier moves one step at
   a time. §17 asks explicitly that difficulty not jump unpredictably — a student
   who gets two right and is handed a Legendary question learns that the app is
   erratic, not that they are improving. */
const PRACTICE_TIERS = ["easy", "moderate", "hard", "epic"];
function nextDifficulty(current, recent){
  const i = Math.max(0, PRACTICE_TIERS.indexOf(current || "moderate"));
  if(recent.length < 3) return PRACTICE_TIERS[i];
  const acc = recent.filter(Boolean).length / recent.length;
  if(acc >= 0.85) return PRACTICE_TIERS[Math.min(PRACTICE_TIERS.length - 1, i + 1)];
  if(acc <= 0.4)  return PRACTICE_TIERS[Math.max(0, i - 1)];
  return PRACTICE_TIERS[i];
}

/* Builds a practice set. Weakest topics first, unseen questions before repeats,
   and the ones you got wrong before ahead of the ones you got right. */
function buildPracticeSet(subjectId, size = 10){
  const a = academy(); if(!a) return [];
  const topics = allTopics(subjectId).map(t => ({ t, m:masteryOf(t) }));
  const errs = a.errors || [];
  const wrongCount = {};
  for(const e of errs) if(!e.resolved) wrongCount[e.questionId] = (wrongCount[e.questionId] || 0) + 1;

  const pool = [];
  for(const { t, m } of topics){
    for(const q of questionsFor(t.id)){
      pool.push({
        q, topic:t,
        score: (1 - m.pct) * 3                      /* weak topics first */
             + (wrongCount[q.id] || 0) * 2          /* previously wrong, unresolved */
             + (q.stats.attempts === 0 ? 1.5 : 0)   /* never seen */
             - Math.min(1, q.stats.attempts / 8),   /* over-drilled last */
      });
    }
  }
  pool.sort((x, y) => y.score - x.score);
  return pool.slice(0, size);
}

/* ══════════════ answering ══════════════
   This is the one function that moves mastery. Everything else records intent. */
function recordAnswer({ questionId, correct, mistakeKind = null, given = "", confidence = null, seconds = null }){
  const a = academy(); if(!a) return null;
  const q = (a.questions || []).find(x => x.id === questionId); if(!q) return null;
  const t = findTopicRef(q.topicId); if(!t) return null;

  /* §7 — the capability stat is paid from here, and it is measured as how far
     mastery actually MOVED, not as a count of answers. That makes it unfarmable
     without a separate anti-farm rule: masteryOf() has diminishing returns, so
     the tenth correct answer on a topic moves it barely at all and pays close to
     nothing, while the answer that first demonstrates a hard question moves it
     properly and pays properly. Capability stats track demonstrated capability.
     Snapshot before mutating the evidence counters below. */
  const before = masteryOf(t);
  q.stats.attempts++; if(correct) q.stats.correct++;
  t.ev.attempts++;
  if(correct){
    t.ev.correct++;
    if(q.difficulty === "hard" || q.difficulty === "epic") t.ev.hardCorrect++;
  }
  if(confidence != null) t.ev.confidence = confidence;

  if(!correct){
    /* §18 — the error log. Recorded with a cause, because "I got it wrong" is not
       information you can act on next week. */
    a.errors.push({
      id: uid(), questionId, topicId: q.topicId,
      kind: mistakeKind || "gap", given: String(given || "").slice(0, 300),
      date: todayKey(), resolved: false, seconds,
    });
    if(a.errors.length > 500) a.errors = a.errors.slice(-500);
  } else {
    /* clearing an old error on the same question closes the loop */
    for(const e of a.errors) if(e.questionId === questionId && !e.resolved) e.resolved = true;
  }

  save(); invalidateAcademy();
  const after = masteryOf(t);
  if(correct){
    grantXp(8, `Practice — ${t.name}`, { once:"practice:" + questionId + ":" + todayKey() });
    /* Scaled so a full 0 → 1 climb across a topic's whole life is worth about
       10 points of Intellect, spread across every answer that earned it. */
    const moved = Math.max(0, (after ? after.pct : 0) - (before ? before.pct : 0));
    if(moved > 0) grantStat("study", Math.round(moved * 100) / 10,
      { evidence: `mastery ${t.name} ${Math.round((before?before.pct:0)*100)}% → ${Math.round(after.pct*100)}%` });
  }
  return { mastery: after, question:q };
}

/* ══════════════ the error log (§18, §19) ══════════════ */
function errorLog({ subjectId = null, unresolvedOnly = true } = {}){
  const a = academy(); if(!a) return [];
  const topicIds = subjectId ? new Set(allTopics(subjectId).map(t => t.id)) : null;
  return (a.errors || [])
    .filter(e => (!unresolvedOnly || !e.resolved) && (!topicIds || topicIds.has(e.topicId)))
    .map(e => {
      const t = getTopic(e.topicId);
      const q = (a.questions || []).find(x => x.id === e.questionId);
      return { ...e, topic:t, question:q, kindInfo: MISTAKE_KINDS.find(k => k.k === e.kind) || MISTAKE_KINDS[0] };
    })
    .sort((x, y) => String(y.date).localeCompare(String(x.date)));
}

/* Which mistake is costing the most, and what kind of problem it actually is. */
function errorPattern(subjectId){
  const log = errorLog({ subjectId, unresolvedOnly:false });
  if(log.length < 5) return null;
  const byKind = {}, byTopic = {};
  for(const e of log){
    byKind[e.kind] = (byKind[e.kind] || 0) + 1;
    byTopic[e.topicId] = (byTopic[e.topicId] || 0) + 1;
  }
  const topKind = Object.entries(byKind).sort((a,b) => b[1] - a[1])[0];
  const topTopic = Object.entries(byTopic).sort((a,b) => b[1] - a[1])[0];
  const kind = MISTAKE_KINDS.find(k => k.k === topKind[0]) || MISTAKE_KINDS[0];
  const t = getTopic(topTopic[0]);
  return {
    n: log.length,
    kind, kindCount: topKind[1],
    topic: t, topicCount: topTopic[1],
    text: `${topKind[1]} of your last ${log.length} mistakes were ${kind.label.toLowerCase()}.`,
    fix: kind.fix,
  };
}

/* ══════════════ mistake → boss (§20) ══════════════
   The phase document asks for a "recovery quest" chain when a topic keeps going
   wrong. Phase 4 already built that mechanic, so this reuses it rather than
   inventing a second one — the same argument Phase 9 §12 makes about not building
   a parallel task system. */
function recoveryCandidates(){
  const a = academy(); if(!a) return [];
  const count = {};
  for(const e of a.errors || []) if(!e.resolved) count[e.topicId] = (count[e.topicId] || 0) + 1;
  return Object.entries(count)
    .filter(([, n]) => n >= 3)
    .map(([id, n]) => ({ topic: getTopic(id), errors: n, mastery: masteryOf(id) }))
    .filter(x => x.topic)
    .sort((a, b) => b.errors - a.errors);
}
function bossFromTopic(topicId){
  const t = getTopic(topicId); if(!t) return null;
  const errs = errorLog({ unresolvedOnly:true }).filter(e => e.topicId === topicId);
  const kinds = [...new Set(errs.map(e => e.kind))]
    .map(k => (MISTAKE_KINDS.find(x => x.k === k) || {}).label).filter(Boolean);
  return createBoss({
    name: `${t.name} — recovery`,
    template: "custom",
    difficulty: "hard",
    stages: [
      `Re-learn ${t.name} from one source, not four`,
      kinds.length ? `Read your error log — your mistakes here were: ${kinds.join(", ")}` : "Read your error log for this topic",
      `Redo the ${errs.length} question${errs.length === 1 ? "" : "s"} you got wrong`,
      `Answer five fresh questions on ${t.name}`,
      `Come back after three days and answer three more`,
    ],
  });
}

/* ══════════════ flashcards & spaced review (§21, §22) ══════════════ */
const REVIEW_GRADES = [
  { k:"again", label:"Again",  ease:-0.30, mult:0 },
  { k:"hard",  label:"Hard",   ease:-0.15, mult:1.2 },
  { k:"good",  label:"Good",   ease:0,     mult:2.2 },
  { k:"easy",  label:"Easy",   ease:0.15,  mult:3.2 },
];

function addCard({ topicId, front, back, hint = "" }){
  const a = academy(); if(!a) return null;
  const c = {
    id: uid(), topicId,
    front: String(front || "").slice(0, 400).trim(),
    back:  String(back  || "").slice(0, 600).trim(),
    hint:  String(hint  || "").slice(0, 200),
    ease: 2.3, interval: 0, due: todayKey(), reps: 0, lapses: 0, created: todayKey(),
  };
  if(!c.front || !c.back) return null;
  a.cards.push(c); save(); invalidateAcademy();
  return c;
}
function dueCards(subjectId){
  const a = academy(); if(!a) return [];
  const t = todayKey();
  const ids = subjectId ? new Set(allTopics(subjectId).map(x => x.id)) : null;
  return (a.cards || [])
    .filter(c => c.due <= t && (!ids || ids.has(c.topicId)))
    .sort((x, y) => String(x.due).localeCompare(String(y.due)));
}

function reviewCard(cardId, gradeKey){
  const a = academy(); if(!a) return null;
  const c = (a.cards || []).find(x => x.id === cardId); if(!c) return null;
  const g = REVIEW_GRADES.find(x => x.k === gradeKey) || REVIEW_GRADES[2];

  c.reps++;
  c.ease = Math.max(1.3, Math.min(3.0, c.ease + g.ease));
  if(g.k === "again"){
    c.lapses++;
    c.interval = 0;                    /* §22 — repeated failure returns to learning */
  } else {
    c.interval = c.interval === 0 ? 1 : Math.max(1, Math.round(c.interval * c.ease * (g.mult / 2.2)));
  }
  const d = new Date(); d.setDate(d.getDate() + Math.max(0, c.interval));
  const prevDue = c.due;
  c.due = todayKey(d);

  /* the card's outcome is evidence about the topic — this is what makes
     "recalled" in curriculum.js mean something */
  const t = findTopicRef(c.topicId);
  if(t){
    t.ev.recalls++;
    if(g.k !== "again") t.ev.recallHits++;
    const gap = prevDue ? Math.round((new Date(todayKey()+"T00:00:00") - new Date(prevDue+"T00:00:00"))/86400000) : 0;
    if(g.k !== "again" && c.interval > 0) t.ev.reviewGap = Math.max(t.ev.reviewGap || 0, c.interval);
    t.ev.lastReview = todayKey();
  }
  save(); invalidateAcademy();
  grantXp(4, "Review", { once:"card:" + cardId + ":" + todayKey() });
  return { card:c, nextIn:c.interval, mastery: t ? masteryOf(t) : null };
}

/* Turning a mistake into a card is the single highest-value action in the whole
   Academy, so it gets a one-call path (§24 — notes into flashcards, same idea). */
function cardFromError(errorId){
  const a = academy(); if(!a) return null;
  const e = (a.errors || []).find(x => x.id === errorId); if(!e) return null;
  const q = (a.questions || []).find(x => x.id === e.questionId); if(!q) return null;
  return addCard({ topicId: q.topicId, front: q.text, back: q.answer || q.explanation || "", hint: q.explanation ? "" : "" });
}

function reviewLoad(){
  const a = academy(); if(!a) return { due:0, tomorrow:0, week:0, total:0 };
  const t = todayKey();
  const plus = n => { const d = new Date(); d.setDate(d.getDate()+n); return todayKey(d); };
  const cards = a.cards || [];
  return {
    due: cards.filter(c => c.due <= t).length,
    tomorrow: cards.filter(c => c.due === plus(1)).length,
    week: cards.filter(c => c.due > t && c.due <= plus(7)).length,
    total: cards.length,
  };
}
