/* THE SYSTEM v14 — services/ai.js
   One service, several possible providers, and a local answer for when there are
   none.

   Phase 3 §24 asks that no part of the application be wired to a specific vendor.
   v13 had exactly one call site — the tutor, posting to a self-hosted worker — and
   that was already the right shape, so this file generalises it rather than
   replacing it. Everything above talks to `AI.ask(...)`; which provider answers is
   a configuration detail.

   Three things this file refuses to do, all of them deliberate:

   1. It never holds a provider API key. The key lives on the hunter's own worker,
      server-side. A key in frontend JavaScript is a public key, and v4 of this app
      already had that argument and settled it — Phase 6 §32 says the same.
   2. It never sends the record. §25 says do not ship the database to a model.
      Callers pass a small, named context object and nothing else travels.
   3. It never becomes load-bearing. Every capability has a local answer, so the
      app works identically with the network unplugged — §26. AI improves wording
      and handles open questions; it is not where the product's intelligence lives.

   Cost control (§25): a per-day request cap, a response cache keyed on the exact
   request, and context compression before anything is sent. */
"use strict";

const AI_CAP_PER_DAY = 40;      /* deliberately conservative — a student on mobile data */
const AI_TIMEOUT_MS  = 20000;
const AI_CACHE_MAX   = 30;

/* This app's capabilities, mapped onto the gateway's fixed modes. The two
   vocabularies grew separately and mapping them is one table rather than a
   rename across either side. Anything unmapped falls back to "tutor". */
const AI_SERVER_MODES = {
  tutor:"tutor", brief:"plan", review:"plan", goal:"plan", why:"diagnose",
  practice:"practice", feedback:"feedback", socratic:"socratic",
};

/* ---------- provider adapters ----------
   An adapter turns {system, messages} into a string. Adding a provider means
   adding one object here; nothing else in the codebase changes. */
const AI_PROVIDERS = {
  /* The ASCEND backend. First in the list, so a signed-in student uses it and
     the hunter's own worker becomes the fallback rather than the default.

     This is the arrangement the whole design has been pointing at: the browser
     talks to ASCEND, ASCEND talks to OpenAI. The key sits in the server's
     environment, the daily cap is counted in a table only the server can write,
     and the context allow-list lives in server/src/ai/gateway.js — so a tampered
     client can spend nothing and leak nothing that the gateway does not permit.

     Note what is deliberately NOT sent: `system`. The server composes its own
     system prompt from a fixed set of modes. A client that could supply the
     system prompt could talk the model out of every rule in it, which is the
     usual way a "secure proxy" turns out not to be one. The capability name maps
     to a mode instead; the caller's own instruction rides along as text. */
  ascend: {
    name:"ascend",
    label:"ASCEND server",
    available(){
      const c = typeof cloud === "function" ? cloud() : null;
      return !!(c && c.apiBase && c.mode === "account" && c.token);
    },
    async send({ system, messages, signal, capability, context }){
      const list = Array.isArray(messages) ? messages : [];
      const lastUser = [...list].reverse().find(m => m.role === "user");
      const prompt = String((lastUser && lastUser.content) || "").trim();
      if(!prompt) throw new Error("Nothing to ask");

      const data = await restFetch("/ai/ask", {
        method:"POST",
        body:{
          mode: AI_SERVER_MODES[capability] || "tutor",
          prompt,
          /* The instruction the caller wrote, carried as user-side text so the
             server's own system prompt stays the outer authority. */
          task: typeof system === "string" ? system.slice(0, 1200) : undefined,
          context: context || undefined,
          history: list.filter(m => m !== lastUser).slice(-8),
        },
        signal,
      });
      if(!data || typeof data.text !== "string") throw new Error("Malformed reply");
      return data.text.slice(0, 8000);
    },
  },

  /* the hunter's own proxy — still supported, for anyone self-hosting a worker
     rather than the ASCEND backend */
  worker: {
    name: "worker",
    label: "Your own endpoint",
    available(){ const h = H(); return !!(h && h.aiEndpoint); },
    async send({ system, messages, signal }){
      const h = H();
      const res = await fetch(h.aiEndpoint, {
        method:"POST", headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ system, messages }), signal,
      });
      if(!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      if(typeof data.reply !== "string") throw new Error("Malformed reply");
      return data.reply.slice(0, 8000);
    },
  },
};

/* ---------- usage ledger ---------- */
function aiUsage(){
  const h = H(); if(!h) return { used:0, cap:AI_CAP_PER_DAY, left:AI_CAP_PER_DAY };
  h.brain = h.brain || {};
  const u = h.brain.ai = h.brain.ai || { day:todayKey(), used:0 };
  if(u.day !== todayKey()){ u.day = todayKey(); u.used = 0; }
  return { used:u.used, cap:AI_CAP_PER_DAY, left:Math.max(0, AI_CAP_PER_DAY - u.used) };
}
function aiCount(){ const h = H(); if(!h) return; aiUsage(); h.brain.ai.used++; save(); }

/* ---------- cache ---------- */
const _aiCache = new Map();
function cacheKey(o){ return JSON.stringify(o).slice(0, 2000); }
function cacheGet(k){ return _aiCache.get(k) || null; }
function cacheSet(k, v){
  _aiCache.set(k, v);
  while(_aiCache.size > AI_CACHE_MAX) _aiCache.delete(_aiCache.keys().next().value);
}

/* ---------- context minimisation (§25, §33) ----------
   Callers hand over what they think is relevant; this strips it to primitives,
   caps the size, and drops anything that looks like it identifies a person. The
   hunter's name, avatar, PIN material and raw logs never leave. */
function compressContext(ctx){
  if(!ctx || typeof ctx !== "object") return null;
  const BLOCKED = /name|avatar|pin|hash|salt|endpoint|install|email|phone|address|log$/i;
  const out = {};
  for(const [k,v] of Object.entries(ctx)){
    if(BLOCKED.test(k)) continue;
    if(v == null) continue;
    if(typeof v === "number" || typeof v === "boolean"){ out[k] = v; continue; }
    if(typeof v === "string"){ out[k] = v.slice(0, 300); continue; }
    if(Array.isArray(v)){ out[k] = v.slice(0, 8).map(x => typeof x === "string" ? x.slice(0,120) : x); continue; }
  }
  return Object.keys(out).length ? out : null;
}

/* ══════════════ the service ══════════════ */
const AI = {
  get provider(){
    for(const p of Object.values(AI_PROVIDERS)) if(p.available()) return p;
    return null;
  },
  get online(){ return typeof navigator === "undefined" || navigator.onLine !== false; },
  get ready(){ return !!this.provider && this.online; },

  status(){
    const p = this.provider, u = aiUsage();
    /* v18: the online tutor is a paid feature, so it asks. The local analysis
       below it never does — that is the free core, and licenceCheck() refuses by
       name any attempt to register it as paid. */
    if(typeof licenceCheck === "function"){
      const lic = licenceCheck("onlineai");
      if(!lic.allowed) return { ok:false, reason:"not-entitled", text:lic.note ||
        "The online tutor is part of the paid layer. The System's own analysis is local, free, and unaffected." };
    }
    if(!p)          return { ok:false, reason:"no-endpoint", text:"No AI endpoint configured. Everything still works — the System's own analysis is local and does not need one." };
    if(!this.online)return { ok:false, reason:"offline",     text:"Offline. Local analysis is unaffected; anything needing the endpoint is paused until the connection returns." };
    if(!u.left)     return { ok:false, reason:"capped",      text:`Daily AI limit reached (${u.cap} requests). It resets at midnight. Local analysis is unaffected.` };
    return { ok:true, provider:p.label, left:u.left, text:`${p.label} · ${u.left} of ${u.cap} requests left today.` };
  },

  /* ask(capability, {system, messages, context, local})
     `local` is the deterministic answer and is mandatory. If a caller cannot write
     one, that capability does not belong behind an AI call. */
  async ask(capability, opts = {}){
    const local = typeof opts.local === "function" ? opts.local : () => null;
    const st = this.status();
    if(!st.ok) return { source:"local", text:local(), note:st.text };

    const ctx = compressContext(opts.context);
    const payload = {
      system: (opts.system || "").slice(0, 4000),
      messages: (opts.messages || []).slice(-8).map(m => ({
        role: m.role === "user" ? "user" : "assistant",
        content: String(m.content || "").slice(0, 2000),
      })),
    };
    if(ctx) payload.system += "\n\nContext (numbers already computed on the student's device — use them, do not invent others): " + JSON.stringify(ctx);

    const key = capability + "|" + cacheKey(payload);
    const hit = cacheGet(key);
    if(hit) return { source:"ai", text:hit, cached:true, note:"Cached — no request sent." };

    /* 18.14 — entitlement(), server-authoritative since 18.7, had ZERO call
       sites outside cloud.js. That is the second time this exact defect has been
       found in this codebase: v18 found the same rule declared and enforced
       nowhere, and the fix then was to write the rule, not to call it.

       The server already refuses over its own limit, so this is not the security
       boundary — it is the difference between a student being told their plan
       does not include the tutor and a student watching a request fail with no
       explanation. Checked here because this is the one capability that spends
       somebody's money. */
    if(typeof hasEntitlement === "function"){
      const key = capability === "tutor" ? "ADVANCED_TUTOR" : "AI_COACH";
      const ent = entitlement(key);
      if(!ent.allowed){
        return { source:"local", text: local ? local() : "",
          note:"Your account does not include this. Everything else on this screen is unaffected." };
      }
    }

    const ac = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timer = setTimeout(() => ac && ac.abort(), AI_TIMEOUT_MS);
    try{
      /* The compressed context goes to the provider as an object as well as
         inside `system`. The worker adapter only understands the string; the
         ascend adapter wants the object, because the server re-filters it
         against its own allow-list and cannot do that to prose. */
      const text = await this.provider.send({
        ...payload, signal: ac ? ac.signal : undefined,
        capability, context: ctx || undefined,
      });
      clearTimeout(timer);
      aiCount(); cacheSet(key, text);
      return { source:"ai", text, note:null };
    }catch(err){
      clearTimeout(timer);
      return {
        source:"local", text:local(),
        note:`The endpoint did not answer (${err && err.message ? err.message : "unknown error"}). This is the System's own analysis instead.`,
      };
    }
  },

  /* A prompt the hunter can paste into any free AI app. This is the fallback that
     has always worked best on a school phone with no budget: no endpoint, no key,
     no cost, and the student keeps control of what is shared. */
  promptFor(capability, ctx){
    const c = compressContext(ctx);
    return [
      `You are a study coach for a secondary-school student. Be specific and brief. Do not invent facts about the student.`,
      c ? `Here is what their own tracking app has computed: ${JSON.stringify(c)}` : "",
      AI_TASKS[capability] || "Give one concrete piece of advice.",
    ].filter(Boolean).join("\n\n");
  },
};

const AI_TASKS = {
  brief:  "Using only those numbers, write a 60-word plan for today. Say what to do first and why.",
  review: "Using only those numbers, write a 100-word weekly review: what improved, what slipped, and the one change to make next week.",
  goal:   "Break this goal into 3 milestones with 3 concrete actions each. Each action must be startable within an hour.",
  why:    "Explain in 80 words why this pattern might happen and one thing to test next week.",
  tutor:  "Teach this step by step: the core idea in plain words, one fully worked example, the common mistake, and one practice question you do not solve. Never hand over a finished homework answer without the method.",
};
