/* THE SYSTEM v18 — services/tutor.js
   The tutor's brain. views/tutor.js now only draws it.

   ## Why this file exists

   Until v18 the tutor called fetch() directly from the view:

       const res = await fetch(h.aiEndpoint, { method:"POST", ... });

   services/ai.js existed the whole time, with a daily cap, a response cache, a
   timeout, context minimisation and an entitlement check — and the one feature
   in the app that actually talks to a model went around all of it. Every one of
   those protections was absent at the only call site that needed them:

     · no timeout      — a hung endpoint hung the Ask button until the tab died,
                         because fetch() with no AbortController waits for the
                         OS to give up, which on mobile can be minutes.
     · no daily cap    — a student on Ghanaian mobile data could spend the
                         bundle on a retry loop.
     · no cache        — the same question re-billed the endpoint every time.
     · no privacy filter — the view posted its own log; ai.js's compressContext()
                         (which strips name, avatar, PIN material, endpoints)
                         never ran.
     · no entitlement  — onlineai is a registered paid feature. The paywall was
                         declared in business.js and enforced nowhere.

   A gateway that a caller may bypass is not a gateway; it is a suggestion. So
   the rule for v18 is narrow and testable: **no fetch() outside services/ and
   online.js**, checked statically in brain-test.js. If a view needs the network,
   it needs a service.

   ## The local answer is not a fallback

   AI.ask() requires a `local` function and this file gives it a real one: the
   study-card knowledge base plus a master prompt the student can paste into any
   free AI app. That has always been the mode that works best on a school phone
   with no budget, so it is the default rather than the consolation prize. The
   online path improves the wording of an answer that already exists. */
"use strict";

/* ---------- knowledge base ----------
   Moved here unchanged from views/tutor.js. It is data, and data does not
   belong in a file whose job is to build DOM nodes. */
const TUT_KB = [
  {k:/quadratic|ax\^?2|roots of/i, t:"Quadratic formula", b:"For ax\u00b2 + bx + c = 0:\nx = (\u2212b \u00b1 \u221a(b\u00b2 \u2212 4ac)) / 2a\nDiscriminant b\u00b2\u22124ac: >0 two real roots \u00b7 =0 one root \u00b7 <0 no real roots."},
  {k:/peel|paragraph|essay structure|topic sentence/i, t:"PEEL paragraphs", b:"Point \u2014 one clear claim.\nEvidence \u2014 quote/data/example.\nExplain \u2014 how the evidence proves the point.\nLink \u2014 tie back to the question.\nOne idea per paragraph. The examiner marks the explain step hardest."},
  {k:/revis|study plan|timetable|spaced/i, t:"Spaced repetition", b:"Review new material after 1 day \u2192 3 days \u2192 1 week \u2192 2 weeks \u2192 1 month.\nEach review: close the notes, recall from memory first, then check. Recall beats re-reading \u2014 every time."},
  {k:/active recall|flashcard|memoriz|remember/i, t:"Active recall", b:"Don't re-read \u2014 self-test. Turn headings into questions, answer from memory, then check.\nFlashcards: question on front, minimal answer on back, shuffle daily, retire cards you get right 3\u00d7 in a row."},
  {k:/feynman|understand|explain simply/i, t:"Feynman technique", b:"1. Pick the concept. 2. Explain it aloud as if to a 10-year-old. 3. Note where you stumble \u2014 that's the gap. 4. Re-learn the gap, simplify again. If you can't say it simply, you don't own it yet."},
  {k:/exam day|night before|panic|stress|anxious|nervous/i, t:"Exam-day protocol", b:"Night before: pack ID/tools, stop studying by 21:00, sleep \u2265 8h.\nIn the hall: read the whole paper first, do easiest questions first to bank marks, budget minutes per mark, leave 10 min to check.\nBlank mind? Breathe out slowly 4\u00d7 and start writing anything relevant \u2014 momentum returns."},
  {k:/past paper|mark scheme|past question/i, t:"Past-paper method", b:"1. Do the paper timed, no notes. 2. Mark it yourself WITH the official mark scheme \u2014 be brutal. 3. Log every lost mark in an error log (topic + why). 4. Re-drill only the error-log topics. The error log is the syllabus that matters for YOU."},
  {k:/money blueprint|thermostat|mindset about money|think rich/i, t:"Money blueprint", b:"Your results tend to match the level you're inwardly set for — like a thermostat. Raise the setting: notice the money beliefs you absorbed as a kid, question them, and act from the new setting daily. Thoughts → feelings → actions → results."},
  {k:/pay yourself|jars|manage money|save money/i, t:"Pay yourself first", b:"Split every amount you receive the moment it arrives: 10% Freedom (invest only — never spend), 10% Learn, 10% Long-term, 10% Play, 10% Give, 50% Needs. The Vault tab does this for you. Small amounts split with discipline beat big amounts unsplit."},
  {k:/five buckets|network|reputation|career capital|first job/i, t:"The five buckets", b:"Career value fills in order: what you know \u2192 what you can do \u2192 who you know \u2192 what you have \u2192 what people say about you. Early on, trade for knowledge and skill even over money \u2014 the later buckets fill themselves once the first two are heavy."},
  {k:/quit|give up|sunk cost|keep going or stop/i, t:"Quitting well", b:"Sunk cost is deciding from what you already spent instead of what lies ahead. Ask: knowing everything I know now, would I start this today? If the honest answer is no, quitting isn't failure \u2014 it's redirecting the grind. Quit the thing, keep the discipline."},
  {k:/mastery|mentor|apprentice|get really good|10,?000/i, t:"The path to mastery", b:"Skill grows in phases: deep observation and basics first (apprentice), then bold experiments (practitioner), then intuition (master). Pick one craft, find someone ahead of you to learn from, and out-practice everyone — boredom is part of the toll."},
  {k:/sat.*(pacing|time)|pacing|run out of time/i, t:"Timed-section pacing", b:"Divide minutes by questions before you start. Mark the checkpoint question for halftime. If a question takes >90 seconds, flag it, guess, move on \u2014 come back with leftover time. Never leave blanks if there's no wrong-answer penalty."},
];

/* ---------- conversation state ----------
   Owned here, read by the view. The view used to hold this in three loose
   globals it also mutated mid-render. */
const Tutor = {
  subject: "Study skills",
  log: [],
  busy: false,

  kbFind(q){ return TUT_KB.find(e => e.k.test(String(q || ""))) || null; },

  curriculumLabel(h){
    const C = (typeof CURRICULA !== "undefined" && CURRICULA[h && h.curriculum]) || (typeof CURRICULA !== "undefined" ? CURRICULA.igcse : null);
    return (C && C.label) || "your curriculum";
  },

  subjects(h){
    if(typeof CURRICULA === "undefined") return ["Study skills"];
    const C = CURRICULA[h && h.curriculum] || CURRICULA.igcse;
    const names = [...new Set([...C.a, ...C.b, ...C.c].map(s => s.split(" \u2014 ")[0].trim()))];
    return ["Study skills", ...names.slice(0, 10)];
  },

  setSubject(s){ if(s) this.subject = String(s).slice(0, 60); },

  systemPrompt(h){
    const lab = this.curriculumLabel(h);
    return `You are the System's Tutor inside a Solo-Leveling-style study app. The student follows the ${lab} curriculum. Current subject: ${this.subject}. Explain step by step at ${lab} level, use worked examples, ask one short check-question at the end, and never just give final answers to homework without the method. Keep answers under 250 words unless asked for more.`;
  },

  /* The paste-anywhere prompt. Also the local answer when there is no card. */
  masterPrompt(h, q){
    const lab = this.curriculumLabel(h);
    return `Act as an expert ${lab} tutor for the subject "${this.subject}".\nMy question: ${q}\n\nTeach me step by step at ${lab} level: 1) the core idea in plain words, 2) one fully worked example, 3) the common mistake students make, 4) one practice question for me (don't solve it). Keep it under 300 words.`;
  },

  /* What the tutor knows about the student that is safe to send. Numbers only —
     ai.js's compressContext() strips the rest, but the right place to not send
     something is before it is put in the object. No name, no log, no endpoint. */
  context(h){
    if(!h) return null;
    const ctx = { subject: this.subject, curriculum: this.curriculumLabel(h), level: h.level || 1 };
    try{
      if(typeof academy === "function"){
        const a = academy();
        if(a && Array.isArray(a.subjects) && a.subjects.length) ctx.subjectsTracked = a.subjects.length;
      }
    }catch(e){ /* the tutor answering is worth more than a context field */ }
    return ctx;
  },

  status(){
    return (typeof AI !== "undefined" && AI && typeof AI.status === "function")
      ? AI.status()
      : { ok:false, reason:"no-service", text:"Offline mode: instant study cards and a master prompt to paste into any free AI chat app." };
  },

  modeText(){
    const st = this.status();
    if(st.ok) return `Online mode: ${st.text}`;
    return "Offline mode: the System gives instant study cards and builds a master prompt to paste into any free AI chat app (Claude, ChatGPT, Gemini). " + (st.text || "");
  },

  /* ask(question) → array of messages for the view to draw.
     Every route through here goes via AI.ask, so the cap, cache, timeout,
     privacy filter and entitlement check apply whether the endpoint answers,
     refuses, or is not configured at all. */
  async ask(question){
    const h = typeof H === "function" ? H() : null;
    const q = String(question || "").trim();
    if(!q || this.busy) return [];

    const out = [];
    this.log.push({ role:"user", text:q });
    out.push({ role:"user", text:q });

    const card = this.kbFind(q);
    if(card) out.push({ role:"sys", text: card.t + "\n\n" + card.b, cls:"tcard" });

    /* The deterministic answer. Mandatory: AI.ask() will not run without one,
       and this is the thing that must still work with the network unplugged. */
    const local = () => card ? (card.t + "\n\n" + card.b) : this.masterPrompt(h, q);

    this.busy = true;
    let res;
    try{
      res = await AI.ask("tutor", {
        system: this.systemPrompt(h),
        messages: this.log.filter(m => m.role === "user" || m.role === "assistant")
                          .slice(-10)
                          .map(m => ({ role: m.role, content: m.text })),
        context: this.context(h),
        local,
      });
    }catch(err){
      /* AI.ask is written not to throw. If it ever does, the tutor still answers. */
      res = { source:"local", text: local(), note:"The tutor service failed unexpectedly (" + (err && err.message) + "). This is the System's own answer instead." };
    }
    this.busy = false;

    if(res.source === "ai" && res.text){
      this.log.push({ role:"assistant", text:res.text });
      out.push({ role:"assistant", text:res.text, note: res.cached ? "Cached — no request sent." : null });
    } else {
      /* Local route. Show the note explaining why (capped, offline, not
         entitled, endpoint down) rather than pretending nothing happened. */
      if(res.note) out.push({ role:"sys", text:res.note, cls:"note" });
      if(!card) out.push({ role:"sys", text:"No instant card for that one \u2014 your master prompt is below. Copy it into any free AI chat app for the full lesson." });
      out.push({ role:"sys", text:this.masterPrompt(h, q), cls:"promptbox" });
      out.push({ role:"sys", text:"Tip: after pasting, reply \u2018harder\u2019 or \u2018simpler\u2019 to tune the level." });
    }
    return out;
  },
};
