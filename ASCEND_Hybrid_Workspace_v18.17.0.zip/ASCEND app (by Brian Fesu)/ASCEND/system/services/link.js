/* ASCEND — services/link.js
   The Student Graph, expressed the way goals.js expressed the ladder: two
   optional fields on objects that already exist, not a parallel data model.

   The audit measured this precisely. A goal broken down produced 3 targets and
   8 steps and zero quests. Clearing a quest moved XP and left goal progress at
   0%. Six wrong answers moved mastery to 25% and never reached a
   recommendation. The engines were sound; nothing carried a result from one to
   the next.

   So a quest may now carry `link`:

     { goal:<goalId>, target:<targetId>, step:<stepIdx>, topic:<topicId>,
       project:<projectId>, milestone:<msId> }

   Every field is optional and every reader tolerates its absence, which is why
   a v17 quest opens here untouched. Nothing is deleted, nothing is renamed, and
   a hunter who never links anything gets exactly the v17 behaviour.

   The writeback is subscribed, not inlined. day.js announces that a quest was
   cleared; this file decides what that means for the goal ladder, the Academy
   and the project board. That keeps the execution path free of knowledge about
   five other subsystems, and it is why a broken listener cannot stop a student
   ticking off their morning. */
"use strict";

const LINK_SCHEMA = 6;

/* ---------- reading ---------- */
function linkOf(quest){
  if(!quest || typeof quest !== "object") return null;
  const l = quest.link;
  if(!l || typeof l !== "object") return null;
  return l;
}
function questsLinkedTo(kind, id){
  const h = typeof H === "function" ? H() : null;
  if(!h || !Array.isArray(h.quests) || !id) return [];
  return h.quests.filter(q => { const l = linkOf(q); return l && l[kind] === id; });
}

/* Resolve a link into the objects it points at, skipping anything that has since
   been deleted. A dangling link is not an error — a student may delete a goal and
   keep the habit it produced. */
function goalStepRef(l){
  if(!l || !l.goal || typeof getGoal !== "function") return null;
  const g = getGoal(l.goal); if(!g) return null;
  const t = (g.targets || []).find(x => x.id === l.target); if(!t) return null;
  const step = (t.steps || [])[l.step];
  if(!step) return null;
  return { goal:g, target:t, step, index:l.step };
}

/* The sentence Home and the quest list print under a linked action: this is what
   the next twenty minutes is actually for. */
function questChain(quest){
  const l = linkOf(quest); if(!l) return null;
  const out = [];
  const ref = goalStepRef(l);
  if(ref){
    const chain = typeof goalChain === "function" ? goalChain(ref.goal.id) : [ref.goal];
    out.push({ kind:"goal", text: chain.map(g => g.name).join(" → "), id: ref.goal.id });
  }
  if(l.topic && typeof getTopic === "function"){
    const t = getTopic(l.topic);
    if(t) out.push({ kind:"topic", text: t.name, id: t.id });
  }
  if(l.project && typeof projectStore === "function"){
    const p = (projectStore().items || []).find(x => x.id === l.project);
    if(p) out.push({ kind:"project", text: p.title, id: p.id });
  }
  return out.length ? out : null;
}

/* ---------- writing ---------- */
function setQuestLink(questId, patch){
  const h = typeof H === "function" ? H() : null; if(!h) return null;
  const q = (h.quests || []).find(x => x.id === questId); if(!q) return null;
  q.link = Object.assign({}, q.link || {}, patch || {});
  for(const k of Object.keys(q.link)) if(q.link[k] == null) delete q.link[k];
  if(!Object.keys(q.link).length) delete q.link;
  save();
  return q;
}

/* ══════════════ a goal step becomes a real action ══════════════
   §"A goal should ultimately produce concrete actions." This is the bridge the
   audit found missing: the ladder ended in text.

   It creates an ordinary quest — same shape, same board, same XP engine — and
   marks it with the step it came from. Nothing about the quest is special, which
   is the point: it can be edited, moved, paused and deleted like any other. The
   schedule is never changed silently; the caller passes a time the student
   chose. */
function scheduleStepAsQuest(goalId, targetId, stepIndex, { time = "18:00", days = null, cat = "study", xp = 20, mand = false } = {}){
  const h = typeof H === "function" ? H() : null; if(!h) return null;
  const g = typeof getGoal === "function" ? getGoal(goalId) : null; if(!g) return null;
  const t = (g.targets || []).find(x => x.id === targetId); if(!t) return null;
  const step = (t.steps || [])[stepIndex]; if(!step) return null;

  const existing = (h.quests || []).find(q => {
    const l = linkOf(q);
    return l && l.goal === goalId && l.target === targetId && l.step === stepIndex;
  });
  if(existing) return { quest: existing, created:false };

  const q = {
    id: uid(),
    time: /^\d{2}:\d{2}$/.test(time) ? time : "18:00",
    name: String(step.text || step.name || "Goal step").slice(0, 90),
    cat, days: Array.isArray(days) && days.length ? days : [1,2,3,4,5],
    mand, xp,
    link: { goal:goalId, target:targetId, step:stepIndex },
  };
  h.quests.push(q);
  save();
  if(typeof invalidateModel === "function") invalidateModel();
  Bus.emit(SYSTEM_EVENTS.QUEST_CREATED, { quest:q, source:"goal-step", goalId });
  return { quest:q, created:true };
}

/* ══════════════ a recommendation becomes a quest ══════════════
   v19 §6: "That action becomes the next quest."

   Built on scheduleStepAsQuest's shape rather than beside it — same link
   vocabulary, same idempotence rule, same bus event. A second quest-creation
   path with its own subtly different rules is how this project shipped five
   duplicate-rule collisions.

   Two things it deliberately refuses to do:

     · It will not promote a recommendation that already IS a quest. Those items
       exist because the quest is on today's board and unfinished; creating a
       copy would double the board and pay XP twice for one piece of work.
     · It will not invent a link it cannot support. A recommendation whose id
       names a goal, topic or project carries that link so clearing the quest
       settles up the ladder; one that names nothing gets no link rather than a
       guessed one, because a wrong link silently ticks off work never done. */
const PROMOTABLE = {
  errors:  l => ({ topic: l }),
  stale:   l => ({ topic: l }),
  weak:    null,          /* already a quest */
  project: l => ({ project: l }),
  goal:    l => ({ goal: l }),
  exam:    null,
  opp:     null,
  deadline:null,
  style:   null,
};

function scheduleActionAsQuest(rec, { time = "18:00", days = null, cat = "study", xp = 20, mand = false } = {}){
  const h = typeof H === "function" ? H() : null;
  if(!h || !rec || !rec.id) return { created:false, reason:"nothing to schedule" };

  if(rec.quest) return { quest:rec.quest, created:false, reason:"already on the board" };

  const [kind, ...rest] = String(rec.id).split(":");
  const ref = rest.join(":");
  const linkFor = Object.prototype.hasOwnProperty.call(PROMOTABLE, kind) ? PROMOTABLE[kind] : undefined;
  if(linkFor === null) return { created:false, reason:"this one is not a piece of work you can put on the board" };

  const link = (typeof linkFor === "function" && ref) ? linkFor(ref) : null;

  /* Idempotent by the same rule scheduleStepAsQuest uses: if a quest already
     points at this thing, hand it back rather than making a second one. */
  const existing = (h.quests || []).find(q => {
    if(q.fromAction === rec.id) return true;
    const l = linkOf(q);
    if(!l || !link) return false;
    return Object.keys(link).every(k => l[k] === link[k]);
  });
  if(existing) return { quest:existing, created:false, reason:"already scheduled" };

  const q = {
    id: uid(),
    time: /^\d{2}:\d{2}$/.test(time) ? time : "18:00",
    name: String(rec.title || "Recommended work").slice(0, 90),
    cat, days: Array.isArray(days) && days.length ? days : [1,2,3,4,5],
    mand, xp,
    /* Kept so the board can say where this came from, and so promoting the same
       recommendation twice is a no-op even when there is no link to match on. */
    fromAction: rec.id,
  };
  if(link) q.link = link;

  h.quests.push(q);
  save();
  if(typeof invalidateModel === "function") invalidateModel();
  Bus.emit(SYSTEM_EVENTS.QUEST_CREATED, { quest:q, source:"recommendation", action:rec.id });
  return { quest:q, created:true };
}

/* ══════════════ consequences ══════════════
   Everything below is a consumer. None of it is reachable from the execution
   path except through the bus, so a failure here degrades a feature instead of
   breaking quest completion. */

function wireLinks(){
  /* --- a cleared quest settles up the ladder --- */
  Bus.on(SYSTEM_EVENTS.QUEST_COMPLETED, ({ quest }) => {
    const l = linkOf(quest); if(!l) return;

    const ref = goalStepRef(l);
    if(ref && !ref.step.done){
      ref.step.done = true;
      if(typeof touchGoal === "function") touchGoal(ref.goal.id);
      save();
      Bus.emit(SYSTEM_EVENTS.GOAL_STEP_DONE, { goal:ref.goal, target:ref.target, step:ref.step });
      const p = typeof goalProgress === "function" ? goalProgress(ref.goal) : null;
      if(p && p.steps && p.done === p.steps){
        Bus.emit(SYSTEM_EVENTS.GOAL_COMPLETED, { goal:ref.goal });
      }
    }

    /* A study quest attached to a topic is self-reported study time — the
       weakest grade of evidence the Academy accepts, and it stays that way.
       markStudied() caps a studied-only topic at 25%, so this cannot inflate
       mastery; it only stops the record pretending the session never happened. */
    if(l.topic && typeof markStudied === "function"){
      try{
        markStudied(l.topic, Number(l.minutes) || 25);
        Bus.emit(SYSTEM_EVENTS.MASTERY_CHANGED, { topicId:l.topic, source:"quest" });
      }catch(e){}
    }

    if(l.project && l.milestone && typeof toggleMilestone === "function"){
      try{
        const p = (projectStore().items || []).find(x => x.id === l.project);
        const ms = p && (p.milestones || []).find(m => m.id === l.milestone);
        if(ms && !ms.done){
          toggleMilestone(l.project, l.milestone);
          Bus.emit(SYSTEM_EVENTS.MILESTONE_COMPLETED, { projectId:l.project, milestoneId:l.milestone });
        }
      }catch(e){}
    }
  });

  /* --- un-clearing reverses it, or the ladder drifts out of true --- */
  Bus.on(SYSTEM_EVENTS.QUEST_UNCLEARED, ({ quest }) => {
    const l = linkOf(quest); if(!l) return;
    const ref = goalStepRef(l);
    if(ref && ref.step.done){ ref.step.done = false; save(); }
  });

  /* --- caches that must not answer from before the write --- */
  Bus.onAny(() => {
    if(typeof invalidateModel === "function") invalidateModel();
    if(typeof invalidateAcademy === "function") invalidateAcademy();
  });
}

/* ---------- migration to schema 6 ----------
   Additive and idempotent, in the shape core/store.js already uses. There is
   nothing to backfill: a v17 quest has no link and a quest with no link behaves
   exactly as it did. This exists so the schema number moves with the model. */
function migrateLinks(rec){
  for(const h of Object.values((rec && rec.hunters) || {})){
    if(!Array.isArray(h.quests)) continue;
    for(const q of h.quests) if(q.link && typeof q.link !== "object") delete q.link;
  }
  return rec;
}

if(typeof Bus !== "undefined") wireLinks();
