/* THE SYSTEM v14 — services/records.js
   Achievements, titles, rank gating, personal bests and anti-farming.

   The rule the whole file serves is Phase 4 §44: virtual progression must
   represent real progression. Nothing here can be earned by using the app. Every
   condition below is satisfied by doing something outside it and recording that
   you did — clearing quests, finishing books, practising a craft, seeing a goal
   through, getting back after a collapsed week.

   §41 is enforced in the same place, because anti-farming is not a separate
   feature: if XP can be printed by tapping a quest on and off, none of the
   achievements above it mean anything either.

   Pure over local state. No DOM. */
"use strict";

/* ══════════════ the stats every rule is checked against ══════════════
   Computed once and cached briefly — several rules read the same figures and
   they walk the whole done-record. */
let _sCache = null, _sAt = 0;
function progressStats(force){
  const h = H(); if(!h) return null;
  if(!force && _sCache && Date.now() - _sAt < 3000) return _sCache;

  const done = h.done || {};
  const keys = Object.keys(done).sort();
  let cleared = 0, perfectDays = 0, zeroToPerfect = false, before6 = false, after23 = false;
  const catCleared = {};
  let prevZero = false;

  const qById = Object.fromEntries((h.quests || []).map(q => [q.id, q]));

  for(const k of keys){
    const set = done[k] || {};
    const ids = Object.keys(set).filter(id => set[id]);
    cleared += ids.length;
    for(const id of ids){
      const q = qById[id]; if(!q) continue;
      catCleared[q.cat] = (catCleared[q.cat] || 0) + 1;
      const hr = Number(String(q.time || "12:00").split(":")[0]);
      if(hr < 6) before6 = true;
      if(hr >= 23) after23 = true;
    }
    /* a "day" only counts if quests were actually scheduled on it */
    let due = [];
    try{ due = questsFor(new Date(k + "T12:00:00")); }catch(e){ due = []; }
    if(due.length){
      const all = due.every(q => set[q.id]);
      const none = !due.some(q => set[q.id]);
      if(all){ perfectDays++; if(prevZero) zeroToPerfect = true; }
      prevZero = none;
    }
  }

  const b = h.brain || {};
  const s = {
    level: h.level || 1,
    rank: h.rank || "E",
    streak: h.streak || 0,
    bestStreak: Math.max(h.streak || 0, (b.records && b.records.bestStreak) || 0),
    cleared, perfectDays, zeroToPerfect, before6, after23,
    catCleared,
    books: (h.booksRead || []).length,
    hobbyDays: h.hobbyLog ? Object.keys(h.hobbyLog).length : 0,
    skills: (h.skills || []).length,
    bosses: (b.bosses || []).filter(x => x.done).length,
    goalsDone: (Array.isArray(h.goals) ? h.goals : []).filter(g => {
      const all = (g.targets || []).reduce((a,t) => a.concat(t.steps || []), []);
      return all.length && all.every(x => x.done);
    }).length,
    areas: (b.areas || []).length,
    achievements: (b.achievements || []).length,
    recoveries: (b.recoveryCount || 0),
    totalXp: h.totalXp || 0,
  };
  _sCache = s; _sAt = Date.now();
  return s;
}
function invalidateStats(){ _sCache = null; }

/* ══════════════ rank (§6) ══════════════
   Level alone no longer grants a rank. Everything else in the requirement is
   evidence of work done, so rank cannot be reached by waiting. */
function rankProgress(){
  const s = progressStats(); if(!s) return null;
  const tiers = BALANCE.ranks;
  let current = tiers[0], next = null;
  for(const t of tiers){
    if(rankMet(t, s)) current = t; else { next = t; break; }
  }
  return {
    rank: current.r,
    name: BALANCE.rankNames[current.r],
    next: next ? {
      rank: next.r, name: BALANCE.rankNames[next.r],
      missing: rankMissing(next, s),
    } : null,
  };
}
function rankMet(tier, s){
  if(s.level < tier.level) return false;
  const n = tier.need || {};
  if(n.cleared && s.cleared < n.cleared) return false;
  if(n.streak && s.bestStreak < n.streak) return false;
  if(n.achievements && s.achievements < n.achievements) return false;
  if(n.bosses && s.bosses < n.bosses) return false;
  return true;
}
function rankMissing(tier, s){
  const out = [];
  if(s.level < tier.level) out.push({ what:"Level", have:s.level, need:tier.level });
  const n = tier.need || {};
  if(n.cleared && s.cleared < n.cleared) out.push({ what:"Quests cleared", have:s.cleared, need:n.cleared });
  if(n.streak && s.bestStreak < n.streak) out.push({ what:"Best streak", have:s.bestStreak, need:n.streak });
  if(n.achievements && s.achievements < n.achievements) out.push({ what:"Achievements", have:s.achievements, need:n.achievements });
  if(n.bosses && s.bosses < n.bosses) out.push({ what:"Bosses cleared", have:s.bosses, need:n.bosses });
  return out;
}

/* ══════════════ achievements (§18) ══════════════ */
function achievementMet(a, s){
  const n = a.need || {};
  if(n.level && s.level < n.level) return false;
  if(n.rank){
    const order = BALANCE.ranks.map(r => r.r);
    if(order.indexOf(s.rank) < order.indexOf(n.rank)) return false;
  }
  if(n.streak && s.bestStreak < n.streak) return false;
  if(n.cleared && s.cleared < n.cleared) return false;
  if(n.perfectDays && s.perfectDays < n.perfectDays) return false;
  if(n.books && s.books < n.books) return false;
  if(n.hobbyDays && s.hobbyDays < n.hobbyDays) return false;
  if(n.skills && s.skills < n.skills) return false;
  if(n.bosses && s.bosses < n.bosses) return false;
  if(n.goalsDone && s.goalsDone < n.goalsDone) return false;
  if(n.areas && s.areas < n.areas) return false;
  if(n.recoveries && s.recoveries < n.recoveries) return false;
  if(n.catCleared && (s.catCleared[n.catCleared.cat] || 0) < n.catCleared.n) return false;
  if(n.clearedBefore && !s.before6) return false;
  if(n.clearedAfter && !s.after23) return false;
  if(n.zeroToPerfect && !s.zeroToPerfect) return false;
  return true;
}

/* Runs after anything that could change the picture. Returns newly earned ones
   so the UI can celebrate exactly once. */
function checkAchievements(){
  const h = H(); if(!h) return [];
  const b = brain(); if(!b) return [];
  b.achievements = b.achievements || [];
  const s = progressStats(true);
  const held = new Set(b.achievements.map(x => x.id));
  const fresh = [];

  for(const a of BALANCE.achievements){
    if(held.has(a.id)) continue;
    if(!achievementMet(a, s)) continue;
    b.achievements.push({ id:a.id, at: todayKey(), ts: Date.now() });
    fresh.push(a);
  }
  if(fresh.length){ save(); invalidateStats(); invalidateModel(); }
  return fresh;
}

function achievementList(){
  const b = brain(); const held = new Map((b && b.achievements || []).map(x => [x.id, x]));
  const s = progressStats();
  return BALANCE.achievements
    .filter(a => !a.secret || held.has(a.id))
    .map(a => ({ ...a, earned: held.has(a.id), at: held.get(a.id) ? held.get(a.id).at : null,
                 progress: achievementProgress(a, s) }));
}
/* a rough 0..1 for the bar — only for the single-number conditions */
function achievementProgress(a, s){
  if(!s) return 0;
  const n = a.need || {};
  const pairs = [
    [n.level, s.level], [n.streak, s.bestStreak], [n.cleared, s.cleared],
    [n.perfectDays, s.perfectDays], [n.books, s.books], [n.hobbyDays, s.hobbyDays],
    [n.skills, s.skills], [n.bosses, s.bosses], [n.goalsDone, s.goalsDone], [n.areas, s.areas],
  ].filter(p => p[0]);
  if(n.catCleared) pairs.push([n.catCleared.n, s.catCleared[n.catCleared.cat] || 0]);
  if(!pairs.length) return achievementMet(a, s) ? 1 : 0;
  return Math.min(1, Math.min(...pairs.map(([need, have]) => have / need)));
}
function secretsRemaining(){
  const b = brain(); const held = new Set((b && b.achievements || []).map(x => x.id));
  return BALANCE.achievements.filter(a => a.secret && !held.has(a.id)).length;
}

/* ══════════════ titles (§19) ══════════════ */
function titleList(){
  const b = brain(); const held = new Set((b && b.achievements || []).map(x => x.id));
  return BALANCE.titles.map(t => ({ ...t, unlocked: held.has(t.from), equipped: b && b.title === t.id }));
}
function equipTitle(id){
  const b = brain(); if(!b) return false;
  if(id === null){ b.title = null; save(); return true; }
  const t = BALANCE.titles.find(x => x.id === id); if(!t) return false;
  const held = new Set((b.achievements || []).map(x => x.id));
  if(!held.has(t.from)) return false;
  b.title = id; save(); return true;
}
function equippedTitle(){
  const b = brain(); if(!b || !b.title) return null;
  return BALANCE.titles.find(t => t.id === b.title) || null;
}

/* ══════════════ personal bests (§35) ══════════════
   §4 of Phase 11 makes the same point early: the primary comparison is you
   against yourself. These are recorded as they happen so they survive a bad month
   — a personal best is not recomputed away by later data. */
function updateRecords(){
  const b = brain(); if(!b) return null;
  const h = H(); const s = progressStats(true);
  const r = b.records = b.records || {};
  const bump = (k, v) => { if(typeof v === "number" && v > (r[k] || 0)){ r[k] = v; return true; } return false; };

  let changed = false;
  changed = bump("bestStreak", h.streak || 0) || changed;
  changed = bump("mostCleared", s.cleared) || changed;
  changed = bump("perfectDays", s.perfectDays) || changed;
  changed = bump("books", s.books) || changed;
  changed = bump("level", h.level || 1) || changed;

  /* best week, measured over the last seven complete days */
  try{
    let week = 0;
    for(let i = 1; i <= 7; i++){
      const d = new Date(); d.setDate(d.getDate() - i);
      week += Object.keys(h.done[todayKey(d)] || {}).length;
    }
    changed = bump("bestWeek", week) || changed;
  }catch(e){}

  if(changed) save();
  return r;
}
function personalBests(){
  const b = brain(); const r = (b && b.records) || {};
  return [
    { k:"bestStreak",  label:"Longest streak",        v:r.bestStreak || 0,  unit:"days" },
    { k:"bestWeek",    label:"Best week",             v:r.bestWeek || 0,    unit:"quests" },
    { k:"perfectDays", label:"Perfect days",          v:r.perfectDays || 0, unit:"days" },
    { k:"mostCleared", label:"Quests cleared",        v:r.mostCleared || 0, unit:"total" },
    { k:"books",       label:"Books finished",        v:r.books || 0,       unit:"books" },
    { k:"level",       label:"Highest level reached", v:r.level || 1,       unit:"" },
  ];
}

/* ══════════════ anti-farming (§41) ══════════════
   grantXp is wrapped rather than rewritten, the same idiom used for penalties.
   Two limits: a quest pays once per day however many times it is toggled, and a
   daily ceiling that a real day cannot reach but a farmer hits in a minute. */
Hooks.wrap("grantXp", "anti-farm ledger", function(__grantXpBase, n, why, opts){
    const h = H(); if(!h) return __grantXpBase(n, why);
    const b = brain(); if(!b) return __grantXpBase(n, why);
    const key = todayKey();
    const led = b.xpLedger = b.xpLedger || { day:key, total:0, paid:{} };
    if(led.day !== key){ led.day = key; led.total = 0; led.paid = {}; }

    const tag = opts && opts.once;
    if(tag){
      if(led.paid[tag]){
        /* already paid for this today — the action still counts, the XP does not */
        return;
      }
      led.paid[tag] = 1;
    }
    /* The ceiling exists to catch grants that could repeat. A tagged grant has
       already been proved unrepeatable one line above, so a genuinely enormous
       day — a boss falling on top of a full board — is not punished for being
       real. Untagged grants are the ones that could loop, and they are capped. */
    const cap = BALANCE.antiFarm.dailyXpCap;
    if(!tag && led.total >= cap){
      if(typeof toast === "function") toast("Daily XP cap reached",
        `${cap} XP in one day is the ceiling. Everything you clear still counts toward streaks, records and achievements — it just stops paying.`, "gold");
      save(); return;
    }
    const grant = tag ? n : Math.min(n, Math.max(0, cap - led.total));
    led.total += grant;
    save();
    const out = __grantXpBase(grant, why);

    /* progression is checked here because this is the one funnel every reward
       passes through — putting the check in each caller would guarantee misses */
    try{
      updateRecords();
      const fresh = checkAchievements();
      applyRank();
      const areas = checkWorld && checkWorld();
      if(fresh.length && typeof announceAchievements === "function") announceAchievements(fresh);
      if(areas && areas.length && typeof announceAreas === "function") announceAreas(areas);
    }catch(e){}
    return out;
});

/* Rank is derived, so it is applied rather than granted. */
function applyRank(){
  const h = H(); if(!h) return;
  const rp = rankProgress(); if(!rp) return;
  if(rp.rank !== h.rank){
    const up = BALANCE.ranks.findIndex(r => r.r === rp.rank) > BALANCE.ranks.findIndex(r => r.r === h.rank);
    h.rank = rp.rank; save();
    if(up && typeof takeover === "function") takeover({
      kind:"rankup", title:`RANK UP — ${rp.rank}`,
      sub:`You are now recognised as ${rp.name}. Rank is not time served — it is level, quests cleared, a streak held and bosses put down.`,
      reward:`Level ${h.level}`,
    });
  }
}

/* The level title from the balance table (§5). */
function levelTitle(lvl){
  const t = [...BALANCE.level.titles].reverse().find(x => (lvl || 1) >= x.at);
  return t ? t.name : "Awakened";
}
