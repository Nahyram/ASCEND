/* THE SYSTEM v13 — services/coach.js
   The coach does not guess and it does not flatter. Everything below is computed
   from the record already on this device: which quests were due, which were cleared,
   on what day, at what hour. Pure functions — no DOM, no network. */
"use strict";

const DAYNAME = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const DAYSHORT = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const BANDS = [
  { k:"morning", lab:"before noon",   from:0,  to:11 },
  { k:"day",     lab:"noon to 6 PM",  from:12, to:17 },
  { k:"evening", lab:"after 6 PM",    from:18, to:23 },
];

/* ---------- the raw sample: one row per day, per quest ---------- */
function coachSample(days = 60){
  const h = H(); if(!h) return [];
  const rows = [];
  for(let i = days - 1; i >= 1; i--){          /* today is still in play — excluded */
    const d = new Date(); d.setDate(d.getDate() - i);
    const key = todayKey(d), dow = d.getDay();
    const due = (h.quests || []).filter(q => q.days.includes(dow));
    if(!due.length) continue;
    const doneSet = h.done[key] || {};
    /* a day with zero record before the hunter existed is not evidence */
    if(!h.done[key] && rows.length === 0) continue;
    for(const q of due){
      rows.push({
        key, dow, id:q.id, name:q.name, cat:q.cat, mand:!!q.mand,
        hour: Number(String(q.time || "12:00").split(":")[0]) || 12,
        done: !!doneSet[q.id],
      });
    }
  }
  return rows;
}

const rate = rows => rows.length ? rows.filter(r => r.done).length / rows.length : 0;
const pct  = n => Math.round(n * 100);

/* ---------- grouped views over the sample ---------- */
function byDay(rows){
  return DAYNAME.map((_, i) => {
    const r = rows.filter(x => x.dow === i);
    return { dow:i, n:r.length, rate:rate(r) };
  }).filter(d => d.n >= 3);
}
function byBand(rows){
  return BANDS.map(b => {
    const r = rows.filter(x => x.hour >= b.from && x.hour <= b.to);
    return { ...b, n:r.length, rate:rate(r) };
  }).filter(b => b.n >= 5);
}
function byQuest(rows){
  const map = {};
  for(const r of rows){
    (map[r.id] = map[r.id] || { name:r.name, cat:r.cat, mand:r.mand, n:0, hit:0 });
    map[r.id].n++; if(r.done) map[r.id].hit++;
  }
  return Object.entries(map)
    .map(([id, v]) => ({ id, ...v, rate:v.hit / v.n }))
    .filter(q => q.n >= 4);
}
function byCat(rows){
  const map = {};
  for(const r of rows){ (map[r.cat] = map[r.cat] || { n:0, hit:0 }); map[r.cat].n++; if(r.done) map[r.cat].hit++; }
  return Object.entries(map).map(([cat, v]) => ({ cat, n:v.n, rate:v.hit / v.n })).filter(c => c.n >= 5);
}
function windowRate(rows, from, to){       /* days ago, inclusive */
  const keys = [];
  for(let i = from; i <= to; i++){ const d = new Date(); d.setDate(d.getDate() - i); keys.push(todayKey(d)); }
  return rate(rows.filter(r => keys.includes(r.key)));
}

/* how much of today is left, and what's still owed */
function todayPressure(){
  const h = H(); if(!h) return null;
  const due = questsFor();
  const left = due.filter(q => !isDone(q));
  const mandLeft = left.filter(q => q.mand);
  const now = new Date().getHours() * 60 + new Date().getMinutes();
  const overdue = left.filter(q => {
    const [hh, mm] = String(q.time || "23:59").split(":").map(Number);
    return hh * 60 + mm < now;
  });
  return { due:due.length, left:left.length, mandLeft, overdue, cleared:due.length - left.length };
}

/* ---------- the notes ---------- */
/* tone: up | warn | hard | flat   —  each note carries what it was computed from */
function coachNotes(max = 4){
  const h = H(); if(!h) return [];
  const rows = coachSample();
  const notes = [];
  const P = todayPressure();

  /* 1. today first — the only note that is about right now */
  if(P && P.due){
    if(P.overdue.length){
      notes.push({ tone:"hard", icon:"!", text: P.overdue.length > 1 ? `${P.overdue.length} quests are past their hour today.` : "One quest is past its hour today.",
        detail:`Start with ${P.overdue[0].name}. Late is still cleared.`, go:["quests","q-today"] });
    } else if(!P.left){
      notes.push({ tone:"up", icon:"✔", text:"Today is fully cleared.",
        detail:"Nothing else is owed. Rest is part of the plan, not a failure of it." });
    } else if(P.mandLeft.length){
      notes.push({ tone:"flat", icon:"▸", text:`${P.mandLeft.length} mandatory quest${P.mandLeft.length>1?"s":""} still open.`,
        detail:`Next up: ${P.mandLeft[0].name} at ${P.mandLeft[0].time}.`, go:["quests","q-today"] });
    }
  }

  if(rows.length < 20){
    notes.push({ tone:"flat", icon:"◌", text:"The coach is still reading you.",
      detail:`It needs roughly a week of record before its patterns mean anything. ${Math.max(0, 20 - rows.length)} more quest-days to go.` });
    return notes.slice(0, max);
  }

  /* 2. the weakest weekday, only if it is genuinely worse */
  const days = byDay(rows).sort((a, b) => a.rate - b.rate);
  if(days.length >= 4){
    const worst = days[0], best = days[days.length - 1];
    if(best.rate - worst.rate >= 0.2 && worst.rate < 0.7){
      notes.push({ tone:"warn", icon:"◐", text:`${DAYNAME[worst.dow]} is where you lose ground — ${pct(worst.rate)}% cleared.`,
        detail:`${DAYNAME[best.dow]} runs at ${pct(best.rate)}%. Same person, different day. Move one hard quest off ${DAYNAME[worst.dow]} and see if it holds.`,
        go:["quests","q-today"] });
    }
  }

  /* 3. time of day */
  const bands = byBand(rows).sort((a, b) => b.rate - a.rate);
  if(bands.length >= 2){
    const top = bands[0], bottom = bands[bands.length - 1];
    if(top.rate - bottom.rate >= 0.18){
      notes.push({ tone:"flat", icon:"◷", text:`You finish what you start ${top.lab} — ${pct(top.rate)}% against ${pct(bottom.rate)}% ${bottom.lab}.`,
        detail:`Put the quest you least want to do into your ${top.lab} block. Willpower is cheapest there.` });
    }
  }

  /* 4. the single most-skipped quest */
  const quests = byQuest(rows).sort((a, b) => a.rate - b.rate);
  if(quests.length && quests[0].rate <= 0.5){
    const q = quests[0];
    notes.push({ tone:"warn", icon:"▤", text:`"${q.name}" is the one you skip — cleared ${q.hit} of ${q.n} times.`,
      detail:`Either it is at the wrong hour, it is too big for one sitting, or it does not belong on the list. Pick one and fix it. Pretending it is a willpower problem has not worked so far.`,
      go:["set"] });
  }

  /* 5. a real strength, stated plainly */
  const cats = byCat(rows).sort((a, b) => b.rate - a.rate);
  if(cats.length && cats[0].rate >= 0.8){
    const CATLAB = { study:"Study", body:"Training", mind:"Deep work", discipline:"Discipline", rest:"Rest" };
    notes.push({ tone:"up", icon:"▲", text:`${CATLAB[cats[0].cat] || cats[0].cat} is holding at ${pct(cats[0].rate)}%.`,
      detail:"That is not luck any more. It is a habit — protect it before you add anything new." });
  }

  /* 6. direction of travel */
  const now7 = windowRate(rows, 1, 7), prev7 = windowRate(rows, 8, 14);
  if(prev7 > 0){
    const delta = now7 - prev7;
    if(delta <= -0.15) notes.push({ tone:"hard", icon:"↓", text:`This week is ${pct(Math.abs(delta))} points down on last week.`,
      detail:`${pct(now7)}% against ${pct(prev7)}%. Something changed — either the load or the life around it. Cut two optional quests for seven days rather than losing the streak entirely.`, go:["insight"] });
    else if(delta >= 0.15) notes.push({ tone:"up", icon:"↑", text:`You are up ${pct(delta)} points on last week.`,
      detail:`${pct(prev7)}% → ${pct(now7)}%. This is the moment to add one hard thing, not five.`, go:["insight"] });
  }

  /* 7. load advice — the adaptive bit, proposed rather than imposed */
  const r14 = windowRate(rows, 1, 14);
  if(r14 && r14 < 0.45){
    notes.push({ tone:"hard", icon:"⚠", text:`Two-week clear rate is ${pct(r14)}%. The plan is bigger than the day.`,
      detail:"A schedule you miss teaches you to miss schedules. Cut it to what you would still do on your worst day, then grow it back.", go:["set"] });
  } else if(r14 >= 0.92){
    notes.push({ tone:"up", icon:"◈", text:`${pct(r14)}% over two weeks. This has stopped being hard.`,
      detail:"Raise the training tier or add one quest with real weight. Comfort is where progress goes to sit down.", go:["grow","tr-quest"] });
  }

  return notes.slice(0, max);
}

/* ---------- one-line summary for the top of Home ---------- */
function coachHeadline(){
  const P = todayPressure();
  if(!P || !P.due) return "No quests scheduled today.";
  if(!P.left) return "Every quest cleared. The day is yours.";
  if(P.overdue.length) return `${P.overdue.length} overdue · ${P.left} of ${P.due} still open`;
  return `${P.cleared} of ${P.due} cleared · ${P.left} to go`;
}
