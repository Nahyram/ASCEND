/* ASCEND — services/vacation.js
   Vacation mode, and the home quests that fill it.

   ## The problem this solves

   ASCEND's board is a timetable. Quests carry `days:[1..5]` and the mandatory
   ones drive penalties, so on the first day of a long vacation the System starts
   asking a student to attend lessons that are not happening, marks them missed,
   docks XP for it, and then terminates a streak they did nothing to lose.

   Ghana's school year has three of these — roughly August–September, December,
   and April. A product that punishes a student for six weeks of every year for
   being on holiday is not a product they keep using.

   ## Where it hooks in, and why there

   One place: questsFor(). During a vacation that function returns the campaign
   instead of the timetable, and everything downstream then works with no special
   cases at all:

     · campaign quests are never mandatory, so `missed` is empty and penalty.js
       never fires — no change to the penalty engine
     · they are real quests, so the streak advances on them normally — a student
       who reads every day through December keeps their streak honestly
     · clearing one pays XP through grantXp like anything else, so the ledger,
       the event log and the server all see it without knowing vacations exist

   The alternative — special-casing "is it a vacation?" inside the streak
   calculation, the penalty engine and the rollover — is three places to get
   wrong instead of one, and this codebase's history is a list of rules
   implemented twice.

   ## What it deliberately does not do

   It does not delete or edit the school timetable. Vacation is a lens over the
   board, not a change to it: ending a vacation restores exactly what was there,
   because nothing was ever taken away. */
"use strict";

/* Data-driven so a new track is a row here, not a code change. `mins` feeds the
   time estimates in services/recommend.js; `xp` is deliberately modest because
   holiday work should feel lighter than term work, not heavier. */
const VACATION_TRACKS = [
  { k:"revision",  label:"Revision",       cat:"study",  mins:30, xp:25,
    quest:"30 minutes of revision", blurb:"Keep one subject warm rather than all of them cold." },
  { k:"reading",   label:"Reading",        cat:"read",   mins:30, xp:20,
    quest:"Read for 30 minutes",    blurb:"Anything that is not a screen you scroll." },
  { k:"coding",    label:"Coding",         cat:"build",  mins:45, xp:30,
    quest:"45 minutes of building", blurb:"A holiday is the only time most students get a long enough run at it." },
  { k:"research",  label:"Research",       cat:"study",  mins:30, xp:25,
    quest:"Research something you chose", blurb:"Your question, not a syllabus's." },
  { k:"creative",  label:"Creative work",  cat:"build",  mins:45, xp:30,
    quest:"Work on a creative project", blurb:"Writing, music, drawing, film — it counts." },
  { k:"practical", label:"Practical",      cat:"life",   mins:30, xp:20,
    quest:"Learn something practical", blurb:"Cooking, repairs, money, a language." },
  { k:"physical",  label:"Physical",       cat:"train",  mins:30, xp:20,
    quest:"Move for 30 minutes",   blurb:"Not training for anything. Just moving." },
];

const VAC_DAYS = [0,1,2,3,4,5,6];   /* every day — a vacation has no weekdays */

function vacation(){
  const h = typeof H === "function" ? H() : null;
  if(!h) return null;
  if(!h.vacation) h.vacation = { on:false, from:null, to:null, tracks:[], quests:[], startXp:0, startCleared:0 };
  return h.vacation;
}

/* Expiry is checked on read rather than on a timer, because a phone that was
   closed for the whole of December never runs a timer. Any caller asking whether
   a vacation is on gets the truthful answer for today. */
function vacationOn(){
  const v = vacation();
  if(!v || !v.on) return false;
  if(v.to && todayKey() > v.to){ endVacation("ran to its end date"); return false; }
  return true;
}

function vacationQuests(){
  const v = vacation();
  return vacationOn() && Array.isArray(v.quests) ? v.quests : [];
}

function startVacation({ to = null, tracks = [] } = {}){
  const h = H(); if(!h) return { ok:false, why:"No hunter." };
  const picked = VACATION_TRACKS.filter(t => tracks.includes(t.k));
  if(!picked.length) return { ok:false, why:"Choose at least one thing to keep doing." };
  if(to && !/^\d{4}-\d{2}-\d{2}$/.test(to)) return { ok:false, why:"That end date is not a date." };
  if(to && to <= todayKey()) return { ok:false, why:"The end date needs to be after today." };

  const start = 9;
  const quests = picked.map((t, i) => ({
    id: uid(),
    /* Spread through the day rather than stacked at 09:00, so the board reads
       like a day and not like a to-do list dumped at breakfast. */
    time: String(start + i * 2).padStart(2, "0") + ":00",
    name: t.quest, cat: t.cat, days: VAC_DAYS.slice(),
    mand: false,                      /* §11 — a holiday must not generate penalties */
    xp: t.xp, minutes: t.mins,
    vacation: true, track: t.k,
  }));

  h.vacation = {
    on:true, from: todayKey(), to,
    tracks: picked.map(t => t.k), quests,
    /* So progression during the vacation can be reported separately (§15)
       without a second XP counter that could disagree with the first. */
    startXp: h.totalXp || 0,
    startCleared: h.totalCleared || 0,
  };
  save();
  if(typeof invalidateModel === "function") invalidateModel();
  if(typeof Bus === "object" && SYSTEM_EVENTS) Bus.emit(SYSTEM_EVENTS.QUEST_CREATED, { vacation:true, count:quests.length });
  return { ok:true, quests: quests.length };
}

function endVacation(why = "ended"){
  const h = H(); if(!h || !h.vacation) return { ok:false };
  const summary = vacationSummary();
  h.vacation.on = false;
  h.vacation.endedAt = todayKey();
  h.vacation.endedWhy = why;
  save();
  if(typeof invalidateModel === "function") invalidateModel();
  return { ok:true, summary };
}

/* Vacation progression, reported from the same totals the rest of the app uses
   rather than from a counter of its own. Two numbers that are supposed to agree
   eventually will not. */
function vacationSummary(){
  const h = H(); const v = vacation();
  if(!h || !v || !v.from) return null;
  const days = Math.max(1, Math.round((Date.parse(todayKey()) - Date.parse(v.from)) / 86400000) + 1);
  return {
    on: v.on, from: v.from, to: v.to,
    daysIn: days,
    daysLeft: v.to ? Math.max(0, Math.round((Date.parse(v.to) - Date.parse(todayKey())) / 86400000)) : null,
    xp: Math.max(0, (h.totalXp || 0) - (v.startXp || 0)),
    cleared: Math.max(0, (h.totalCleared || 0) - (v.startCleared || 0)),
    tracks: (v.tracks || []).map(k => VACATION_TRACKS.find(t => t.k === k)).filter(Boolean),
    quests: (v.quests || []).length,
  };
}

/* Adding or dropping a track mid-vacation, without restarting and losing the
   start markers that make the summary meaningful. */
function setVacationTracks(tracks){
  const v = vacation(); if(!v || !v.on) return { ok:false, why:"No vacation is running." };
  const picked = VACATION_TRACKS.filter(t => tracks.includes(t.k));
  if(!picked.length) return { ok:false, why:"Keep at least one." };
  const keep = new Map((v.quests || []).map(q => [q.track, q]));
  v.tracks = picked.map(t => t.k);
  v.quests = picked.map((t, i) => keep.get(t.k) || {
    id: uid(), time: String(9 + i * 2).padStart(2, "0") + ":00",
    name: t.quest, cat: t.cat, days: VAC_DAYS.slice(), mand:false,
    xp: t.xp, minutes: t.mins, vacation:true, track: t.k,
  });
  save();
  if(typeof invalidateModel === "function") invalidateModel();
  return { ok:true };
}
