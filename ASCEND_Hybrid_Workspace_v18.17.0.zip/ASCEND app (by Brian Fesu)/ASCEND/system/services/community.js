/* THE SYSTEM v14 — services/community.js
   Phase 16: community, teachers and schools — and a substantial refusal.

   ## What is not here, and why

   The phase brief describes messaging, a student directory, public profiles, photo
   sharing, and teacher accounts that can see a student's progress. Every one of
   those is buildable. None of them ship, and the reason is not technical.

   This app is for 13–18-year-olds. Those features require a moderation operation:
   somebody reading reports, a takedown path, an escalation route when an adult
   contacts a child, retention and disclosure policies, and a legal position in
   every country it runs in. There is one developer and no operation. Shipping
   student-to-student messaging into that gap would not be an incomplete feature,
   it would be a hazard — and the brief's own §50 and §53 say to default to
   protecting minors.

   So what ships is the useful 80% that carries none of that risk: collaboration
   that works through things the student already controls, and reports the student
   generates and hands over themselves.

   The seam is real, so the day there is a moderation operation, the refusals become
   a build rather than a rewrite. */
"use strict";

const COMMUNITY_REFUSED = [
  { k:"Student-to-student messaging",
    why:"Needs moderation, reporting, blocking and an escalation path for adult contact. Without them it is a channel for harm with a study app around it." },
  { k:"A searchable student directory",
    why:"A list of minors, searchable by school, is the single worst artefact this project could produce." },
  { k:"Public profiles by default",
    why:"Phase 9 already made publishing deliberate. A community feature that quietly reverses that would undo it." },
  { k:"Photo sharing",
    why:"Images of children, uploaded to shared storage, with no review. No." },
  { k:"Teacher accounts that read a student's device",
    why:"A teacher seeing everything a student tracks — including their reflections and their weak topics — changes what the student is willing to write down. The report below gives the teacher what they actually need and leaves ownership with the student." },
];

/* ---------- study groups (§9, §10) ----------
   A group is a shared *intention*, not a shared server. Members are names the
   student typed. There is no account lookup, no invitation to a stranger, and
   nothing leaves the device. */
function community(){
  const h = H(); if(!h) return null;
  if(!h.circle) h.circle = { groups:[], pacts:[], reports:[] };
  const c = h.circle;
  for(const k of ["groups","pacts","reports"]) if(!Array.isArray(c[k])) c[k] = [];
  return c;
}
function createGroup({ name, purpose = "", members = [] }){
  const c = community(); if(!c) return null;
  const g = {
    id: uid(), name: String(name || "").slice(0, 60).trim(),
    purpose: String(purpose).slice(0, 200),
    /* first names only, by design — see the directory refusal above */
    members: (members || []).slice(0, 12).map(m => String(m).slice(0, 24).trim()).filter(Boolean),
    goals: [], sessions: [], created: todayKey(),
  };
  if(!g.name) return null;
  c.groups.push(g); save(); markChanged("progress","group");
  return g;
}
function addGroupGoal(groupId, { text, due = null }){
  const c = community(); const g = (c.groups || []).find(x => x.id === groupId); if(!g) return null;
  const goal = { id: uid(), text: String(text || "").slice(0, 160).trim(), due, done:false };
  if(!goal.text) return null;
  g.goals.push(goal); save(); return goal;
}
function logGroupSession(groupId, { minutes = 30, note = "", present = [] }){
  const c = community(); const g = (c.groups || []).find(x => x.id === groupId); if(!g) return null;
  g.sessions.push({ id:uid(), date:todayKey(), minutes:Math.max(5, Number(minutes) || 30),
                    note:String(note).slice(0,200), present:(present||[]).slice(0,12) });
  save();
  grantXp(BALANCE.xp.focusSession, `Study group — ${g.name}`, { once:"grp:" + groupId + ":" + todayKey() });
  return g;
}
function groupHealth(g){
  const recent = (g.sessions || []).filter(s => s.date >= (() => { const d=new Date(); d.setDate(d.getDate()-28); return todayKey(d); })());
  const mins = recent.reduce((n, s) => n + s.minutes, 0);
  const goalsDone = (g.goals || []).filter(x => x.done).length;
  return {
    sessions: recent.length, minutes: mins, goals: (g.goals||[]).length, goalsDone,
    verdict: recent.length === 0
      ? "No sessions logged in four weeks. A study group that stops meeting is a group chat — worth either restarting it or letting it go without guilt."
      : recent.length >= 4
        ? `${recent.length} sessions and ${mins} minutes in four weeks. This one is real.`
        : `${recent.length} session${recent.length===1?"":"s"} in four weeks. Early — one fixed weekly time is what makes these survive.`,
  };
}

/* ---------- the teacher/parent report (§29, §30) ----------
   The student generates it and hands it over. That inverts the usual arrangement
   deliberately: the adult gets what they need, and the student keeps ownership of
   everything they did not choose to include. */
const REPORT_SECTIONS = [
  { k:"attendance", label:"Study consistency",  blurb:"Days studied and clear rate. No content." },
  { k:"mastery",    label:"Subject progress",   blurb:"Topic coverage per subject, by evidence." },
  { k:"exams",      label:"Upcoming exams",     blurb:"Dates and readiness." },
  { k:"weak",       label:"Weak areas",         blurb:"Where help would actually land." },
  { k:"work",       label:"Projects & results", blurb:"What has been finished." },
];
function buildReport(include){
  const h = H(); if(!h) return null;
  const inc = new Set(include && include.length ? include : REPORT_SECTIONS.map(s => s.k));
  const m = typeof userModel === "function" ? userModel() : null;
  const acad = typeof academyOverview === "function" ? academyOverview() : null;
  const rep = { at: todayKey(), name: h.name, sections: [] };

  if(inc.has("attendance") && m) rep.sections.push({ label:"Study consistency",
    lines:[ `Days with a record: ${Object.keys(h.done || {}).length}`,
            `Quests cleared: ${h.totalCleared || 0}`,
            `Clear rate, last 14 days: ${mPct(m.perf.last14)}%`,
            `Current streak: ${h.streak || 0} days` ] });

  if(inc.has("mastery") && acad) rep.sections.push({ label:"Subject progress",
    lines: acad.subjects.length
      ? acad.subjects.map(s => `${s.subject.name}: ${Math.round(s.avg*100)}% of topics have evidence behind them (${s.mastered} mastered of ${s.total})`)
      : ["No subjects set up yet."] });

  if(inc.has("exams")){
    const ex = typeof upcomingExams === "function" ? upcomingExams() : [];
    rep.sections.push({ label:"Upcoming exams",
      lines: ex.length ? ex.slice(0,6).map(e => `${e.subject.name} — ${e.date} (${e.in} days)`) : ["None registered."] });
  }
  if(inc.has("weak") && acad) rep.sections.push({ label:"Where help would land",
    lines: acad.weak.length ? acad.weak.slice(0,6).map(w => `${w.t.subject.name} — ${w.t.name} (${Math.round(w.m.pct*100)}%)`)
                            : ["Nothing flagged as weak."] });

  if(inc.has("work")){
    const done = typeof projects === "function" ? projects().filter(p => p.stage === "completed") : [];
    const res = typeof oppList === "function" ? oppList().filter(o => o.result) : [];
    rep.sections.push({ label:"Finished work",
      lines: [...done.map(p => `Project: ${p.title}`), ...res.map(o => `${o.name} — ${o.result.kind} (${o.result.verification === "evidence" ? "evidence attached" : "self-reported"})`)]
             .slice(0,10).concat(done.length + res.length ? [] : ["Nothing recorded yet."]) });
  }
  /* what is deliberately absent, stated in the report itself so the adult knows */
  rep.excluded = ["Reflections and journal entries","Notes and their contents","Anything marked private","Money and Vault records","AI conversations"];
  return rep;
}
function reportText(rep){
  if(!rep) return "";
  return [
    `THE SYSTEM — progress report`,
    `${rep.name} · ${rep.at}`,
    ``,
    ...rep.sections.flatMap(s => [s.label.toUpperCase(), ...s.lines.map(l => "  " + l), ""]),
    `Not included: ${rep.excluded.join("; ")}.`,
    `Generated by the student from their own device. Figures come from their own record and are not independently verified.`,
  ].join("\n");
}

/* ---------- class work in, quests out (§22, §81) ----------
   A teacher sets homework on paper or in a group chat. The student pastes it here
   and it becomes quests. No integration, no accounts, works everywhere. */
function importClassWork(text, { subject = "", due = null } = {}){
  const lines = String(text || "").split("\n").map(l => l.replace(/^[\s\-*•\d.)]+/, "").trim()).filter(Boolean);
  if(!lines.length) return { added:0 };
  const h = H(); if(!h) return { added:0 };
  let added = 0;
  for(const line of lines.slice(0, 12)){
    h.deadlines = h.deadlines || [];
    h.deadlines.push({ id:uid(), name: (subject ? subject + ": " : "") + line.slice(0, 80),
                       date: due || (() => { const d=new Date(); d.setDate(d.getDate()+7); return todayKey(d); })(),
                       weight:"2" });
    added++;
  }
  save(); markChanged("progress","classwork");
  return { added };
}

/* ---------- accountability pact (§58, §59) ----------
   Peer recognition without a scoreboard: two people, one commitment, a check-in
   date. Nothing is ranked and nothing is public. */
function createPact({ withWhom, commitment, until }){
  const c = community(); if(!c) return null;
  const p = { id:uid(), withWhom:String(withWhom||"").slice(0,24).trim(),
              commitment:String(commitment||"").slice(0,160).trim(),
              until: until || null, checkins:[], created:todayKey() };
  if(!p.withWhom || !p.commitment) return null;
  c.pacts.push(p); save(); return p;
}
function pactCheckin(id, kept, note){
  const c = community(); const p = (c.pacts || []).find(x => x.id === id); if(!p) return null;
  p.checkins.push({ at:todayKey(), kept: !!kept, note:String(note||"").slice(0,140) });
  save();
  if(kept) grantXp(BALANCE.xp.reflection, "Kept a commitment", { once:"pact:" + id + ":" + todayKey() });
  return p;
}
