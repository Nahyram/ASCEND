/* THE SYSTEM v13 — services/security.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ v8: SECURITY — PBKDF2 PINs, lockout, auto-lock, encrypted export ══════════════ */
const PBKDF2_ITER = 150000;
async function pbkdf2hex(pin, saltHex, iter = PBKDF2_ITER){
  const enc = new TextEncoder();
  const salt = new Uint8Array((saltHex.match(/../g)||[]).map(h=>parseInt(h,16)));
  const key = await crypto.subtle.importKey("raw", enc.encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({name:"PBKDF2", hash:"SHA-256", salt, iterations:iter}, key, 256);
  return [...new Uint8Array(bits)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
const randSalt16 = () => [...crypto.getRandomValues(new Uint8Array(16))].map(b=>b.toString(16).padStart(2,"0")).join("");
async function setPinFor(h, pin){
  if(!pin){ delete h.pinHash; delete h.pinSalt; delete h.pin2; return; }
  const salt = randSalt16();
  h.pin2 = { salt, iter: PBKDF2_ITER, hash: await pbkdf2hex(pin, salt) };
  delete h.pinHash; delete h.pinSalt; delete h.pin;
}
async function verifyPin(h, pin){
  if(h.pin2) return (await pbkdf2hex(pin, h.pin2.salt, h.pin2.iter)) === h.pin2.hash;
  if(h.pinHash){ // legacy salted sha256 — verify, then silently upgrade
    const ok = (await sha256hex((h.pinSalt||"") + pin)) === h.pinHash;
    if(ok) await setPinFor(h, pin);
    return ok;
  }
  if(h.pin){ const ok = pin === h.pin; if(ok) await setPinFor(h, pin); return ok; }
  return true;
}
function lockLeft(id){
  const t = (DB.sec.until||{})[id] || 0;
  return Math.max(0, Math.ceil((t - Date.now())/1000));
}
function noteFail(id){
  DB.sec.fails[id] = (DB.sec.fails[id]||0) + 1;
  if(DB.sec.fails[id] >= 5){
    const strikes = DB.sec.fails[id] - 4;
    DB.sec.until[id] = Date.now() + Math.min(30*60000, 60000 * Math.pow(2, strikes-1));
  }
  save();
}
function clearFails(id){ delete DB.sec.fails[id]; delete DB.sec.until[id]; save(); }

/* auto-lock on inactivity (only when a PIN exists) */
let lastTouch = Date.now();
["click","keydown","pointerdown","touchstart","scroll"].forEach(ev =>
  document.addEventListener(ev, () => lastTouch = Date.now(), {passive:true}));
setInterval(() => {
  const h = H(); if(!h) return;
  const mins = Number(h.autoLockMin||0);
  if(!mins || !(h.pin2 || h.pinHash || h.pin)) return;
  if(Date.now() - lastTouch > mins*60000){ DB.active = null; save(); location.reload(); }
}, 15000);

/* encrypted export helpers (AES-256-GCM, key from passphrase via PBKDF2) */
async function aesKeyFrom(pass, salt){
  const enc = new TextEncoder();
  const km = await crypto.subtle.importKey("raw", enc.encode(pass), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2", hash:"SHA-256", salt, iterations:PBKDF2_ITER}, km,
    {name:"AES-GCM", length:256}, false, ["encrypt","decrypt"]);
}
const b64 = u8 => btoa(String.fromCharCode(...u8));
const unb64 = s => new Uint8Array([...atob(s)].map(c=>c.charCodeAt(0)));
async function encryptExport(obj, pass){
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await aesKeyFrom(pass, salt);
  const data = new TextEncoder().encode(JSON.stringify(obj));
  const ct = new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM", iv}, key, data));
  return { type:"system.hunter.enc", v:1, salt:b64(salt), iv:b64(iv), data:b64(ct) };
}
async function decryptImport(pkg, pass){
  const key = await aesKeyFrom(pass, unb64(pkg.salt));
  const pt = await crypto.subtle.decrypt({name:"AES-GCM", iv:unb64(pkg.iv)}, key, unb64(pkg.data));
  return JSON.parse(new TextDecoder().decode(pt));
}

