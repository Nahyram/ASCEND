/* THE SYSTEM v14 — services/integrity.js
   Phase 14: the trust layer, scoped honestly to what a client-only app can
   actually guarantee.

   ## The distinction this file exists to keep straight

   Phase 14 §19 is unambiguous: authorisation must be enforced server-side, and
   hidden buttons are not security. THE SYSTEM has no server. So there is a class
   of protection it genuinely cannot provide, and the correct engineering response
   is to say so plainly rather than to ship a `checkPermission()` that returns true
   and looks reassuring in a diff.

   What a local-first app CAN do, and what this file does:

     - **§26, §27, §28 — never render user text as markup.** Everything typed into
       THE SYSTEM (project titles, notes, opportunity names, AI output) is drawn
       through `esc()`. This file audits that and tests it.
     - **§41, §42 — data integrity.** Broken references, impossible values and
       orphaned records are found and repaired.
     - **§80, §81 — never lose work.** Storage failures surface with the work still
       in hand, not as a silent drop.
     - **§2, §3 — a real QA register**, generated from tests that actually run
       rather than a hand-written table of ticks.

   What it does not do, and says so: authenticate, authorise, or protect one user's
   data from another. There is one user, on one device, and pretending otherwise
   would be the dishonest part. */
"use strict";

/* ══════════════ input safety (§26, §27, §28) ══════════════ */
const XSS_PROBES = [
  '<img src=x onerror=alert(1)>',
  '<script>alert(1)</script>',
  '"><svg onload=alert(1)>',
  "javascript:alert(1)",
  '<iframe src="javascript:alert(1)">',
];

/* §71 — never trust a URL from anywhere, including an AI response */
function safeUrl(raw){
  const s = String(raw || "").trim();
  if(!s) return { ok:false, reason:"empty" };
  if(!/^https?:\/\//i.test(s)) return { ok:false, reason:"Only http and https links are allowed.", value:"" };
  try{
    const u = new URL(s);
    if(/^javascript:|^data:|^vbscript:/i.test(u.protocol)) return { ok:false, reason:"Blocked scheme." };
    return { ok:true, value:u.href, host:u.host, secure:u.protocol === "https:" };
  }catch(e){ return { ok:false, reason:"Not a valid link." }; }
}

/* §26 — validation on every user-controlled field, with the limits in one place */
const FIELD_LIMITS = {
  name: 120, title: 120, description: 600, note: 800, url: 500,
  short: 200, essay: 4000,
};
function sanitiseText(raw, kind = "short"){
  const max = FIELD_LIMITS[kind] || 200;
  return String(raw == null ? "" : raw)
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "")   /* control chars */
    .slice(0, max)
    .trim();
}
function validNumber(raw, { min = -Infinity, max = Infinity, fallback = 0 } = {}){
  const n = Number(raw);
  if(!isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

/* ══════════════ data integrity (§41, §42) ══════════════
   Every check names what it found and what repairing it would do, and repair is
   never automatic — §40's principle that a signal is not a verdict. */
function integrityCheck(){
  const h = H(); if(!h) return { issues: [], ok: true };
  const issues = [];
  const add = (sev, what, detail, fix) => issues.push({ sev, what, detail, fix });

  /* orphaned done-entries: a quest was deleted, its history was not */
  const questIds = new Set((h.quests || []).map(q => q.id));
  let orphanDays = 0, orphanTicks = 0;
  for(const [, set] of Object.entries(h.done || {})){
    const bad = Object.keys(set || {}).filter(id => !questIds.has(id));
    if(bad.length){ orphanDays++; orphanTicks += bad.length; }
  }
  if(orphanTicks) add("low", "History for quests that no longer exist",
    `${orphanTicks} ticks across ${orphanDays} days reference deleted quests.`,
    "They are harmless — they inflate nothing, because clear-rate is measured against what was scheduled. Clearing them only tidies the file.");

  /* impossible values (§17 — negative or absurd figures) */
  for(const [k, lim] of [["xp", 1e7], ["totalXp", 1e8], ["level", 999], ["streak", 3650]]){
    const v = Number(h[k]);
    if(!isFinite(v) || v < 0) add("high", `${k} is not a valid number`, `Value: ${h[k]}`, `Reset ${k} to 0.`);
    else if(v > lim) add("medium", `${k} is implausibly large`, `Value: ${v}`, "Worth checking whether an import went wrong.");
  }

  /* broken cross-references introduced by phases 7–10 */
  if(h.projects && Array.isArray(h.projects.items)){
    const oppIds = new Set(((h.opportunities || {}).items || []).map(o => o.id));
    const broken = h.projects.items.filter(p => p.competitionId && !oppIds.has(p.competitionId)).length;
    if(broken) add("low", "Projects linked to removed opportunities",
      `${broken} project${broken===1?"":"s"}.`, "The link is dropped; the project is untouched.");
  }
  if(h.opportunities && Array.isArray(h.opportunities.packages)){
    const oppIds = new Set((h.opportunities.items || []).map(o => o.id));
    const orphanPk = h.opportunities.packages.filter(p => !oppIds.has(p.oppId)).length;
    if(orphanPk) add("medium", "Application packages with no opportunity",
      `${orphanPk} package${orphanPk===1?"":"s"} point at something that was deleted.`,
      "They are unreachable in the interface. Removing them loses only the checklist state.");
  }

  /* the Academy's evidence record must not claim more correct than attempted */
  if(h.academy) for(const s of h.academy.subjects || []) for(const u of s.units || []) for(const t of u.topics || []){
    const e = t.ev || {};
    if((e.correct || 0) > (e.attempts || 0)) add("high", "A topic records more correct answers than attempts",
      `${s.name} — ${t.name}`, "Mastery for that topic is overstated. Resetting its evidence is the only honest repair.");
  }

  /* storage headroom (§80) */
  const bytes = typeof Store === "object" ? Store.bytes() : 0;
  if(bytes > 4_000_000) add("medium", "The record is getting large",
    `${(bytes/1024/1024).toFixed(1)} MB. Most browsers stop writing somewhere around 5 MB.`,
    "Export a backup now. Old daily history is the biggest component and the safest to trim.");
  if(typeof Store === "object" && !Store.durable) add("high", "This browser is not storing data durably",
    "Storage is in memory only.", "Export before you close the tab. Private browsing is the usual cause.");

  return {
    issues,
    ok: !issues.some(i => i.sev === "high"),
    counts: { high: issues.filter(i => i.sev === "high").length,
              medium: issues.filter(i => i.sev === "medium").length,
              low: issues.filter(i => i.sev === "low").length },
  };
}

function repairIntegrity(){
  const h = H(); if(!h) return { fixed: 0 };
  let fixed = 0;
  const questIds = new Set((h.quests || []).map(q => q.id));
  for(const [day, set] of Object.entries(h.done || {})){
    for(const id of Object.keys(set || {})) if(!questIds.has(id)){ delete h.done[day][id]; fixed++; }
  }
  for(const k of ["xp", "totalXp", "level", "streak"]){
    if(!isFinite(Number(h[k])) || Number(h[k]) < 0){ h[k] = k === "level" ? 1 : 0; fixed++; }
  }
  if(h.opportunities && Array.isArray(h.opportunities.packages)){
    const oppIds = new Set((h.opportunities.items || []).map(o => o.id));
    const before = h.opportunities.packages.length;
    h.opportunities.packages = h.opportunities.packages.filter(p => oppIds.has(p.oppId));
    fixed += before - h.opportunities.packages.length;
  }
  if(h.academy) for(const s of h.academy.subjects || []) for(const u of s.units || []) for(const t of u.topics || []){
    const e = t.ev; if(e && (e.correct || 0) > (e.attempts || 0)){ e.correct = e.attempts || 0; fixed++; }
  }
  if(fixed) { save(); if(typeof invalidateAcademy === "function") invalidateAcademy(); if(typeof invalidateModel === "function") invalidateModel(); }
  return { fixed };
}

/* ══════════════ never lose work (§80, §81) ══════════════
   A failed write must reach the user holding the thing they were writing, not as
   a toast after the form has been cleared. */
function guardedSave(work){
  const r = typeof Store === "object" ? Store.writeJSON("system.v1", DB) : { ok:false };
  if(!r.ok){
    /* sessionStorage, not localStorage: the store that just refused a write is
       the wrong place to put the recovery copy. sessionStorage is a separate
       quota, and a tab that survives long enough to show the message is exactly
       the tab that can still hand the work back. */
    const stash = { at: Date.now(), work };
    try{ sessionStorage.setItem("system.unsaved", JSON.stringify(stash)); }catch(e){}
    return { ok:false,
      message:"That could not be saved — storage is full or blocked. What you just wrote is still on screen and a copy is held for this session. Export a backup, free some space, and try again." };
  }
  try{ sessionStorage.removeItem("system.unsaved"); }catch(e){}
  return { ok:true };
}
function recoverUnsaved(){
  try{
    const raw = sessionStorage.getItem("system.unsaved");
    return raw ? JSON.parse(raw) : null;
  }catch(e){ return null; }
}

/* ══════════════ a render that fails must not fail quietly ══════════════

   Views are wrapped in `try{ render(); }catch(e){}` in several places so that
   one broken panel cannot take a whole section down with it. Isolation is the
   right instinct; an empty catch block is the wrong implementation of it.

   The Open Gate's nine dropout-help cards and the 90-day heatmap were both
   missing for two releases. Neither threw — they were shadowed by a duplicate
   global — but the empty catches around neighbouring renders are why nobody
   had a habit of looking: a section that renders four panels out of five looks
   like a section, and nothing anywhere says otherwise.

   safeRender() keeps the isolation and removes the silence. The failure is
   logged once per render name (so a broken panel in a 30-second refresh loop
   does not become a thousand console lines), recorded so the Studio panel and
   the QA register can show it, and the panel itself is told to say it failed
   rather than sitting there empty. */
const RENDER_FAILURES = new Map();

function safeRender(name, fn, opts = {}){
  try{
    fn();
    if(RENDER_FAILURES.has(name)) RENDER_FAILURES.delete(name);   /* recovered */
    return true;
  }catch(err){
    const first = !RENDER_FAILURES.has(name);
    const rec = RENDER_FAILURES.get(name) || { name, count:0, message:"", at:0 };
    rec.count++; rec.message = (err && err.message) || String(err); rec.at = Date.now();
    RENDER_FAILURES.set(name, rec);
    if(first) console.error(`[render] ${name} failed and was skipped:`, err);

    /* If the panel has a container, say so in it. An empty panel is
       indistinguishable from a panel with nothing to show. */
    const el = opts.into && typeof document !== "undefined" ? document.querySelector(opts.into) : null;
    if(el && !el.querySelector(".render-failed")){
      const d = document.createElement("p");
      d.className = "tiny render-failed";
      d.style.color = "var(--blood, #d33)";
      d.textContent = "This panel could not be drawn. The rest of the section is unaffected \u2014 details are in Settings \u203a Studio.";
      el.appendChild(d);
    }
    return false;
  }
}

function renderFailures(){ return [...RENDER_FAILURES.values()].sort((a,b) => b.count - a.count); }

/* ══════════════ the honest security posture (§19, §37) ══════════════
   Written out so nobody — including a future version of me — mistakes what this
   build does and does not protect. */
function securityPosture(){
  return {
    model: "Local-first, single user, single device.",
    protects: [
      { k:"Injection", how:"Every string typed into THE SYSTEM is rendered through esc(). Nothing user-entered, imported or AI-generated is inserted as markup." },
      { k:"Link safety", how:"Links are parsed and restricted to http and https; javascript: and data: are refused." },
      { k:"Data integrity", how:"Broken references, impossible values and overstated evidence are detected and repairable." },
      { k:"Secrets", how:"THE SYSTEM ships no API key. A key you supply is stored on your device and the interface states plainly that a browser-held key is public." },
      { k:"Your data", how:"It never leaves the device unless you sign in and choose what to sync. Export and delete are one tap each." },
    ],
    doesNotProtect: [
      { k:"Authentication", why:"There is no server to authenticate against. The account in the Gate is a sync identity, not a security boundary." },
      { k:"Authorisation", why:"Phase 14 §19 is right that this must be enforced server-side. There is no server, so it is not enforced anywhere — and a client-side check would be theatre." },
      { k:"Device access", why:"Anyone who can unlock your phone can read the record. The PIN is a deterrent against a passing glance, not encryption." },
      { k:"Other users' data", why:"There are none. Multi-tenant isolation becomes a real requirement the moment a backend exists, and not before." },
    ],
    note: "This list is deliberately explicit. A security section that lists only what a build does well is worse than none, because it tells you the wrong thing about what to rely on.",
  };
}

/* ══════════════ QA register (§2, §3) ══════════════
   §99 says the matrix must be generated from tests that actually ran, not
   hard-coded ticks. This reads the test suite's own results file if one has been
   produced, and otherwise reports honestly that it does not know. */
const QA_AREAS = [
  { k:"storage",     label:"Storage & migrations",   covered:true },
  { k:"intelligence",label:"Patterns & recommendations", covered:true },
  { k:"progression", label:"XP, ranks, achievements", covered:true },
  { k:"academy",     label:"Mastery, practice, exams", covered:true },
  { k:"sync",        label:"Cloud sync & conflicts",  covered:true },
  { k:"opportunities",label:"Opportunities & matching", covered:true },
  { k:"projects",    label:"Projects & portfolio",    covered:true },
  { k:"integrity",   label:"Input safety & repair",   covered:true },
  { k:"auth",        label:"Authentication",          covered:false, why:"No backend exists to test against." },
  { k:"multiuser",   label:"Cross-user isolation",    covered:false, why:"Single-user build — there is nothing to isolate." },
  { k:"payments",    label:"Billing & entitlements",  covered:false, why:"Phase 17. The entitlement seam exists; no billing does." },
];
function qaRegister(){
  return {
    areas: QA_AREAS,
    covered: QA_AREAS.filter(a => a.covered).length,
    total: QA_AREAS.length,
    note: "Coverage here means an automated check runs against it in brain-test.js. Areas marked uncovered are uncovered because the thing they would test does not exist yet — not because testing was skipped.",
  };
}
