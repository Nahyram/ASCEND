/* ASCEND — services/day.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- daily rollover: judge yesterday ---------- */
function rollover(){
  const h = H(), t = todayKey();
  if(h.lastActive === t) return;
  if(h.lastActive){
    const y = h.lastActive;
    /* todayKey() writes a local date; new Date("2026-08-18") reads it back as
       UTC midnight. West of UTC that lands on the previous day, so getDay()
       returned the wrong weekday and yesterday was judged against the wrong
       day's quest list. Every other date site in this codebase appends the time
       for exactly this reason. */
    const dayQuests = questsFor(dateFromKey(y));
    const mand = dayQuests.filter(q=>q.mand);
    const doneSet = h.done[y] || {};
    const missed = mand.filter(q => !doneSet[q.id]);
    const cleared = dayQuests.filter(q=>doneSet[q.id]).length;
    /* A day with nothing scheduled is a rest day, not a failure. Quest days have
       been user-selectable since v2, so this fell through to streak = 0 and
       wiped the streak of anyone who left a day empty. Nothing was asked of
       them; nothing is judged. */
    if(!dayQuests.length){
      /* rest day — the streak is neither advanced nor broken */
    }
    else if(cleared / dayQuests.length >= 0.7) h.streak++;
    else if(typeof skillShieldAbsorbs === "function" && skillShieldAbsorbs(y)){
      /* Ironclad: one missed day a week does not kill the streak */
    }
    else {
      const lost = h.streak;
      h.streak = 0;
      if(lost >= 3) setTimeout(()=> takeover({kind:"penalty", penalty:true, title:"STREAK TERMINATED",
        sub:`${lost} days of consistency erased on ${y}. The record does not care why.`,
        reward:"Start again today. That is the only repair the System accepts."}), 1200);
    }
    if(missed.length && h.penaltyMode === "on"){
      h.penalties.push({ id:uid(), text: PENALTIES[missed.length % PENALTIES.length],
        reason:`${missed.length} mandatory quest${missed.length>1?"s":""} missed on ${y}`, date:t, done:false });
      h.xp = Math.max(0, h.xp - Math.round(20*Math.min(missed.length,3) * (typeof skillPenaltyMult === "function" ? skillPenaltyMult() : 1)));
    }
  }
  h.lastActive = t; h.firedToday = {}; save();
}

/* ---------- quest helpers ---------- */
function questsFor(d = new Date()){
  const day = d.getDay();
  /* 18.15 — vacation mode, hooked in exactly once.

     During a vacation the board is the campaign rather than the timetable, and
     everything downstream then needs no special case: campaign quests are never
     mandatory so penalty.js never fires, and they are real quests so the streak
     advances on them honestly. The timetable is not touched — ending a vacation
     restores it because nothing was removed. */
  if(typeof vacationOn === "function" && vacationOn()){
    return vacationQuests().filter(q => q.days.includes(day)).sort((a,b)=>a.time.localeCompare(b.time));
  }
  return H().quests.filter(q => q.days.includes(day)).sort((a,b)=>a.time.localeCompare(b.time));
}
const isDone = q => !!(H().done[todayKey()]||{})[q.id];
function toggleQuest(q){ return Hooks.dispatch("toggleQuest", toggleQuestBase, this, arguments); }
function toggleQuestBase(q){
  const h = H(), t = todayKey();
  h.done[t] = h.done[t] || {};
  let cleared;
  if(h.done[t][q.id]){ delete h.done[t][q.id]; h.totalCleared = Math.max(0,h.totalCleared-1); cleared = false; }
  else {
    h.done[t][q.id] = true; h.totalCleared++;
    /* §7 — the tick pays XP, because the effort is real and the student is the
       honest witness to it. It does not pay Intellect or Perception: those are
       claims about capability, and "I sat down with Physics" is not evidence of
       Physics. grantStat says which happened; the toast says so out loud rather
       than quietly paying less than last week. */
    const st = grantStat(q.cat, q.mand?1:0.5);
    grantXp(q.xp, q.name, q.cat);
    if(st && st.withheld){
      toast("Quest cleared", `${q.name} · +${q.xp} XP · ${st.stats.join("/")} held — ${st.hint}`, "gold");
    } else {
      toast("Quest cleared", `${q.name} · +${q.xp} XP`, "gold");
    }
    cleared = true;
  }
  save();
  /* v18: announce it. Until now this function moved XP and nothing else — a goal
     step scheduled onto the board could be cleared every day for a month without
     the goal it belonged to ever noticing. The consequences live in
     services/link.js; a listener that throws is caught by the bus, so nothing
     here can stop a quest being ticked off. */
  if(typeof Bus !== "undefined"){
    Bus.emit(cleared ? SYSTEM_EVENTS.QUEST_COMPLETED : SYSTEM_EVENTS.QUEST_UNCLEARED,
             { quest:q, date:t });
  }
  renderAll();
}
const fmt12 = t => { const [H_,M] = t.split(":").map(Number); const ap = H_>=12?"PM":"AM"; const hh = H_%12||12; return `${hh}:${pad(M)} ${ap}`; };
const dayStr = ds => ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].filter((_,i)=>ds.includes(i)).join(" ");
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

/* ---------- crypto helpers (v4 security) ---------- */
async function sha256hex(str){
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
const randSalt = () => [...crypto.getRandomValues(new Uint8Array(8))].map(b=>b.toString(16).padStart(2,"0")).join("");
/* Access-key hashes. Generate keys with the console snippet in README.md,
   paste the sha256 hashes here before deploying. Keys are NOT derivable from this file. */
const KEY_HASHES = [];

