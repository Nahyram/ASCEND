/* THE SYSTEM v14 — services/goals.js
   Goals stop being a flat list and become a ladder:

     year → six months → ninety days → month → week → today's quest

   Phase 3 §30 asks for that chain to be visible, so that a step cleared this
   afternoon can be traced up to the thing it is actually for. The old shape is
   preserved exactly — goal → targets → steps — and the ladder is expressed with
   two optional fields, `horizon` and `parent`. A v13 goal opens here untouched.

   §8 asks that a goal can be broken into a progression. That is done locally, from
   templates, not from a model: the sequence for preparing an exam is not a
   creative problem, and a deterministic answer is faster, free, works offline and
   cannot invent a step. services/ai.js can rewrite the wording later when the
   hunter is online and asks for it. */
"use strict";

const HORIZONS = [
  { k:"year",    label:"This year",   days:365, blurb:"The one thing that would make the year count." },
  { k:"half",    label:"Six months",  days:182, blurb:"A destination you could reach by the next long holiday." },
  { k:"quarter", label:"90 days",     days:90,  blurb:"Close enough to plan, far enough to matter." },
  { k:"month",   label:"This month",  days:30,  blurb:"What has to be true by month end." },
  { k:"week",    label:"This week",   days:7,   blurb:"The next visible move." },
];
const HORIZON = Object.fromEntries(HORIZONS.map(h => [h.k, h]));
const horizonRank = k => HORIZONS.findIndex(h => h.k === k);

/* ---------- reading and writing ---------- */
function allGoals(){ const h = H(); if(!h) return []; if(!Array.isArray(h.goals)) h.goals = []; return h.goals; }
function getGoal(id){ return allGoals().find(g => g.id === id) || null; }

function addGoal({ name, horizon = "month", due = null, parent = null }){
  const h = H(); if(!h) return null;
  if(!Array.isArray(h.goals)) h.goals = [];
  const g = {
    id: uid(), name: String(name || "").slice(0, 120).trim(),
    horizon: HORIZON[horizon] ? horizon : "month",
    due: due || defaultDue(horizon), parent,
    targets: [], created: todayKey(), touched: todayKey(),
  };
  if(!g.name) return null;
  h.goals.push(g); save(); invalidateModel();
  return g;
}
function defaultDue(horizon){
  const d = new Date(); d.setDate(d.getDate() + (HORIZON[horizon] ? HORIZON[horizon].days : 30));
  return todayKey(d);
}
function touchGoal(id){ const g = getGoal(id); if(g){ g.touched = todayKey(); save(); invalidateModel(); } }

/* A child may not outlive its parent's horizon — a 90-day goal hanging under a
   weekly one is a filing error, and quietly allowing it makes the ladder useless. */
function canParent(childHorizon, parentHorizon){
  return horizonRank(parentHorizon) < horizonRank(childHorizon);
}
function setParent(childId, parentId){
  const c = getGoal(childId); if(!c) return false;
  if(!parentId){ c.parent = null; save(); invalidateModel(); return true; }
  const p = getGoal(parentId); if(!p || p.id === c.id) return false;
  if(!canParent(c.horizon, p.horizon)) return false;
  /* no cycles: walk up from the proposed parent and refuse if we meet the child */
  let cur = p, guard = 0;
  while(cur && guard++ < 12){ if(cur.id === c.id) return false; cur = cur.parent ? getGoal(cur.parent) : null; }
  c.parent = parentId; save(); invalidateModel(); return true;
}

/* ---------- the ladder ---------- */
function goalTree(){
  const goals = allGoals();
  const byId = Object.fromEntries(goals.map(g => [g.id, { ...g, children:[] }]));
  const roots = [];
  for(const g of Object.values(byId)){
    if(g.parent && byId[g.parent]) byId[g.parent].children.push(g);
    else roots.push(g);
  }
  const order = (a,b) => horizonRank(a.horizon) - horizonRank(b.horizon) || String(a.due||"").localeCompare(String(b.due||""));
  roots.sort(order);
  for(const g of Object.values(byId)) g.children.sort(order);
  return roots;
}

/* The chain from one goal up to its furthest ancestor — printed under a step so a
   student can see that tonight's twenty minutes is attached to something. */
function goalChain(id){
  const out = []; let cur = getGoal(id), guard = 0;
  while(cur && guard++ < 12){ out.unshift(cur); cur = cur.parent ? getGoal(cur.parent) : null; }
  return out;
}

function goalProgress(g){
  const all = (g.targets || []).reduce((s,t) => s.concat(t.steps || []), []);
  const done = all.filter(s => s.done).length;
  const daysLeft = g.due ? Math.round((new Date(g.due+"T00:00:00") - new Date(todayKey()+"T00:00:00")) / 86400000) : null;
  return {
    steps:all.length, done, pct: all.length ? done/all.length : 0,
    next: all.find(s => !s.done) || null,
    daysLeft,
    /* behind = the calendar has used more of the window than the work has */
    behind: (() => {
      if(!g.due || !all.length || daysLeft === null) return false;
      const span = HORIZON[g.horizon] ? HORIZON[g.horizon].days : 30;
      const used = Math.max(0, Math.min(1, (span - daysLeft) / span));
      return used - (done / all.length) >= 0.25;
    })(),
  };
}

/* ══════════════ breakdown ══════════════
   §8: a goal becomes a progression. Which progression depends on what kind of goal
   it is, and the kind is guessed from the words the hunter used. If nothing matches
   we use the generic ladder, which is honest — a plan that admits it is generic is
   more useful than one that pretends to be tailored. */
const GOAL_KINDS = [
  { k:"exam",    match:/\b(exam|igcse|gcse|a[- ]?level|wassce|waec|sat|ib|mock|paper|test|revis)/i,
    label:"Exam preparation",
    targets:[
      { name:"Map the ground", steps:["List every topic on the syllabus","Mark each topic confident / shaky / unknown","Collect two past papers and the mark schemes"] },
      { name:"Close the gaps",  steps:["Study the weakest topic for one session","Do 10 questions on that topic","Mark them honestly and log every mistake","Repeat for the next weakest topic"] },
      { name:"Prove it",        steps:["Sit one past paper under timed conditions","Mark it and sort errors by cause","Re-test the two topics that cost the most marks","Final pass over the error log"] },
    ] },
  { k:"skill",   match:/\b(learn|master|practi[sc]e|piano|guitar|code|coding|program|language|japanese|french|spanish|chess|draw|art|write|speak)/i,
    label:"Skill building",
    targets:[
      { name:"Get started properly", steps:["Pick one source and stop shopping for others","Do the first session today, badly if necessary","Decide the fixed hour you will practise"] },
      { name:"Build the reps",       steps:["Practise on schedule for one full week","Record what is still hard after that week","Drill only the hard part for three sessions"] },
      { name:"Use it for real",      steps:["Do one thing with the skill that is not practice","Show it to one person","Write down what to fix next"] },
    ] },
  { k:"project", match:/\b(build|make|launch|ship|create|app|website|product|business|store|robot|prototype|channel)/i,
    label:"Project",
    targets:[
      { name:"Define it",  steps:["Write in one sentence what it is and who it is for","List what must exist for it to count as done","Cut that list to the smallest version worth showing"] },
      { name:"Build it",   steps:["Make the ugliest version that works","Use it yourself once","Fix the worst thing you found"] },
      { name:"Release it", steps:["Show it to three people who are not friends","Write down what they got confused by","Fix that, then publish"] },
    ] },
  { k:"body",    match:/\b(fit|gym|run|weight|push[- ]?up|muscle|train|martial|health|sleep|diet)/i,
    label:"Physical",
    targets:[
      { name:"Set the floor",  steps:["Record where you are today, honestly","Pick the minimum you would do on your worst day","Do that minimum for seven days straight"] },
      { name:"Add load",       steps:["Raise one variable only — reps, weight, or distance","Hold the new level for two weeks","Log every session, including the bad ones"] },
      { name:"Check the work", steps:["Re-test the measurement from day one","Decide what to change for the next block"] },
    ] },
  { k:"money",   match:/\b(save|money|earn|income|sell|sales|client|customer|ghs|cedis|fund|invest)/i,
    label:"Money",
    targets:[
      { name:"See the numbers", steps:["Write down what comes in and what goes out","Set the amount that goes to the Freedom jar first","Name the single figure this goal is aiming at"] },
      { name:"Do the work",     steps:["List three ways the figure could actually be reached","Pick one and give it two weeks","Log every cedi that arrives from it"] },
      { name:"Review",          steps:["Compare what arrived against the target","Keep what worked, drop what did not"] },
    ] },
  { k:"generic", match:/.*/, label:"General goal",
    targets:[
      { name:"Make it concrete", steps:["Write how you will know it is finished","Name the first action you could start in the next hour","Decide when in the week it happens"] },
      { name:"Do the work",      steps:["Complete the first action","Complete the second action","Keep going for one full week"] },
      { name:"Review",           steps:["Check what actually moved","Adjust the plan rather than the ambition"] },
    ] },
];

function classifyGoal(name){
  const s = String(name || "");
  return GOAL_KINDS.find(k => k.match.test(s)) || GOAL_KINDS[GOAL_KINDS.length - 1];
}

/* Returns a proposal. It does not write. The hunter accepts it, edits it, or
   throws it away — §31, the AI recommends and the user decides. */
function proposeBreakdown(name){
  const kind = classifyGoal(name);
  return {
    kind: kind.k,
    label: kind.label,
    why: kind.k === "generic"
      ? "Nothing in the wording pointed at a particular kind of goal, so this is the general ladder: make it concrete, do the work, check what moved."
      : `Read as a ${kind.label.toLowerCase()} goal from the words you used. Every step is editable, and steps you delete stay deleted.`,
    targets: kind.targets.map(t => ({ name:t.name, steps:t.steps.slice() })),
  };
}

function applyBreakdown(goalId, proposal){
  const g = getGoal(goalId); if(!g || !proposal) return false;
  g.targets = g.targets || [];
  for(const t of proposal.targets.slice(0, 3 - g.targets.length)){
    g.targets.push({ id:uid(), name:t.name, steps:t.steps.map(s => ({ id:uid(), text:s, done:false })) });
  }
  g.touched = todayKey();
  save(); invalidateModel();
  return true;
}

/* Create and populate in one move — what the "break this down for me" button does. */
function createGoalWithPlan({ name, horizon = "month", parent = null }){
  const g = addGoal({ name, horizon, parent });
  if(!g) return null;
  applyBreakdown(g.id, proposeBreakdown(name));
  return g;
}
