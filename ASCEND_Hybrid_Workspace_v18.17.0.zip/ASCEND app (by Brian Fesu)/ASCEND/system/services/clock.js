/* THE SYSTEM v13 — services/clock.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ══════════════ CLOCK · ALARMS · TAKEOVER ══════════════ */
const toMin = t => { const [h,m] = t.split(":").map(Number); return h*60+m; };
const nowMin = () => { const d = new Date(); return d.getHours()*60 + d.getMinutes(); };
let lastDay = todayKey();

function tick(){
  const d = new Date();
  $("#clkTime").textContent = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  $("#clkDate").textContent = d.toLocaleDateString(undefined,{weekday:"short", day:"numeric", month:"short", year:"numeric"});
  if(todayKey() !== lastDay){ lastDay = todayKey(); rollover(); renderAll(); }
  const h = H(); if(!h) return;
  h.firedToday = h.firedToday || {};
  if(h.alarmMode === "off" || takeoverOpen) return;
  const now = nowMin();
  const due = questsFor().find(q => toMin(q.time) === now && !h.firedToday[q.id] && !isDone(q));
  if(due){
    h.firedToday[due.id] = true; save();
    fireQuest(due);
  }
  // late judgement: 60 min past a mandatory quest, unfinished → penalty
  questsFor().forEach(q => {
    if(!q.mand || isDone(q)) return;
    const k = "late_" + q.id;
    if(now === toMin(q.time) + 60 && !h.firedToday[k]){
      h.firedToday[k] = true; save();
      issuePenalty(`Mandatory quest missed: ${q.name}`);
    }
  });
}

function fireQuest(q){
  beep(); vibrate([300,120,300,120,600]);
  notify("QUEST: " + q.name, `${fmt12(q.time)} · ${q.xp} XP · Clear it.`);
  takeover({
    kind:"quest", title: q.name, sub:`${fmt12(q.time)} · ${q.cat.toUpperCase()}${q.mand?" · MANDATORY":""}`,
    reward:`Reward: +${q.xp} XP${q.mand?" · Penalty on failure":""}`,
    actions:[
      {label:"Accept", cls:"btn", fn: close},
      {label:"Complete now", cls:"btn gold", fn: () => { toggleQuest(q); close(); }},
      {label:"Snooze 5 min", cls:"btn ghost", fn: () => { setTimeout(()=>fireQuest(q), 5*60000); close(); }},
    ],
    autoclose: 120
  });
}

let takeoverOpen = false, alTimer = null;
function takeover(o){
  const t = $("#takeover");
  /* Achievements, rank-ups and level-ups all reach this from grantXp, which can
     fire before the shell has painted — during a migration, an import, or a sync
     that lands on startup. A missing overlay should cost the celebration, not the
     action that earned it. */
  if(!t){
    if(typeof toast === "function") toast(o.title || "", o.sub || "", o.penalty ? "blood" : "gold");
    return;
  }
  takeoverOpen = true;
  t.classList.remove("hidden");
  t.classList.toggle("penalty", !!o.penalty);
  const kick = {quest:"Quest Info", levelup:"Notification", rankup:"Notification", penalty:"Warning", welcome:"Notification", unlock:"Notification"}[o.kind] || "Notification";
  $("#alKick").textContent = kick;
  $("#alIcon").textContent = o.penalty ? "✕" : "!";
  $("#alTitle").textContent = o.kind === "quest" ? `[${o.title}]` : o.title;
  $("#alSub").textContent = o.sub || "";
  $("#alReward").textContent = o.reward || "";
  const wt = o.kind === "quest" ? "Failure to complete the quest will result in a penalty."
           : o.kind === "penalty" ? "Complete the penalty quest before midnight." : "";
  $("#alWarn").textContent = wt;
  $("#alWarn").classList.toggle("show", !!wt);
  const acts = $("#alActions"); acts.innerHTML = "";
  (o.actions || [{label:"Understood", cls:"btn", fn: close}]).forEach(a => {
    const b = document.createElement("button"); b.className = a.cls; b.textContent = a.label; b.onclick = a.fn; acts.appendChild(b);
  });
  if(o.kind !== "quest" && o.kind !== "penalty") beep(o.kind==="rankup"?880:660, .12);
  if(o.autoclose){
    let left = o.autoclose;
    $("#alCount").textContent = `Closing in ${left}s`;
    clearInterval(alTimer);
    alTimer = setInterval(()=>{ left--; $("#alCount").textContent = `Closing in ${left}s`; if(left<=0) close(); }, 1000);
  } else $("#alCount").textContent = "";
  if(document.fullscreenEnabled && o.kind === "quest" && !document.fullscreenElement){
    document.documentElement.requestFullscreen?.().catch(()=>{});
  }
  document.addEventListener("keydown", escClose);
}
function close(){
  takeoverOpen = false; clearInterval(alTimer);
  $("#takeover").classList.add("hidden");
  document.removeEventListener("keydown", escClose);
  renderAll();
}
function escClose(e){ if(e.key === "Escape") close(); }

