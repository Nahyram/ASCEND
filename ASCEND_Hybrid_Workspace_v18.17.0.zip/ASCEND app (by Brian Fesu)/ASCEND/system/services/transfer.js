/* THE SYSTEM v13 — services/transfer.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- import sanitizer (v4 security) ---------- */
function sanitizeHunter(x){
  const str = (v,max,fb="") => typeof v==="string" ? v.slice(0,max) : fb;
  const num = (v,lo,hi,fb) => { v = Number(v); return Number.isFinite(v) ? Math.min(hi,Math.max(lo,v)) : fb; };
  const CATS = ["study","body","mind","discipline","rest"];
  const cleanDays = d => Array.isArray(d) ? [...new Set(d.map(Number).filter(n=>Number.isInteger(n)&&n>=0&&n<=6))].sort((a,b)=>a-b) : [];
  const cleanQ = q => ({
    id: str(q.id,24) || uid(),
    time: /^([01]\d|2[0-3]):[0-5]\d$/.test(q.time) ? q.time : "12:00",
    name: str(q.name,120,"Quest"),
    cat: CATS.includes(q.cat) ? q.cat : "study",
    days: cleanDays(q.days).length ? cleanDays(q.days) : [1,2,3,4,5],
    mand: !!q.mand,
    xp: num(q.xp,1,100,15)
  });
  const cleanDl = d => ({ id: str(d.id,24)||uid(), name: str(d.name,140,"Deadline"),
    date: /^\d{4}-\d{2}-\d{2}$/.test(d.date) ? d.date : todayKey(),
    weight: ["1","2","3"].includes(String(d.weight)) ? String(d.weight) : "1" });
  const boolMap = (o,max) => { const out = {};
    if(o && typeof o==="object") Object.keys(o).slice(0,max).forEach(k => { out[String(k).slice(0,40)] = true; });
    return out; };
  const dayMap = (o,maxDays) => { const out = {};
    if(o && typeof o==="object") Object.keys(o).slice(0,maxDays).forEach(k => { out[String(k).slice(0,10)] = boolMap(o[k],80); });
    return out; };
  const h = {
    id: uid(),
    name: str(x.name,40,"Hunter"), title: str(x.title,60,"Newly Awakened"),
    avatar: (typeof x.avatar==="string" && x.avatar.startsWith("data:image/") && x.avatar.length<300000) ? x.avatar : DEFAULT_AVATAR,
    level: num(x.level,1,999,1), xp: num(x.xp,0,1e6,0), totalXp: num(x.totalXp,0,1e8,0),
    rank: ["E","D","C","B","A","S"].includes(x.rank) ? x.rank : "E",
    stats: {}, quests: Array.isArray(x.quests) ? x.quests.slice(0,120).map(cleanQ) : seedQuests("igcse"),
    mode: x.mode==="founder" ? "founder" : "student",
    curriculum: CURRICULA[x.curriculum] ? x.curriculum : "igcse",
    workout: str(x.workout,20,"calisthenics"), diff: ["1","2","3"].includes(String(x.diff)) ? String(x.diff) : "2",
    restDay: num(x.restDay,-1,6,0), reroll: num(x.reroll,0,999,0),
    done: dayMap(x.done,400), workoutDone: boolMap(x.workoutDone,400),
    penalties: Array.isArray(x.penalties) ? x.penalties.slice(0,50).map(p=>({id:str(p.id,24)||uid(), text:str(p.text,140,"Penalty"), reason:str(p.reason,140,""), done:!!p.done})) : [],
    deadlines: Array.isArray(x.deadlines) ? x.deadlines.slice(0,60).map(cleanDl) : [],
    streak: num(x.streak,0,9999,0), lastActive: /^\d{4}-\d{2}-\d{2}$/.test(x.lastActive) ? x.lastActive : null,
    totalCleared: num(x.totalCleared,0,1e6,0),
    spotify: (typeof x.spotify==="string" && /^https:\/\/open\.spotify\.com\//.test(x.spotify)) ? x.spotify.slice(0,200) : "",
    aiEndpoint: (typeof x.aiEndpoint==="string" && /^https:\/\//.test(x.aiEndpoint)) ? x.aiEndpoint.slice(0,300) : "",
    penaltyMode: x.penaltyMode==="off" ? "off" : "on", alarmMode: x.alarmMode==="off" ? "off" : "on",
    unlocked: !!x.unlocked, created: /^\d{4}-\d{2}-\d{2}$/.test(x.created) ? x.created : todayKey(),
    goals: Array.isArray(x.goals) ? x.goals.slice(0,5).map(g => ({
      id: str(g.id,24)||uid(), name: str(g.name,100,"Goal"),
      targets: Array.isArray(g.targets) ? g.targets.slice(0,3).map(t => ({
        id: str(t.id,24)||uid(), name: str(t.name,80,"Target"),
        steps: Array.isArray(t.steps) ? t.steps.slice(0,30).map(s => ({id: str(s.id,24)||uid(), text: str(s.text,120,"Step"), done: !!s.done})) : []
      })) : []
    })) : [],
    vault: (x.vault && typeof x.vault==="object")
      ? {freedom:num(x.vault.freedom,0,1e9,0), learn:num(x.vault.learn,0,1e9,0), lts:num(x.vault.lts,0,1e9,0), play:num(x.vault.play,0,1e9,0), give:num(x.vault.give,0,1e9,0), needs:num(x.vault.needs,0,1e9,0)}
      : {freedom:0,learn:0,lts:0,play:0,give:0,needs:0},
    firedToday: {},
    genres: Array.isArray(x.genres) ? [...new Set(x.genres.map(g=>String(g).slice(0,20)))].slice(0,30) : [],
    booksRead: boolMap(x.booksRead, 200),
    wealthDone: boolMap(x.wealthDone, 40),
    blocklist: str(x.blocklist, 2000, ""),
    autoLockMin: num(x.autoLockMin, 0, 120, 0),
    moneyLog: Array.isArray(x.moneyLog) ? x.moneyLog.slice(-400).map(e => ({
      ts: num(e.ts, 0, 4102444800000, Date.now()),
      k: e.k === "in" ? "in" : "sp",
      jar: ["freedom","learn","lts","play","give","needs"].includes(e.jar) ? e.jar : undefined,
      amt: num(e.amt, 0, 1e9, 0)
    })) : []
  };
  STAT_KEYS.forEach(k => h.stats[k] = num(x.stats && x.stats[k],1,9999,5));
  if(x.pin2 && typeof x.pin2==="object" && /^[a-f0-9]{64}$/.test(x.pin2.hash||"") && /^[a-f0-9]{16,64}$/.test(x.pin2.salt||"")){
    h.pin2 = { salt: x.pin2.salt, iter: num(x.pin2.iter, 50000, 1000000, 150000), hash: x.pin2.hash };
  } else if(typeof x.pinHash==="string" && /^[a-f0-9]{64}$/.test(x.pinHash)){ h.pinHash = x.pinHash; h.pinSalt = str(x.pinSalt,16,""); }
  return h;
}

$("#impFile").onchange = e => {
  const f = e.target.files[0]; if(!f) return;
  const fr = new FileReader();
  fr.onload = async () => {
    try{
      if(fr.result.length > 1_500_000) throw 0;
      let d = JSON.parse(fr.result);
      if(d && d.type === "system.hunter.enc"){
        const pass = await sysPrompt("This hunter file is encrypted",
          {msg:"Enter the passphrase it was exported with. There is no recovery.", inputType:"password", ok:"Open", placeholder:"Passphrase"});
        if(!pass) return;
        try{ d = await decryptImport(d, pass); }
        catch(e){ return toast("Wrong passphrase","The file would not open. No passphrase, no hunter.","blood"); }
      }
      if(!d.hunter) throw 0;
      const clean = sanitizeHunter(d.hunter);
      DB.hunters[clean.id] = clean; DB.active = clean.id;
      save(); renderAll(); toast("Hunter imported", clean.name + " has arrived.","gold");
    }catch(err){ toast("Bad file","That isn't a valid hunter file.","blood"); }
  };
  fr.readAsText(f);
};
$("#btnLogout").onclick = () => { DB.active = null; save(); location.reload(); };
$("#btnWipe").onclick = async () => {
  if(!await sysConfirm("Delete this hunter?",
      "Every quest, level, streak and record on this device goes with it. This cannot be undone.\n\nExport a hunter file first if there is any doubt.",
      {ok:"Delete everything", danger:true, kick:"Point of no return"})) return;
  delete DB.hunters[DB.active]; DB.active = null; save(); location.reload();
};
$("#setAITest").onclick = async () => {
  const url = $("#setAI").value.trim();
  if(!/^https:\/\/.+/.test(url)) return toast("No endpoint","Paste an https:// Worker URL first.","blood");
  $("#setAITest").textContent = "Testing\u2026";
  try{
    const res = await fetch(url, { method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ system:"Reply with the single word: ready", messages:[{role:"user",content:"ping"}] }) });
    if(!res.ok) throw new Error("HTTP " + res.status);
    const d = await res.json();
    if(typeof d.reply !== "string") throw new Error("no reply field");
    toast("Endpoint works","Tutor online mode is live: \u201c" + d.reply.slice(0,60) + "\u201d","gold");
  }catch(err){
    toast("Endpoint failed", err.message + " \u2014 check the Worker is deployed and the key variable is set.","blood");
  }
  $("#setAITest").textContent = "Test endpoint";
};
$("#loreClose").onclick = () => $("#loreModal").classList.add("hidden");
$("#loreModal").onclick = e => { if(e.target.id === "loreModal") $("#loreModal").classList.add("hidden"); };
$("#imgModal").onclick = () => $("#imgModal").classList.add("hidden");
$("#btnAddGoal").onclick = async () => {
  const h = H(); if(!Array.isArray(h.goals)) h.goals = [];
  if(h.goals.length >= 5) return toast("Five goals max","Finish one before you stack more.","blood");
  const v = (await sysPrompt("Name the goal", {msg:"One sentence. Something you would recognise as finished.", placeholder:"e.g. Pass IGCSE Physics with an A", ok:"Add goal"})||"").trim().slice(0,100);
  if(!v) return; h.goals.push({id:uid(), name:v, targets:[]}); save(); renderGoals();
};
$("#vaultSplit").onclick = () => {
  const h = H(); if(!h.vault) h.vault = {freedom:0,learn:0,lts:0,play:0,give:0,needs:0};
  const v = parseFloat($("#vaultIn").value||"0");
  if(!(v > 0)) return toast("Enter an amount","How much came in?","blood");
  VAULT_JARS.forEach(([k,_,pct]) => h.vault[k] = (h.vault[k]||0) + v*pct/100);
  h.moneyLog = h.moneyLog || [];
  h.moneyLog.push({ts: Date.now(), k:"in", amt:v});
  if(h.moneyLog.length > 400) h.moneyLog = h.moneyLog.slice(-400);
  $("#vaultIn").value = ""; save(); renderVault(); renderWealthAdvice();
  grantXp(15, "Paid yourself first");
  toast("Split done","GHS " + v.toFixed(2) + " divided. The Freedom jar just grew — it never shrinks.","gold");
};
$("#tutGo").onclick = tutAsk;
$("#tutIn").addEventListener("keydown", e => { if(e.key==="Enter") tutAsk(); });
$("#btnAllDone").onclick = () => { questsFor().forEach(q => { if(!isDone(q)) toggleQuest(q); }); };
$("#btnResetDay").onclick = () => { H().done[todayKey()] = {}; H().firedToday = {}; save(); renderAll(); toast("Day reset",""); };

