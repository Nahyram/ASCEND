/* THE SYSTEM v14 — services/adaptive.js
   Adaptive difficulty and recovery.

   The governing decision, and it is not a small one: this file never edits the
   hunter's schedule on its own. Phase 3 §31 says the AI recommends and the user
   decides, and v13's coach already worked that way for a reason — a system that
   quietly rewrites your plan is one you stop being able to trust, and once you
   stop trusting it you stop reading it.

   So everything here is a *proposal*: it states what it wants to change, what it
   was computed from, and what happens if you say yes. Four answers are supported —
   accept, modify, reject, snooze — and all four are recorded, because a rejected
   proposal that keeps coming back is worse than no proposal at all.

   Recovery (§10) follows the same rule. A missed week does not silently delete
   quests. It offers a smaller board for a few days, with penalties suspended, and
   says exactly when it ends. */
"use strict";

/* ---------- decision ledger ---------- */
function brain(){
  const h = H(); if(!h) return null;
  if(!h.brain) h.brain = { decisions:[], snoozed:{}, recovery:null, lastBrief:null, lastReview:null };
  if(!Array.isArray(h.brain.decisions)) h.brain.decisions = [];
  if(!h.brain.snoozed) h.brain.snoozed = {};
  return h.brain;
}
function recordDecision(id, verdict, note){
  const b = brain(); if(!b) return;
  b.decisions.push({ id, verdict, note: note || "", at: todayKey(), ts: Date.now() });
  if(b.decisions.length > 200) b.decisions = b.decisions.slice(-200);
  save(); invalidateModel();
}
function isSnoozed(id){
  const b = brain(); if(!b) return false;
  const until = b.snoozed[id];
  return !!until && todayKey() < until;
}
function snoozeProposal(id, days = 7){
  const b = brain(); if(!b) return;
  const d = new Date(); d.setDate(d.getDate() + days);
  b.snoozed[id] = todayKey(d);
  recordDecision(id, "snoozed", `${days} days`);
}
/* A proposal rejected twice is not shown again for a season. The hunter has
   answered; asking a third time is nagging, not coaching. */
function rejectedTwice(id){
  const b = brain(); if(!b) return false;
  return b.decisions.filter(d => d.id === id && d.verdict === "rejected").length >= 2;
}

/* ══════════════ proposals ══════════════
   Each has an id stable across days so the ledger means something, an `apply`
   that performs the edit, and an `undo` where the edit is reversible. */

function adaptiveProposals(opts = {}){
  const m = opts.model || userModel();
  if(!m) return [];
  const out = [];
  const h = H();

  /* --- 1. the board is bigger than the day --- */
  if(m.perf.n >= 25 && m.perf.last14 < 0.5){
    const optional = m.byQuest.filter(q => !q.mand && q.rate < 0.4).slice(0, 3);
    if(optional.length >= 2){
      out.push({
        id:"trim-load",
        severity:"high",
        title:`Pause ${optional.length} quests you are not doing anyway`,
        detail:`${optional.map(q => `"${q.name}"`).join(", ")} — cleared under 40% each. Pausing them is not giving up; it is admitting what the record already shows, so the rest of the board becomes clearable again.`,
        why:`Two-week clear rate is ${mPct(m.perf.last14)}% across ${m.perf.n} scheduled quests. Below roughly 50%, missing becomes the norm and the schedule stops working as a commitment.`,
        effect:`These ${optional.length} quests come off the board. Nothing is deleted — they are kept in Settings and can be switched back on any time.`,
        apply(){
          const ids = optional.map(q => q.id);
          const removed = h.quests.filter(q => ids.includes(q.id));
          h.brain.parked = (h.brain.parked || []).concat(removed);
          h.quests = h.quests.filter(q => !ids.includes(q.id));
          save(); invalidateModel();
          return { parked: removed.length };
        },
      });
    }
  }

  /* --- 2. it has stopped being hard --- */
  if(m.perf.n >= 25 && m.perf.last14 >= 0.92){
    const tier = Number(h.diff || 2);
    if(tier < 3){
      out.push({
        id:"raise-tier",
        severity:"low",
        title:"Raise the training tier",
        detail:`You are clearing ${mPct(m.perf.last14)}% of a board you set when it was harder. Tier ${tier} → ${tier + 1} raises training volume; the quest list itself does not change.`,
        why:`14-day clear rate ${mPct(m.perf.last14)}% over ${m.perf.n} scheduled quests, with a ${h.streak}-day streak behind it. That is the profile of someone who has outgrown the setting.`,
        effect:`Training quests get heavier. Reversible in Settings in one tap.`,
        apply(){ h.diff = String(tier + 1); save(); invalidateModel(); return { tier: tier + 1 }; },
        undo(){ h.diff = String(tier); save(); invalidateModel(); },
      });
    }
  }

  /* --- 3. a quest is at the wrong hour --- */
  if(m.rhythm.bestBand && m.rhythm.worstBand && m.rhythm.bestBand.rate - m.rhythm.worstBand.rate >= 0.2){
    const bad = m.byQuest.find(q =>
      q.rate < 0.5 && q.hour >= m.rhythm.worstBand.from && q.hour <= m.rhythm.worstBand.to);
    if(bad){
      const target = String(Math.max(m.rhythm.bestBand.from, 6)).padStart(2,"0") + ":30";
      out.push({
        id:"move-hour:" + bad.id,
        severity:"medium",
        title:`Move "${bad.name}" into your strongest hours`,
        detail:`It currently sits ${m.rhythm.worstBand.lab}, where you clear ${mPct(m.rhythm.worstBand.rate)}%. ${m.rhythm.bestBand.lab} you clear ${mPct(m.rhythm.bestBand.rate)}%. Proposed new time: ${fmt12(target)}.`,
        why:`"${bad.name}" cleared ${bad.hit} of ${bad.n} attempts, and the band it sits in is your weakest by ${mPct(m.rhythm.bestBand.rate - m.rhythm.worstBand.rate)} points.`,
        effect:`The quest's time changes. Everything else about it stays.`,
        apply(){
          const q = h.quests.find(x => x.id === bad.id); if(!q) return null;
          const was = q.time; q.time = target; save(); invalidateModel();
          return { from:was, to:target };
        },
      });
    }
  }

  /* --- 4. a mandatory quest that is never cleared is a lie on the board --- */
  const brokenMandatory = m.byQuest.find(q => q.mand && q.n >= 6 && q.rate <= 0.35);
  if(brokenMandatory){
    out.push({
      id:"demote:" + brokenMandatory.id,
      severity:"medium",
      title:`Make "${brokenMandatory.name}" optional instead of mandatory`,
      detail:`Cleared ${brokenMandatory.hit} of ${brokenMandatory.n} times. Marked mandatory, it generates a penalty most weeks, and a penalty you expect stops working as one.`,
      why:`Mandatory quests carry penalties and break streaks. A mandatory quest under 35% is not holding a standard, it is manufacturing failure.`,
      effect:`It stays on the board and still pays XP. It stops issuing penalties and stops breaking the streak.`,
      apply(){
        const q = h.quests.find(x => x.id === brokenMandatory.id); if(!q) return null;
        q.mand = false; save(); invalidateModel(); return { id:q.id };
      },
      undo(){ const q = h.quests.find(x => x.id === brokenMandatory.id); if(q){ q.mand = true; save(); } },
    });
  }

  /* --- 5. deadline pressure wants the board thinner this week --- */
  if(m.clustered){
    out.push({
      id:"deadline-focus",
      severity:"high",
      title:"Thin the board until the deadlines pass",
      detail:`${m.within7.length} deadlines inside seven days. Optional quests can wait ${m.within7[m.within7.length-1].in} days; deadlines cannot.`,
      why:`Deadlines within 7 days: ${m.within7.map(d => `${d.name} (${d.in}d)`).join(", ")}.`,
      effect:`Starts a ${Math.max(3, m.within7[m.within7.length-1].in)}-day focus window: optional quests are hidden and penalties pause. Mandatory quests are untouched.`,
      apply(){ return startRecovery(Math.max(3, m.within7[m.within7.length-1].in), "deadline"); },
    });
  }

  return out.filter(p => !isSnoozed(p.id) && !rejectedTwice(p.id));
}

function acceptProposal(id){
  const p = adaptiveProposals().find(x => x.id === id);
  if(!p) return null;
  const res = p.apply ? p.apply() : null;
  recordDecision(id, "accepted");
  return res;
}
function rejectProposal(id, note){ recordDecision(id, "rejected", note); }

/* ══════════════ recovery (§10) ══════════════
   Recovery > punishment. Three missed days should not cost three months. */

function missedRun(){
  const h = H(); if(!h) return 0;
  let run = 0;
  for(let i = 1; i <= 14; i++){
    const d = new Date(); d.setDate(d.getDate() - i);
    const key = todayKey(d);
    const due = questsFor(d);
    if(!due.length) continue;
    const doneSet = h.done[key] || {};
    const rate = due.filter(q => doneSet[q.id]).length / due.length;
    if(rate < 0.25) run++; else break;
  }
  return run;
}

function recoveryState(){
  const b = brain(); if(!b) return { active:false, suggest:false, missed:0 };
  const r = b.recovery;
  const active = !!r && todayKey() <= r.until;
  if(r && !active){ b.recovery = null; save(); }
  const missed = missedRun();
  return {
    active,
    plan: active ? r : null,
    daysLeft: active ? Math.max(0, Math.round((new Date(r.until+"T00:00:00") - new Date(todayKey()+"T00:00:00")) / 86400000)) : 0,
    missed,
    suggest: !active && missed >= 2,
  };
}

/* The reduced board: mandatory quests only, capped at three, cheapest first.
   The point is a day that can be finished, not a day that looks productive. */
function recoveryQuests(){
  const h = H(); if(!h) return [];
  const due = questsFor();
  const mand = due.filter(q => q.mand);
  const pool = (mand.length ? mand : due).slice();
  pool.sort((a,b) => (a.xp || 0) - (b.xp || 0));
  return pool.slice(0, 3);
}

function startRecovery(days = 3, reason = "missed"){
  const b = brain(); if(!b) return null;
  const d = new Date(); d.setDate(d.getDate() + Math.max(1, days));
  b.recovery = {
    from: todayKey(), until: todayKey(d), reason,
    keep: recoveryQuests().map(q => q.id),
  };
  save(); invalidateModel();
  return b.recovery;
}
function endRecovery(){ const b = brain(); if(b){ b.recovery = null; save(); invalidateModel(); } }

/* Penalties are suspended while recovering. Wrapping rather than editing
   penalty.js keeps that file exactly as v12 wrote it, and makes the suspension a
   single obvious line rather than a condition buried in the penalty logic. */
Hooks.wrap("issuePenalty", "recovery suspension", function(next, reason){
  const st = recoveryState();
  if(st.active){
    if(typeof toast === "function") toast("Penalty suspended", `Recovery runs for ${st.daysLeft} more day${st.daysLeft===1?"":"s"}. Missing is expected right now — that is the point of it.`, "gold");
    return;
  }
  return next(reason);
});
