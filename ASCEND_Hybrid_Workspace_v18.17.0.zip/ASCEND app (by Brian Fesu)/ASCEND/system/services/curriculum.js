/* THE SYSTEM v14 — services/curriculum.js
   The Academy's spine: what you are studying, broken down, and how much of it you
   can actually do.

   Phase 5 §4 asks for a hierarchy that survives contact with different education
   systems, so it is deliberately shallow and generic:

     Qualification → Subject → Unit → Topic

   IGCSE calls them papers and topics, WASSCE calls them sections, a university
   course calls them modules and lectures. Naming the middle layer "Unit" and not
   hard-coding a board is what lets one model serve all of them. Subtopics and
   learning objectives from §4 are represented as topics under their own unit
   rather than as a fifth level — a five-deep tree is a data model that looks
   thorough on paper and that nobody ever finishes filling in.

   §8 and §9 are the important part of this file, and they are where most study
   apps quietly cheat: mastery must come from evidence, and "I read it" is not the
   same claim as "I can do it". */
"use strict";

/* ---------- syllabus states (§5) ---------- */
const TOPIC_STATES = [
  { k:"new",      label:"Not started", pct:0,    blurb:"Nothing recorded yet." },
  { k:"learning", label:"Learning",    pct:0.25, blurb:"You have studied it. That is not the same as knowing it." },
  { k:"practice", label:"Practising",  pct:0.5,  blurb:"You are attempting questions and getting some wrong. This is the useful part." },
  { k:"review",   label:"Reviewing",   pct:0.75, blurb:"Accurate under practice. Now it has to survive a gap." },
  { k:"mastered", label:"Mastered",    pct:1,    blurb:"Accurate, and still accurate after time away." },
];
const TOPIC_STATE = Object.fromEntries(TOPIC_STATES.map(s => [s.k, s]));

/* ---------- storage ---------- */
function academy(){
  const h = H(); if(!h) return null;
  if(!h.academy) h.academy = {
    qualification:"", subjects:[], questions:[], cards:[], errors:[], sessions:[], exams:[], grades:[],
  };
  const a = h.academy;
  for(const k of ["subjects","questions","cards","errors","sessions","exams","grades"]){
    if(!Array.isArray(a[k])) a[k] = [];
  }
  return a;
}
const subjects   = () => academy() ? academy().subjects : [];
const getSubject = id => subjects().find(s => s.id === id) || null;

function allTopics(subjectId){
  const out = [];
  for(const s of subjects()){
    if(subjectId && s.id !== subjectId) continue;
    for(const u of s.units || []) for(const t of u.topics || []) out.push({ ...t, unit:u, subject:s });
  }
  return out;
}
function getTopic(id){ return allTopics().find(t => t.id === id) || null; }

/* ---------- building a curriculum ---------- */
function addSubject({ name, qualification = "", target = "", examDate = null }){
  const a = academy(); if(!a) return null;
  const s = {
    id: uid(), name: String(name || "").slice(0, 60).trim(),
    qualification: qualification || a.qualification || "",
    target: String(target || "").slice(0, 12),
    examDate: examDate || null,
    units: [], created: todayKey(),
  };
  if(!s.name) return null;
  a.subjects.push(s); save(); invalidateAcademy();
  return s;
}
function addUnit(subjectId, name){
  const s = getSubject(subjectId); if(!s) return null;
  const u = { id: uid(), name: String(name || "").slice(0, 80).trim(), topics: [] };
  if(!u.name) return null;
  s.units.push(u); save(); invalidateAcademy();
  return u;
}
function addTopic(subjectId, unitId, name){
  const s = getSubject(subjectId); if(!s) return null;
  const u = (s.units || []).find(x => x.id === unitId); if(!u) return null;
  const t = {
    id: uid(), name: String(name || "").slice(0, 100).trim(),
    /* the evidence record. Every field is something that happened, with a date. */
    ev: { studied:0, lastStudied:null, attempts:0, correct:0, hardCorrect:0,
          recalls:0, recallHits:0, lastReview:null, reviewGap:0, confidence:null },
  };
  if(!t.name) return null;
  u.topics.push(t); save(); invalidateAcademy();
  return t;
}
function removeTopic(topicId){
  for(const s of subjects()) for(const u of s.units || []){
    const i = (u.topics || []).findIndex(t => t.id === topicId);
    if(i >= 0){ u.topics.splice(i, 1); save(); invalidateAcademy(); return true; }
  }
  return false;
}
function removeSubject(id){
  const a = academy(); if(!a) return false;
  a.subjects = a.subjects.filter(s => s.id !== id);
  a.exams = a.exams.filter(e => e.subjectId !== id);
  save(); invalidateAcademy(); return true;
}

/* Bulk entry — a student typing a syllabus in should not do it one topic at a
   time. Accepts indented text: unindented lines are units, indented are topics. */
function importOutline(subjectId, text){
  const s = getSubject(subjectId); if(!s) return null;
  const lines = String(text || "").split("\n").map(l => l.replace(/\s+$/, "")).filter(l => l.trim());
  let unit = null, units = 0, topics = 0;
  for(const line of lines){
    /* A topic line is one that is indented at all, or bulleted. The first version
       demanded two spaces OR a leading bullet, which meant the single most common
       way a student writes an outline — one space then a dash — matched neither
       and every topic silently became a unit. */
    const indented = /^(\s+|[-*•])/.test(line);
    const name = line.replace(/^[\s\-*•\d.)]+/, "").trim();
    if(!name) continue;
    if(!indented || !unit){
      unit = addUnit(subjectId, name); if(unit) units++;
    } else {
      if(addTopic(subjectId, unit.id, name)) topics++;
    }
  }
  return { units, topics };
}

/* ══════════════ mastery (§8, §9) ══════════════
   The three claims §9 insists on separating, and what counts as evidence for each:

     studied   — you opened it and marked it studied. Self-reported, weakest.
     recalled  — you retrieved it correctly after a gap. Flashcards prove this.
     applied   — you answered questions on it correctly, including harder ones.

   A topic cannot become mastered on the first two. Reading something ten times
   produces a confident feeling and no ability, and an app that rewards the feeling
   is actively harmful to a student two weeks from an exam. */
function knowledgeStates(t){
  const e = t.ev || {};
  const acc = e.attempts ? e.correct / e.attempts : 0;
  return {
    studied:  !!e.studied,
    recalled: e.recalls >= 3 && (e.recallHits / Math.max(1, e.recalls)) >= 0.7,
    applied:  e.attempts >= 5 && acc >= 0.7 && e.hardCorrect >= 1,
  };
}

function masteryOf(topic){
  const t = typeof topic === "string" ? getTopic(topic) : topic;
  if(!t) return null;
  const e = t.ev || {};
  const k = knowledgeStates(t);
  const acc = e.attempts ? e.correct / e.attempts : 0;
  const why = [];

  let pct = 0, state = "new";

  if(k.studied){ state = "learning"; pct = 0.25; why.push("marked as studied"); }
  if(e.attempts >= 3){
    state = "practice";
    /* accuracy carries the middle of the range, capped until there is enough of it */
    const conf = Math.min(1, e.attempts / 10);
    pct = Math.max(pct, 0.25 + 0.35 * acc * conf);
    why.push(`${e.correct} of ${e.attempts} practice questions correct`);
  }
  if(k.applied){
    state = "review"; pct = Math.max(pct, 0.75);
    why.push("including at least one harder question");
  }
  if(k.applied && k.recalled && e.reviewGap >= 5){
    state = "mastered"; pct = Math.max(pct, 0.9 + Math.min(0.1, e.reviewGap / 200));
    why.push(`still accurate after a ${e.reviewGap}-day gap`);
  }

  /* Decay: a topic mastered in September is not mastered in March unless it has
     been seen since. Nothing is ever pushed below "practice" by time alone —
     forgetting is not the same as never having learnt it. */
  let decayed = false;
  if(e.lastReview){
    const gap = Math.round((new Date(todayKey()+"T00:00:00") - new Date(e.lastReview+"T00:00:00")) / 86400000);
    if(gap > 45 && pct > 0.5){
      pct = Math.max(0.5, pct - Math.min(0.35, (gap - 45) / 180));
      decayed = true;
      why.push(`last reviewed ${gap} days ago`);
    }
  }

  return {
    pct: Math.max(0, Math.min(1, pct)),
    state, label: TOPIC_STATE[state].label,
    states: k, accuracy: acc, attempts: e.attempts || 0, decayed,
    why: why.length ? why.join(" · ") : "no evidence recorded yet",
  };
}

/* Everything the Academy needs about one subject, computed once. */
let _aCache = null, _aAt = 0;
function invalidateAcademy(){ _aCache = null; }
function subjectSummary(id){
  const s = getSubject(id); if(!s) return null;
  const topics = allTopics(id);
  const m = topics.map(t => ({ t, m:masteryOf(t) }));
  const avg = m.length ? m.reduce((a,x) => a + x.m.pct, 0) / m.length : 0;
  const counts = {};
  for(const st of TOPIC_STATES) counts[st.k] = m.filter(x => x.m.state === st.k).length;
  const weak = m.filter(x => x.m.pct < 0.5).sort((a,b) => a.m.pct - b.m.pct);
  const exam = (academy().exams || []).filter(e => e.subjectId === id)
    .map(e => ({ ...e, in: Math.round((new Date(e.date+"T00:00:00") - new Date(todayKey()+"T00:00:00"))/86400000) }))
    .filter(e => e.in >= 0).sort((a,b) => a.in - b.in)[0] || null;
  const grades = (academy().grades || []).filter(g => g.subjectId === id)
    .sort((a,b) => String(b.date).localeCompare(String(a.date)));
  return {
    subject:s, topics:m, total:m.length, avg, counts,
    weak: weak.slice(0, 5),
    mastered: counts.mastered, untouched: counts.new,
    exam, grades, latestGrade: grades[0] || null,
  };
}
function academyOverview(force){
  if(!force && _aCache && Date.now() - _aAt < 3000) return _aCache;
  const list = subjects().map(s => subjectSummary(s.id)).filter(Boolean);
  const all = list.reduce((a,s) => a.concat(s.topics), []);
  const out = {
    subjects: list,
    topics: all.length,
    avg: all.length ? all.reduce((a,x) => a + x.m.pct, 0) / all.length : 0,
    mastered: all.filter(x => x.m.state === "mastered").length,
    weak: all.filter(x => x.m.pct < 0.5).sort((a,b) => a.m.pct - b.m.pct).slice(0, 6),
    stale: all.filter(x => x.m.decayed).slice(0, 6),
    nextExam: list.map(s => s.exam).filter(Boolean).sort((a,b) => a.in - b.in)[0] || null,
  };
  _aCache = out; _aAt = Date.now();
  return out;
}

/* ---------- recording evidence ---------- */
function markStudied(topicId, minutes){
  const t = getTopic(topicId); if(!t) return null;
  const real = findTopicRef(topicId); if(!real) return null;
  real.ev.studied++; real.ev.lastStudied = todayKey();
  save(); invalidateAcademy();
  grantXp(BALANCE.xp.focusSession, `Studied — ${real.name}`, { once:"study:" + topicId + ":" + todayKey() });
  return masteryOf(real);
}
/* getTopic returns a flattened copy; writes need the object inside the tree */
function findTopicRef(topicId){
  for(const s of subjects()) for(const u of s.units || []){
    const t = (u.topics || []).find(x => x.id === topicId);
    if(t){ t.ev = t.ev || { studied:0, attempts:0, correct:0, hardCorrect:0, recalls:0, recallHits:0, reviewGap:0 }; return t; }
  }
  return null;
}

/* ---------- subject → skill (§43) ----------
   Configurable rather than hard-coded, because "Physics develops problem solving"
   is a defensible claim and "Physics develops exactly these three v11 skills" is
   not something this file should decide for someone else's curriculum. */
const SUBJECT_SKILL_HINTS = [
  { match:/math|algebra|calculus|statistic/i, skill:"Analytical thinking" },
  { match:/physics|engineer|mechanic/i,       skill:"Problem solving" },
  { match:/chem|biolog|science/i,             skill:"Investigation" },
  { match:/english|literat|language|french|spanish|japanese/i, skill:"Communication" },
  { match:/comput|program|code|ict|software/i,skill:"Computational thinking" },
  { match:/business|econom|account/i,         skill:"Commercial reasoning" },
  { match:/histor|geograph|social|govern/i,   skill:"Source analysis" },
];
function skillFor(subjectName){
  const hit = SUBJECT_SKILL_HINTS.find(h => h.match.test(String(subjectName || "")));
  return hit ? hit.skill : "Study discipline";
}
