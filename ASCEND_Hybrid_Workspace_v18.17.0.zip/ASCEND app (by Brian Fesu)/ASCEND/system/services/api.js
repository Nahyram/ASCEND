/* THE SYSTEM v14 — services/api.js
   One gateway for every external service.

   §24 asks that fetch() stop being scattered through UI files. v13 had four call
   sites in three layers, each with its own idea of what a timeout was. Everything
   external now goes through `Api.call`, which owns timeouts, retries, caching,
   rate limiting and — most importantly — failure isolation (§26, §56): TMDB being
   down must not break the library, and nothing external may take the app with it.

   ## The API key question, answered honestly

   §22 and §32 are blunt: a key in frontend JavaScript is a public key. v13 stored
   the hunter's own TMDB key in their record and called TMDB directly from the
   browser, which is not a leak of *our* secret but is still a key sitting in
   localStorage and travelling in a query string.

   Both options are supported, and the app says which one is in use rather than
   quietly implying safety:

     proxy   — a URL the hunter controls, holding the key server-side. Correct.
     direct  — the hunter's own key from the browser. Works today, and the UI
               states plainly that a browser key should be treated as public and
               scoped to a throwaway account.

   THE SYSTEM ships no key of its own and never will. */
"use strict";

const API_TIMEOUT = 12000;
const API_CACHE_TTL = 1000 * 60 * 60 * 6;      /* §27 — metadata does not change hourly */
const API_RATE = { windowMs: 60000, max: 30 };  /* §28 — one client, sane ceiling */

const _apiCache = new Map();
let _apiHits = [];

/* ---------- service registry (§24) ----------
   Each entry knows how to build a URL and how to normalise a response. Adding a
   source is one object; no UI file learns a new hostname. */
const API_SERVICES = {
  media: {
    label:"Films & series",
    host:"api.themoviedb.org",
    needsKey:true,
    build(path, params, key){
      const qs = new URLSearchParams({ ...params, api_key:key }).toString();
      return `https://api.themoviedb.org/3${path}?${qs}`;
    },
  },
  books: {
    label:"Books",
    host:"openlibrary.org",
    needsKey:false,
    build(path, params){
      return `https://openlibrary.org${path}?${new URLSearchParams(params).toString()}`;
    },
  },
  series: {
    label:"TV",
    host:"api.tvmaze.com",
    needsKey:false,
    build(path, params){ return `https://api.tvmaze.com${path}?${new URLSearchParams(params).toString()}`; },
  },
  anime: {
    label:"Anime",
    host:"api.jikan.moe",
    needsKey:false,
    build(path, params){ return `https://api.jikan.moe/v4${path}?${new URLSearchParams(params).toString()}`; },
  },
  /* v18: the hunter counter. It used to be a bare fetch() in views/access.js
     with no AbortController at all, so a dead endpoint left a promise pending
     until the OS gave up — minutes, on mobile. It is decoration; it had the
     weakest error handling in the app. Now it gets the same timeout, rate limit
     and failure isolation as everything else.

     `dynamic` marks a service whose host is configured by the hunter rather
     than shipped. https is required: the counter posts an install id, and an
     install id over plain http is an install id on the café Wi-Fi. */
  counter: {
    label:"Hunter counter",
    dynamic:true,
    needsKey:false,
    method:"POST",
    build(){
      const url = String((typeof DB !== "undefined" && DB.store && DB.store.countEndpoint) || "").trim();
      return /^https:\/\/.+/.test(url) ? url : null;
    },
  },
};

/* ---------- configuration ---------- */
function apiConfig(patch){
  const h = H(); if(!h) return null;
  if(!h.apiCfg) h.apiCfg = { proxyBase:"", keys:{} };
  if(patch){
    if("proxyBase" in patch) h.apiCfg.proxyBase = String(patch.proxyBase || "").slice(0, 300).trim();
    if(patch.keys) h.apiCfg.keys = { ...h.apiCfg.keys, ...patch.keys };
    save();
  }
  return h.apiCfg;
}
function apiMode(service){
  const cfg = apiConfig();
  if(cfg && cfg.proxyBase) return "proxy";
  const svc = API_SERVICES[service];
  if(svc && svc.needsKey) return (cfg && cfg.keys && cfg.keys[service]) ? "direct" : "unconfigured";
  return "direct";
}
function apiKeyAdvice(service){
  const mode = apiMode(service);
  if(mode === "proxy") return { ok:true, text:"Routed through your own endpoint. The key stays on your server, which is the right arrangement." };
  if(mode === "direct" && API_SERVICES[service] && API_SERVICES[service].needsKey) return {
    ok:true, warn:true,
    text:"Using a key stored in this browser. Anything in a browser is public — use a free key on a throwaway account, and never a key with billing attached. Setting a proxy URL removes the problem entirely.",
  };
  if(mode === "unconfigured") return { ok:false, text:"Not configured. This service is simply unavailable — nothing else is affected." };
  return { ok:true, text:"No key required." };
}

/* ---------- rate limiting (§28) ---------- */
function rateOk(){
  const now = Date.now();
  _apiHits = _apiHits.filter(t => now - t < API_RATE.windowMs);
  return _apiHits.length < API_RATE.max;
}

/* ---------- the gateway ---------- */
const Api = {
  /* Never throws. Every caller gets { ok, data, error, cached, stale } and the UI
     decides what to show — that is what makes §26's "the rest of THE SYSTEM keeps
     working" true rather than aspirational. */
  async call(service, path, params = {}, { ttl = API_CACHE_TTL, allowStale = true, body = null } = {}){
    const svc = API_SERVICES[service];
    if(!svc) return { ok:false, error:"Unknown service" };

    const cfg = apiConfig() || { proxyBase:"", keys:{} };
    const key = (cfg.keys || {})[service] || "";
    const mode = apiMode(service);
    if(mode === "unconfigured"){
      return { ok:false, error:`${svc.label} is not configured.`, unconfigured:true };
    }

    const cacheKey = service + "|" + path + "|" + JSON.stringify(params);
    const hit = _apiCache.get(cacheKey);
    if(hit && Date.now() - hit.at < ttl) return { ok:true, data:hit.data, cached:true };

    if(typeof navigator !== "undefined" && navigator.onLine === false){
      return hit && allowStale
        ? { ok:true, data:hit.data, cached:true, stale:true, error:"Offline — showing what was cached." }
        : { ok:false, error:"Offline.", offline:true };
    }
    if(!rateOk()){
      return hit && allowStale
        ? { ok:true, data:hit.data, cached:true, stale:true }
        : { ok:false, error:"Too many requests in the last minute. Try again shortly.", rateLimited:true };
    }

    const url = (mode === "proxy" && !svc.dynamic)
      ? `${cfg.proxyBase.replace(/\/$/,"")}/${service}${path}?${new URLSearchParams(params).toString()}`
      : svc.build(path, params, key);
    /* A dynamic service with nothing configured is not an error to shout about —
       it is a feature the hunter has not switched on. */
    if(!url) return { ok:false, error:`${svc.label} has no endpoint configured.`, unconfigured:true };

    const ac = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timer = setTimeout(() => ac && ac.abort(), API_TIMEOUT);
    try{
      _apiHits.push(Date.now());
      const method = svc.method || "GET";
      const res = await fetch(url, {
        signal: ac ? ac.signal : undefined,
        method,
        headers: method === "POST"
          ? { "Accept":"application/json", "Content-Type":"application/json" }
          : { "Accept":"application/json" },
        body: method === "POST" ? JSON.stringify(body || {}) : undefined,
      });
      clearTimeout(timer);
      /* §25 — every one of these is a case, not an exception to be swallowed */
      if(res.status === 401 || res.status === 403) return { ok:false, error:`${svc.label} rejected the credentials.`, auth:true };
      if(res.status === 429) return { ok:false, error:`${svc.label} is rate-limiting. Try again in a few minutes.`, rateLimited:true };
      if(res.status >= 500) throw new Error(`${svc.label} is having problems (${res.status})`);
      if(!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      if(data == null || typeof data !== "object") throw new Error("Malformed response");
      _apiCache.set(cacheKey, { at: Date.now(), data });
      while(_apiCache.size > 120) _apiCache.delete(_apiCache.keys().next().value);
      return { ok:true, data };
    }catch(e){
      clearTimeout(timer);
      const msg = e && e.name === "AbortError" ? `${svc.label} did not respond in time.` : (e.message || "Request failed");
      /* stale beats nothing: a film list from this morning is more useful than an
         error, as long as it is labelled */
      if(hit && allowStale) return { ok:true, data:hit.data, cached:true, stale:true, error:msg };
      return { ok:false, error:msg };
    }
  },

  /* §53 — a service-status model the UI can show without leaking infrastructure */
  status(){
    return Object.entries(API_SERVICES).map(([k, s]) => {
      const mode = apiMode(k);
      return {
        key:k, label:s.label, mode,
        state: (mode === "unconfigured" || (s.dynamic && !s.build())) ? "unavailable"
             : (typeof navigator !== "undefined" && navigator.onLine === false) ? "offline"
             : "operational",
        advice: apiKeyAdvice(k),
      };
    });
  },

  clearCache(){ _apiCache.clear(); },
  get cacheSize(){ return _apiCache.size; },
};

/* ---------- named services (§24) ---------- */
const MediaService = {
  discover: (genreIds, page = 1) => Api.call("media", "/discover/movie", {
    with_genres: genreIds, sort_by:"popularity.desc", include_adult:"false", page }),
};
const BookService = {
  subject: (subject, limit = 20) => Api.call("books", `/subjects/${encodeURIComponent(subject)}.json`, { limit }),
};
const SeriesService = { shows: (page = 0) => Api.call("series", "/shows", { page }) };
const AnimeService  = { top: (page = 1) => Api.call("anime", "/top/anime", { page }) };
/* ttl 0: a live count that is six hours stale is a lie with a number on it. */
const CounterService = {
  ping: installId => Api.call("counter", "", {}, { ttl:0, allowStale:false, body:{ id:installId } }),
};
