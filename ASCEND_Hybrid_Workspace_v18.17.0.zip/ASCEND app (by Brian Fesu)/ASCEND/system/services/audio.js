/* THE SYSTEM v13 — services/audio.js
   Extracted verbatim from v12 index.html. Loaded as a classic script; shared global scope. */
/* ---------- feedback: sound, vibration, notification ---------- */
let AC = null;
function ctx(){ if(!AC) AC = new (window.AudioContext||window.webkitAudioContext)(); return AC; }
function beep(freq=520, dur=.5){
  try{
    const c = ctx(), o = c.createOscillator(), g = c.createGain();
    o.type = "triangle"; o.frequency.value = freq;
    o.connect(g); g.connect(c.destination);
    g.gain.setValueAtTime(0, c.currentTime);
    g.gain.linearRampToValueAtTime(.25, c.currentTime+.02);
    g.gain.exponentialRampToValueAtTime(.001, c.currentTime+dur);
    o.start(); o.stop(c.currentTime+dur+.02);
  }catch(e){}
}
const vibrate = p => { try{ navigator.vibrate?.(p); }catch(e){} };
function notify(title, body){
  try{ if("Notification" in window && Notification.permission === "granted") new Notification(title, {body, tag:"system-quest", requireInteraction:true}); }catch(e){}
}

/* ══════════════ v8: focus audio engine — three modes, volume control ══════════════ */
let focusNodes = null, focusMaster = null, focusMode = "deep";
function focVolVal(){ return Number($("#focVol").value)/100 * 0.5; }
function brownBuffer(c){
  const buf = c.createBuffer(1, c.sampleRate*4, c.sampleRate), d = buf.getChannelData(0);
  let last = 0;
  for(let i=0;i<d.length;i++){ const w = Math.random()*2-1; last = (last + .02*w)/1.02; d[i] = last*3.5; }
  return buf;
}
function whiteBuffer(c){
  const buf = c.createBuffer(1, c.sampleRate*4, c.sampleRate), d = buf.getChannelData(0);
  for(let i=0;i<d.length;i++) d[i] = Math.random()*2-1;
  return buf;
}
function stopFocus(){
  if(!focusNodes) return;
  focusNodes.forEach(n=>{try{n.stop?.();}catch(e){} try{n.disconnect?.();}catch(e){}});
  focusNodes = null; focusMaster = null;
  $("#btnFocusTone").textContent = "▶ Start focus audio";
}
function startFocus(){
  stopFocus();
  const c = ctx(), out = c.createGain(); out.gain.value = focVolVal(); out.connect(c.destination);
  const nodes = [out];
  if(focusMode === "deep"){
    // deep drone: brown noise floor + low sine — dense, steady, masks speech
    const s = c.createBufferSource(); s.buffer = brownBuffer(c); s.loop = true;
    const lp = c.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 600;
    const ng = c.createGain(); ng.gain.value = .8;
    s.connect(lp); lp.connect(ng); ng.connect(out);
    const o = c.createOscillator(); o.type = "sine"; o.frequency.value = 55;
    const og = c.createGain(); og.gain.value = .12;
    o.connect(og); og.connect(out);
    s.start(); o.start(); nodes.push(s, lp, ng, o, og);
  } else if(focusMode === "pulse"){
    // pulse 40: 200 Hz left, 240 Hz right — a 40 Hz beat when worn on headphones
    const oL = c.createOscillator(), oR = c.createOscillator();
    oL.type = oR.type = "sine"; oL.frequency.value = 200; oR.frequency.value = 240;
    const pL = c.createStereoPanner(), pR = c.createStereoPanner();
    pL.pan.value = -1; pR.pan.value = 1;
    const g = c.createGain(); g.gain.value = .3;
    oL.connect(pL); oR.connect(pR); pL.connect(g); pR.connect(g); g.connect(out);
    oL.start(); oR.start(); nodes.push(oL, oR, pL, pR, g);
  } else {
    // rainfall: filtered white noise with a slow wandering bandpass
    const s = c.createBufferSource(); s.buffer = whiteBuffer(c); s.loop = true;
    const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 1600; bp.Q.value = .6;
    const lp = c.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 5200;
    const g = c.createGain(); g.gain.value = .5;
    const lfo = c.createOscillator(); lfo.type = "sine"; lfo.frequency.value = .09;
    const lg = c.createGain(); lg.gain.value = 500;
    lfo.connect(lg); lg.connect(bp.frequency);
    s.connect(bp); bp.connect(lp); lp.connect(g); g.connect(out);
    s.start(); lfo.start(); nodes.push(s, bp, lp, g, lfo, lg);
  }
  focusNodes = nodes; focusMaster = out;
  $("#btnFocusTone").textContent = "■ Stop focus audio";
}
$("#btnFocusTone").onclick = () => { try{ focusNodes ? stopFocus() : startFocus(); }catch(e){ toast("No audio","This browser has no audio engine. The session still works without it.","blood"); } };
$$("#focusModes .chip").forEach(b => b.onclick = () => {
  $$("#focusModes .chip").forEach(x=>x.classList.remove("on")); b.classList.add("on");
  focusMode = b.dataset.fm;
  if(focusNodes) startFocus(); // hot-swap
});
$("#focVol").oninput = () => {
  $("#focVolRead").textContent = $("#focVol").value;
  if(focusMaster) focusMaster.gain.value = focVolVal();
};

/* ══════════════ v8: focus session — the Enforcer ══════════════ */
let sess = null, sessMin = 25;
$$("#sessLen .chip").forEach(b => b.onclick = () => {
  $$("#sessLen .chip").forEach(x=>x.classList.remove("on")); b.classList.add("on");
  sessMin = Number(b.dataset.min);
});
function sessTick(){
  if(!sess) return;
  const left = Math.max(0, Math.round((sess.until - Date.now())/1000));
  $("#sessRead").textContent = `${pad(Math.floor(left/60))}:${pad(left%60)}`;
  document.title = left ? `⚔ ${pad(Math.floor(left/60))}:${pad(left%60)} — THE SYSTEM` : "THE SYSTEM";
  if(left <= 0) endSession(true);
}
function beginSession(){
  const h = H();
  h.blocklist = $("#sessBlock").value.slice(0, 2000); save();
  sess = { until: Date.now() + sessMin*60000, min: sessMin, breaches: 0, t: setInterval(sessTick, 500) };
  $("#sessState").textContent = "SESSION LIVE — LEAVING IS RECORDED";
  $("#sessState").className = "sess-state live";
  $("#btnSession").textContent = "Surrender session";
  document.documentElement.requestFullscreen?.().catch(()=>{});
  try{ if(!focusNodes) startFocus(); }catch(e){}
  toast("Session live", `${sessMin} minutes. The blacklist is in effect. The System is watching the door.`, "gold");
  sessTick();
}
function endSession(complete){
  if(!sess) return;
  clearInterval(sess.t);
  const {min, breaches} = sess; sess = null;
  document.title = "THE SYSTEM";
  document.exitFullscreen?.().catch?.(()=>{});
  $("#sessRead").textContent = "—";
  $("#btnSession").textContent = "Begin Focus Session";
  if(complete){
    const base = Math.round(min/2);
    const earned = Math.max(0, base - breaches*10);
    if(breaches === 0){
      grantStat("discipline", 1); grantXp(base, "Clean focus session", "focus");
      $("#sessState").textContent = "SESSION COMPLETE — CLEAN"; $("#sessState").className = "sess-state live";
      takeover({kind:"levelup", title:"FOCUS HELD", sub:`${min} minutes. Zero breaches. This is what the work looks like.`, reward:`+${base} XP · +DIS`});
    } else {
      if(earned) grantXp(earned, "Focus session (breached)", "focus");
      $("#sessState").textContent = `SESSION COMPLETE — ${breaches} BREACH${breaches>1?"ES":""}`; $("#sessState").className = "sess-state breach";
      takeover({kind:"penalty", penalty:true, title:"SESSION COMPLETE — COMPROMISED",
        sub:`${breaches} breach${breaches>1?"es":""} in ${min} minutes. You left. The record shows it.`,
        reward: earned ? `Reduced reward: +${earned} XP` : "Reward voided."});
    }
  } else {
    $("#sessState").textContent = "SESSION SURRENDERED — NO REWARD"; $("#sessState").className = "sess-state breach";
    toast("Surrendered","You ended it early. The System pays nothing for that.","blood");
  }
}
$("#btnSession").onclick = () => sess ? endSession(false) : beginSession();
document.addEventListener("visibilitychange", () => {
  if(!sess || !document.hidden) return;
  sess.breaches++;
  notify("FOCUS BREACHED", "You left during a live session. It has been recorded.");
});
window.addEventListener("focus", () => {
  if(!sess || !sess.breaches || sess.warned === sess.breaches) return;
  sess.warned = sess.breaches;
  beep(240,.6); vibrate([400,150,400]);
  takeover({kind:"penalty", penalty:true, title:"FOCUS BREACHED",
    sub:`Breach #${sess.breaches}. Whatever you left for was not worth what you are building. Get back in.`,
    reward:"-10 XP from the session reward", actions:[{label:"Back to work", cls:"btn danger", fn: close}]});
});
$("#btnEnforceGuide").onclick = () => $("#enforceGuide").classList.toggle("hidden");

/* ---------- 50/10 pomodoro ---------- */
let pomo = null;
$("#btnPomo").onclick = () => {
  if(pomo){ clearInterval(pomo.t); pomo = null; $("#pomoRead").textContent = ""; $("#btnPomo").textContent = "◷ Start 50/10 Pomodoro"; return; }
  let left = 50*60, phase = "Focus";
  $("#btnPomo").textContent = "■ Stop";
  const t = setInterval(()=>{
    left--;
    $("#pomoRead").textContent = `${phase} — ${pad(Math.floor(left/60))}:${pad(left%60)}`;
    if(left <= 0){
      beep(phase==="Focus"?740:520,.8); vibrate([200,100,200]);
      if(phase === "Focus"){ phase = "Break"; left = 10*60; notify("Break","10 minutes. Move, drink water, look away from the screen."); }
      else { phase = "Focus"; left = 50*60; notify("Focus","50 minutes. Back in."); }
    }
  },1000);
  pomo = {t};
};

