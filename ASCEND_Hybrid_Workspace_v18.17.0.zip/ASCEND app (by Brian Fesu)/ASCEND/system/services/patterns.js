/* THE SYSTEM v14 — services/patterns.js
   The pattern engine. It looks for repeatable structure in the record and refuses
   to report anything it cannot back with a sample size and an effect size.

   Every detector returns the same shape:

     { id, kind, title, detail, effect, n, conf, go }

   `effect` is the size of the difference in the units the detector works in
   (usually a proportion). `conf` comes from confidenceOf(n, effect), so a big gap
   over few observations lands as "early signal", not as fact. The UI prints the
   confidence next to the claim — that is the whole point of the confidence system,
   and hiding it would defeat it.

   Pure functions. No DOM, no writes, no network. */
"use strict";

const PATTERN_KIND = {
  timing:"Timing", reliability:"Reliability", trend:"Trend",
  load:"Workload", deadline:"Deadlines", habit:"Habit", focus:"Focus",
};

/* ---------- individual detectors ----------
   Each takes the model and returns a pattern or null. Returning null is the
   normal outcome: most days, most people have no pattern worth naming. */

const DETECTORS = [

  /* time of day — the single most actionable thing the record can say */
  function bestBand(m){
    const b = m.byBand; if(b.length < 2) return null;
    const top = b[0], bottom = b[b.length - 1];
    const effect = top.rate - bottom.rate;
    if(!significant(top.rate, top.n, bottom.rate, bottom.n, 0.15, zForGroups(b.length))) return null;
    const n = top.n + bottom.n;
    return {
      id:"band", kind:PATTERN_KIND.timing,
      title:`You finish more of what you start ${top.lab}.`,
      detail:`${mPct(top.rate)}% cleared ${top.lab} against ${mPct(bottom.rate)}% ${bottom.lab}, across ${n} scheduled quests. Put the quest you least want to do inside the ${top.lab} block — willpower is cheapest there.`,
      effect, n, conf:confidenceOf(n, effect), go:["insight","in-coach"],
    };
  },

  /* weekday — the pattern people are most surprised by */
  function weakDay(m){
    const d = m.byDay; if(d.length < 4) return null;
    const best = d[0], worst = d[d.length - 1];
    const effect = best.rate - worst.rate;
    if(worst.rate >= 0.7) return null;
    if(!significant(best.rate, best.n, worst.rate, worst.n, 0.2, zForGroups(d.length))) return null;
    const n = best.n + worst.n;
    return {
      id:"weekday", kind:PATTERN_KIND.timing,
      title:`${DAYNAME[worst.dow]} is where the week comes apart.`,
      detail:`${mPct(worst.rate)}% cleared on ${DAYNAME[worst.dow]} against ${mPct(best.rate)}% on ${DAYNAME[best.dow]}. Same board, same person. Move one hard quest off ${DAYNAME[worst.dow]} for two weeks and see whether the number moves with it.`,
      effect, n, conf:confidenceOf(n, effect), go:["set"],
    };
  },

  /* the quest that is quietly dead */
  function deadQuest(m){
    const q = m.byQuest[0]; if(!q || q.rate > 0.5) return null;
    const others = m.rows.filter(r => r.id !== q.id);
    if(others.length >= 20 && !significant(mRate(others), others.length, q.rate, q.n, 0.2, zForGroups(m.byQuest.length))) return null;
    return {
      id:"skipped", kind:PATTERN_KIND.reliability,
      title:`"${q.name}" is on the board but not in your life.`,
      detail:`Cleared ${q.hit} of ${q.n} times it was scheduled. There are only three real explanations: wrong hour, too big for one sitting, or it does not belong on the list. Pick one and change it. Another month of intending to do it will produce the same number.`,
      effect: 1 - q.rate, n:q.n, conf:confidenceOf(q.n, 1 - q.rate), go:["set"],
    };
  },

  /* the quest that has become automatic */
  function anchorQuest(m){
    const q = [...m.byQuest].reverse().find(x => x.rate >= 0.9 && x.n >= 12);
    if(!q) return null;
    /* eight-for-eight happens by luck often enough to be worthless. An anchor has
       to be reliably better than the rest of the board, not just lucky lately. */
    const rest = m.rows.filter(r => r.id !== q.id);
    if(rest.length < 20) return null;
    if(!significant(q.rate, q.n, mRate(rest), rest.length, 0.12, zForGroups(m.byQuest.length))) return null;
    return {
      id:"anchor", kind:PATTERN_KIND.habit,
      title:`"${q.name}" has stopped costing you anything.`,
      detail:`${q.hit} of ${q.n}. That is an anchor habit — the thing the rest of the day can be built around. Schedule anything you struggle with directly after it rather than in an empty slot.`,
      effect:q.rate, n:q.n, conf:confidenceOf(q.n, q.rate - 0.5), go:["quests","q-today"],
    };
  },

  /* category strength, stated once and plainly */
  function strongCategory(m){
    const c = m.byCat[0]; if(!c || c.rate < 0.8) return null;
    /* "you are strong at X" only means something if X beats how you do at
       everything else. Comparing it against an overall rate that already contains
       X is comparing a number with itself and calling the overlap a finding. */
    const rest = m.rows.filter(r => r.cat !== c.cat);
    if(rest.length < 20) return null;
    const restRate = mRate(rest);
    if(!significant(c.rate, c.n, restRate, rest.length, 0.1, zForGroups(m.byCat.length))) return null;
    const CATLAB = { study:"Study", body:"Training", mind:"Deep work", discipline:"Discipline", rest:"Rest" };
    return {
      id:"strength", kind:PATTERN_KIND.habit,
      title:`${CATLAB[c.cat] || c.cat} is holding at ${mPct(c.rate)}%.`,
      detail:`Across ${c.n} scheduled quests. That is no longer luck or motivation, it is a habit with a track record. Protect it before adding anything new next to it.`,
      effect:c.rate - 0.5, n:c.n, conf:confidenceOf(c.n, c.rate - 0.5), go:["insight","in-coach"],
    };
  },

  /* category weakness — the avoided subject */
  function avoidedCategory(m){
    if(m.byCat.length < 2) return null;
    const c = m.byCat[m.byCat.length - 1];
    const top = m.byCat[0];
    const effect = top.rate - c.rate;
    if(c.rate >= 0.55) return null;
    if(!significant(top.rate, top.n, c.rate, c.n, 0.25, zForGroups(m.byCat.length))) return null;
    const CATLAB = { study:"Study", body:"Training", mind:"Deep work", discipline:"Discipline", rest:"Rest" };
    return {
      id:"avoided", kind:PATTERN_KIND.reliability,
      title:`${CATLAB[c.cat] || c.cat} is the category you avoid.`,
      detail:`${mPct(c.rate)}% cleared over ${c.n} scheduled quests, against ${mPct(top.rate)}% for ${CATLAB[top.cat] || top.cat}. Avoidance is usually about the first two minutes, not the hour. Cut the next one in half and put it in your strongest time block.`,
      effect, n:c.n, conf:confidenceOf(c.n, effect), go:["quests","q-today"],
    };
  },

  /* direction of travel */
  function trend(m){
    if(!m.perf.prev7) return null;
    const delta = m.perf.delta;
    const nNow = m.rows.filter(r => keysBack(1,7).includes(r.key)).length;
    const nPrev = m.rows.filter(r => keysBack(8,14).includes(r.key)).length;
    if(!significant(m.perf.last7, nNow, m.perf.prev7, nPrev, 0.15)) return null;
    const up = delta > 0;
    return {
      id:"trend", kind:PATTERN_KIND.trend,
      title: up ? `You are ${mPct(delta)} points up on last week.` : `This week is ${mPct(Math.abs(delta))} points down on last week.`,
      detail: up
        ? `${mPct(m.perf.prev7)}% → ${mPct(m.perf.last7)}%. This is the moment to add one hard thing, not five. Adding five is how last month ended.`
        : `${mPct(m.perf.prev7)}% → ${mPct(m.perf.last7)}%. Something changed — the load, or the life around it. Cutting two optional quests for seven days keeps the streak alive; carrying on as though nothing happened usually does not.`,
      effect:Math.abs(delta), n:m.perf.n, conf:confidenceOf(m.perf.n, Math.abs(delta)), go:["insight","in-coach"],
    };
  },

  /* load, in both directions */
  function loadTooHeavy(m){
    if(!m.perf.n || m.perf.last14 >= 0.45) return null;
    return {
      id:"overload", kind:PATTERN_KIND.load,
      title:`Two-week clear rate is ${mPct(m.perf.last14)}%. The plan is bigger than the day.`,
      detail:`${m.load.perDay} quests a day on average, ${m.load.mandatory} of them mandatory. A schedule you routinely miss teaches you that schedules are optional. Cut it to what you would still do on your worst day, hold that for two weeks, then grow it back.`,
      effect:0.45 - m.perf.last14, n:m.perf.n, conf:confidenceOf(m.perf.n, 0.2), go:["set"],
    };
  },
  function loadTooLight(m){
    if(!m.perf.n || m.perf.last14 < 0.92) return null;
    return {
      id:"underload", kind:PATTERN_KIND.load,
      title:`${mPct(m.perf.last14)}% over two weeks. This has stopped being hard.`,
      detail:`Comfort is where progress sits down. Raise the training tier, or add one quest with real weight — not three small ones, which is how the board gets crowded without getting heavier.`,
      effect:m.perf.last14 - 0.92, n:m.perf.n, conf:confidenceOf(m.perf.n, 0.2), go:["grow","tr-quest"],
    };
  },

  /* deadline clustering — Phase 3 §18 */
  function deadlineCluster(m){
    if(!m.clustered) return null;
    const soon = m.within7;
    const heaviest = [...soon].sort((a,b) => Number(b.weight||1) - Number(a.weight||1))[0];
    return {
      id:"cluster", kind:PATTERN_KIND.deadline,
      title:`${soon.length} deadlines land inside seven days.`,
      detail:`${soon.map(d => `${d.name} (${d.in === 0 ? "today" : d.in + "d"})`).join(" · ")}. Start with "${heaviest.name}" — it carries the most weight, so it is the one that cannot be recovered by a late night. Order matters more than effort in a week like this.`,
      effect:soon.length / 7, n:soon.length, conf:confidenceOf(40, 0.3), go:["quests","q-timed"],
    };
  },
  function deadlineImminent(m){
    const d = m.deadlines[0]; if(!d || d.in > 2) return null;
    if(m.clustered) return null;   /* the cluster note already covers it */
    return {
      id:"deadline", kind:PATTERN_KIND.deadline,
      title:`"${d.name}" is due ${d.in === 0 ? "today" : d.in === 1 ? "tomorrow" : "in two days"}.`,
      detail:`Everything else on the board is negotiable this week. This is not.`,
      effect:1, n:1, conf:{ level:"high", label:"stated, not inferred", n:1 }, go:["quests","q-timed"],
    };
  },

  /* streak fragility — how the misses are distributed, not how many */
  function fragileStreak(m){
    const rows = m.rows; if(rows.length < 40) return null;
    const byKey = {};
    for(const r of rows){ (byKey[r.key] = byKey[r.key] || { n:0, hit:0 }); byKey[r.key].n++; if(r.done) byKey[r.key].hit++; }
    /* A day with one quest on it is not evidence of a collapse — a single missed
       weekend alarm would otherwise read as the day falling apart. Three or more. */
    const days = Object.entries(byKey).sort((a,b) => a[0].localeCompare(b[0]))
      .filter(([,v]) => v.n >= 3).map(([,v]) => v.hit / v.n);
    if(days.length < 14) return null;
    const zeroish = days.filter(x => x < 0.25).length;
    const good = days.filter(x => x >= 0.75).length;
    if(zeroish < 3 || good < days.length * 0.5) return null;
    return {
      id:"fragile", kind:PATTERN_KIND.trend,
      title:`You are not inconsistent — you collapse.`,
      detail:`${good} of ${days.length} days ran at 75% or better, but ${zeroish} days came in under 25%. That is a different problem from being unreliable, and it has a different fix: a floor. Decide the two quests you clear even on a written-off day, and let the rest go on those days without calling it a failure.`,
      effect:zeroish / days.length, n:days.length, conf:confidenceOf(days.length * 3, 0.25), go:["insight","in-coach"],
    };
  },

  /* self-reported focus against actual clearing */
  function focusSignal(m){
    const h = H(); if(!h || !h.focusLog) return null;
    const entries = Object.entries(h.focusLog);
    if(entries.length < 10) return null;
    const byKey = {};
    for(const r of m.rows){ (byKey[r.key] = byKey[r.key] || { n:0, hit:0 }); byKey[r.key].n++; if(r.done) byKey[r.key].hit++; }
    const hi = [], lo = [];
    for(const [k,v] of entries){
      const d = byKey[k]; if(!d) continue;
      (v >= 4 ? hi : v <= 2 ? lo : []).push(d.hit / d.n);
    }
    if(hi.length < 4 || lo.length < 4) return null;
    const avg = a => a.reduce((x,y)=>x+y,0) / a.length;
    const effect = avg(hi) - avg(lo);
    if(!significant(avg(hi), hi.length * 3, avg(lo), lo.length * 3, 0.15)) return null;
    return {
      id:"focusfit", kind:PATTERN_KIND.focus,
      title: effect > 0
        ? `Your focus rating predicts your day.`
        : `Your focus rating and your day disagree.`,
      detail: effect > 0
        ? `Days you called a 4 or 5 cleared ${mPct(avg(hi))}%; days you called a 1 or 2 cleared ${mPct(avg(lo))}%. So the morning rating is worth trusting — on a low day, plan review and admin, not new material.`
        : `Days you rated low cleared ${mPct(avg(lo))}%, days you rated high cleared ${mPct(avg(hi))}%. Your read on your own state is not tracking the outcome, which usually means the rating is measuring mood rather than capacity. Start anyway on low days; the record says you deliver.`,
      effect:Math.abs(effect), n:hi.length + lo.length, conf:confidenceOf((hi.length + lo.length) * 3, Math.abs(effect)), go:["home"],
    };
  },

  /* goals that were made and then abandoned */
  function stalledGoal(m){
    const g = m.goals.find(x => x.steps >= 3 && x.pct < 0.34 && x.done === 0);
    if(!g) return null;
    return {
      id:"stalled", kind:PATTERN_KIND.reliability,
      title:`"${g.name}" has ${g.steps} steps and none of them done.`,
      detail:`A goal with no cleared step is not a goal yet, it is a wish with formatting. Do the smallest step on the list today, even badly. ${g.nextStep ? `Start with: ${g.nextStep.text}` : ""}`,
      effect:1, n:g.steps, conf:confidenceOf(30, 0.4), go:["quests","q-goals"],
    };
  },
];

/* ---------- the action each pattern implies ----------
   The weekly review used to derive its "one change" by taking the last sentence
   of a pattern's detail text. That produced fragments like "This is not." — a
   grammatically valid sentence carrying none of the meaning. A pattern should
   state its own implied action rather than leaving a consumer to guess at one
   from prose written for a different purpose. */
const PATTERN_ACTION = {
  band:      m => `Move your hardest quest into the ${m && m.rhythm.bestBand ? m.rhythm.bestBand.lab : "block you clear most"} block for two weeks.`,
  weekday:   m => `Take one hard quest off ${m && m.rhythm.worstDay ? DAYNAME[m.rhythm.worstDay.dow] : "your weakest day"} and see whether the number moves.`,
  skipped:   () => `Pick your least-cleared quest and change one thing about it — its hour, its size, or whether it belongs on the board at all.`,
  anchor:    () => `Schedule something you struggle with directly after your most reliable quest, rather than in an empty slot.`,
  strength:  () => `Protect what is already working before adding anything new beside it.`,
  avoided:   () => `Cut the next quest in your weakest category in half and put it in your strongest hours.`,
  trend:     m => (m && m.perf.delta < 0)
                ? `Drop two optional quests for seven days. Keeping the streak alive beats keeping the plan intact.`
                : `Add one quest with real weight this week — one, not five.`,
  overload:  () => `Cut the board to what you would still clear on your worst day, hold it two weeks, then grow it back.`,
  underload: () => `Raise the training tier or add one heavier quest. This has stopped costing you anything.`,
  cluster:   () => `Order this week's deadlines by weight and start with the heaviest, not the nearest.`,
  deadline:  () => `Clear the deadline first. Everything else on the board can move; it cannot.`,
  fragile:   () => `Decide the two quests you clear even on a written-off day, and let the rest go guilt-free on those days.`,
  focusfit:  () => `Use your morning focus rating to choose the kind of work, not whether to work.`,
  stalled:   () => `Do the smallest step on your stalled goal today, badly if necessary.`,
};

/* ---------- the engine ---------- */
function detectPatterns(opts = {}){
  const m = opts.model || userModel();
  if(!m) return [];
  const min = opts.minConfidence || "low";
  const floor = { low:0, medium:1, high:2 }[min] ?? 0;

  const out = [];
  for(const fn of DETECTORS){
    let p = null;
    try{ p = fn(m); }catch(e){ p = null; }     /* one bad detector must not kill the page */
    if(p && confRank(p.conf) >= floor){
      const act = PATTERN_ACTION[p.id] || PATTERN_ACTION[String(p.id).split(":")[0]];
      p.action = act ? act(m) : null;
      out.push(p);
    }
  }
  /* strongest evidence first, then biggest effect */
  out.sort((a,b) => confRank(b.conf) - confRank(a.conf) || b.effect - a.effect);
  return opts.max ? out.slice(0, opts.max) : out;
}

/* Does the engine have enough to say anything at all? Used by the UI to show an
   honest "still reading you" state rather than an empty panel. */
function patternReadiness(){
  const m = userModel(); if(!m) return { ready:false, need:20, have:0 };
  return { ready:m.meta.sample >= 20, have:m.meta.sample, need:20, conf:m.meta.conf };
}
