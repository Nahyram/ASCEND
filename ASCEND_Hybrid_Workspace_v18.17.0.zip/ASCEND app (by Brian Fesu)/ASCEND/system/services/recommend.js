/* ASCEND — services/recommend.js
   What to do next, ranked, with the reason attached.

   Phase 3 §22 is the rule this file is built around: every recommendation explains
   itself. Not "recommended for you" — the actual sentence, naming the actual
   numbers. A student who can see why a suggestion appeared can tell when it is
   wrong, and being told when it is wrong is how the ranking gets better.

   §19 is the other rule: the system does not measure energy. It asks for a 1–5
   focus rating and uses that to decide what *kind* of work to put first. On a 2,
   it stops recommending new material and starts recommending review. It never
   tells anyone how they feel.

   Ordering is deterministic. Hard constraints (a deadline tomorrow, an overdue
   mandatory quest) always outrank soft ones (interest, streak, a goal that is
   drifting), because §15 of Phase 10 makes the same point in a different context:
   an interest score must never override a hard requirement. */
"use strict";

const TIER = { HIGH:"high", MED:"medium", OPT:"optional" };
const TIER_LABEL = { high:"Do first", medium:"Then this", optional:"If there is room" };

/* what kind of work suits a self-reported focus level */
const FOCUS_FIT = {
  1: { label:"low",      prefer:["rest","discipline"],        avoid:["study","mind"], advice:"Review and admin only. Starting something new today will cost more than it returns." },
  2: { label:"low",      prefer:["rest","discipline","body"], avoid:["mind"],         advice:"Revisit what you already know rather than opening new material." },
  3: { label:"ordinary", prefer:["study","discipline","body"],avoid:[],               advice:"Normal load. Take the list in order." },
  4: { label:"high",     prefer:["study","mind"],             avoid:[],               advice:"Put the hardest thing first while it is cheap." },
  5: { label:"high",     prefer:["mind","study"],             avoid:[],               advice:"Deep work. Protect a long block and do not spend it on small tasks." },
};

function recommendations(opts = {}){
  const m = opts.model || userModel();
  if(!m) return [];
  const h = H();
  const now = typeof nowMin === "function" ? nowMin() : new Date().getHours()*60 + new Date().getMinutes();
  const rec = recoveryState();
  const focus = m.focus.today;
  const fit = FOCUS_FIT[focus] || null;
  const out = [];

  const push = (tier, o) => out.push({ tier, ...o });

  /* ---------- recovery overrides the ordinary ranking entirely ---------- */
  if(rec.active){
    const keep = recoveryQuests().filter(q => !isDone(q));
    if(keep.length){
      push(TIER.HIGH, {
        id:"recovery",
        title: keep[0].name,
        action:"Clear it",
        minutes:null,
        because:`Recovery mode, ${rec.daysLeft} day${rec.daysLeft===1?"":"s"} left. The board is deliberately down to ${keep.length} quest${keep.length===1?"":"s"} so the day is finishable. Everything else can wait without costing you anything.`,
        go:["quests","q-today"], quest:keep[0],
      });
    }
  }

  /* ---------- hard constraint: deadlines ---------- */
  for(const d of m.deadlines.filter(x => x.in <= 3).slice(0, 2)){
    push(d.in <= 1 ? TIER.HIGH : TIER.MED, {
      id:"deadline:" + d.id,
      title: d.name,
      action:"Open deadlines",
      because: d.in === 0
        ? `Due today, weight ${d.weight || 1} of 3. A deadline is the one thing on this list that cannot be moved to tomorrow, so it outranks every quest below it regardless of how you feel about it.`
        : `Due in ${d.in} day${d.in===1?"":"s"}, weight ${d.weight || 1} of 3. Deadlines are hard constraints — they are ranked above interest and above the streak, because missing one costs something the board cannot give back.${m.clustered ? ` It is also one of ${m.within7.length} landing this week, so the order matters more than the hours.` : ""}`,
      go:["quests","q-timed"],
    });
  }

  /* ---------- hard constraint: overdue mandatory quests ---------- */
  const open = questsFor().filter(q => !isDone(q));
  const overdueMand = open.filter(q => q.mand && toMin(q.time) < now);
  if(overdueMand.length && !rec.active){
    const q = overdueMand[0];
    const stat = m.byQuest.find(x => x.id === q.id);
    push(TIER.HIGH, {
      id:"overdue:" + q.id,
      title: q.name,
      action:"Clear it",
      because:`Mandatory, scheduled for ${fmt12(q.time)}, ${Math.round((now - toMin(q.time))/60*10)/10} hours ago. Missing it issues a penalty at rollover and ends a ${h.streak}-day streak.${stat && stat.rate < 0.6 ? ` You clear this one ${mPct(stat.rate)}% of the time — it is a repeat offender, not a one-off.` : ""}`,
      go:["quests","q-today"], quest:q,
    });
  }

  /* ---------- the next quest, chosen with the focus rating in mind ---------- */
  if(!rec.active && open.length){
    const upcoming = open.filter(q => toMin(q.time) >= now);
    let pick = null, reason = "";
    if(fit && fit.prefer.length){
      pick = upcoming.find(q => fit.prefer.includes(q.cat));
      if(pick) reason = `You rated focus ${focus}/5 today. ${fit.advice} "${pick.name}" is ${pick.cat} work, which fits that.`;
    }
    if(!pick){
      pick = upcoming.find(q => q.mand) || upcoming[0] || open[0];
      const band = m.rhythm.bestBand;
      /* v18.1: this branch used to be able to produce "Next on the board at
         7:00 AM." — twenty-eight characters, and the only explanation in this
         file that explains nothing. The extra clause was appended ONLY when the
         quest happened to sit inside the strongest block, so any student whose
         next quest falls outside their best hours got the bare sentence. It
         surfaced as a timezone-dependent test failure because the fixture's
         pick changes with the clock, but the defect has nothing to do with
         timezones: it is a missing else. Explainable recommendations are this
         product's stated promise, so every branch now says why.

         Ranked by what the record can actually support: inside the best block,
         a known-unreliable quest, a mandatory one, then position on the board. */
      if(pick){
        const stat = m.byQuest.find(x => x.id === pick.id);
        const inBand = band && pick.hour >= band.from && pick.hour <= band.to;
        const head = `Next on the board at ${fmt12(pick.time)}${pick.mand ? ", mandatory" : ""}.`;
        let why;
        if(inBand){
          why = ` It sits inside your strongest block — you clear ${mPct(band.rate)}% ${band.lab}, so this is the cheapest one on the list to actually finish.`;
        } else if(stat && stat.rate < 0.6){
          why = ` You clear this one ${mPct(stat.rate)}% of the time, which makes it the weakest link on today's board rather than the easiest win.`;
        } else if(pick.mand){
          why = ` Mandatory quests issue a penalty at rollover, so this one has a cost attached that the rest of the board does not.`;
        } else {
          why = ` Nothing on the board is overdue and no deadline is close, so the ranking falls back to what comes next in the day — clear it in order and the rest stays finishable.`;
        }
        reason = head + why;
      } else {
        reason = "";
      }
    }
    if(pick && !overdueMand.length){
      push(pick.mand ? TIER.HIGH : TIER.MED, {
        id:"next:" + pick.id, title:pick.name, action:"Clear it",
        because:reason, go:["quests","q-today"], quest:pick,
      });
    }
  }

  /* ══════════════ v18: the Learning Engine, which this file could not see ══════════════
     The audit found 182 lines here with no reference to mastery, errors, exams or
     projects. The Academy could record six wrong answers on one topic and drop it
     to 25% mastery without a single recommendation changing. "Learning
     recommendations must prioritize demonstrated weakness rather than simply
     showing content" was true inside academy.js and invisible everywhere else.

     These sit below hard constraints and above interest, deliberately. A topic
     you keep failing is more important than a preference and less important than
     a deadline that lands tomorrow. */

  /* --- a topic with repeated unresolved errors: the strongest learning signal --- */
  if(!rec.active && typeof recoveryCandidates === "function"){
    let stuck = [];
    try{ stuck = recoveryCandidates(); }catch(e){ stuck = []; }
    const worst = stuck[0];
    if(worst && worst.topic){
      const pct = Math.round((worst.mastery && worst.mastery.pct || 0) * 100);
      push(TIER.HIGH, {
        id:"errors:" + worst.topic.id,
        title: worst.topic.name,
        action:"Practise this topic",
        because:`${worst.errors} unresolved mistakes on this one topic, and mastery is ${pct}%. Repeated errors on the same topic are the clearest signal in your whole record — they are the one thing that does not fix itself by moving on to the next chapter.`,
        go:["academy","ac-practice"], topicId: worst.topic.id,
      });
    }
  }

  /* --- an exam close enough to change what tonight is for --- */
  if(typeof academyOverview === "function"){
    let ov = null;
    try{ ov = academyOverview(); }catch(e){}
    if(ov && ov.nextExam && ov.nextExam.in <= 21){
      const weak = (ov.weak || [])[0];
      push(ov.nextExam.in <= 7 ? TIER.HIGH : TIER.MED, {
        id:"exam:" + (ov.nextExam.id || ov.nextExam.date),
        title: weak && weak.t ? weak.t.name : (ov.nextExam.name || "Revision"),
        action:"Open the revision plan",
        because: weak && weak.t
          ? `${ov.nextExam.name || "An exam"} is ${ov.nextExam.in} day${ov.nextExam.in === 1 ? "" : "s"} away and "${weak.t.name}" is your weakest topic at ${Math.round(weak.m.pct * 100)}%. With a fixed date and limited hours, the order matters more than the total — weakest first is worth more marks than another pass over what you already know.`
          : `${ov.nextExam.name || "An exam"} is ${ov.nextExam.in} day${ov.nextExam.in === 1 ? "" : "s"} away. Add topics to the subject so the plan has something to rank.`,
        go:["academy","ac-exams"],
      });
    }
    /* --- mastery that has decayed: known once, unverified since --- */
    if(ov && (ov.stale || []).length && !rec.active){
      const st = ov.stale[0];
      if(st && st.t) push(TIER.MED, {
        id:"stale:" + st.t.id,
        title: st.t.name,
        action:"Review it",
        because:`You had this at ${Math.round(st.m.pct * 100)}% but nothing has confirmed it recently, so the record has let it decay. A short review is cheap now and expensive the week before an exam.`,
        go:["academy","ac-review"], topicId: st.t.id,
      });
    }
  }

  /* --- a project with real momentum that has stopped --- */
  if(typeof projectStore === "function" && !rec.active){
    let live = [];
    try{
      live = (projectStore().items || []).filter(p => !p.archived && p.stage !== "complete");
    }catch(e){}
    const stalled = live
      .map(p => {
        const prog = typeof projectProgress === "function" ? projectProgress(p) : { pct:0 };
        const next = (p.milestones || []).find(x => !x.done);
        const idle = p.touched ? Math.round((new Date(todayKey()+"T12:00:00") - dateFromKey(p.touched)) / 86400000) : null;
        return { p, prog, next, idle };
      })
      .filter(x => x.next && x.prog.pct > 0 && x.prog.pct < 1 && (x.idle === null || x.idle >= 7))
      .sort((a,b) => (b.idle || 0) - (a.idle || 0))[0];
    if(stalled){
      push(TIER.MED, {
        id:"project:" + stalled.p.id,
        title: stalled.next.name,
        action:"Open the project",
        because:`"${stalled.p.title}" is ${Math.round(stalled.prog.pct * 100)}% done and has not moved${stalled.idle ? ` in ${stalled.idle} days` : ""}. An unfinished project is worth nothing as evidence — the next milestone is the whole distance between a good idea and something you can show someone.`,
        go:["build","b-projects"], projectId: stalled.p.id,
      });
    }
  }

  /* --- an application deadline, which is a hard constraint like any other --- */
  if(typeof oppList === "function"){
    let soon = [];
    const DONE = ["applied","registered","participating","result","completed","rejected","withdrawn"];
    try{
      soon = oppList()
        .filter(o => o.deadline && !DONE.includes(o.stage))
        .map(o => ({ o, in: daysUntil(o.deadline) }))
        .filter(x => x.in !== null && x.in >= 0 && x.in <= 14)
        .sort((a,b) => a.in - b.in);
    }catch(e){}
    if(soon[0]){
      const x = soon[0];
      push(x.in <= 3 ? TIER.HIGH : TIER.MED, {
        id:"opp:" + x.o.id,
        title: x.o.name || "Application",
        action:"Open the application",
        because:`Closes in ${x.in} day${x.in === 1 ? "" : "s"}. This is a date someone else set — it does not move, and unlike a quest it cannot be caught up tomorrow.`,
        go:["beyond","bo-apply"],
      });
    }
  }

  /* ---------- a goal that is drifting ---------- */
  const behind = m.goals
    .map(g => ({ g, p: goalProgress(getGoal(g.id) || {}) }))
    .filter(x => x.p.next && (x.p.behind || x.g.pct === 0))
    .sort((a,b) => (a.p.daysLeft ?? 999) - (b.p.daysLeft ?? 999))[0];
  if(behind){
    const chain = goalChain(behind.g.id).map(x => x.name);
    push(TIER.MED, {
      id:"goal:" + behind.g.id,
      title: behind.p.next.text,
      action:"Open goals",
      because:`One step of "${behind.g.name}"${chain.length > 1 ? `, which sits under "${chain[0]}"` : ""}. ${behind.p.daysLeft !== null ? `${behind.p.daysLeft} days left and ${behind.p.done} of ${behind.p.steps} steps done` : `${behind.p.done} of ${behind.p.steps} steps done`} — the calendar is moving faster than the work.`,
      go:["quests","q-goals"],
    });
  }

  /* ---------- the category being avoided ---------- */
  const weakCat = m.byCat.length >= 2 ? m.byCat[m.byCat.length - 1] : null;
  if(weakCat && weakCat.rate < 0.55 && !rec.active){
    const q = open.find(x => x.cat === weakCat.cat);
    if(q && (!fit || !fit.avoid.includes(q.cat))){
      push(TIER.MED, {
        id:"weak:" + q.id, title:q.name, action:"Clear it",
        because:`${weakCat.cat} is your weakest category at ${mPct(weakCat.rate)}% across ${weakCat.n} scheduled quests. Clearing one today is worth more to the average than clearing two of something you already do reliably.`,
        go:["quests","q-today"], quest:q,
      });
    }
  }

  /* ---------- optional, interest-led, and clearly labelled as such ---------- */
  if(!rec.active){
    const style = m.playstyle[0];
    if(style && confRank(style.conf) >= 1){
      const MAP = {
        scholar:    { title:"Read for twenty minutes", go:["learn","l-books"],  why:"reading is where your record is strongest" },
        builder:    { title:"Practise one craft",      go:["grow","tr-forge"],  why:"you keep the crafts going more reliably than most things on your board" },
        explorer:   { title:"Open something new",      go:["learn","l-screen"], why:"breadth is how you actually engage with this" },
        competitor: { title:"Check the Arena",         go:["wealth","w-arena"], why:"you respond to things with a scoreboard" },
        strategist: { title:"Review your goals",       go:["quests","q-goals"], why:"planning is the part you follow through on" },
        achiever:   { title:"Clear one optional quest",go:["quests","q-today"], why:"finishing the whole board is what you actually chase" },
      };
      const s = MAP[style.k];
      if(s) push(TIER.OPT, {
        id:"style:" + style.k, title:s.title, action:"Open",
        /* v18.1: this was the one recommendation in the file that named no
           number. It asserted a leaning and a confidence label — "Scholar is
           your strongest leaning right now (high confidence)" — with nothing
           behind either. Every sibling cites its evidence: "42% of the time",
           "5 unresolved mistakes", "3 days left". A confidence label is itself
           derived from a count (services/model.js confidenceOf(n, effect)), so
           the count was always available and simply never shown. It surfaced as
           a timezone failure because just after midnight the time-driven
           recommendations do not fire and this one gets promoted into the
           returned set, but the gap is there in every timezone. */
        because:`Suggested because ${s.why} — ${style.label} is your strongest leaning right now, scored ${Math.round(style.score * 100)}% from ${style.conf.n} recorded signal${style.conf.n === 1 ? "" : "s"} (${style.conf.label}). This is a preference, not a requirement: it is the first thing to drop on a busy day.`,
        go:s.go,
      });
    }
  }

  /* de-duplicate by quest, keep the highest tier of each */
  const seen = new Set();
  const ranked = out
    .filter(r => { const k = r.quest ? "q" + r.quest.id : r.id; if(seen.has(k)) return false; seen.add(k); return true; })
    .sort((a,b) => TIER_RANK[a.tier] - TIER_RANK[b.tier])
    .slice(0, opts.max || 6);

  /* 18.12 — every item now says how long it takes.

     This file has ranked by importance since v14 and never once asked how much
     time the student had, so the list at 21:40 on a school night was the list
     they would have seen on a free Saturday. The estimate is coarse on purpose:
     §22 applies to time as much as to reasons, and an honest band beats a
     precise-looking number the record cannot justify. */
  return ranked.map(r => ({
    ...r,
    minutes: estimateMinutes(r, r.quest && Number(r.quest.minutes)),
  }));
}

/* The ranking, fitted to the time the student actually has.

   Budgeting narrows; it never reorders, and it never drops a hard constraint —
   a deadline does not stop being due because the evening is short. Everything is
   returned, annotated, so a student choosing what to skip can see what they are
   skipping. */
function plannedRecommendations(minutes, opts = {}){
  const ranked = recommendations(opts);
  return planForBudget(ranked, minutes);
}

/* One line for the top of Home — the single next action, no list. */
function nextBestAction(){
  const r = recommendations({ max:1 })[0];
  return r || null;
}

/* what the focus rating means for today, as prose */
function focusGuidance(){
  const m = userModel(); if(!m) return null;
  const f = m.focus.today;
  if(f == null) return { asked:false, text:"Rate your focus to shape today's order." };
  const fit = FOCUS_FIT[f];
  return { asked:true, level:f, label:fit.label, text:fit.advice };
}
