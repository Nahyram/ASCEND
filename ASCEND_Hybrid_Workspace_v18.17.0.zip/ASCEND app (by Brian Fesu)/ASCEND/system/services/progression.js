/* ASCEND — services/progression.js
   Loaded as a classic script; shared global scope. */
/* ---------- ranks, stats, xp ----------

   v19 §6 — "do not make rank simply a renamed XP level".

   Until v18.1 this file owned a second rank system: a table keyed on level
   alone, consulted here on every level-up, writing h.rank and firing a RANK UP
   takeover. services/records.js owns the real one — applyRank(), gated on
   BALANCE.ranks, which requires quests cleared, a streak held, achievements
   earned and bosses put down alongside the level.

   Both wrote the same field. applyRank() runs as a hook on grantXp, so it ran
   second and won — meaning the level-only rank was never what the student
   ended up with, but it WAS what they were congratulated for. Crossing level
   10 with nothing else behind it showed "RANK UP — D" full-screen, and then
   left the stored rank at E. A celebration for a rank the System immediately
   took back, with no explanation, which is precisely the flattery failure
   records.js and evidence.js are both written to prevent.

   The table is gone rather than deprecated: two implementations of one rule is
   how five collisions have already shipped in this project. rankName now reads
   BALANCE.rankNames instead of restating it, for the same reason. It is read at
   call time, so balance.js loading after this file is fine. */
const rankName = r => (typeof BALANCE !== "undefined" && BALANCE.rankNames && BALANCE.rankNames[r]) || String(r || "E");
/* xpNeeded moved to shared/domain/progression.js in 18.10 and arrives through
   the bundle's bridge. It is defined once because the server replays the same
   log with the same curve; two copies of a level curve is two answers to "what
   level am I", and the student believes whichever they saw first. */
const STAT_MAP = { study:["INT","PER"], body:["STR","VIT"], mind:["PER","INT"], discipline:["DIS","VIT"], rest:["VIT","DIS"] };
const STAT_KEYS = ["STR","VIT","INT","PER","DIS"];
const STAT_LABEL = {STR:"Strength",VIT:"Vitality",INT:"Intellect",PER:"Perception",DIS:"Discipline"};

function grantXp(n, why, ctx){ return Hooks.dispatch("grantXp", grantXpBase, this, arguments); }
function grantXpBase(n, why){
  const h = H();
  /* 18.10 — the fact is recorded before the state changes.

     This is the only XP funnel in the app, which is what makes an event log
     tractable here: one call site, not eighty-six. The log is not authoritative
     yet. It runs in shadow, and Log.audit() compares what it replays against
     what the record says, so the switch-over in a later release is made on
     evidence instead of on confidence. */
  if(typeof Log !== "undefined" && n > 0) Log.append(Log.TYPES.XP_GRANTED, { n, why: why || "" });
  h.xp += n; h.totalXp += n;
  let leveled = false;
  while(h.xp >= xpNeeded(h.level)){ h.xp -= xpNeeded(h.level); h.level++; leveled = true; }
  /* A level-up announces a level-up and nothing else. Rank is not this
     function's to grant: applyRank() in services/records.js recomputes it from
     the full requirement immediately after this returns, and announces the
     promotion itself when one is genuinely earned. */
  if(leveled){
    takeover({kind:"levelup", title:`LEVEL ${h.level}`, sub:"Your strength has increased.", reward:`+${n} XP · ${why||""}`});
  }
  save();
}
/* v19 §7 — a stat is a claim about capability, so it is not paid for a tap.

   grantStat now returns an outcome rather than nothing, because the caller has
   to be able to TELL the student what happened. A stat that silently fails to
   arrive is worse than one that was never offered — §42, no silent failures.

   Categories in BALANCE.stats.needsEvidence require opts.evidence: a short
   string naming what backed the grant, which is recorded on the grant itself so
   it can be audited later. Everything else is unchanged; the gate is config,
   not hard-coded, so the policy can move without touching this function. */
function grantStat(cat, amt = 1, opts){
  const h = H(); if(!h) return { paid:false, reason:"no hunter" };
  const cfg = (typeof BALANCE !== "undefined" && BALANCE.stats) || {};
  const needs = (cfg.needsEvidence || []).indexOf(cat) >= 0;
  const evidence = opts && opts.evidence;

  if(needs && !evidence){
    return { paid:false, withheld:true, cat,
             stats:(STAT_MAP[cat] || []).slice(),
             hint: cfg.evidenceHint || "" };
  }
  (STAT_MAP[cat]||["DIS"]).forEach((k,i)=>{ h.stats[k] += i===0?amt:amt*0.5; });
  STAT_KEYS.forEach(k=> h.stats[k] = Math.round(h.stats[k]*10)/10);
  return { paid:true, cat, amount:amt, evidence: evidence || "activity pattern" };
}

/* ---------- workouts ---------- */
const WORKOUTS = {
  combatant:{ label:"Formidable Combatant", moves:[
    ["Push-ups",30,60,100],["Sit-ups",30,60,100],["Squats",30,60,100],["Run (km)",3,6,10]]},
  calisthenics:{ label:"Calisthenics", moves:[
    ["Push-ups",20,35,60],["Pull-ups",5,10,20],["Dips",10,18,30],["Pike push-ups",8,15,25],
    ["Squats",30,50,100],["Lunges (each leg)",15,25,40],["Plank (seconds)",45,75,120],
    ["Hanging leg raises",8,15,25],["Burpees",10,20,40],["Australian rows",12,20,35]]},
  gym:{ label:"Gym", moves:[
    ["Bench press (reps)",15,25,40],["Barbell squat (reps)",15,25,40],["Deadlift (reps)",10,18,28],
    ["Overhead press (reps)",12,20,30],["Lat pulldown (reps)",20,30,45],["Barbell row (reps)",15,25,40],
    ["Leg press (reps)",20,30,50],["Bicep curls (reps)",20,30,45],["Cable fly (reps)",20,30,45],
    ["Treadmill (minutes)",10,18,30]]},
  home:{ label:"Home / no equipment", moves:[
    ["Push-ups",15,28,50],["Chair dips",12,20,35],["Bodyweight squats",30,50,90],
    ["Glute bridges",20,35,55],["Mountain climbers",30,50,90],["Jumping jacks",40,70,120],
    ["Plank (seconds)",40,70,110],["Superman hold (seconds)",30,50,80],["Wall sit (seconds)",45,80,120],
    ["High knees (seconds)",30,50,80]]},
  martial:{ label:"Martial arts", moves:[
    ["Shadowboxing rounds (3 min)",3,5,8],["Front kicks (each leg)",25,40,70],["Roundhouse kicks (each leg)",25,40,70],
    ["Jab-cross combos",50,90,150],["Knee strikes (each side)",25,40,70],["Stance holds (seconds)",45,75,120],
    ["Sprawls",15,25,45],["Skipping rope (minutes)",5,10,18],["Core rotations",30,50,80],["Neck bridges",10,18,28]]},
  mixed:{ label:"Mixed", moves:[
    ["Push-ups",20,35,60],["Squats",30,50,90],["Burpees",10,20,40],["Plank (seconds)",45,75,120],
    ["Skipping rope (minutes)",5,10,18],["Lunges (each leg)",15,25,40],["Sit-ups",25,40,70],
    ["Shadowboxing rounds (3 min)",3,5,8],["Pull-ups or rows",8,14,24],["Sprints (x100m)",4,7,12]]},
};
// deterministic per-day RNG so the quest is stable until rerolled
function rng(seed){ let x = 0; for(const c of seed) x = (x*31 + c.charCodeAt(0)) >>> 0; return () => (x = (x*1103515245 + 12345) >>> 0) / 4294967296; }
function makeWorkout(){
  const h = H(); const d = new Date();
  if(h.restDay >= 0 && d.getDay() === h.restDay) return {rest:true, moves:[]};
  const pool = (WORKOUTS[h.workout] || WORKOUTS.mixed).moves;
  const r = rng(todayKey() + h.workout + h.diff + (h.reroll||0) + DB.active);
  const picked = [...pool].sort(()=> r()-0.5).slice(0, 4 + Number(h.diff));
  const i = Number(h.diff); // 1..3
  return { rest:false, moves: picked.map(m => ({ name:m[0], target: m[i], done:false })) };
}

