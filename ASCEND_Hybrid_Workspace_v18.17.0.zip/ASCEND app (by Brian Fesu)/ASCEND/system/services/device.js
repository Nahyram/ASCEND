/* THE SYSTEM v14 — services/device.js
   Phase 13: making the app behave on the devices and networks it will actually run
   on.

   §30 of Phase 15 and §51–52 of Phase 13 both point at the same reality, and it is
   the one that matters most for this project's actual audience: a student in Accra
   on a mid-range Android with a metered data bundle and 3G that comes and goes.
   Every decision here follows from that rather than from a benchmark score.

   Four things:

     - **Data saver.** Not a toggle that dims some images. It suppresses decorative
       weight, stops background sync, and says what it turned off, because a
       student who cannot tell what a setting did will turn it back off.
     - **Network awareness.** On a slow connection, external calls are skipped
       rather than left to time out — twelve seconds of spinner costs data and
       patience and delivers nothing.
     - **Install.** §26 forbids interrupting. The prompt is offered after real use
       and never on first load.
     - **Update.** §59 — a new version must not silently break the running session
       or drop work in progress. */
"use strict";

/* ---------- capability detection ---------- */
function deviceProfile(){
  const nav = typeof navigator !== "undefined" ? navigator : {};
  const conn = nav.connection || nav.mozConnection || nav.webkitConnection || null;
  const mem = nav.deviceMemory || null;
  const cores = nav.hardwareConcurrency || null;
  const w = typeof window !== "undefined" ? (window.innerWidth || 1024) : 1024;
  return {
    width: w,
    size: w < 640 ? "phone" : w < 1024 ? "tablet" : w < 1440 ? "laptop" : "desktop",
    touch: typeof window !== "undefined" && ("ontouchstart" in window || (nav.maxTouchPoints || 0) > 0),
    memory: mem, cores,
    /* a phone with 2GB and four cores is the common case, not the edge case */
    lowEnd: (mem != null && mem <= 2) || (cores != null && cores <= 4),
    effectiveType: conn ? conn.effectiveType : null,
    saveData: !!(conn && conn.saveData),
    downlink: conn ? conn.downlink : null,
    online: nav.onLine !== false,
    standalone: typeof window !== "undefined" && window.matchMedia
      ? window.matchMedia("(display-mode: standalone)").matches : false,
    reducedMotion: typeof window !== "undefined" && window.matchMedia
      ? window.matchMedia("(prefers-reduced-motion: reduce)").matches : false,
  };
}
function isSlowNetwork(){
  const d = deviceProfile();
  if(!d.online) return true;
  if(d.saveData) return true;          /* the browser's own Save-Data flag */
  /* The first version checked only the browser flag, so switching data saver on
     inside THE SYSTEM changed the banner and nothing else — external calls still
     fired and still spent the bundle. A setting that does not do what it says is
     worse than no setting, because the student stops believing the others. */
  if(typeof dataSaver === "function" && dataSaver()) return true;
  return d.effectiveType === "slow-2g" || d.effectiveType === "2g" || d.effectiveType === "3g";
}

/* ---------- data saver (§52) ---------- */
function dataSaver(set){
  const h = H(); if(!h) return false;
  h.prefs = h.prefs || {};
  if(set !== undefined){
    h.prefs.dataSaver = !!set;
    save();
    applyDataSaver();
  }
  /* the browser's own Save-Data header wins if the student set it at OS level */
  return h.prefs.dataSaver || deviceProfile().saveData;
}
function applyDataSaver(){
  if(typeof document === "undefined" || !document.body) return;
  document.body.classList.toggle("data-saver", !!dataSaver());
}
function dataSaverEffects(){
  return [
    "External film, book and series lookups are skipped rather than left to time out.",
    "Background sync waits until you ask for it.",
    "Decorative images and animations are not loaded.",
    "Nothing you have written, tracked or earned is affected — this only touches what gets fetched and drawn.",
  ];
}

/* ---------- network banner (§30, §64) ---------- */
function networkNotice(){
  const d = deviceProfile();
  if(!d.online) return {
    tone:"offline",
    text:"Offline. Quests, the Academy, projects and everything already saved keep working. Anything that needs the internet is paused, not broken.",
  };
  if(dataSaver()) return {
    tone:"saver",
    text:"Data saver is on. External lookups and background sync are paused to protect your bundle.",
  };
  if(isSlowNetwork()) return {
    tone:"slow",
    text:`Slow connection${d.effectiveType ? ` (${d.effectiveType})` : ""}. External lookups are skipped so you are not waiting on them — everything local is unaffected.`,
  };
  return null;
}

/* Api.call is wrapped rather than edited: on a slow or metered connection an
   external lookup is refused up front. Twelve seconds of spinner that ends in a
   timeout has cost data and delivered nothing. */
if(typeof Api === "object" && Api && typeof Api.call === "function"){
  const __apiCallBase = Api.call.bind(Api);
  Api.call = async function(service, path, params, opts){
    if(isSlowNetwork() && !(opts && opts.force)){
      return { ok:false, skipped:true,
        error: dataSaver()
          ? "Skipped — data saver is on. Turn it off in System → Gate if you want this lookup."
          : "Skipped — the connection is too slow for this to be worth the wait. Everything local still works." };
    }
    return __apiCallBase(service, path, params, opts);
  };
}

/* ---------- install (§25, §26) ---------- */
let _installEvent = null;
function watchInstall(){
  if(typeof window === "undefined" || !window.addEventListener) return;
  window.addEventListener("beforeinstallprompt", e => {
    e.preventDefault(); _installEvent = e;
    if(typeof renderOnlineGate === "function") renderOnlineGate();
  });
  window.addEventListener("appinstalled", () => {
    _installEvent = null;
    const h = H(); if(h){ h.prefs = h.prefs || {}; h.prefs.installed = true; save(); }
  });
}
/* §26 — never on first load. Offered after the app has proved itself useful. */
function installOffer(){
  const h = H(); if(!h) return { available:false };
  const d = deviceProfile();
  if(d.standalone || (h.prefs && h.prefs.installed)) return { available:false, installed:true };
  const cleared = h.totalCleared || 0;
  const days = Object.keys(h.done || {}).length;
  return {
    available: !!_installEvent && days >= 3 && cleared >= 5,
    earned: days >= 3 && cleared >= 5,
    days, cleared,
    text:"Install THE SYSTEM for faster starts and a proper app window. It works the same either way — this only changes how you open it.",
  };
}
async function runInstall(){
  if(!_installEvent) return { ok:false, reason:"Not available in this browser." };
  _installEvent.prompt();
  try{
    const choice = await _installEvent.userChoice;
    _installEvent = null;
    return { ok: choice && choice.outcome === "accepted" };
  }catch(e){ return { ok:false, reason:e.message }; }
}

/* ---------- updates (§59, §60) ---------- */
let _waitingWorker = null;
function watchUpdates(){
  if(typeof navigator === "undefined" || !navigator.serviceWorker) return;
  navigator.serviceWorker.getRegistration && navigator.serviceWorker.getRegistration().then(reg => {
    if(!reg) return;
    reg.addEventListener("updatefound", () => {
      const w = reg.installing;
      if(!w) return;
      w.addEventListener("statechange", () => {
        if(w.state === "installed" && navigator.serviceWorker.controller){
          _waitingWorker = w;
          if(typeof toast === "function") toast("A new version is ready",
            "It will be used next time you open THE SYSTEM. Nothing you are in the middle of is interrupted.", "gold");
        }
      });
    });
  }).catch(() => {});
}
function updateWaiting(){ return !!_waitingWorker; }
function applyUpdate(){
  if(!_waitingWorker) return false;
  /* §59 — the running session is never torn down under the user */
  try{ _waitingWorker.postMessage({ type:"SKIP_WAITING" }); }catch(e){}
  if(typeof location !== "undefined") location.reload();
  return true;
}

/* ---------- startup ---------- */
function initDevice(){
  applyDataSaver();
  watchInstall();
  watchUpdates();
  if(typeof window !== "undefined" && window.addEventListener){
    let t = null;
    window.addEventListener("resize", () => { clearTimeout(t); t = setTimeout(() => {
      if(typeof renderNetBanner === "function") renderNetBanner();
    }, 250); });
    for(const ev of ["online","offline"]) window.addEventListener(ev, () => {
      if(typeof renderNetBanner === "function") renderNetBanner();
    });
  }
}
