/* THE SYSTEM v14 — services/opportunities.js
   Phase 7 (Opportunities & Extracurriculars) and Phase 8 (Competitions &
   Challenges), in one file, because Phase 8 §44 says so explicitly: a competition
   is an opportunity subtype, not a second database. Two tables here would mean two
   deadline engines, two matchers and two verification states drifting apart within
   a month.

   ## The decision that shapes everything: THE SYSTEM ships no listings

   Phase 7 §5 and §42, and Phase 8 §6, all say the same thing — the official
   organiser is the source of truth, deadlines must never be invented, and nothing
   may be scraped. An offline-first app on a student's phone has no way to verify
   that a scholarship deadline is still real. So it does not pretend to:

     - the app ships **zero** pre-loaded opportunities;
     - every record is one the student entered or an admin imported;
     - every record carries a verification state and a last-checked date;
     - anything unverified for 30 days is flagged for re-checking, not hidden;
     - the primary action is always "open the official page".

   A directory of stale listings is worse than an empty one. A student who misses a
   real deadline because we showed them last year's is materially harmed, and
   "sorry, our data was old" is not a defence anyone should have to hear.

   ## Matching is explained or it is not shown

   §10 (Phase 7) and §10 (Phase 8) both forbid a bare percentage. Every match here
   returns its factors, and hard eligibility can never be outvoted by interest —
   the ordering rule Phase 10 §15 states outright. */
"use strict";

/* ---------- taxonomy ---------- */
const OPP_KINDS = [
  { k:"competition", label:"Competition", blurb:"Olympiads, hackathons, debates, science fairs." },
  { k:"program",     label:"Programme",   blurb:"Summer schools, camps, research placements." },
  { k:"activity",    label:"Activity",    blurb:"Clubs, teams, volunteering, leadership roles." },
  { k:"scholarship", label:"Scholarship", blurb:"Funding, bursaries, fee waivers." },
  { k:"internal",    label:"Challenge",   blurb:"A challenge THE SYSTEM sets you." },
];
const OPP_CATEGORIES = ["Academic","STEM","Creative","Leadership","Community","Sports","Career","International"];

/* §6 / §5 — an expired thing must never read as open */
const OPP_STATUS = [
  { k:"open",    label:"Open" },
  { k:"soon",    label:"Opening soon" },
  { k:"closing", label:"Closing soon" },
  { k:"closed",  label:"Closed" },
  { k:"ongoing", label:"Ongoing" },
  { k:"unknown", label:"Dates unknown" },
];
/* §8 (P7) / §28 (P8) — never imply we checked something we did not */
const VERIFY = [
  { k:"unverified", label:"Unverified",  blurb:"Nobody has confirmed this against the organiser." },
  { k:"selfcheck",  label:"You checked", blurb:"You confirmed it on the official page." },
  { k:"needsreview",label:"Needs review",blurb:"Last checked over a month ago — details may have changed." },
  { k:"expired",    label:"Expired",     blurb:"The date has passed." },
];

/* §14 (P7) / §12 (P8) — one pipeline for both */
const PIPELINE = ["discovered","interested","checking","preparing","applied","registered","participating","result","completed","rejected","withdrawn"];
const PIPELINE_LABEL = {
  discovered:"Discovered", interested:"Interested", checking:"Checking eligibility",
  preparing:"Preparing", applied:"Applied", registered:"Registered",
  participating:"Taking part", result:"Awaiting result", completed:"Completed",
  rejected:"Not selected", withdrawn:"Withdrawn",
};
/* §27 (P8) — not every competition uses medals */
const RESULT_KINDS = ["Participated","Finalist","Shortlisted","Placed","Winner","Certificate","Not selected","Other"];

/* ---------- storage ---------- */
function opps(){
  const h = H(); if(!h) return null;
  if(!h.opportunities) h.opportunities = { items:[], activities:[], challenges:[], ignored:[] };
  const o = h.opportunities;
  for(const k of ["items","activities","challenges","ignored"]) if(!Array.isArray(o[k])) o[k] = [];
  return o;
}
const oppList  = () => opps() ? opps().items : [];
const getOpp   = id => oppList().find(o => o.id === id) || null;

function addOpportunity({ kind = "competition", name, organiser = "", category = "Academic",
                          deadline = null, eventDate = null, url = "", cost = "", online = true,
                          region = "", eligibility = "", team = false, notes = "" }){
  const o = opps(); if(!o) return null;
  const rec = {
    id: uid(), kind, name: String(name || "").slice(0, 120).trim(),
    organiser: String(organiser).slice(0, 100),
    category: OPP_CATEGORIES.includes(category) ? category : "Academic",
    deadline, eventDate, url: String(url).slice(0, 400),
    cost: String(cost).slice(0, 60), online: !!online,
    region: String(region).slice(0, 60), eligibility: String(eligibility).slice(0, 400),
    team: !!team, notes: String(notes).slice(0, 600),
    stage:"discovered", verify:"unverified", lastChecked: todayKey(),
    checklist: [], result:null, evidence: [], reflection:"",
    created: todayKey(),
  };
  if(!rec.name) return null;
  o.items.push(rec); save(); markChanged("opportunities", "added " + rec.kind);
  return rec;
}
function removeOpportunity(id){
  const o = opps(); if(!o) return false;
  o.items = o.items.filter(x => x.id !== id); save(); markChanged("opportunities","removed"); return true;
}
function ignoreOpportunity(id){
  const o = opps(); const rec = getOpp(id); if(!o || !rec) return false;
  o.ignored.push({ id, name:rec.name, at:todayKey() });
  o.items = o.items.filter(x => x.id !== id);
  save(); return true;                     /* §20/§69 — a refusal is remembered */
}

/* ---------- dates and status (§7 P7, §5 P8) ---------- */
function daysUntil(d){
  if(!d) return null;
  return Math.round((new Date(d + "T00:00:00") - new Date(todayKey() + "T00:00:00")) / 86400000);
}
function oppStatus(rec){
  const dl = daysUntil(rec.deadline);
  const ev = daysUntil(rec.eventDate);
  if(rec.deadline == null && rec.eventDate == null) return { k:"unknown", label:"Dates not recorded", days:null };
  if(dl != null && dl < 0) return { k:"closed", label:"Applications closed", days:dl };
  if(dl != null && dl <= 7) return { k:"closing", label:`Closes in ${dl} day${dl===1?"":"s"}`, days:dl };
  if(dl != null) return { k:"open", label:`Closes in ${dl} days`, days:dl };
  if(ev != null && ev >= 0) return { k:"ongoing", label:`Event in ${ev} day${ev===1?"":"s"}`, days:ev };
  return { k:"closed", label:"Past", days:ev };
}
/* §8 — anything not re-checked in a month is flagged, never silently trusted */
function verifyState(rec){
  const st = oppStatus(rec);
  if(st.k === "closed") return VERIFY.find(v => v.k === "expired");
  const age = rec.lastChecked ? -daysUntil(rec.lastChecked) : 999;
  if(rec.verify === "selfcheck" && age <= 30) return VERIFY.find(v => v.k === "selfcheck");
  if(rec.verify === "selfcheck") return VERIFY.find(v => v.k === "needsreview");
  return VERIFY.find(v => v.k === "unverified");
}
function markChecked(id){
  const rec = getOpp(id); if(!rec) return false;
  rec.verify = "selfcheck"; rec.lastChecked = todayKey(); save(); return true;
}

/* ══════════════ matching (§9, §10) ══════════════
   Hard eligibility is a gate, not a weight. A programme that closed yesterday
   cannot be a 92% match because the student likes robotics. */
function matchOpportunity(rec){
  const m = typeof userModel === "function" ? userModel() : null;
  const factors = [];
  const st = oppStatus(rec);

  /* --- hard gates first --- */
  if(st.k === "closed"){
    return { score:0, blocked:true, label:"Closed",
      factors:[{ k:"Deadline", state:"fail", text:"The deadline has passed. Nothing else about the fit matters." }] };
  }
  factors.push({ k:"Deadline", state:"pass", text: st.label });

  /* --- soft factors, each stated --- */
  let score = 0.4, n = 1;

  const subjectNames = (typeof subjects === "function" ? subjects() : []).map(s => s.name.toLowerCase());
  const text = (rec.name + " " + rec.category + " " + rec.notes).toLowerCase();
  const subjHit = subjectNames.find(s => s && text.includes(s.split(" ")[0]));
  if(subjHit){ score += 0.25; n++; factors.push({ k:"Subjects", state:"pass", text:`Matches "${subjHit}" in your Academy.` }); }
  else factors.push({ k:"Subjects", state:"unknown", text:"No obvious overlap with the subjects you have set up." });

  if(m && m.playstyle && m.playstyle.length){
    const top = m.playstyle[0];
    const MAP = { scholar:["Academic"], builder:["STEM","Creative"], competitor:["Sports","Academic","STEM"],
                  strategist:["Leadership","Career"], explorer:["International","Creative"], achiever:["Academic","STEM"] };
    if((MAP[top.k] || []).includes(rec.category)){
      score += 0.15; n++;
      factors.push({ k:"How you work", state:"pass", text:`${top.label} is your strongest leaning and this is a ${rec.category} opportunity.` });
    }
  }

  /* --- v18: what the student has actually built, not what they have typed ---
     The audit found the opportunity engine could not see the build engine at
     all. A finished, evidenced project in the same category is the strongest
     honest signal that someone is ready for a thing, and it counted for zero.
     Claims are excluded by evidenceMatching(); only demonstrated work reaches
     here, so this can raise a score but can never be raised by wishful typing. */
  const ev = typeof evidenceMatching === "function" ? evidenceMatching(text + " " + rec.name, rec.category) : null;
  if(ev && ev.projects.length){
    score += 0.2; n++;
    const p0 = ev.projects[0];
    factors.push({ k:"Your evidence", state:"pass",
      text:`${ev.projects.length} project${ev.projects.length===1?"":"s"} you can point at — "${p0.title}", ${p0.evidence} piece${p0.evidence===1?"":"s"} of evidence and ${p0.milestonesDone} milestone${p0.milestonesDone===1?"":"s"} done. That is what an application asks for.` });
  } else {
    factors.push({ k:"Your evidence", state:"unknown",
      text:"No completed, evidenced project matches this. Not disqualifying — but you would be applying on intention rather than on work." });
  }
  if(ev && ev.skills.length){
    score += 0.1; n++;
    factors.push({ k:"Demonstrated skills", state:"pass",
      text:`${ev.skills.map(s => s.name).slice(0,3).join(", ")} — demonstrated on a project, not self-assessed.` });
  }
  if(ev && ev.mastery.length){
    const best = ev.mastery.sort((a,b) => b.mastery - a.mastery)[0];
    const pctM = Math.round(best.mastery * 100);
    if(best.mastery >= 0.6){
      score += 0.1; n++;
      factors.push({ k:"Mastery", state:"pass", text:`${best.name} sits at ${pctM}% in your Academy.` });
    } else {
      factors.push({ k:"Mastery", state:"unknown",
        text:`${best.name} is the relevant subject and sits at ${pctM}%. Worth closing some of that before the deadline rather than after it.` });
    }
  }

  if(rec.online){ score += 0.1; factors.push({ k:"Location", state:"pass", text:"Online — travel is not a barrier." }); }
  else factors.push({ k:"Location", state:"unknown", text:`In person${rec.region ? " in " + rec.region : ""}. Check whether you can actually get there.` });

  /* §10 — eligibility we cannot confirm must say so, not be assumed */
  factors.push(rec.eligibility
    ? { k:"Eligibility", state:"unknown", text:`Stated: ${rec.eligibility}. THE SYSTEM has not checked this against the organiser — you must.` }
    : { k:"Eligibility", state:"unknown", text:"No eligibility recorded. Read the official page before spending time on it." });

  /* clashes with things already in the calendar (§27 of Phase 10, §38 of Phase 7) */
  const clash = examClash(rec);
  if(clash) factors.push({ k:"Clash", state:"fail", text:`Overlaps ${clash.name} on ${clash.date}. Not disqualifying — but decide deliberately.` });

  return {
    score: Math.max(0, Math.min(1, score)),
    blocked:false,
    label: `${Math.round(Math.min(1, score) * 100)}%`,
    factors,
  };
}
function examClash(rec){
  const d = rec.eventDate || rec.deadline; if(!d) return null;
  const list = typeof upcomingExams === "function" ? upcomingExams() : [];
  const near = list.find(e => Math.abs(daysUntil(e.date) - daysUntil(d)) <= 2);
  return near ? { name: near.name, date: near.date } : null;
}

/* ---------- ranked view (§12 P7, §7 P8) ---------- */
function rankedOpportunities({ kind = null, max = 20 } = {}){
  return oppList()
    .filter(o => !kind || o.kind === kind)
    .map(o => ({ o, m: matchOpportunity(o), status: oppStatus(o), verify: verifyState(o) }))
    .sort((a, b) => {
      const ad = a.status.days ?? 9999, bd = b.status.days ?? 9999;
      if(a.m.blocked !== b.m.blocked) return a.m.blocked ? 1 : -1;
      if(a.status.k === "closing" || b.status.k === "closing") return ad - bd;
      return b.m.score - a.m.score || ad - bd;
    })
    .slice(0, max);
}
function deadlinesSoon(days = 21){
  return oppList()
    .map(o => ({ o, d: daysUntil(o.deadline) }))
    .filter(x => x.d != null && x.d >= 0 && x.d <= days)
    .sort((a, b) => a.d - b.d);
}

/* ---------- pipeline & checklists (§14, §15) ---------- */
function setStage(id, stage){
  const rec = getOpp(id); if(!rec || !PIPELINE.includes(stage)) return false;
  rec.stage = stage; save(); markChanged("opportunities","stage");
  if(stage === "completed") grantXp(BALANCE.xp.milestone, `Completed — ${rec.name}`, { once:"opp:" + id });
  return true;
}
/* §13 (P8) — the checklist adapts to the kind rather than being one generic list */
const CHECKLIST_TEMPLATES = {
  competition: ["Read the official rules","Check eligibility","Register on the official site","Build a preparation plan","Do a timed mock","Take part","Record the result"],
  program:     ["Read the official page","Check eligibility and age limits","Note what documents are needed","Prepare the written parts","Submit","Save the confirmation"],
  scholarship: ["Confirm eligibility on the official page","List required documents","Draft the essay","Request a recommendation","Review everything","Submit","Save the confirmation"],
  activity:    ["Find out when and where it meets","Speak to whoever runs it","Attend once","Decide whether to commit","Take on a responsibility"],
  internal:    ["Read the challenge","Do the work","Record what happened","Reflect"],
};
function buildChecklist(id){
  const rec = getOpp(id); if(!rec) return null;
  const items = CHECKLIST_TEMPLATES[rec.kind] || CHECKLIST_TEMPLATES.competition;
  rec.checklist = items.map(t => ({ id:uid(), text:t, done:false }));
  save(); return rec.checklist;
}
function toggleChecklistItem(oppId, itemId){
  const rec = getOpp(oppId); if(!rec) return false;
  const it = (rec.checklist || []).find(x => x.id === itemId); if(!it) return false;
  it.done = !it.done; save();
  if(it.done) grantXp(10, `Application step — ${rec.name}`, { once:"oppstep:" + itemId });
  return true;
}
/* §17 (P7) / §14 (P8) — a deadline becomes a quest chain, using Phase 4's mechanic */
function bossFromOpportunity(id){
  const rec = getOpp(id); if(!rec) return null;
  if(!rec.checklist || !rec.checklist.length) buildChecklist(id);
  return createBoss({
    name: rec.name,
    template:"custom",
    difficulty: (daysUntil(rec.deadline) ?? 30) <= 10 ? "epic" : "hard",
    stages: rec.checklist.map(c => c.text).slice(0, 8),
  });
}

/* ---------- results & evidence (§27, §28, §29 of P8) ---------- */
function recordResult(id, { kind = "Participated", detail = "", evidenceUrl = "", verified = false }){
  const rec = getOpp(id); if(!rec) return null;
  rec.result = {
    kind, detail: String(detail).slice(0, 300),
    /* §28 — self-reported is never presented as verified */
    verification: verified ? "evidence" : "selfreported",
    evidenceUrl: String(evidenceUrl).slice(0, 400),
    at: todayKey(),
  };
  rec.stage = "completed";
  save(); markChanged("opportunities","result");
  /* §31 — preparation and participation are rewarded, not only winning */
  grantXp(BALANCE.xp.milestone, `Result recorded — ${rec.name}`, { once:"oppresult:" + id });
  return rec.result;
}

/* ---------- extracurricular profile (§18–§22 of P7) ---------- */
const ACTIVITY_ROLES = ["Member","Contributor","Team lead","Project lead","Captain","Founder"];
function addActivity({ name, organisation = "", category = "Community", role = "Member",
                       start = null, end = null, hours = 0, description = "" }){
  const o = opps(); if(!o) return null;
  const a = {
    id: uid(), name:String(name||"").slice(0,100).trim(), organisation:String(organisation).slice(0,100),
    category, role, start: start || todayKey(), end,
    hours: Math.max(0, Number(hours) || 0),
    description: String(description).slice(0, 500),
    log: [], reflection:"", created: todayKey(),
  };
  if(!a.name) return null;
  o.activities.push(a); save(); markChanged("opportunities","activity");
  return a;
}
function logActivity(id, { hours = 1, note = "" }){
  const o = opps(); const a = (o.activities || []).find(x => x.id === id); if(!a) return null;
  a.log.push({ id:uid(), date:todayKey(), hours:Math.max(0, Number(hours) || 0), note:String(note).slice(0,200) });
  a.hours += Math.max(0, Number(hours) || 0);
  save();
  grantXp(BALANCE.xp.hobbySession, `Activity — ${a.name}`, { once:"act:" + id + ":" + todayKey() });
  return a;
}
/* §20 — depth, not a count. Progression through roles is the signal that matters. */
function activityDepth(a){
  const months = a.start ? Math.max(0, Math.round(-daysUntil(a.start) / 30)) : 0;
  const roleRank = ACTIVITY_ROLES.indexOf(a.role);
  const sessions = (a.log || []).length;
  return {
    months, sessions, hours: a.hours, role: a.role, roleRank,
    depth: Math.min(1, months / 12 * 0.4 + Math.min(1, sessions / 20) * 0.3 + Math.max(0, roleRank) / 5 * 0.3),
    note: months >= 6 && roleRank >= 2
      ? "Sustained, with responsibility. This is the kind of involvement that reads as real."
      : months >= 6 ? "Sustained. Taking on a defined responsibility would deepen it."
      : sessions >= 5 ? "Started properly. Keep it going — duration is what separates involvement from attendance."
      : "Early. Nothing to judge yet.",
  };
}
/* §30/§31 — gaps are named without pretending they are admission requirements */
function developmentGaps(){
  const o = opps(); if(!o) return [];
  const cats = new Set((o.activities || []).map(a => a.category));
  const comps = oppList().filter(x => x.kind === "competition" && x.result).length;
  const out = [];
  if((o.activities || []).length && !cats.has("Leadership"))
    out.push({ text:"Your activities show participation but no leadership role recorded.",
               suggest:"Taking a defined responsibility in something you already do counts for more than joining a fourth club.",
               caveat:"This is an observation about your own record, not a requirement anyone has set." });
  if(!comps && oppList().some(x => x.kind === "competition"))
    out.push({ text:"You have saved competitions but not recorded a result for any.",
               suggest:"Entering one and recording what happened — including not placing — is worth more than saving ten.",
               caveat:"Participation is the point; winning is not the only outcome worth having." });
  const deep = (o.activities || []).map(activityDepth).filter(d => d.months >= 6).length;
  if((o.activities || []).length >= 4 && !deep)
    out.push({ text:"Several activities, none of them yet six months old.",
               suggest:"Depth in one beats breadth across four. Pick the one you actually enjoy and stay.",
               caveat:"Breadth is not wrong — but it is what everyone has." });
  return out;
}

/* ══════════════ internal challenges (§19–22 of P8) ══════════════
   THE SYSTEM's own challenges, clearly separated from real-world competitions
   (§3) so nothing here can be mistaken for an external achievement. */
const CHALLENGE_POOL = [
  { k:"daily",   name:"Ten-minute start",     blurb:"Do ten minutes of the thing you have been avoiding.", xp:20 },
  { k:"daily",   name:"Close one error",      blurb:"Take one unresolved mistake from the error log and fix it.", xp:25 },
  { k:"weekly",  name:"Five clean days",      blurb:"Clear every mandatory quest, five days out of seven.", xp:120 },
  { k:"weekly",  name:"Twenty questions",     blurb:"Answer twenty practice questions across any subjects.", xp:100 },
  { k:"weekly",  name:"Teach it back",        blurb:"Explain one topic out loud, from memory, to somebody.", xp:90 },
  { k:"monthly", name:"Master a topic",       blurb:"Take one topic from 'not started' to 'review'.", xp:300 },
  { k:"monthly", name:"Finish something",     blurb:"Complete a project, a book, or a boss chain.", xp:350 },
];
function activeChallenges(){
  const o = opps(); if(!o) return [];
  const t = todayKey();
  o.challenges = (o.challenges || []).filter(c => !c.expires || c.expires >= t);
  return o.challenges;
}
function drawChallenge(kind = "daily"){
  const o = opps(); if(!o) return null;
  const live = activeChallenges();
  if(live.some(c => c.kind === kind && !c.done)) return null;    /* one at a time */
  const pool = CHALLENGE_POOL.filter(c => c.k === kind);
  /* deterministic per period so it cannot be re-rolled until it is liked */
  const seed = todayKey() + kind + (H() ? H().id : "");
  let n = 0; for(const ch of seed) n = (n * 31 + ch.charCodeAt(0)) >>> 0;
  const pick = pool[n % pool.length];
  const days = kind === "daily" ? 1 : kind === "weekly" ? 7 : 30;
  const d = new Date(); d.setDate(d.getDate() + days);
  const c = { id:uid(), kind, name:pick.name, blurb:pick.blurb, xp:pick.xp,
              started:todayKey(), expires:todayKey(d), done:false, internal:true };
  o.challenges.push(c); save();
  return c;
}
function completeChallenge(id){
  const o = opps(); const c = (o.challenges || []).find(x => x.id === id); if(!c || c.done) return null;
  c.done = true; c.doneAt = todayKey(); save();
  grantXp(c.xp, `Challenge — ${c.name}`, { once:"chal:" + id });
  return c;
}

/* ══════════════ scam protection (§46 P7, §55 P10) ══════════════
   Mandatory, and cheap to do well. These are heuristics on what the student typed
   in, shown as questions to ask rather than accusations. */
const SCAM_SIGNALS = [
  { test: r => /pay|fee|deposit|processing charge/i.test(r.cost || "") && !/waiv|free/i.test(r.cost || ""),
    text:"There is a fee. Plenty of legitimate programmes charge one — but a fee simply to apply, especially paid to a person rather than an organisation, is the pattern most often reported as a problem." },
  { test: r => r.url && !/^https:\/\//i.test(r.url),
    text:"The link is not https. Do not enter personal details on it." },
  { test: r => r.url && /bit\.ly|tinyurl|linktr|goo\.gl|t\.co/i.test(r.url),
    text:"The application link is a shortener, so you cannot see where it goes. Ask for the organiser's own domain." },
  { test: r => /guarantee|100%|assured|no interview|instant/i.test(r.name + " " + r.notes),
    text:"The wording promises a guaranteed outcome. No genuine scholarship or competition can guarantee selection." },
  { test: r => /whatsapp|telegram|dm |direct message/i.test(r.notes || ""),
    text:"Applications handled through a personal messaging account are worth questioning. Established programmes use a form on their own site." },
];
function scamCheck(rec){
  const hits = SCAM_SIGNALS.filter(s => { try{ return s.test(rec); }catch(e){ return false; } }).map(s => s.text);
  return {
    flagged: hits.length > 0,
    signals: hits,
    /* §46 — never tell a student to send money or share credentials */
    advice: hits.length
      ? "None of this proves it is fake. It means check the organiser's own website directly before giving anything — and never send money to an individual, share a password, or send ID documents to an address you were given in a message."
      : "Nothing obvious flagged. That is not a verification — only the organiser's official page is.",
  };
}

/* ---------- integrity (§37 of P8) ---------- */
function integrityWarning(rec){
  if(rec.kind !== "competition") return null;
  return "Check the rules before using the AI tutor or any outside help during an official round. THE SYSTEM will help you prepare; it will not help you compete against rules that forbid it.";
}
