/* THE SYSTEM v14 — services/business.js
   Phase 17: monetisation, with the central rule enforced in code rather than
   written in a comment.

   ## The rule

   Nothing that helps a student learn is ever behind a payment. Not the Academy,
   not practice, not the error log, not the revision planner, not quests, not the
   Archive, not the offline experience. A student with no money gets the whole
   learning product.

   `registerPaidFeature()` refuses any feature on the protected list. That is not a
   flourish — a policy that lives only in prose is one a future release quietly
   breaks when a revenue target appears. This way the build fails instead.

   What is paid: things that cost money to run (sync and cloud backup, online AI)
   and one convenience that costs nothing to withhold (bulk import). */
"use strict";

/* Every feature the paywall may never touch. Additions welcome; removals are the
   thing this list exists to prevent. */
const NEVER_PAID = [
  "academy","subjects","syllabus","mastery","practice","questions","errorlog","flashcards",
  "review","revision","exams","grades","quests","goals","streak","xp","levels","skills",
  "achievements","insight","patterns","coach","brief","weeklyreview","projects","portfolio",
  "opportunities","competitions","scholarships","archive","library","offline","export","themes",
];
const PAID_FEATURES = {};

function registerPaidFeature(key, { label, why, cost }){
  const k = String(key || "").toLowerCase();
  if(NEVER_PAID.includes(k)){
    /* Loud on purpose. A silent refusal would let the attempt pass review. */
    const msg = `Refused: "${k}" is on the never-paid list. Learning is not the thing this product sells.`;
    if(typeof console !== "undefined") console.warn("[business] " + msg);
    return { ok:false, reason:msg };
  }
  PAID_FEATURES[k] = { key:k, label, why, cost };
  return { ok:true };
}

/* The three that actually cost money to provide, plus one honest convenience. */
registerPaidFeature("cloudsync",  { label:"Cloud sync across devices", why:"Server and storage cost money per user, every month.", cost:"real" });
registerPaidFeature("cloudbackup",{ label:"Automatic cloud backup",    why:"Same. Local export stays free and always will.", cost:"real" });
registerPaidFeature("onlineai",   { label:"Online AI tutor",           why:"Every request costs money. The offline analysis, which is most of the intelligence, is free.", cost:"real" });
registerPaidFeature("bulkimport", { label:"Bulk import of past papers",
  why:"Costs nothing to run. Priced because it saves an hour of typing, and because something has to fund the free part.", cost:"convenience" });

/* ---------- entitlement (§17, §37) ----------
   The client is never the authority. Until a server exists, everything is granted
   and `authority` says why — so the call sites do not change on the day it is. */
/* v18: the decision moved to services/entitlements.js, which separates a
   device grant from a server grant and refuses to blur them. This stays as the
   name every call site already uses. It delegates rather than deciding, so
   there is one implementation, not two that agree until they do not. */
function licenceCheck(key){
  if(typeof entitlementFor === "function") return entitlementFor(key);
  /* entitlements.js failed to load. Fail towards the student: learning is free
     by rule, so a missing entitlement service must never lock anything. */
  return { allowed:true, authority:"policy", verified:false,
    note:"The entitlement service did not load, so nothing is being gated. Every learning feature is free by rule in any case." };
}

/* ---------- pricing (§9, §10, §88) ----------
   Configurable, regional, and never hard-coded into a call site. */
function pricing(){
  const r = typeof region === "function" ? region() : { currency:"GHS", k:"gh" };
  const TABLE = {
    GHS: { month: 1500, year: 12000 },     /* minor units — GHS 15 / GHS 120 */
    NGN: { month: 250000, year: 2000000 },
    KES: { month: 20000, year: 160000 },
    ZAR: { month: 4900, year: 39000 },
    USD: { month: 200, year: 1600 },
  };
  const p = TABLE[r.currency] || TABLE.USD;
  const fmt = n => (n / 100).toFixed(2);
  return {
    currency: r.currency, region: r.label,
    month: p.month, year: p.year,
    monthText: `${r.currency} ${fmt(p.month)}`,
    yearText: `${r.currency} ${fmt(p.year)}`,
    /* §11 — money is integer minor units, never a float */
    note:"Stored as integer minor units. Regional pricing is a table, not a currency conversion, because purchasing power is not an exchange rate.",
    free: NEVER_PAID.length,
    paid: Object.keys(PAID_FEATURES).length,
  };
}

/* ---------- refused patterns (§50) ---------- */
const DARK_PATTERNS_REFUSED = [
  { k:"Countdown offers",       why:"Manufactured urgency aimed at teenagers with their parents' card." },
  { k:"Hidden cancellation",    why:"If it takes more than one tap to leave, it is a trap." },
  { k:"Free trial that auto-charges without a reminder", why:"A reminder costs nothing and removes the entire complaint." },
  { k:"Paywalling a feature after someone relied on it", why:"Anything free at signup stays free for that account." },
  { k:"Shaming free users",     why:"The free tier is the product. It should not feel like a warning." },
  { k:"Ads",                    why:"Minors, academic data. Not a revenue model this product will use." },
];

/* ---------- the model, with pessimistic defaults (§62, §63) ---------- */
function revenueModel({ users = 1000, convert = 0.02 } = {}){
  const p = pricing();
  const payers = Math.round(users * convert);
  const monthly = payers * p.month;
  /* AI and storage are the only real variable costs, and they are guesses labelled
     as guesses. A model with confident numbers in it is a story. */
  const costPerPayer = 40;   /* minor units per month, deliberately pessimistic */
  return {
    users, convert, payers,
    grossText: `${p.currency} ${(monthly/100).toFixed(2)} / month`,
    netText: `${p.currency} ${((monthly - payers*costPerPayer)/100).toFixed(2)} / month`,
    note:`At ${Math.round(convert*100)}% conversion — a deliberately low assumption — ${users} students give ${payers} payers. This is arithmetic, not a forecast: nobody has paid anything yet, so the conversion rate is invented and should be treated as such.`,
    breakeven: `Roughly ${Math.ceil(2000 / (p.month/100))} payers a month covers a small server bill. That is the number that matters, not the total.`,
  };
}
