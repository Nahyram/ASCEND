/* THE SYSTEM v14 — services/model.js
   The user model: one structured, honest picture of the hunter, assembled from the
   record already on this device.

   Three rules this file exists to enforce:

   1. It describes behaviour, never the person. "You clear fewer quests after 6 PM"
      is a fact about a record. "You have poor evening focus" is a claim about a
      brain, and this file is not qualified to make it.
   2. Every derived number arrives with the sample size that produced it. Anything
      that consumes the model can therefore refuse to speak when the evidence is thin,
      and most of the layer above does exactly that.
   3. No network, no model provider, no upload. Pure functions over local state.

   Pure — no DOM, no writes. Callers own rendering. */
"use strict";

/* ══════════════ confidence ══════════════
   Two things have to be true before a pattern is worth telling someone about:
   enough observations, and a difference big enough to survive noise. A 40-point
   gap over 6 data points is a coincidence with good marketing. */
const CONF = { LOW:"low", MED:"medium", HIGH:"high" };

function confidenceOf(n, effect = 1){
  if(n < 8)   return { level:CONF.LOW,  label:"not enough data yet", n };
  if(n < 20)  return { level:CONF.LOW,  label:"early signal",        n };
  if(n < 45)  return { level: effect >= 0.2 ? CONF.MED : CONF.LOW,  label:"moderate confidence", n };
  return       { level: effect >= 0.15 ? CONF.HIGH : CONF.MED,      label:"high confidence",     n };
}
const confRank = c => ({ low:0, medium:1, high:2 })[c && c.level] ?? 0;

/* Two proportions differ *meaningfully* only when the gap survives the noise in
   the samples that produced them. Without this, a detector fed random data with a
   75% success rate will happily announce that Tuesdays are your weak day, because
   over seven weekdays one of them is always the unluckiest. The engine reporting
   coincidences is worse than the engine saying nothing, so the gap must clear
   roughly two standard errors as well as a fixed floor. */
function significant(rateA, nA, rateB, nB, floor = 0.15, z = 2.6){
  if(!nA || !nB) return false;
  const diff = Math.abs(rateA - rateB);
  if(diff < floor) return false;
  const se = Math.sqrt((rateA*(1-rateA))/nA + (rateB*(1-rateB))/nB);
  if(se === 0) return diff >= floor;
  return diff >= z * se;
}
/* Picking the best and worst of k groups and then testing that pair is not one
   comparison — it is all k(k-1)/2 of them, and the extremes are the ones most
   likely to be flukes. Testing the widest gap in seven weekdays at the same
   threshold as a single planned comparison is how an engine ends up confidently
   announcing that Tuesdays are your problem. This widens the bar accordingly. */
function zForGroups(k){
  const pairs = Math.max(1, k * (k - 1) / 2);
  return Math.min(4.0, 2.6 + 0.42 * Math.log(pairs));
}

/* z defaults to 2.6 rather than the textbook 1.96 on purpose. The engine runs
   thirteen detectors over the same record every time it is asked, so at a 5%
   false-positive rate roughly one detector would fire on pure noise on any given
   day. A student cannot tell a fluke from a finding, and the whole point of the
   confidence system is that they should not have to. 2.6 is about 1% per test,
   which puts the expected false positives per run below one. */

/* ══════════════ small helpers ══════════════ */
const mRate = rows => rows.length ? rows.filter(r => r.done).length / rows.length : 0;
const mPct  = n => Math.round(n * 100);
function daysAgoKey(i){ const d = new Date(); d.setDate(d.getDate() - i); return todayKey(d); }
function keysBack(from, to){ const out = []; for(let i = from; i <= to; i++) out.push(daysAgoKey(i)); return out; }
function daysBetween(aKey, bKey){
  const a = new Date(aKey + "T00:00:00"), b = new Date(bKey + "T00:00:00");
  return Math.round((b - a) / 86400000);
}

/* ══════════════ focus log ══════════════
   Phase 3 is explicit that the system must not pretend to measure biological
   energy. It asks, the hunter answers 1–5, and that is all it ever knows. */
function focusToday(){ const h = H(); return h && h.focusLog ? (h.focusLog[todayKey()] ?? null) : null; }
function setFocusToday(v){
  const h = H(); if(!h) return null;
  h.focusLog = h.focusLog || {};
  const n = Math.max(1, Math.min(5, Math.round(Number(v) || 3)));
  h.focusLog[todayKey()] = n;
  /* 120 days is plenty to spot a rhythm and small enough to never matter for size */
  const cut = daysAgoKey(120);
  for(const k of Object.keys(h.focusLog)) if(k < cut) delete h.focusLog[k];
  save();
  invalidateModel();          /* the model caches focus.today — a stale read here
                                 would make the recommender ignore the answer the
                                 hunter just gave it */
  return n;
}
function focusStats(){
  const h = H(); if(!h || !h.focusLog) return { n:0, avg:null };
  const vals = Object.values(h.focusLog).filter(v => typeof v === "number");
  return { n:vals.length, avg: vals.length ? vals.reduce((a,b)=>a+b,0) / vals.length : null };
}

/* ══════════════ playstyle ══════════════
   Six leanings, scored 0–1 from things the hunter actually did. Nobody is labelled:
   these are weights that move as behaviour moves, and they are used only to order
   suggestions. A Scholar score of 0.8 changes which quest is recommended first.
   It never changes what the hunter is allowed to do. */
const TRAITS = [
  { k:"scholar",    label:"Scholar",    blurb:"Learning is where your record is strongest." },
  { k:"achiever",   label:"Achiever",   blurb:"You finish what the board asks. Consistency is your edge." },
  { k:"strategist", label:"Strategist", blurb:"You plan before you move — goals, targets, steps." },
  { k:"builder",    label:"Builder",    blurb:"You practise crafts and make things, not just study them." },
  { k:"explorer",   label:"Explorer",   blurb:"You range widely — new shelves, new subjects, new tools." },
  { k:"competitor", label:"Competitor", blurb:"You aim at contests, ranks and measurable outcomes." },
];

function playstyle(rows){
  const h = H(); if(!h) return [];
  rows = rows || coachSample();
  const catRate = c => { const r = rows.filter(x => x.cat === c); return r.length >= 4 ? mRate(r) : null; };
  const clamp = n => Math.max(0, Math.min(1, n));

  const study = catRate("study"), mind = catRate("mind"), body = catRate("body"), disc = catRate("discipline");
  const goals = Array.isArray(h.goals) ? h.goals : [];
  const steps = goals.reduce((s,g) => s + (g.targets||[]).reduce((t,x)=>t+(x.steps||[]).length,0), 0);
  const hobbyDays = h.hobbyLog ? Object.keys(h.hobbyLog).length : 0;
  const shelves = (h.genres||[]).length + (h.screenGenres||[]).length;
  const overall = rows.length ? mRate(rows) : 0;

  const raw = {
    scholar:    clamp(((study ?? 0) * 0.6 + (mind ?? 0) * 0.4) + Math.min((h.booksRead||[]).length, 10) / 40),
    achiever:   clamp(overall * 0.8 + Math.min(h.streak || 0, 30) / 100),
    strategist: clamp(Math.min(goals.length, 4) / 8 + Math.min(steps, 20) / 40 + (disc ?? 0) * 0.35),
    builder:    clamp(Math.min(hobbyDays, 30) / 45 + (h.hobbies||[]).length / 12 + (mind ?? 0) * 0.25),
    explorer:   clamp(Math.min(shelves, 14) / 22 + Math.min((h.watched||[]).length, 12) / 40),
    competitor: clamp(Math.min((h.arenaSaved||[]).length, 8) / 12 + (body ?? 0) * 0.3 + Math.min((h.careers||[]).length, 4) / 12),
  };

  /* evidence count per trait decides whether we say anything about it at all */
  const evidence = {
    scholar: rows.filter(r => r.cat === "study" || r.cat === "mind").length,
    achiever: rows.length,
    strategist: steps * 2 + rows.filter(r => r.cat === "discipline").length,
    builder: hobbyDays * 2 + rows.filter(r => r.cat === "mind").length,
    explorer: shelves * 3 + (h.watched||[]).length,
    competitor: (h.arenaSaved||[]).length * 4 + rows.filter(r => r.cat === "body").length,
  };

  return TRAITS
    .map(t => ({ ...t, score: Number(raw[t.k].toFixed(2)), conf: confidenceOf(evidence[t.k] || 0, raw[t.k]) }))
    .sort((a,b) => b.score - a.score);
}

/* ══════════════ the model ══════════════
   Assembled once per call and cached for a few seconds, because Home, the brief
   and the recommender all want it inside the same render pass and it walks 60 days
   of record to build. */
let _mCache = null, _mAt = 0, _mKey = "";
function userModel(force){
  const h = H(); if(!h) return null;
  const key = h.id + "|" + todayKey() + "|" + Object.keys(h.done[todayKey()] || {}).length + "|" + (h.quests||[]).length;
  if(!force && _mCache && _mKey === key && Date.now() - _mAt < 4000) return _mCache;

  const rows = coachSample();
  const qs   = (h.quests || []);
  const dueToday = typeof questsFor === "function" ? questsFor() : [];

  /* --- performance, sliced the ways the rest of the layer asks for --- */
  const win = (a,b) => { const ks = keysBack(a,b); return mRate(rows.filter(r => ks.includes(r.key))); };
  const perf = {
    overall: rows.length ? mRate(rows) : 0,
    last7:   win(1,7),
    prev7:   win(8,14),
    last14:  win(1,14),
    n:       rows.length,
  };
  perf.delta = perf.prev7 > 0 ? perf.last7 - perf.prev7 : 0;

  const byDayRows  = DAYNAME.map((_,i) => { const r = rows.filter(x => x.dow === i); return { dow:i, n:r.length, rate:mRate(r) }; });
  const byBandRows = BANDS.map(b => { const r = rows.filter(x => x.hour >= b.from && x.hour <= b.to); return { ...b, n:r.length, rate:mRate(r) }; });
  const catMap = {};
  for(const r of rows){ (catMap[r.cat] = catMap[r.cat] || { n:0, hit:0 }); catMap[r.cat].n++; if(r.done) catMap[r.cat].hit++; }
  const byCatRows = Object.entries(catMap).map(([cat,v]) => ({ cat, n:v.n, rate:v.hit/v.n }));
  const qMap = {};
  for(const r of rows){
    (qMap[r.id] = qMap[r.id] || { id:r.id, name:r.name, cat:r.cat, mand:r.mand, hour:r.hour, n:0, hit:0 });
    qMap[r.id].n++; if(r.done) qMap[r.id].hit++;
  }
  const byQuestRows = Object.values(qMap).map(q => ({ ...q, rate:q.hit/q.n }));

  const rank = (arr, min) => arr.filter(x => x.n >= min).sort((a,b) => b.rate - a.rate);
  const dRank = rank(byDayRows, 3), bRank = rank(byBandRows, 5);

  /* --- goals, flattened so the recommender does not have to walk the tree --- */
  const goals = (Array.isArray(h.goals) ? h.goals : []).map(g => {
    const targets = g.targets || [];
    const all = targets.reduce((s,t) => s.concat(t.steps || []), []);
    const done = all.filter(s => s.done).length;
    return {
      id:g.id, name:g.name, horizon:g.horizon || "month", due:g.due || null, parent:g.parent || null,
      targets:targets.length, steps:all.length, done,
      pct: all.length ? done/all.length : 0,
      nextStep: all.find(s => !s.done) || null,
      stalled: all.length > 0 && done < all.length && !!g.touched && daysBetween(g.touched, todayKey()) >= 10,
    };
  });

  /* --- deadlines, with the clustering Phase 3 §18 asks about --- */
  const today = todayKey();
  const deadlines = (h.deadlines || [])
    .map(d => ({ ...d, in: daysBetween(today, d.date) }))
    .filter(d => d.in >= 0)
    .sort((a,b) => a.in - b.in);
  const within7 = deadlines.filter(d => d.in <= 7);
  const clustered = within7.length >= 3;

  const model = {
    meta: {
      sample: rows.length,
      days: new Set(rows.map(r => r.key)).size,
      since: h.created || null,
      conf: confidenceOf(rows.length, 0.2),
      generated: Date.now(),
    },
    identity: {
      name:h.name, mode:h.mode || "student", curriculum:h.curriculum || "igcse",
      level:h.level || 1, rank:h.rank || "E", streak:h.streak || 0, totalCleared:h.totalCleared || 0,
    },
    load: {
      scheduled: qs.length,
      mandatory: qs.filter(q => q.mand).length,
      today: dueToday.length,
      todayLeft: dueToday.filter(q => typeof isDone === "function" && !isDone(q)).length,
      perDay: qs.length ? Number((qs.reduce((s,q)=>s+(q.days||[]).length,0) / 7).toFixed(1)) : 0,
    },
    perf,
    byDay:   dRank,
    byBand:  bRank,
    byCat:   byCatRows.filter(c => c.n >= 5).sort((a,b) => b.rate - a.rate),
    byQuest: byQuestRows.filter(q => q.n >= 4).sort((a,b) => a.rate - b.rate),
    rhythm: {
      bestDay:   dRank[0] || null,  worstDay:  dRank[dRank.length-1] || null,
      bestBand:  bRank[0] || null,  worstBand: bRank[bRank.length-1] || null,
    },
    focus: { today: focusToday(), ...focusStats() },
    goals, deadlines, within7, clustered,
    playstyle: playstyle(rows),
    rows,
  };

  _mCache = model; _mAt = Date.now(); _mKey = key;
  return model;
}

/* Consumers that mutate the record call this so the next read is not stale. */
function invalidateModel(){ _mCache = null; _mKey = ""; }
