/* THE SYSTEM v14 — services/verification.js
   Phase 11: the trust layer — verification states, personal records, and rankings.

   ## Why there are no global leaderboards in this build

   §51 makes global rankings opt-in; §52 says do not present a tiny sample as a
   definitive global ranking; §71 requires minimum sample sizes before showing
   school or country statistics. Phase 6 shipped a sync seam and a loopback server,
   not a population.

   Building a "global leaderboard" against a database of one is not a partial
   implementation of the feature — it is a fabrication of the thing the feature is
   for. So this file builds the ranking *engine* (metrics, tie rules, snapshots,
   percentiles, opt-out, anti-farming) and points it at the only population that
   genuinely exists: the hunter's own history. §4 already says that should be the
   primary comparison anyway, and §82 warns against making global position the
   definition of success.

   `rankAgainst()` takes a population and computes honestly over it. The day there
   are real users, it is passed a real cohort and the leaderboard turns on, with
   `rankingConfidence()` already refusing to rank a sample too small to mean
   anything.

   ## Verification means somebody outside the app looked

   §8 and §33: six states, and only the first two can be reached from inside THE
   SYSTEM. A blue tick that a user awards themselves is not verification, it is
   decoration that misleads whoever reads it later. */
"use strict";

const VERIFY_STATES = [
  { k:"selfreported", label:"Self-reported",        inApp:true,  weight:0,
    blurb:"You recorded it. That is a claim, and claims are fine — most achievements start here." },
  { k:"evidence",     label:"Evidence attached",    inApp:true,  weight:1,
    blurb:"Something is attached that a reader could check for themselves." },
  { k:"pending",      label:"Awaiting verification",inApp:true,  weight:1,
    blurb:"Submitted for review by somebody outside THE SYSTEM." },
  { k:"verified",     label:"Verified",             inApp:false, weight:2,
    blurb:"An authorised verifier checked the evidence." },
  { k:"official",     label:"Officially confirmed", inApp:false, weight:3,
    blurb:"Confirmed by the organisation that ran it." },
  { k:"rejected",     label:"Not verified",         inApp:false, weight:0,
    blurb:"Review did not confirm it. The record is kept, including the reason." },
];
const VS = Object.fromEntries(VERIFY_STATES.map(v => [v.k, v]));

/* §15 — a user cannot promote their own achievement past the in-app ceiling */
function canSetVerification(state){
  const v = VS[state];
  return !!v && v.inApp;
}
function setVerification(kind, id, state, note){
  if(!canSetVerification(state)) return { ok:false,
    reason:"Only a verifier outside THE SYSTEM can set that state. Marking your own work verified would make the word mean nothing." };
  const rec = kind === "opportunity" ? getOpp(id) : kind === "project" ? getProject(id) : null;
  if(!rec) return { ok:false, reason:"Not found" };
  const target = kind === "opportunity" ? (rec.result || (rec.result = {})) : rec;
  target.verification = state;
  target.verifiedAt = todayKey();
  if(note) target.verifyNote = String(note).slice(0, 200);
  save();
  /* §17, §64 — the history is kept, never silently rewritten */
  const b = brain();
  if(b){ b.verifyLog = (b.verifyLog || []).concat([{ kind, id, state, at:todayKey(), note: note || "" }]).slice(-100); save(); }
  return { ok:true };
}

/* §14 — the workflow exists even though no verifier does yet, so the states are
   real rather than invented later */
function requestVerification(kind, id){
  const r = setVerification(kind, id, "pending");
  if(!r.ok) return r;
  return { ok:true,
    note:"Recorded as awaiting verification. There is no verifier network yet — when a school or organiser can confirm it, this is the state they act on. Until then it reads as pending, which is honest." };
}

/* ---------- the achievement ledger (§9, §37) ---------- */
function achievementLedger(){
  const out = [];
  /* system achievements — internal by definition, and labelled so (§59) */
  const b = brain();
  for(const a of (b && b.achievements) || []){
    const def = BALANCE.achievements.find(x => x.id === a.id); if(!def) continue;
    out.push({ id:a.id, source:"system", title:def.name, category:def.cat, date:a.at,
               verification:"selfreported", internal:true,
               note:"A THE SYSTEM achievement. It describes your use of this app, not an outside accomplishment." });
  }
  /* competition results */
  if(typeof oppList === "function") for(const o of oppList()){
    if(!o.result) continue;
    out.push({ id:o.id, source:"competition", title:`${o.name} — ${o.result.kind}`,
               category:o.category, date:o.result.at, organisation:o.organiser,
               verification:o.result.verification || "selfreported", internal:false,
               evidence:o.result.evidenceUrl });
  }
  /* completed projects */
  if(typeof projects === "function") for(const p of projects()){
    if(p.stage !== "completed") continue;
    out.push({ id:p.id, source:"project", title:p.title, category:p.category, date:p.completed,
               verification:p.verification || "selfreported", internal:false,
               evidence:(p.evidence || []).length });
  }
  return out.sort((a, b_) => String(b_.date || "").localeCompare(String(a.date || "")));
}
function verificationSummary(){
  const led = achievementLedger();
  const counts = {};
  for(const v of VERIFY_STATES) counts[v.k] = led.filter(x => x.verification === v.k).length;
  return {
    total: led.length, counts,
    external: led.filter(x => !x.internal).length,
    /* the honest headline: how much of this could somebody else check? */
    checkable: led.filter(x => !x.internal && VS[x.verification] && VS[x.verification].weight >= 1).length,
  };
}

/* ══════════════ personal records (§4, §21) ══════════════ */
function recordBook(){
  const h = H(); if(!h) return [];
  const b = brain(); const r = (b && b.records) || {};
  const acad = typeof academyOverview === "function" ? academyOverview() : null;
  const led = achievementLedger();
  const rows = [
    { k:"streak",    label:"Longest streak",         v:r.bestStreak || 0, unit:"days" },
    { k:"week",      label:"Best week",              v:r.bestWeek || 0,   unit:"quests" },
    { k:"perfect",   label:"Perfect days",           v:r.perfectDays || 0,unit:"days" },
    { k:"level",     label:"Highest level",          v:r.level || h.level || 1, unit:"" },
    { k:"mastered",  label:"Topics mastered",        v:acad ? acad.mastered : 0, unit:"" },
    { k:"projects",  label:"Projects completed",     v:led.filter(x => x.source === "project").length, unit:"" },
    { k:"comps",     label:"Competition results",    v:led.filter(x => x.source === "competition").length, unit:"" },
    { k:"bosses",    label:"Bosses defeated",        v:((b && b.bosses) || []).filter(x => x.done).length, unit:"" },
  ];
  return rows;
}

/* §22, §23 — improvement is its own category, and the measure is stated */
function improvementReport(){
  const m = typeof userModel === "function" ? userModel() : null;
  if(!m || m.perf.n < 20) return { enough:false,
    note:"Improvement needs a few weeks of record before it means anything. Comparing two thin weeks measures the weather." };
  const rows = [];
  if(m.perf.prev7){
    rows.push({ k:"Clear rate", from:mPct(m.perf.prev7), to:mPct(m.perf.last7),
                delta:mPct(m.perf.last7 - m.perf.prev7), unit:"%",
                measure:"percentage-point change in quests cleared, last 7 days against the 7 before" });
  }
  const acad = typeof academyOverview === "function" ? academyOverview() : null;
  if(acad && acad.topics) rows.push({ k:"Syllabus coverage", to:mPct(acad.avg), unit:"%",
    measure:"average evidence-based mastery across every topic you track" });
  return { enough:true, rows,
    note:"Improvement is measured against your own earlier record. §23 of the design brief is right that comparing incompatible measurements produces a number that looks meaningful and is not." };
}

/* ══════════════ the ranking engine (§6, §53, §90) ══════════════
   Generic over a population so it is honest today and correct later. */
function rankingConfidence(populationSize){
  if(populationSize < 2) return { ok:false, label:"No cohort",
    text:"There is nobody to rank against. THE SYSTEM has no user network, and inventing one would be worse than saying so." };
  if(populationSize < 20) return { ok:true, label:"Limited data",
    text:`Ranked against ${populationSize}. A position in a group this small says more about who happens to be in it than about you.` };
  return { ok:true, label:"Ranked", text:`Ranked against ${populationSize}.` };
}

/* §90 — ties share a rank and the next rank skips, stated rather than hidden */
function rankAgainst(entries, metricKey){
  const sorted = [...entries].sort((a, b) => (b[metricKey] || 0) - (a[metricKey] || 0));
  let lastVal = null, lastRank = 0;
  return sorted.map((e, i) => {
    const v = e[metricKey] || 0;
    const rank = v === lastVal ? lastRank : i + 1;
    lastVal = v; lastRank = rank;
    return { ...e, rank, tied: v === lastVal && i > 0 && sorted[i-1] && (sorted[i-1][metricKey] || 0) === v };
  });
}
function percentile(rank, n){
  if(n < 20) return null;              /* §53 — needs a real sample */
  return Math.max(1, Math.round((rank / n) * 100));
}

/* §5 — specialised boards, each with an explicit metric (§6) */
const BOARDS = [
  { k:"consistency", label:"Consistency", metric:"Percentage of scheduled quests cleared, last 30 days" },
  { k:"mastery",     label:"Mastery",     metric:"Topics at 'mastered', by evidence" },
  { k:"projects",    label:"Projects",    metric:"Projects completed with evidence and a reflection" },
  { k:"improvement", label:"Improvement", metric:"Change in clear rate against your own previous period" },
];

/* Against the only real population: previous versions of this hunter. */
function personalBoards(){
  const h = H(); if(!h) return [];
  const m = typeof userModel === "function" ? userModel() : null;
  const acad = typeof academyOverview === "function" ? academyOverview() : null;
  const b = brain();
  const snaps = (b && b.snapshots) || [];
  return BOARDS.map(board => {
    const now = (() => {
      if(board.k === "consistency") return m ? mPct(m.perf.last14) : 0;
      if(board.k === "mastery")     return acad ? acad.mastered : 0;
      if(board.k === "projects")    return typeof projects === "function"
        ? projects().filter(p => p.stage === "completed" && (p.evidence||[]).length && p.reflection).length : 0;
      if(board.k === "improvement") return m && m.perf.prev7 ? mPct(m.perf.last7 - m.perf.prev7) : 0;
      return 0;
    })();
    const history = snaps.map(s => ({ at:s.at, v: (s.boards || {})[board.k] ?? 0 }));
    const best = history.reduce((x, y) => y.v > x ? y.v : x, now);
    return { ...board, now, best, history: history.slice(-6),
             confidence: rankingConfidence(1),
             isBest: now >= best && history.length > 0 };
  });
}

/* §27, §67 — snapshots, so a past standing stays reproducible */
function takeSnapshot(){
  const b = brain(); if(!b) return null;
  b.snapshots = b.snapshots || [];
  const key = todayKey().slice(0, 7);      /* one per month is plenty */
  if(b.snapshots.some(s => s.at === key)) return null;
  const boards = {};
  for(const bd of personalBoards()) boards[bd.k] = bd.now;
  b.snapshots.push({ at:key, boards, level:H().level, rank:H().rank });
  if(b.snapshots.length > 36) b.snapshots = b.snapshots.slice(-36);
  save();
  return b.snapshots[b.snapshots.length - 1];
}

/* §83 — opt-out exists before there is anything to opt out of, on purpose */
function rankingPrefs(patch){
  const b = brain(); if(!b) return null;
  b.ranking = b.ranking || { global:false, country:false, school:false, publicProfile:false };
  if(patch){ Object.assign(b.ranking, patch); save(); }
  return b.ranking;
}

/* §38, §61 — anti-farming signals, flagged for review, never auto-punished */
function integritySignals(){
  const out = [];
  const led = achievementLedger();
  const ext = led.filter(x => !x.internal);
  const noEvidence = ext.filter(x => x.verification === "selfreported").length;
  if(ext.length >= 5 && noEvidence === ext.length) out.push({
    k:"No evidence anywhere",
    text:`All ${ext.length} of your external achievements are self-reported with nothing attached.`,
    note:"That is not an accusation — most start that way. But a record nobody can check is worth much less than a shorter one they can, so attaching one link to each is the highest-value hour you could spend here.",
  });
  const sameDay = {};
  for(const x of ext) sameDay[x.date] = (sameDay[x.date] || 0) + 1;
  const burst = Object.entries(sameDay).find(([, n]) => n >= 5);
  if(burst) out.push({
    k:"Entered in a burst",
    text:`${burst[1]} achievements all dated ${burst[0]}.`,
    note:"Perfectly normal if you were catching up on a backlog. Worth knowing that a reader may read it as one, so a date per item is better where you can remember them.",
  });
  return out;
}
