/* THE SYSTEM v14 — services/projects.js
   Phase 9: projects, evidence, and the portfolio built from them.

   §2 sets the standard — not "a folder where students upload projects" but a
   system that turns ideas into finished work and finished work into credible
   evidence. Three decisions follow from that and they are the substance of this
   file.

   **1. Evidence is metadata and links, not uploads.**
   §16 allows files; §19 warns against encouraging uploads of sensitive material;
   Phase 6 has no file storage. Uploading a certificate into localStorage would
   bloat a record that has to sync over Ghanaian mobile data and would put a
   student's documents somewhere with no access control. So evidence is a
   description plus a link the student controls. The one exception, deliberately
   absent, is anything resembling an ID document — the UI refuses to suggest it.

   **2. Nothing becomes public by accident.**
   §18 and §44 both default to private, and §48 says a project must never
   automatically reach a portfolio. Publishing is a separate, deliberate act with a
   review checklist in front of it, and for a minor the default stays private
   whatever else happens.

   **3. Verification means verification.**
   §32 forbids implying THE SYSTEM checked something. There are four states and
   only two of them are reachable from inside the app, because the other two would
   require somebody outside it to actually look. */
"use strict";

const PROJECT_STAGES = [
  { k:"idea",      label:"Idea",      blurb:"Written down. Nothing built." },
  { k:"planning",  label:"Planning",  blurb:"Goal and milestones decided." },
  { k:"active",    label:"Active",    blurb:"Being built." },
  { k:"paused",    label:"Paused",    blurb:"Deliberately parked, not abandoned." },
  { k:"review",    label:"Review",    blurb:"Built. Being documented and checked." },
  { k:"completed", label:"Completed", blurb:"Finished, documented, reflected on." },
  { k:"archived",  label:"Archived",  blurb:"Kept, out of the way." },
];
const PROJECT_CATEGORIES = ["Academic","STEM","Technology","Creative","Enterprise","Community","Personal"];

/* §7 — templates guide without forcing every project into one shape */
const PROJECT_TEMPLATES = {
  research:  { label:"Research", milestones:["Question","Background reading","Method","Collect data","Analyse","Conclusion","Write up"] },
  software:  { label:"Software", milestones:["Problem","Requirements","Design","Build","Test","Document","Release"] },
  robotics:  { label:"Robotics", milestones:["Problem","Research","Design","Parts","Build","Program","Test","Iterate"] },
  business:  { label:"Business", milestones:["Problem","Who it is for","Research","Solution","Prototype","Test with users","Results"] },
  community: { label:"Community", milestones:["Problem","The people affected","Plan","Act","Involve others","Measure impact","Reflect"] },
  creative:  { label:"Creative", milestones:["Idea","References","First draft","Feedback","Revise","Finish","Show it"] },
  blank:     { label:"Blank", milestones:["Milestone one","Milestone two","Milestone three"] },
};

/* §32 — and only the first two can be set from inside the app */
const EVIDENCE_VERIFY = [
  { k:"selfreported", label:"Self-reported", inApp:true,  blurb:"You said it happened." },
  { k:"evidence",     label:"Evidence attached", inApp:true, blurb:"You attached something that shows it." },
  { k:"verified",     label:"Verified", inApp:false, blurb:"Someone outside THE SYSTEM checked it." },
  { k:"official",     label:"Officially confirmed", inApp:false, blurb:"Confirmed by the organisation itself." },
];
const VISIBILITY = [
  { k:"private",   label:"Private",   blurb:"Only you." },
  { k:"portfolio", label:"Portfolio", blurb:"Shown on your portfolio." },
  { k:"link",      label:"Shared link", blurb:"Anyone with the link. Still not indexed anywhere." },
];

/* ---------- storage ---------- */
function projectStore(){
  const h = H(); if(!h) return null;
  if(!h.projects) h.projects = { items:[], portfolio:{ about:"", headline:"", sections:[], theme:"minimal", visibility:"private" } };
  const p = h.projects;
  if(!Array.isArray(p.items)) p.items = [];
  if(!p.portfolio) p.portfolio = { about:"", headline:"", sections:[], theme:"minimal", visibility:"private" };
  return p;
}
const projects   = () => projectStore() ? projectStore().items : [];
const getProject = id => projects().find(p => p.id === id) || null;

/* §6 — creating a project asks four things, not a form */
function createProject({ title, description = "", category = "Technology", template = "blank",
                         goal = "", competitionId = null, opportunityId = null, topicId = null }){
  const st = projectStore(); if(!st) return null;
  const t = PROJECT_TEMPLATES[template] || PROJECT_TEMPLATES.blank;
  const p = {
    id: uid(), title:String(title||"").slice(0,120).trim(),
    description:String(description).slice(0,400),
    category: PROJECT_CATEGORIES.includes(category) ? category : "Technology",
    template, goal:String(goal).slice(0,300),
    stage:"idea", created: todayKey(), completed:null,
    milestones: t.milestones.map(m => ({ id:uid(), name:m, done:false, at:null, weight:1 })),
    tasks: [], evidence: [], timeline: [{ id:uid(), at:todayKey(), text:"Project created" }],
    versions: [], reflection:null, skills: [],
    competitionId, opportunityId, topicId,
    visibility:"private", verification:"selfreported",
    featured:false, archived:false,
  };
  if(!p.title) return null;
  st.items.push(p); save(); markChanged("projects","created");
  grantXp(20, `Project started — ${p.title}`, { once:"projnew:" + p.id });
  return p;
}
function setProjectStage(id, stage){
  const p = getProject(id); if(!p || !PROJECT_STAGES.some(s => s.k === stage)) return false;
  if(p.stage === stage) return true;
  p.stage = stage;
  p.timeline.push({ id:uid(), at:todayKey(), text:`Moved to ${stage}` });
  if(stage === "completed"){
    p.completed = todayKey();
    grantXp(BALANCE.xp.milestone, `Project completed — ${p.title}`, { once:"projdone:" + p.id });
  }
  save(); markChanged("projects","stage");
  return true;
}
function archiveProject(id, on = true){
  const p = getProject(id); if(!p) return false;
  p.archived = !!on; if(on) p.stage = "archived";     /* §65 — archived, never deleted */
  save(); return true;
}
function deleteProject(id){
  const st = projectStore(); if(!st) return false;
  st.items = st.items.filter(x => x.id !== id); save(); markChanged("projects","deleted"); return true;
}

/* ---------- milestones (§9, §11) ----------
   §9 — progress is weighted milestones, not a task count, so "wrote the readme"
   and "built the thing" do not count the same. */
function toggleMilestone(projectId, msId){
  const p = getProject(projectId); if(!p) return false;
  const m = (p.milestones || []).find(x => x.id === msId); if(!m) return false;
  m.done = !m.done; m.at = m.done ? todayKey() : null;
  if(m.done){
    p.timeline.push({ id:uid(), at:todayKey(), text:`Milestone: ${m.name}` });
    if(p.stage === "idea" || p.stage === "planning") p.stage = "active";
    grantXp(30, `Milestone — ${p.title}`, { once:"projms:" + msId });
  }
  save(); markChanged("projects","milestone");
  return true;
}
function setMilestoneWeight(projectId, msId, weight){
  const p = getProject(projectId); if(!p) return false;
  const m = (p.milestones || []).find(x => x.id === msId); if(!m) return false;
  m.weight = Math.max(1, Math.min(5, Number(weight) || 1)); save(); return true;
}
function projectProgress(p){
  const ms = p.milestones || [];
  const total = ms.reduce((s, m) => s + (m.weight || 1), 0);
  const done = ms.filter(m => m.done).reduce((s, m) => s + (m.weight || 1), 0);
  return {
    pct: total ? done / total : 0,
    done: ms.filter(m => m.done).length, n: ms.length,
    next: ms.find(m => !m.done) || null,
  };
}

/* ---------- evidence (§16, §17, §19) ---------- */
const SENSITIVE_HINT = /passport|national id|birth certificate|bank|password|address|social security|ghana card/i;
function addEvidence(projectId, { name, kind = "link", url = "", description = "", milestoneId = null }){
  const p = getProject(projectId); if(!p) return null;
  const e = {
    id: uid(), name:String(name||"").slice(0,120).trim(), kind,
    url:String(url).slice(0,500), description:String(description).slice(0,400),
    milestoneId, at: todayKey(), visibility:"private",
  };
  if(!e.name) return null;
  p.evidence.push(e);
  if(p.verification === "selfreported") p.verification = "evidence";
  p.timeline.push({ id:uid(), at:todayKey(), text:`Evidence: ${e.name}` });
  save(); markChanged("projects","evidence");
  return e;
}
/* §19 — warn before, not after */
function evidenceWarning(text){
  return SENSITIVE_HINT.test(String(text || ""))
    ? "That looks like it might be an identity or financial document. Do not put one in a portfolio, and do not link to one from anywhere public. Describe the achievement instead."
    : null;
}
function setEvidenceVisibility(projectId, evId, visibility){
  const p = getProject(projectId); if(!p) return false;
  const e = (p.evidence || []).find(x => x.id === evId); if(!e) return false;
  if(!VISIBILITY.some(v => v.k === visibility)) return false;
  e.visibility = visibility; save(); return true;
}

/* ---------- versions & iteration (§14, §15) ---------- */
function addVersion(projectId, { label, changed = "", why = "" }){
  const p = getProject(projectId); if(!p) return null;
  const v = { id:uid(), label:String(label||"").slice(0,40), changed:String(changed).slice(0,300),
              why:String(why).slice(0,300), at: todayKey() };
  p.versions.push(v);
  p.timeline.push({ id:uid(), at:todayKey(), text:`Version ${v.label}` });
  save(); return v;
}

/* ---------- reflection (§28, §29) ---------- */
const REFLECTION_PROMPTS = [
  { k:"problem",   q:"What problem were you solving?" },
  { k:"process",   q:"How did you approach it?" },
  { k:"challenge", q:"What was hardest?" },
  { k:"result",    q:"What did you end up with?" },
  { k:"learning",  q:"What do you know now that you did not?" },
  { k:"next",      q:"What would you do differently?" },
];
function saveReflection(projectId, answers){
  const p = getProject(projectId); if(!p) return false;
  p.reflection = { at: todayKey(), answers: { ...(answers || {}) } };
  p.timeline.push({ id:uid(), at:todayKey(), text:"Reflection written" });
  save(); markChanged("projects","reflection");
  grantXp(BALANCE.xp.reflection, `Reflection — ${p.title}`, { once:"projref:" + projectId });
  return true;
}

/* ---------- quality dimensions (§35) ----------
   §35 forbids a single mysterious "project quality score", and it is right: one
   number invites optimising the number. Dimensions tell a student what is actually
   missing, which is the only useful thing feedback can do here. */
function projectDimensions(p){
  const prog = projectProgress(p);
  const dims = [
    { k:"planning",  label:"Planning",      have: prog.n >= 3, note:"At least three milestones defined." },
    { k:"execution", label:"Execution",     have: prog.pct >= 0.6, note:"Most of the milestones actually done." },
    { k:"iteration", label:"Iteration",     have: (p.versions || []).length >= 2, note:"Evidence you changed it after finding problems." },
    { k:"evidence",  label:"Evidence",      have: (p.evidence || []).length >= 1, note:"Something showing it exists." },
    { k:"reflection",label:"Reflection",    have: !!p.reflection, note:"You wrote down what you learnt." },
    { k:"skills",    label:"Skills named",  have: (p.skills || []).length >= 1, note:"Which skills this developed." },
  ];
  return { dims, met: dims.filter(d => d.have).length, total: dims.length };
}

/* §36 — the review that stands between a project and a portfolio */
function publishReadiness(id){
  const p = getProject(id); if(!p) return null;
  const { dims, met, total } = projectDimensions(p);
  const blockers = [];
  if(p.stage !== "completed" && p.stage !== "review") blockers.push("The project is not marked completed yet.");
  if(!(p.evidence || []).length) blockers.push("There is no evidence attached — a portfolio entry with nothing behind it is a claim, not a demonstration.");
  if(!p.reflection) blockers.push("No reflection written. What you learnt is the part a reader cannot get from a link.");
  return { dims, met, total, ready: blockers.length === 0, blockers };
}

/* ---------- skills (§22, §23) ----------
   §23 — "Programming +50" means nothing. A skill claim carries the evidence
   sentence, or it does not go on the portfolio. */
function attachSkill(projectId, { name, evidence }){
  const p = getProject(projectId); if(!p) return null;
  const s = { id:uid(), name:String(name||"").slice(0,60).trim(), evidence:String(evidence||"").slice(0,300).trim() };
  if(!s.name || !s.evidence) return null;    /* evidence is not optional */
  p.skills.push(s); save(); return s;
}

/* ══════════════ portfolio (§37–§45) ══════════════ */
function portfolio(){ const st = projectStore(); return st ? st.portfolio : null; }
function updatePortfolio(patch){
  const pf = portfolio(); if(!pf) return null;
  for(const k of ["about","headline","theme"]) if(k in patch) pf[k] = String(patch[k] || "").slice(0, k === "about" ? 900 : 120);
  if("visibility" in patch && ["private","link","public"].includes(patch.visibility)) pf.visibility = patch.visibility;
  save(); markChanged("projects","portfolio");
  return pf;
}
/* §48 — selecting is a deliberate act, and it can be refused */
function featureProject(id, on = true){
  const p = getProject(id); if(!p) return { ok:false, reason:"not found" };
  if(on){
    const r = publishReadiness(id);
    if(!r.ready) return { ok:false, reason:"not ready", blockers:r.blockers };
    p.featured = true; p.visibility = "portfolio";
  } else {
    p.featured = false; p.visibility = "private";
  }
  save(); markChanged("projects","featured");
  return { ok:true };
}
/* §42, §43 — what a visitor would actually see, and nothing else */
function portfolioPreview(){
  const pf = portfolio(); if(!pf) return null;
  const h = H();
  const featured = projects().filter(p => p.featured && !p.archived);
  const wins = typeof oppList === "function"
    ? oppList().filter(o => o.result && o.result.kind !== "Not selected")
    : [];
  const acts = typeof opps === "function" && opps() ? (opps().activities || []).filter(a => activityDepth(a).months >= 3) : [];
  return {
    headline: pf.headline || "",
    about: pf.about || "",
    theme: pf.theme,
    visibility: pf.visibility,
    /* §31 — a display name, never a legal name by default */
    name: (h && h.name) || "Hunter",
    projects: featured.map(p => ({
      title:p.title, category:p.category, description:p.description,
      progress: projectProgress(p).pct, completed:p.completed,
      skills: p.skills, evidence: (p.evidence || []).filter(e => e.visibility !== "private").map(e => ({ name:e.name, url:e.url })),
      verification: p.verification,
    })),
    competitions: wins.map(o => ({ name:o.name, organiser:o.organiser, result:o.result.kind,
                                   verification:o.result.verification, at:o.result.at })),
    activities: acts.map(a => ({ name:a.name, role:a.role, organisation:a.organisation, months: activityDepth(a).months })),
    /* §43 — the things that must never leave, listed so the check is visible */
    excluded: ["private evidence","contact details","school name","exact location","anything you marked private"],
  };
}
/* §44 — public requires a deliberate act, and the warning is not buried */
function portfolioPublishWarning(){
  return [
    "A shared link is guessable only if you share it. THE SYSTEM does not list, index or advertise it anywhere.",
    "Private evidence stays private — only items you explicitly set to portfolio visibility appear.",
    "Do not put your school, your address, your phone number or your exact location in the About text. There is no reason a portfolio needs them.",
    "You can revoke it at any time, and revoking is immediate.",
  ];
}

/* ---------- links out (§49–§52) ---------- */
function projectFromCompetition(oppId){
  const o = typeof getOpp === "function" ? getOpp(oppId) : null; if(!o) return null;
  return createProject({ title:o.name + " — entry", category:"STEM", template:"blank",
                         goal:"Prepare and submit an entry for " + o.name, competitionId:oppId });
}
function projectFromTopic(topicId){
  const t = typeof getTopic === "function" ? getTopic(topicId) : null; if(!t) return null;
  return createProject({ title:`${t.name} — build something with it`, category:"Academic",
                         template:"research", goal:`Turn ${t.name} from something you revise into something you used`,
                         topicId });
}
/* §53, §55 — suggestions from the record, never a claim about requirements */
function projectSuggestions(){
  const out = [];
  const list = projects().filter(p => !p.archived);
  const undoc = list.filter(p => p.stage === "completed" && !p.reflection);
  if(undoc.length) out.push({
    text:`${undoc.length} completed project${undoc.length===1?"":"s"} with no reflection written.`,
    why:"A finished project nobody can read about is hard to point at later. The reflection is ten minutes and it is the part that lasts.",
    go:["build","b-projects"] });
  const noEv = list.filter(p => p.stage === "completed" && !(p.evidence || []).length);
  if(noEv.length) out.push({
    text:`${noEv.length} completed with no evidence attached.`,
    why:"A link to the repository, the document or a photo is what turns a claim into a demonstration.",
    go:["build","b-projects"] });
  const cats = new Set(list.map(p => p.category));
  if(list.length >= 3 && cats.size === 1) out.push({
    text:`Everything you have built is ${[...cats][0]}.`,
    why:"Depth is genuinely valuable, so this is not a criticism. But one project in a different direction tells you something about yourself that three more of the same will not.",
    go:["build","b-projects"] });
  if(!list.length) out.push({
    text:"No projects yet.",
    why:"The smallest real thing beats the best-planned imaginary one. Pick something you could show somebody in two weeks.",
    go:["build","b-projects"] });
  return out;
}

/* ---------- growth timeline (§63) ---------- */
function growthTimeline(){
  const events = [];
  for(const p of projects()){
    if(p.completed) events.push({ at:p.completed, kind:"Project", text:p.title });
    else if(p.created) events.push({ at:p.created, kind:"Started", text:p.title });
  }
  if(typeof oppList === "function") for(const o of oppList()){
    if(o.result) events.push({ at:o.result.at, kind:"Result", text:`${o.name} — ${o.result.kind}` });
  }
  if(typeof brain === "function"){
    const b = brain();
    for(const a of (b && b.achievements) || []){
      const def = BALANCE.achievements.find(x => x.id === a.id);
      if(def) events.push({ at:a.at, kind:"Achievement", text:def.name });
    }
    for(const bo of (b && b.bosses) || []) if(bo.done) events.push({ at:bo.doneAt, kind:"Boss", text:bo.name });
  }
  return events.filter(e => e.at).sort((a, b) => String(b.at).localeCompare(String(a.at))).slice(0, 40);
}
