/* THE SYSTEM v14 — services/journey.js
   The diagram made live.

       LEARN · DEVELOP · DISCOVER  →  BUILD  →  ACHIEVE  →  CONNECT  →  GROW  →  FUTURE

   The point of putting it in code rather than in a README is that it becomes
   answerable. A student can ask "where am I actually stuck?" and get a stage back,
   computed from their own record.

   The verdict deliberately names the **earliest empty stage**, not the furthest one
   reached. Someone with three projects and no finished topic is not "at BUILD" —
   they have skipped LEARN, and telling them they are advanced would be flattery
   with a progress bar attached. */
"use strict";

const JOURNEY = [
  { k:"learn",    label:"LEARN",    go:["academy","ac-home"],
    what:"Subjects with evidence behind them, not just opened." },
  { k:"develop",  label:"DEVELOP",  go:["grow","tr-skill"],
    what:"Skills and crafts practised on a schedule." },
  { k:"discover", label:"DISCOVER", go:["beyond","bo-recommended"],
    what:"Opportunities and competitions you are actually tracking." },
  { k:"build",    label:"BUILD",    go:["build","b-projects"],
    what:"Something finished that exists outside the app." },
  { k:"achieve",  label:"ACHIEVE",  go:["path","p-verify"],
    what:"A result or achievement recorded, with evidence where possible." },
  { k:"connect",  label:"CONNECT",  go:["circle","c-groups"],
    what:"One person who knows what you are working on." },
  { k:"grow",     label:"GROW",     go:["insight","in-review"],
    what:"A measurable change against your own earlier record." },
  { k:"future",   label:"FUTURE",   go:["quests","q-goals"],
    what:"A goal further out than this term, with steps under it." },
];

function journeyState(){
  const h = H(); if(!h) return null;
  const acad = typeof academyOverview === "function" ? academyOverview() : null;
  const m = typeof userModel === "function" ? userModel() : null;
  const c = typeof community === "function" ? community() : null;
  const projs = typeof projects === "function" ? projects().filter(p => !p.archived) : [];
  const led = typeof achievementLedger === "function" ? achievementLedger() : [];

  const evidence = {
    learn:    acad ? acad.subjects.reduce((n, s) => n + s.topics.filter(t => t.m.pct >= 0.5).length, 0) : 0,
    develop:  (h.skills || []).length + (h.hobbies || []).length,
    discover: typeof oppList === "function" ? oppList().length : 0,
    build:    projs.filter(p => p.stage === "completed").length,
    achieve:  led.filter(x => !x.internal).length,
    connect:  c ? (c.groups || []).length + (c.pacts || []).length : 0,
    grow:     m && m.perf.prev7 && m.perf.last7 > m.perf.prev7 ? 1 : 0,
    future:   (Array.isArray(h.goals) ? h.goals : []).filter(g =>
                ["year","half","quarter"].includes(g.horizon) &&
                (g.targets || []).some(t => (t.steps || []).length)).length,
  };

  const stages = JOURNEY.map(s => ({ ...s, count: evidence[s.k] || 0, reached: (evidence[s.k] || 0) > 0 }));
  const firstGap = stages.find(s => !s.reached) || null;
  const reached = stages.filter(s => s.reached).length;

  return {
    stages, reached, total: stages.length, gap: firstGap,
    verdict: !firstGap
      ? "Every stage of the loop has something real in it. That is rarer than it sounds — the thing to do now is go round again with something harder."
      : reached === 0
        ? `Nothing on the map yet. Start at ${firstGap.label}: ${firstGap.what}`
        : `${reached} of ${stages.length} stages have something in them. The earliest gap is ${firstGap.label} — ${firstGap.what.toLowerCase()} Skipping forward is how people end up with a portfolio and no foundation.`,
  };
}
