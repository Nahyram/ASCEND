/* ASCEND — module-check.js
   The guards that make an incremental ES module migration safe to continue.

   ## The three things that go wrong

   1. **The committed bundle drifts from its source.** system/bundle.js is a build
      artefact that is committed so index.html opens with no toolchain. This
      project has shipped exactly this bug twice already: the service worker's
      precache list drifted 20 modules behind index.html and broke the app
      offline for three releases, and the version drifted across four files and
      then into package-lock during 18.7. A generated file nobody regenerates is
      a generated file that lies. So the bundle is rebuilt here and compared byte
      for byte.

   2. **The bridge becomes permanent.** src/entry.js republishes module exports
      onto `window` so the not-yet-converted classic scripts still resolve them.
      That is the exact pattern the migration exists to remove, and a temporary
      measure with no expiry is just an architecture. Every bridged name must be
      referenced by a remaining classic script; the day nothing needs it, it must
      leave the bridge. The migration is done when the bridge is empty.

   3. **The migration runs backwards.** Nothing stops a later change from adding
      a classic script, or from moving a converted module back out. The counts
      below are a ratchet: they may go down, never up. When they go down, the
      numbers here are updated deliberately in the same commit.

   ## Why the numbers are written down rather than computed

   A check that measures the build and compares it to itself always passes. The
   floor has to be a literal that a person edits, because the point is to make
   going backwards require a decision. */
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const ROOT = process.env.ROOT || "./system";
const SRC = path.join(ROOT, "src");

/* ── the ratchet ──────────────────────────────────────────────
   Update these in the same commit that moves them, never separately. */
/* 89 → 76 (18.8) → 77 (18.15).

   This one went the WRONG WAY, and the reason is worth writing down rather than
   quietly raising: services/vacation.js is new service code, and its consumers
   (services/day.js, views/progression.js) are still classic scripts. Written as
   an ES module it would have had to reach for H(), save() and uid() as bare
   globals — a module depending on classic code, which inverts the dependency the
   migration exists to establish and is worse than one more classic file.

   That is the same finding as 18.12's bridge growth, from the other direction:
   **the migration cannot progress by adding leaves, and new code cannot be a
   module until its consumers are.** Converting services/day.js, views/*.js and
   the other consumers is now overdue, and this number will keep drifting up
   until it happens. */
const MAX_CLASSIC_SCRIPTS = 72;
/* 32 → 34 (18.10) → 37 (18.12). A ceiling exists to make going backwards require
   a decision, not to make it impossible, and check 8 still holds so nothing sits
   here without a live consumer.

   But three raises in three releases is itself the finding: the bridge grows
   every time new module code is written for classic consumers, and it only
   shrinks when a CONSUMER converts. Converting more leaves cannot reduce it. The
   next tranche has to be consumers — services/recommend.js, services/link.js,
   services/progression.js — or this number keeps climbing while the migration
   appears to be progressing. */
/* 32 → 34 → 37 → 56 (18.16), and the jump is the point.

   I have called bridge growth a warning sign twice. It is not. The bridge holds
   module exports that classic scripts still consume, so converting a ROOT — as
   18.16 converted core/kernel.js — necessarily adds every name it owns: $, H,
   save, DB and the rest, read by 72 files. The bridge can only shrink when the
   LAST classic consumer of a name converts, which in a leaf-to-root migration is
   near the end.

   So this ceiling is not the health metric. MAX_CLASSIC_SCRIPTS is, and it moves
   monotonically down: 89 → 76 → 77 → 72. Check 8 keeps this list honest in the
   meantime by refusing any name nothing consumes. */
const MAX_BRIDGED_NAMES   = 56;   /* module exports still handed back to window */
const MIN_MODULES         = 21;   /* files under system/src/, entry.js included */

let pass = 0, fail = 0;
function ok(label, cond, detail) {
  if (cond) { pass++; console.log("  PASS  " + label); }
  else { fail++; console.log("  FAIL  " + label); }
  if (detail) console.log("         " + detail);
}

console.log("\nmodule-check — the ES module migration\n");

/* ---------- 1. the bundle matches its source ---------- */
{
  let out = "", threw = null;
  try {
    out = execFileSync(process.execPath, ["build.js", "--check"], { encoding: "utf8", stdio: "pipe" });
  } catch (e) { threw = String(e.stderr || e.stdout || e.message).trim(); }
  ok("system/bundle.js is what system/src/ compiles to", !threw,
    threw || out.trim());
}

/* ---------- 2. nothing loads the converted files as classic scripts ---------- */
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const scripts = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]);
{
  const strays = scripts.filter(s => s.startsWith("src/"));
  ok("index.html loads the bundle, not the module source",
    scripts.includes("bundle.js") && strays.length === 0,
    strays.length ? "loaded directly: " + strays.join(", ")
      : scripts.includes("bundle.js") ? "bundle.js is loaded first at position " + (scripts.indexOf("bundle.js") + 1)
        : "bundle.js is not loaded at all");
}

/* ---------- 3. the ratchet ---------- */
const modules = [];
(function walk(d) {
  if (!fs.existsSync(d)) return;
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) walk(p); else if (e.name.endsWith(".js")) modules.push(p);
  }
})(SRC);

ok("the number of classic scripts has not gone up",
  scripts.length <= MAX_CLASSIC_SCRIPTS,
  `${scripts.length} classic scripts (ceiling ${MAX_CLASSIC_SCRIPTS}); ${modules.length} ES modules`);

ok("the number of converted modules has not gone down",
  modules.length >= MIN_MODULES,
  `${modules.length} modules under system/src/ (floor ${MIN_MODULES})`);

/* ---------- 4. every module actually exports ---------- */
{
  const silent = modules
    .filter(m => path.basename(m) !== "entry.js")
    .filter(m => !/^export\s/m.test(fs.readFileSync(m, "utf8")));
  ok("every file under system/src/ is a module with exports", silent.length === 0,
    silent.length ? "no export statement: " + silent.map(m => path.relative(ROOT, m)).join(", ")
      : `${modules.length - 1} modules, all exporting`);
}

/* ---------- 5. the bridge is honest ----------
   Read from the built bundle rather than from entry.js, so this measures what
   actually shipped. A comment claiming a name was removed proves nothing; the
   compiled array is the truth. */
const bundle = fs.readFileSync(path.join(ROOT, "bundle.js"), "utf8");
const bridged = (() => {
  const m = bundle.match(/BRIDGE\s*=\s*\{([\s\S]*?)\n\s*\};/);
  if (!m) return null;
  /* Comments inside the object literal were being read as bridged names: a line
     beginning "ALLD, QUOTES, WALL..." inside a /* *\/ block matched the same
     pattern as a property, and the check then demanded a consumer for a word in
     a sentence. Strip comments first. */
  return [...m[1].replace(/\/\*[\s\S]*?\*\//g, "").matchAll(/^\s*([A-Za-z_$][\w$]*)\s*[,:]/gm)].map(x => x[1]);
})();

ok("the bridge can be read out of the shipped bundle", Array.isArray(bridged) && bridged.length > 0,
  bridged ? `${bridged.length} names republished to window` : "could not find BRIDGE in bundle.js");

if (bridged) {
  ok("the bridge has not grown", bridged.length <= MAX_BRIDGED_NAMES,
    `${bridged.length} bridged (ceiling ${MAX_BRIDGED_NAMES})`);

  /* Every bridged name must still be needed by something that has not been
     converted. When its last consumer converts, the name comes off this list. */
  const classicSrc = scripts
    .filter(s => s !== "bundle.js")
    .map(s => fs.readFileSync(path.join(ROOT, s), "utf8"))
    .join("\n");
  const unused = bridged.filter(n =>
    !new RegExp("(?<![\\w$.])" + n.replace(/\$/g, "\\$") + "(?![\\w$])").test(classicSrc));
  ok("no name is bridged that nothing still needs", unused.length === 0,
    unused.length
      ? "bridged but unreferenced — remove from src/entry.js: " + unused.join(", ")
      : "all " + bridged.length + " are still consumed by classic scripts");
}

/* ---------- 6. the bundle is the only thing writing globals ----------
   The seam is allowed to publish; anything else doing it would be a second,
   undeclared bridge, which is how the first one would become permanent. */
{
  const entry = fs.readFileSync(path.join(SRC, "entry.js"), "utf8");
  const others = modules
    .filter(m => path.basename(m) !== "entry.js")
    .filter(m => /\b(?:window|globalThis|self)\s*\.\s*[A-Za-z_$][\w$]*\s*=[^=]/.test(fs.readFileSync(m, "utf8")))
    .map(m => path.relative(ROOT, m));
  ok("only src/entry.js publishes to global scope", others.length === 0 && /globalThis\[/.test(entry),
    others.length ? "also writes globals: " + others.join(", ") : "entry.js is the only publisher");

  /* The namespace is allowed to exist; a second undeclared bridge is not. */
  ok("the deliberate API surface is a single frozen namespace",
    /globalThis\.ASCEND = Object\.freeze\(/.test(entry),
    "src/entry.js exposes ASCEND as a frozen object rather than more bare globals");
}

/* ---------- 10. the bundle must survive a page it does not recognise ----------

   18.16 found this the hard way. views/wall.js attached three onclick handlers
   at top level — harmless for eight releases as a classic script, because it
   loaded after the markup. Bundled, it is a module, and a module that throws
   during initialisation takes EVERY other module down with it, including the
   bridge that publishes $, H, save and DB to 72 classic scripts. One view
   touching a missing element would have blanked the whole app.

   The first version of this check looked for `$(` in top-level lines. It passed
   against a wall.js that still touches the DOM at import time through a
   one-line-deep call — a syntactic guess dressed as a guarantee. This loads the
   real bundle into a page with NO app markup at all and asks whether the bridge
   survived, which is the property that actually matters and the one that broke. */
{
  const { JSDOM, VirtualConsole } = require("jsdom");
  const vc = new VirtualConsole();
  const thrown = [];
  vc.on("jsdomError", e => thrown.push(String((e && e.message) || e)));
  const dom = new JSDOM("<!doctype html><body></body>", {
    runScripts: "dangerously", url: "https://local.test/", virtualConsole: vc });
  const w = dom.window;
  Object.defineProperty(w, "crypto", { value: { getRandomValues: a => a, subtle: {} }, configurable: true });
  w.matchMedia = q => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {} });
  const el = dom.window.document.createElement("script");
  el.textContent = bundle;
  dom.window.document.body.appendChild(el);

  const published = typeof w.H === "function" && typeof w.save === "function" && !!w.ASCEND;
  dom.window.close();
  ok("the bundle still publishes its bridge on a page with no app markup", published,
    published
      ? "initialisation survives a bare DOM"
      : "the bridge was never published — an import-time throw took the bundle down: " +
        (thrown[0] || "no error captured"));
}

console.log(`\n  ${pass} passed · ${fail} failed\n`);
if (fail) { console.log("module-check FAILED\n"); process.exit(1); }
console.log("module-check clean\n");
