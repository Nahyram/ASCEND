/* Boot THE SYSTEM v13 in jsdom, create a hunter, and walk every view. */
const { JSDOM, VirtualConsole } = require("jsdom");
const fs = require("fs"), path = require("path");
const ROOT = "./system";

const errors = [];
const vc = new VirtualConsole();
vc.on("jsdomError", e => errors.push("JSDOM: " + (e.message || e)));
vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");

const dom = new JSDOM(html, {
  runScripts: "dangerously",
  resources: undefined,
  url: "https://local.test/",
  virtualConsole: vc,
  pretendToBeVisual: true,
});
const w = dom.window, d = w.document;

/* shims jsdom lacks */
w.crypto = w.crypto || {};
const nodeCrypto = require("crypto");
w.crypto.getRandomValues = a => { nodeCrypto.randomFillSync(Buffer.from(a.buffer, a.byteOffset, a.byteLength)); return a; };
w.crypto.subtle = w.crypto.subtle || { importKey: async () => ({}), deriveBits: async () => new Uint8Array(32).buffer, digest: async () => new Uint8Array(32).buffer, deriveKey: async () => ({}), encrypt: async () => new Uint8Array(16).buffer, decrypt: async () => new Uint8Array(16).buffer };
w.matchMedia = w.matchMedia || (q => ({ matches:false, media:q, addEventListener(){}, removeEventListener(){}, addListener(){}, removeListener(){} }));
w.scrollTo = () => {};
w.HTMLElement.prototype.scrollIntoView = () => {};
w.AudioContext = function(){ return { createGain:()=>({connect(){},gain:{value:0,setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}}}), createOscillator:()=>({connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}},type:""}), createBufferSource:()=>({connect(){},start(){},stop(){},buffer:null,loop:false}), createBuffer:()=>({getChannelData:()=>new Float32Array(1000)}), createBiquadFilter:()=>({connect(){},frequency:{value:0},type:"",Q:{value:0}}), destination:{}, sampleRate:44100, currentTime:0, close(){}, resume(){} }; };
w.indexedDB = undefined;

/* load the scripts in document order */
const srcs = [...d.querySelectorAll("script[src]")].map(s => s.getAttribute("src"));
for(const s of srcs){
  const p = path.join(ROOT, s);
  if(!fs.existsSync(p)){ errors.push("MISSING SCRIPT " + s); continue; }
  try{
    const el = d.createElement("script");
    el.textContent = fs.readFileSync(p, "utf8");
    d.body.appendChild(el);
  }catch(e){ errors.push(`LOAD ${s}: ${e.message}`); }
}

let BRIDGE = null;
const G = name => (BRIDGE ? BRIDGE[name] : undefined);
function makeBridge(){
  const el = d.createElement("script");
  el.textContent = 'window.__T = { H, save, todayKey, renderAll, go, VIEWS, coachNotes, renderInsight, buildPalette, openPalette, closePalette, sysConfirm, setTheme, get palIndex(){ return palIndex; } };';
  d.body.appendChild(el);
  BRIDGE = w.__T;
}

function step(label, fn){
  try{ fn(); }catch(e){ errors.push(`${label}: ${e.message}`); }
}

(async () => {
  makeBridge();
  /* boot animation writes into #bootlog on a timer; force the login screen */
  await new Promise(r => setTimeout(r, 1600));

  step("register", () => {
    d.getElementById("scr-login").classList.remove("hidden");
    d.getElementById("btnNewHunter").click();
    d.getElementById("regName").value = "Test Hunter";
    d.getElementById("regTitle").value = "The Verifier";
    d.getElementById("regGo").click();
  });

  step("onboard", () => {
    d.querySelector('#obWorkout .chip[data-w="calisthenics"]').click();
    d.querySelectorAll('[data-next]').forEach(b => { if(b.dataset.next === "2") b.click(); });
    d.querySelectorAll('[data-next]').forEach(b => { if(b.dataset.next === "3") b.click(); });
    d.querySelectorAll('[data-next]').forEach(b => { if(b.dataset.next === "4") b.click(); });
  });

  await new Promise(r => setTimeout(r, 50));
  step("finish", () => d.getElementById("obFinish").click());
  await new Promise(r => setTimeout(r, 400));

  /* This check used to call getElementById("app") and stop there. index.html had
     two elements carrying that id — a vestigial v12 wrapper that was never
     closed, and the real container inside it — and getElementById returns the
     first in tree order. enterSystem() unhid the wrapper, this check confirmed
     the wrapper was unhidden, and the container holding every tabpane stayed
     display:none. The app rendered nothing and the suite reported clean.

     So: assert that the content is actually reachable, by walking up from a real
     pane looking for any hidden ancestor. That question has one answer no matter
     how many elements share an id. */
  step("app visible", () => {
    const apps = d.querySelectorAll("#app");
    if(apps.length !== 1) throw new Error(`${apps.length} elements carry id="app" — getElementById reads only the first`);
    const pane = d.getElementById("tab-home");
    if(!pane) throw new Error("no #tab-home pane");
    const blocked = [];
    for(let n = pane; n && n !== d.body; n = n.parentElement){
      if(n.classList && n.classList.contains("hidden")) blocked.push(n.tagName + (n.id ? "#" + n.id : ""));
    }
    if(blocked.length) throw new Error("tab-home is invisible — hidden ancestor(s): " + blocked.join(" <- "));
    if(!d.querySelectorAll("#rail .sys-navbtn").length) throw new Error("rail not built");
  });

  /* seed some history so the coach and analytics have something to read */
  step("seed history", () => {
    const h = G("H")();
    for(let i = 1; i <= 40; i++){
      const dt = new Date(); dt.setDate(dt.getDate() - i);
      const key = G("todayKey")(dt), dow = dt.getDay();
      const due = h.quests.filter(q => q.days.includes(dow));
      h.done[key] = {};
      due.forEach((q, n) => { if((i + n) % 3 !== 0) h.done[key][q.id] = true; });
    }
    G("save")();
  });

  step("renderAll", () => G("renderAll")());

  for(const v of G("VIEWS")){
    step("view:" + v.k, () => {
      G("go")(v.k);
      const pane = d.getElementById(v.id);
      if(!pane) throw new Error("no pane " + v.id);
      if(pane.classList.contains("hidden")) throw new Error("pane stayed hidden");
      pane.querySelectorAll(":scope > .segbar:not(.sub) button").forEach(b => b.click());
    });
  }

  step("coach", () => {
    const n = G("coachNotes")(4);
    if(!Array.isArray(n)) throw new Error("coachNotes did not return an array");
    console.log("  coach notes:", n.length);
    n.forEach(x => console.log("   ·", x.tone, "—", x.text));
  });

  step("insight", () => {
    G("go")("insight"); G("renderInsight")();
    const s = d.getElementById("anaSummary").textContent;
    if(!/quest-days/.test(s)) throw new Error("analytics summary empty: " + s);
    console.log("  analytics:", s);
  });

  step("palette", () => {
    G("buildPalette")();
    G("openPalette")();
    const inp = d.getElementById("palIn");
    inp.value = "focus";
    inp.oninput();
    const rows = d.querySelectorAll("[data-pal]").length;
    if(!rows) throw new Error("palette returned nothing for 'focus'");
    console.log("  palette hits for 'focus':", rows, "| indexed:", G("palIndex").length);
    G("closePalette")();
  });

  step("dialog", () => {
    G("sysConfirm")("Test", "Does the window open?");
    if(!d.querySelector("#dialogs .dlg")) throw new Error("dialog did not render");
    d.getElementById("dlgNo").click();
  });

  step("theme", () => {
    G("setTheme")("day");
    if(d.documentElement.getAttribute("data-theme") !== "day") throw new Error("theme not applied");
    G("setTheme")("void");
  });

  step("data compatibility", () => {
    const raw = JSON.parse(w.localStorage.getItem("system.v1"));
    if(!raw.hunters || !raw.active) throw new Error("storage key system.v1 not written");
    const h = raw.hunters[raw.active];
    ["quests","done","stats","level","xp","streak","penalties","goals","vault","skills"].forEach(k => {
      if(!(k in h)) throw new Error("hunter lost field: " + k);
    });
    console.log("  hunter fields:", Object.keys(h).length, "| storage key: system.v1");
  });

  console.log("\n" + (errors.length ? "PROBLEMS:" : "clean run — no errors"));
  errors.forEach(e => console.log(" ✗ " + e));
  process.exit(errors.length ? 1 : 0);
})();
