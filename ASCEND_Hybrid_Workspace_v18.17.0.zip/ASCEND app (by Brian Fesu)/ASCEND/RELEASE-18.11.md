# ASCEND 18.11 — step 4 of v19: the server replays

18.10 proved the same events give the same state in two runtimes. That was
necessary and not sufficient. This release makes the server actually do it — and
answers the question a client cannot be trusted with: **is this total real?**

---

## What landed

**`POST /records/:id/events`** — ingests a client's log, replays it with the same
reducers the browser bundles (`shared/domain/`, loaded by dynamic import), and
compares the result to what the client claims about itself.

**`GET /records/:id/events?since=<cursor>`** — a second device catches up without
pulling the whole history. `seq_global` is server-assigned, so the cursor never
depends on anyone's clock.

**Idempotent by schema, not by care.** The primary key is `(user_id, id)` and an
event id is `device:seq`. A retried sync, a restored backup, or a client that
pushes its whole log every time all collapse to the same rows. Double-counted XP
is the failure a student would notice and never forgive, so it is made impossible
in the table rather than guarded at the call site.

**Deleting cloud data now deletes the event log.** Before this it would have left
a complete history behind, which is the wrong answer to give a parent asking what
you hold.

---

## Detection without punishment

Nothing in this release revokes XP or lowers a level. A mismatch becomes an
`events.divergence` audit row and a field in the response. The server cannot
distinguish a tampered client from a bug in the reducer, and guessing wrong in
the punishing direction costs an honest student their year.

**A client ahead of the server is not cheating.** On a Ghanaian school connection
it is the normal state, by design. The comparison is only made *after* the
submitted batch has been ingested, so offline work never reads as a lie. There is
a check for exactly this, because a design that got it backwards would be
unusable for the students it is for.

---

## The compaction invariant

The client compacts because a phone replays on every boot. The server does not,
because it has a real database and needs to recompute from zero for tamper
detection to mean anything.

That creates a trap: a phone works offline for a term, compacts, folds 1,800
events into a snapshot, then syncs — and the server, which never saw them,
replays a much lower total. The server would look like it was taking XP away.

So `compact()` now clamps to an acknowledgement watermark and can only fold
events the server has confirmed storing. A log that cannot compact grows; a log
that compacts too eagerly loses a year. The guard is mutation-pinned.

The same reasoning governs the compaction base: the server accepts one and
**never advances it**, because a second base stacking on events it already counts
would inflate the total every time a client compacted again.

---

## Two bugs, both found by tests that run the real thing

**Two id spaces, silently confused.** `account.id` identifies the account on the
server; the log is stored per *hunter*, under `DB.active`, because one device can
hold several hunters. `syncLog()` passed the account id to `Log.export()`, which
asked for a hunter that does not exist, got a fresh empty log, pushed nothing —
and reported success the whole way. Zero events reached the server while the sync
said it worked.

A unit test of `syncLog`'s shape would have passed. The end-to-end check caught it
because it boots the real app, grants real XP through the real funnel, and then
counts rows in the database.

**Mutation B** — making the server accept the client's claim unconditionally —
fails both the tamper check and the audit check, which is the pair that has to
hold for any of this to be worth having.

---

## Verification

`server-replay-test.js` — 14 checks over a real socket: replay agreement,
idempotent resubmission, an inflated claim caught with nothing taken away, the
divergence recorded, a client ahead of the server treated correctly, two devices
that never met converging, cursor correctness, hostile input (`1e400`, negative,
oversized, spoofed ids) rejected without corrupting the account, cross-account
isolation on both read and write, oversized batches refused rather than
half-applied, deletion covering the log, and the base rule.

`sync-test.js` — 2 new end-to-end checks driving the real client against the real
server: a device pushing its log and agreeing with the server, and a second device
pulling the first's events and landing on the same total.

**16 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra.

---

## What the server is now authoritative for

* **Identity, sessions, entitlements, AI access and quotas** — since 18.6/18.7.
* **What the account says a student's progression is** — as of now, recomputed
  rather than accepted.

And what it is deliberately *not*: the device still computes its own progression
from its own log, offline, with no connection, forever. That was the whole point
of insisting these two goals were compatible rather than choosing between them.

---

## Next

5. **The next-action engine** — a deterministic scorer over goals, mastery,
   errors, deadlines and available time. The AI explains the choice; it never
   makes it.

Then the remaining domains move onto the log one at a time: quests, mastery,
achievements, and finally rank — which stays gated on quests cleared, a streak
held, achievements and bosses, not on a level.

Still yours: **password reset**, the **host decision**, and the
**data-protection position** for 13–18 year olds. The third one just got more
urgent: the server now holds an event-by-event history of a student's year, which
is more than it held a release ago.
