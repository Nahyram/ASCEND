/* ASCEND — next-action-test.js
   Time budgeting, and turning a recommendation into a quest.

   ## What was actually missing

   services/recommend.js has answered "what is the highest-value next action"
   since v14, from goals, curriculum, mastery, errors, deadlines and history,
   deterministically, with a written reason on every item. Six of the seven
   inputs on the v19 list were already there.

   The seventh — how much time the student has — was used nowhere. Every
   recommendation carried `minutes: null` or no minutes at all, so the list at
   21:40 on a school night was the list a free Saturday would have produced. And
   there was no way to turn any of it into a quest, which is the second half of
   what §6 asks for.

   ## The rule under test

   **Time may narrow the list. It may never reorder it, and it may never drop a
   hard constraint.** A deadline due tomorrow does not stop being due because the
   evening is short; the honest answer is to say it will not fit, not to hide it
   and let the student find out at rollover. */
"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");
const nodeCrypto = require("node:crypto");
const { JSDOM, VirtualConsole } = require("jsdom");

const ROOT = process.env.ROOT || "./system";
const SHARED = path.resolve("./shared");

const results = [], errors = [];
async function check(label, fn) {
  try { await fn(); results.push("  PASS  " + label); }
  catch (e) { results.push("  FAIL  " + label + " — " + e.message); errors.push(label); }
}

const rec = (id, tier, minutes) => ({ id, tier, title: id, because: "reason", minutes });

(async () => {
  const NA = await import(path.join(SHARED, "domain", "next-action.js"));

  await check("nothing in the next-action domain reads the clock or randomness", () => {
    const code = fs.readFileSync(path.join(SHARED, "domain", "next-action.js"), "utf8")
      .replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
    for (const [re, what] of [[/\bDate\.now\s*\(/, "Date.now()"], [/\bnew\s+Date\b/, "new Date"],
      [/\bMath\.random\s*\(/, "Math.random()"], [/toLocale/, "a toLocale* call"], [/\bIntl\./, "Intl"]]) {
      assert.ok(!re.test(code), "next-action.js uses " + what);
    }
  });

  await check("budgeting never reorders the ranking", () => {
    const ranked = [rec("deadline:a", "high", 45), rec("errors:b", "medium", 25),
      rec("next:c", "medium", 20), rec("style:d", "optional", 20)];
    for (const budget of [null, 5, 20, 45, 60, 200]) {
      const out = NA.planForBudget(ranked, budget);
      assert.ok(NA.preservesOrder(ranked, out.plan),
        `budget ${budget} changed the order to ${out.plan.map(p => p.id).join("|")}`);
    }
  });

  await check("a hard constraint that does not fit is shown anyway, not hidden", () => {
    const ranked = [rec("deadline:tomorrow", "high", 45), rec("style:x", "optional", 10)];
    const out = NA.planForBudget(ranked, 20);
    const dl = out.plan.find(p => p.id === "deadline:tomorrow");
    assert.ok(dl, "the deadline was removed from the plan entirely");
    assert.strictEqual(dl.fits, false);
    assert.strictEqual(dl.overruns, true, "an unfittable deadline was not flagged as overrunning");
    assert.strictEqual(dl.shortfall, 25);
    assert.ok(/deadline does not move/.test(out.note), "the note does not explain the overrun: " + out.note);
  });

  await check("an optional item that does not fit is marked, not promoted", () => {
    const ranked = [rec("next:a", "medium", 20), rec("style:b", "optional", 30)];
    const out = NA.planForBudget(ranked, 25);
    const opt = out.plan.find(p => p.id === "style:b");
    assert.strictEqual(opt.fits, false);
    assert.ok(!opt.overruns, "an optional item was flagged as a hard overrun");
    assert.strictEqual(out.fitted, 1);
  });

  await check("no stated budget means the full ranking, not an invented plan", () => {
    const ranked = [rec("deadline:a", "high", 45), rec("next:b", "medium", 20)];
    for (const empty of [null, 0, undefined, ""]) {
      const out = NA.planForBudget(ranked, empty);
      assert.strictEqual(out.budget, null);
      assert.ok(out.plan.every(p => p.fits), "items were filtered against a budget nobody gave");
      assert.ok(/No time stated/.test(out.note));
    }
  });

  await check("every item carries a time estimate, whatever it is", () => {
    const kinds = ["recovery", "deadline", "overdue", "next", "errors", "exam",
      "stale", "project", "opp", "goal", "weak", "style", "somethingnew"];
    for (const k of kinds) {
      const m = NA.estimateMinutes({ id: k + ":1" });
      assert.ok(Number.isFinite(m) && m > 0, `${k} produced ${m}`);
    }
    /* The board's own number wins over the table — it came from the student. */
    assert.strictEqual(NA.estimateMinutes({ id: "next:1" }, 90), 90);
  });

  await check("the same inputs give the same plan in every timezone", () => {
    const ranked = [rec("deadline:a", "high", 45), rec("errors:b", "medium", 25), rec("next:c", "medium", 20)];
    const seen = new Set();
    for (const tz of ["UTC", "America/New_York", "Asia/Tokyo", "Africa/Accra", "Pacific/Kiritimati"]) {
      process.env.TZ = tz;
      seen.add(JSON.stringify(NA.planForBudget(ranked, 60)));
    }
    process.env.TZ = "UTC";
    assert.strictEqual(seen.size, 1, "the plan changed with the timezone");
  });

  await check("the decision path contains no model call", () => {
    /* §6 as stated: the AI explains the choice, it never makes it. A scorer that
       called a model would be unreproducible, unauditable, and dead offline —
       and offline is when a student most needs to know what to do next. */
    const files = ["shared/domain/next-action.js", "system/services/recommend.js"];
    for (const f of files) {
      const code = fs.readFileSync(f, "utf8").replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
      for (const re of [/\bAI\.ask\b/, /\bfetch\s*\(/, /openai/i, /\bawait\b/]) {
        assert.ok(!re.test(code), `${f} reaches for the network or a model in the ranking path`);
      }
    }
  });

  /* ---------- against the real app ---------- */
  const dom = new JSDOM(fs.readFileSync(path.join(ROOT, "index.html"), "utf8"), {
    runScripts: "dangerously", url: "https://local.test/",
    virtualConsole: new VirtualConsole(), pretendToBeVisual: true,
  });
  const w = dom.window, d = w.document;
  Object.defineProperty(w, "crypto", { value: {
    getRandomValues: a => { nodeCrypto.randomFillSync(Buffer.from(a.buffer, a.byteOffset, a.byteLength)); return a; },
    subtle: { importKey: async () => ({}), deriveBits: async () => new Uint8Array(32).buffer,
      digest: async () => new Uint8Array(32).buffer, deriveKey: async () => ({}),
      encrypt: async () => new Uint8Array(16).buffer, decrypt: async () => new Uint8Array(16).buffer },
  }, configurable: true });
  w.matchMedia = q => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
  w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {};
  w.AudioContext = function () { return { createGain: () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} } }), createOscillator: () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0, setValueAtTime() {} }, type: "" }), createBufferSource: () => ({ connect() {}, start() {}, stop() {}, buffer: null, loop: false }), createBuffer: () => ({ getChannelData: () => new Float32Array(1000) }), createBiquadFilter: () => ({ connect() {}, frequency: { value: 0 }, type: "", Q: { value: 0 } }), destination: {}, sampleRate: 44100, currentTime: 0, close() {}, resume() {} }; };
  w.indexedDB = undefined;
  for (const s of [...d.querySelectorAll("script[src]")].map(x => x.getAttribute("src"))) {
    const el = d.createElement("script");
    el.textContent = fs.readFileSync(path.join(ROOT, s), "utf8");
    d.body.appendChild(el);
  }
  await new Promise(r => setTimeout(r, 1600));
  d.getElementById("scr-login").classList.remove("hidden");
  d.getElementById("btnNewHunter").click();
  d.getElementById("regName").value = "Planner";
  d.getElementById("regTitle").value = "The Timed";
  d.getElementById("regGo").click();
  d.querySelector('#obWorkout .chip[data-w="calisthenics"]').click();
  for (const n of ["2", "3", "4"]) d.querySelectorAll("[data-next]").forEach(b => { if (b.dataset.next === n) b.click(); });
  await new Promise(r => setTimeout(r, 50));
  d.getElementById("obFinish").click();
  await new Promise(r => setTimeout(r, 400));
  const br = d.createElement("script");
  br.textContent = 'window.__N = { recommendations, plannedRecommendations, nextBestAction, scheduleActionAsQuest, ' +
    'H, save, addSubject, addTopic, addGoal, invalidateModel };';
  d.body.appendChild(br);
  const S = w.__N;

  /* A freshly onboarded hunter produces exactly one recommendation, and it is
     one that is already a quest. Left that way, half of this suite would take an
     early return and report PASS having tested nothing — which is how 18.10's
     paid-not-requested rule went unenforced for a release. So the fixture is
     seeded through the app's own APIs until the ranking has something in it. */
  if (typeof S.addSubject === "function") {
    const subj = S.addSubject({ name: "Physics", qualification: "IGCSE", target: "A" });
    if (subj && subj.id && typeof S.addTopic === "function") {
      const unit = (subj.units && subj.units[0]) || null;
      if (unit) for (const t of ["Kinematics", "Forces", "Energy"]) S.addTopic(subj.id, unit.id, t);
    }
  }
  if (typeof S.addGoal === "function") S.addGoal({ name: "Pass IGCSE Physics", horizon: "term" });

  /* A deadline two days out, in the shape views/core-views.js writes. This is
     the branch that makes the ranking interesting: a hard constraint the budget
     checks below actually have to deal with. */
  {
    const h = S.H();
    const soon = new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10);
    const today = new Date().toISOString().slice(0, 10);
    h.deadlines.push({ id: "dl-soon", name: "Physics practical writeup", date: soon, weight: "3" });
    h.deadlines.push({ id: "dl-today", name: "Maths problem set", date: today, weight: "2" });
    S.save();
  }
  if (typeof S.invalidateModel === "function") S.invalidateModel();

  await check("the live engine now puts a time on every recommendation", () => {
    assert.ok(typeof S.recommendations === "function", "recommendations() is not reachable");
    const recs = S.recommendations({ max: 6 });
    assert.ok(recs.length >= 2,
      `the fixture produced only ${recs.length} recommendation(s) — too few to be evidence of anything`);
    for (const r of recs) {
      assert.ok(Number.isFinite(r.minutes) && r.minutes > 0,
        `${r.id} carries minutes=${r.minutes} — the input this release exists to add`);
      /* §22 still holds alongside it. */
      assert.ok((r.because || "").length >= 40, `${r.id} does not explain itself`);
    }
  });

  await check("a real ranking fitted to twenty minutes keeps its order and its obligations", () => {
    const ranked = S.recommendations({ max: 6 });
    const out = S.plannedRecommendations(20, { max: 6 });
    assert.strictEqual(out.plan.length, ranked.length, "budgeting removed items from the list");
    assert.deepStrictEqual(out.plan.map(p => p.id), ranked.map(r => r.id), "budgeting reordered a real ranking");
    assert.ok(out.spent <= 20, `the plan scheduled ${out.spent} minutes into a 20-minute budget`);
    for (const p of out.plan) if (p.tier === "high" && !p.fits) assert.strictEqual(p.overruns, true);
    assert.ok(out.note && out.note.length > 20, "the plan came back with no explanation");
  });

  await check("promoting a recommendation puts it on the board once, not twice", () => {
    /* A constructed recommendation, not whichever one the fixture happened to
       produce. The first version of this check looked for a promotable item in
       the live ranking, found none, took an early return and reported PASS
       having never once created a quest. A check that can pass without running
       is worse than no check. */
    const target = { id: "errors:topic-abc", tier: "medium", title: "Redo the questions you missed",
                     because: "x".repeat(50), minutes: 25 };
    const before = S.H().quests.length;
    const first = S.scheduleActionAsQuest(target, { time: "18:30" });
    assert.strictEqual(first.created, true, "the recommendation was not scheduled: " + first.reason);
    assert.strictEqual(S.H().quests.length, before + 1);
    assert.strictEqual(first.quest.fromAction, target.id, "the quest does not record where it came from");

    const second = S.scheduleActionAsQuest(target, { time: "18:30" });
    assert.strictEqual(second.created, false, "promoting the same recommendation twice made two quests");
    assert.strictEqual(S.H().quests.length, before + 1);
  });

  await check("an item already on the board is refused rather than duplicated", () => {
    const quested = S.recommendations({ max: 6 }).find(r => r.quest);
    assert.ok(quested, "the fixture produced no recommendation attached to an existing quest, " +
      "so this check would have silently tested nothing");
    const before = S.H().quests.length;
    const r = S.scheduleActionAsQuest(quested);
    assert.strictEqual(r.created, false,
      "a recommendation about an existing quest created a copy — the board would double and pay XP twice");
    assert.strictEqual(S.H().quests.length, before);
  });

  await check("a recommendation that is not a piece of work is not turned into one", () => {
    for (const id of ["exam:2026-06-01", "opp:x", "deadline:y", "style:scholar"]) {
      const r = S.scheduleActionAsQuest({ id, title: "x" });
      assert.strictEqual(r.created, false, `${id} was turned into a quest`);
      assert.ok(r.reason, `${id} was refused with no reason given`);
    }
  });

  dom.window.close();

  console.log("\nASCEND — the next action, and the time to do it in\n");
  console.log(results.join("\n"));
  if (errors.length) { console.log(`\n${errors.length} of ${results.length} checks failed\n`); process.exit(1); }
  console.log(`\nall ${results.length} checks passed\n`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
