/* ASCEND — store-test.js
   The IndexedDB driver and the migration that carries an existing student onto it.

   ## Why this suite is the careful one

   On the other side of this code is a student's entire record — every quest,
   every mastery score, every project, a term or a year of work. Nothing else in
   this codebase can destroy that in one release. So the migration is not tested
   by asserting that it was written correctly; it is tested by running it against
   a real IndexedDB implementation and reading the bytes back out.

   fake-indexeddb is a full implementation of the spec, not a mock: real
   transactions, real cursors, real key ordering, real errors. A hand-written
   stub would agree with whatever the driver did, which is the failure mode this
   whole project keeps finding.

   ## The rules being enforced

     1. copy, never move
     2. verify the copy by reading it back out of IndexedDB
     3. do not delete the source
     4. a write that races boot cannot overwrite a real record with an empty one
     5. when IndexedDB is refused, fall back rather than boot an empty app */
"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");

const ROOT = process.env.ROOT || "./system";

/* A converted module lives under src/; an unconverted one is still at the top of
   system/. Resolving instead of hard-coding is what keeps these assertions
   honest across the migration — core/kernel.js moved in 18.16 and four suites
   went red on the path rather than on the behaviour. */
function appFile(rel){
  const a = path.join(ROOT, "src", rel), b = path.join(ROOT, rel);
  return fs.existsSync(a) ? a : b;
}


const results = [], errors = [];
async function check(label, fn){
  try{ await fn(); results.push("  PASS  " + label); }
  catch(e){ results.push("  FAIL  " + label + " — " + e.message); errors.push(label); }
}

/* Load the module source in a context we control, so each case gets a clean
   driver rather than one carrying the previous case's cache. */
const SRC = fs.readFileSync(path.join(ROOT, "src", "core", "store.js"), "utf8")
  .replace(/^export\s*\{[^}]*\};?\s*$/m, "");

function freshEnv(opts = {}){
  const { idb = true, local = true } = opts;
  const vm = require("node:vm");
  const store = new Map();
  const sandbox = {
    console, setTimeout, clearTimeout, Date, JSON, Math, Object, Array, String, Number,
    Promise, Error, Map, Set, isNaN, parseInt, parseFloat,
  };
  if(idb){
    /* A private IndexedDB per case.

       require("fake-indexeddb") is a module singleton, so every case sharing it
       shares one set of databases — and three checks here passed or failed
       depending on which ran first, which is worse than no check at all. A fresh
       factory per case is real isolation. */
    const FDBFactory = require("fake-indexeddb/lib/FDBFactory");
    sandbox.indexedDB = opts.factory || new FDBFactory();
    sandbox.IDBKeyRange = require("fake-indexeddb/lib/FDBKeyRange");
  }
  if(local){
    sandbox.localStorage = {
      getItem: k => (store.has(k) ? store.get(k) : null),
      setItem: (k, v) => { store.set(k, String(v)); },
      removeItem: k => { store.delete(k); },
      get length(){ return store.size; },
      key: i => [...store.keys()][i],
    };
    /* Object.keys(localStorage) is what the driver uses. */
    sandbox.localStorage = new Proxy(sandbox.localStorage, {
      ownKeys: () => [...store.keys()],
      getOwnPropertyDescriptor: () => ({ enumerable: true, configurable: true }),
    });
  }
  const ctx = vm.createContext(sandbox);
  new vm.Script(SRC + "\n;this.__X = { SCHEMA, StoreDrivers, Store };").runInContext(ctx);
  return { ...ctx.__X, raw: store, sandbox };
}

const RECORD = JSON.stringify({
  schema: 6, active: "h1",
  hunters: { h1: { id:"h1", name:"Kael", level:12, totalXp:4200, quests:[{id:"q1"}] } },
});

(async () => {

  await check("IndexedDB is chosen over localStorage when it is available", () => {
    const { Store } = freshEnv();
    assert.strictEqual(Store.driver, "idb");
    assert.strictEqual(Store.durable, true);
  });

  await check("localStorage is chosen when IndexedDB is refused", () => {
    const { Store } = freshEnv({ idb:false });
    assert.strictEqual(Store.driver, "local");
  });

  await check("with neither available the app still runs and says it is not durable", () => {
    const { Store } = freshEnv({ idb:false, local:false });
    assert.strictEqual(Store.driver, "memory");
    assert.strictEqual(Store.durable, false);
  });

  await check("before hydration the driver reports nothing rather than a wrong answer", () => {
    const { Store } = freshEnv();
    assert.strictEqual(Store.ready, false);
    assert.strictEqual(Store.readJSON("system.v1"), null);
  });

  await check("an existing localStorage record is copied into IndexedDB and verified", async () => {
    const env = freshEnv();
    env.raw.set("system.v1", RECORD);
    const info = await env.Store.hydrate();
    assert.ok(String(info.migratedFrom || "").startsWith("migrated:"),
      "expected a migration, got " + JSON.stringify(info));
    const back = env.Store.readJSON("system.v1");
    assert.strictEqual(back.hunters.h1.totalXp, 4200, "the record did not survive the copy");
    assert.strictEqual(back.hunters.h1.name, "Kael");
  });

  await check("the migration does not delete the localStorage copy", async () => {
    const env = freshEnv();
    env.raw.set("system.v1", RECORD);
    await env.Store.hydrate();
    assert.strictEqual(env.raw.get("system.v1"), RECORD,
      "the source copy was removed — a rollback would now lose the student's record");
  });

  await check("the copy is verified against IndexedDB itself, not against the cache", async () => {
    /* Break the write path after the cache is populated. If the check compared
       the cache to the source it would pass; it must fail. */
    const env = freshEnv();
    env.raw.set("system.v1", RECORD);
    const idb = env.StoreDrivers.idb;
    const realFlush = idb.flush.bind(idb);
    let calls = 0;
    idb.flush = () => { calls++; return Promise.resolve(); };   /* silently drop writes */
    const info = await env.Store.hydrate();
    idb.flush = realFlush;
    assert.ok(calls > 0, "the migration never tried to flush");
    assert.ok(!String(info.migratedFrom || "").startsWith("migrated:"),
      "a migration whose writes never landed reported success: " + JSON.stringify(info));
  });

  await check("a second boot does not migrate again", async () => {
    const env = freshEnv();
    env.raw.set("system.v1", RECORD);
    await env.Store.hydrate();
    const second = await env.Store.hydrate();       /* idempotent — same promise */
    assert.ok(String(second.migratedFrom || "").startsWith("migrated:"));
    assert.strictEqual(env.Store.readJSON("system.v1").hunters.h1.totalXp, 4200);
  });

  await check("a record already in IndexedDB is never overwritten by an older local copy", async () => {
    const env = freshEnv();
    /* Simulate the rollback case: IndexedDB holds newer work, localStorage holds
       what the previous release left behind. */
    await env.Store.hydrate();
    env.Store.writeJSON("system.v1", { schema:6, active:"h1", hunters:{ h1:{ id:"h1", totalXp: 9999 } } });
    await env.Store.flush();
    env.raw.set("system.v1", RECORD);
    env.StoreDrivers.idb._hydrated = false;
    const info = await env.StoreDrivers.idb.hydrate();
    void info;
    assert.strictEqual(env.Store.readJSON("system.v1").hunters.h1.totalXp, 9999,
      "the older localStorage copy overwrote newer work");
  });

  await check("a save that races boot cannot write an empty record over a real one", async () => {
    const env = freshEnv();
    env.raw.set("system.v1", RECORD);
    /* Write before hydration, exactly as a save() firing during boot would. */
    env.Store.writeJSON("system.v1", { schema:6, hunters:{}, active:null });
    await new Promise(r => setTimeout(r, 5));
    await env.Store.flush();
    /* Nothing may have reached IndexedDB yet. */
    const fresh = freshEnv();
    fresh.raw.set("system.v1", RECORD);
    const info = await fresh.Store.hydrate();
    assert.ok(String(info.migratedFrom || "").startsWith("migrated:"));
    assert.strictEqual(fresh.Store.readJSON("system.v1").hunters.h1.totalXp, 4200,
      "an empty record reached storage before hydration finished");
  });

  await check("writes survive a flush and are readable by a new session", async () => {
    /* The one case that deliberately shares a factory: two page loads against
       the same browser profile. */
    const shared = new (require("fake-indexeddb/lib/FDBFactory"))();
    const session = () => freshEnv({ factory: shared, local: false });
    const a = session();
    await a.Store.hydrate();
    a.Store.writeJSON("system.v1", { schema:6, active:"h1", hunters:{ h1:{ id:"h1", totalXp: 777 } } });
    await a.Store.flush();

    const b = session();                    /* a different "page load" */
    await b.Store.hydrate();
    assert.strictEqual(b.Store.readJSON("system.v1").hunters.h1.totalXp, 777,
      "the write did not survive into a new session");
  });

  await check("many saves in one tick collapse into one transaction, last value winning", async () => {
    const env = freshEnv();
    await env.Store.hydrate();
    const idb = env.StoreDrivers.idb;
    let transactions = 0;
    const open = idb._open.bind(idb);
    idb._open = () => open().then(db => new Proxy(db, {
      get(t, p){
        if(p === "transaction") return (...a) => { transactions++; return t.transaction(...a); };
        const v = t[p];
        return typeof v === "function" ? v.bind(t) : v;
      },
    }));
    for(let i = 1; i <= 50; i++) env.Store.writeJSON("system.v1", { schema:6, n:i });
    await new Promise(r => setTimeout(r, 5));
    await env.Store.flush();
    assert.ok(transactions <= 3, `50 saves produced ${transactions} transactions`);
    assert.strictEqual(env.Store.readJSON("system.v1").n, 50, "the last write did not win");
  });

  await check("a failed write is retried rather than dropped, and the app is told", async () => {
    const env = freshEnv();
    await env.Store.hydrate();
    const idb = env.StoreDrivers.idb;
    let told = null;
    idb._onError = e => { told = e; };
    const open = idb._open.bind(idb);
    let fail = true;
    idb._open = () => (fail ? Promise.reject(new Error("quota exceeded")) : open());
    env.Store.writeJSON("system.v1", { schema:6, n: 1 });
    await new Promise(r => setTimeout(r, 5));
    await idb.flush();
    assert.ok(told, "a storage failure was swallowed — the student would think their work saved");
    assert.ok(idb._pending.size > 0, "the failed write was dropped instead of queued for retry");
    fail = false;
    await idb.flush();
    assert.strictEqual(idb._pending.size, 0, "the retry never landed");
  });

  await check("a hydrate that throws falls back instead of booting an empty app", async () => {
    const env = freshEnv();
    env.StoreDrivers.idb.hydrate = () => Promise.reject(new Error("IndexedDB is disabled"));
    const info = await env.Store.hydrate();
    assert.ok(info.fellBack, "expected a fallback, got " + JSON.stringify(info));
    assert.ok(/disabled/.test(String(env.Store.lastError && env.Store.lastError.message)));
  });

  /* ---------- the assumption the async boot rests on ---------- */
  await check("no classic script reads DB or H() at load time except kernel.js", () => {
    const acorn = require("acorn");
    const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
    const files = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1])
      .filter(f => f !== "bundle.js");
    const FN = new Set(["FunctionDeclaration","FunctionExpression","ArrowFunctionExpression","ClassBody"]);
    const offenders = [];
    for(const f of files){
      let ast;
      try{ ast = acorn.parse(fs.readFileSync(path.join(ROOT, f), "utf8"), { ecmaVersion: 2022 }); }
      catch(e){ continue; }
      const hit = new Set();
      (function scanTop(body){
        for(const n of body){
          if(n.type === "FunctionDeclaration" || n.type === "ClassDeclaration") continue;
          (function scan(node){
            if(!node || typeof node !== "object") return;
            if(Array.isArray(node)) return node.forEach(scan);
            if(!node.type || FN.has(node.type)) return;
            if(node.type === "Identifier" && (node.name === "DB" || node.name === "H")) hit.add(node.name);
            for(const k in node){ if(k === "type" || k === "start" || k === "end" || k === "loc") continue; scan(node[k]); }
          })(n);
        }
      })(ast.body);
      if(hit.size && f !== "core/kernel.js") offenders.push(f + " (" + [...hit].join(", ") + ")");
    }
    assert.strictEqual(offenders.length, 0,
      "boot is asynchronous, so these would read an empty record: " + offenders.join("; "));
  });

  await check("hydration does not discard in-memory work on a synchronous driver", () => {
    /* The regression this pins: kernel.js re-reads the record once hydration
       settles. On localStorage the record was already readable at load, so an
       unconditional re-read throws away anything changed since — which is every
       change made during the first tick. */
    const kernel = fs.readFileSync(appFile("core/kernel.js"), "utf8");
    const then = (kernel.match(/\.then\(info => \{([\s\S]*?)\n\}\)/) || [])[1] || "";
    assert.ok(/DB = load\(\)/.test(then), "kernel.js does not re-read after hydration at all");
    assert.ok(/driver === "idb"/.test(then),
      "the re-read is unconditional — on localStorage it discards unsaved in-memory changes");
  });

  await check("boot waits for hydration rather than for the animation to finish", () => {
    const boot = fs.readFileSync(appFile("ui/boot-auth.js"), "utf8");
    assert.ok(/await\s+SYSTEM_READY/.test(boot),
      "ui/boot-auth.js does not await SYSTEM_READY — the hunter list can render before the record loads");
    const kernel = fs.readFileSync(appFile("core/kernel.js"), "utf8");
    assert.ok(/SYSTEM_READY[\s\S]*Store\.hydrate\(\)/.test(kernel), "kernel.js does not hydrate the store");
    /* Match the re-read inside the .then(), not merely somewhere after the first
       mention of the name — the first mention is in a comment, which is how this
       assertion failed against a kernel that was in fact correct. */
    assert.ok(/Store\.hydrate\(\)[\s\S]*\.then\([\s\S]*DB = load\(\)/.test(kernel),
      "kernel.js never re-reads the record after hydration");
  });

  console.log("\nASCEND — the store, and the migration onto IndexedDB\n");
  console.log(results.join("\n"));
  if(errors.length){ console.log(`\n${errors.length} of ${results.length} checks failed\n`); process.exit(1); }
  console.log(`\nall ${results.length} checks passed\n`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
