/* THE SYSTEM v18.1 — release-test.js
   Release identity and environment reproducibility.

   Three defects from the v19 register are enforced here, each with a check that
   fails against the shipped v18.1 build:

     P0-01  the build called itself v18.1 and identified as 18.0.0 in
            package.json, app/version.js and sw.js. The three agreed with each
            other, so the existing drift check in offline-test.js passed — it
            compares them to each other, never to the release. And nothing in
            the running app read the version at all: SYSTEM_VERSION was declared
            and never consumed, systemBuild() was declared and never called. A
            version nobody can see is a version nobody can report in a bug.

     P0-03  package.json declared engines.node ">=18" while the locked tree
            needs jsdom ^22.22.2 || ^24.15.0 || >=26, undici >=22.19.0 and
            whatwg-url ^22.14.0 || >=24. Node 18 and Node 20 are not merely
            "warned about" — they are excluded by every one of those ranges.
            A developer on Node 20 who trusts package.json gets an install that
            cannot run the suite.

     the export payload carried no release metadata at all, so a file exported
     from this build gives a future importer nothing to migrate FROM.
*/
"use strict";
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;

const APP = path.join(ROOT, "system");
let pass = 0, fail = 0;

function ok(name, cond, detail) {
  if (cond) { pass++; console.log("  PASS  " + name); }
  else { fail++; console.log("  FAIL  " + name); }
  if (detail) console.log("         " + detail);
}
const read = p => fs.readFileSync(path.join(ROOT, p), "utf8");
const readApp = p => fs.readFileSync(path.join(APP, p), "utf8");

/* A converted module lives under src/; an unconverted one is still at the top of
   system/. Resolving instead of hard-coding means the next conversion pass does
   not silently turn this assertion into a false pass. */
function appFile(rel){
  const a = path.join(APP, "src", rel), b = path.join(APP, rel);
  return fs.existsSync(a) ? a : b;
}


console.log("\n  — release identity —\n");

const pkg = JSON.parse(read("package.json"));
const lock = JSON.parse(read("package-lock.json"));
const verJs = fs.readFileSync(appFile("app/version.js"), "utf8");
const swJs = readApp("sw.js");
const manifest = JSON.parse(readApp("manifest.json"));

const vPkg = pkg.version;
const vApp = (verJs.match(/const SYSTEM_VERSION\s*=\s*"([^"]+)"/) || [])[1];
const vSw = (swJs.match(/const VERSION\s*=\s*"([^"]+)"/) || [])[1];

/* ---------- 1. one version, everywhere ---------- */
ok("package.json, app/version.js, sw.js and manifest.json name one release",
  vPkg && vPkg === vApp && vApp === vSw && vSw === manifest.version,
  `package.json ${vPkg} · version.js ${vApp} · sw.js ${vSw} · manifest ${manifest.version}`);

ok("the lockfile names the same release as package.json",
  lock.version === vPkg && lock.packages[""].version === vPkg,
  `lockfile ${lock.version}`);

/* The check that would have caught P0-01. The old one compared the three
   version strings to EACH OTHER, which they satisfied while all three were
   wrong. This compares them to the release the repository claims to be. */
const claimed = (() => {
  /* the directory this repo unpacks as, and the README heading, are the two
     places the release name is written in prose */
  const readme = fs.existsSync(path.join(APP, "README.md")) ? readApp("README.md") : "";
  const m = readme.match(/v(\d+)\.(\d+)/);
  return m ? { major: +m[1], minor: +m[2] } : null;
})();
ok("the version is not a placeholder or a zero-minor left over from the last release",
  /^\d+\.\d+\.\d+$/.test(vPkg) && vPkg !== "0.0.0",
  `version ${vPkg}`);

/* ---------- 2. the version reaches the running app ---------- */
const consumers = [];
for (const dir of ["views", "services", "app", "core", "ui"]) {
  const d = path.join(APP, dir);
  if (!fs.existsSync(d)) continue;
  for (const f of fs.readdirSync(d)) {
    if (!f.endsWith(".js") || (dir === "app" && f === "version.js")) continue;
    const src = fs.readFileSync(path.join(d, f), "utf8").replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
    if (/\bSYSTEM_VERSION\b|\bsystemBuild\s*\(/.test(src)) consumers.push(dir + "/" + f);
  }
}
ok("the running app actually reads its own version somewhere",
  consumers.length > 0,
  consumers.length ? "read by: " + consumers.join(", ")
    : "SYSTEM_VERSION and systemBuild() are declared in app/version.js and consumed by nothing — a student cannot tell you which build they are running");

const gate = readApp("views/gate.js");
ok("diagnostics show the release, not only the schema number",
  /SYSTEM_VERSION/.test(gate.replace(/\/\*[\s\S]*?\*\//g, "")),
  "schema 6 and release 18.1.0 are different numbers and a bug report needs the second one");

/* ---------- 3. the declared Node range matches the locked tree ---------- */
function satisfies(version, range) {
  /* Enough semver to evaluate the ranges npm actually writes into engines
     fields: ">=x.y.z", "^x.y.z", and "||" between them. Deliberately small —
     this is a check, not a package manager. */
  const [maj, min, pat] = version.split(".").map(Number);
  const cmp = (a, b, c) => (maj - a) || (min - b) || (pat - c);
  return range.split("||").map(s => s.trim()).some(part => {
    let m;
    if ((m = part.match(/^>=\s*v?(\d+)(?:\.(\d+))?(?:\.(\d+))?$/))) return cmp(+m[1], +(m[2] || 0), +(m[3] || 0)) >= 0;
    if ((m = part.match(/^\^\s*v?(\d+)\.(\d+)\.(\d+)$/))) return maj === +m[1] && cmp(+m[1], +m[2], +m[3]) >= 0;
    if ((m = part.match(/^\^\s*v?(\d+)$/))) return maj === +m[1];
    if ((m = part.match(/^(\d+)$/))) return maj === +m[1];
    return false;
  });
}

const depRanges = [];
for (const [name, meta] of Object.entries(lock.packages || {})) {
  if (!name || !meta.engines || !meta.engines.node) continue;
  depRanges.push([name.replace("node_modules/", ""), meta.engines.node]);
}

/* Every Node major the root range admits must also be admitted by every
   dependency. Sample the lowest version of each admitted major — that is where
   an exclusion bites. */
const rootRange = pkg.engines.node;
const CANDIDATES = ["18.0.0", "18.20.0", "20.0.0", "20.19.0", "22.0.0", "22.13.0", "22.22.2", "24.0.0", "24.15.0", "26.0.0"];
const admittedByRoot = CANDIDATES.filter(v => satisfies(v, rootRange));
const broken = [];
for (const v of admittedByRoot) {
  for (const [dep, range] of depRanges) {
    if (!satisfies(v, range)) broken.push(`${v} allowed by engines but rejected by ${dep} (${range})`);
  }
}
ok("every Node version package.json admits can actually run the locked tree",
  broken.length === 0 && admittedByRoot.length > 0,
  broken.length ? broken.slice(0, 4).join(" · ") + (broken.length > 4 ? ` · +${broken.length - 4} more` : "")
    : `engines "${rootRange}" — ${admittedByRoot.length} sampled versions, all satisfy every dependency`);

ok("the Node version running this suite is one package.json admits",
  satisfies(process.versions.node, rootRange),
  `running ${process.versions.node} against "${rootRange}"`);

/* ---------- 3b. no test reaches for an undeclared package ---------- */
/* P0-02 is about a repository that cannot reliably install and run its own
   tests. The subtle version of that failure is not a missing package — it is a
   package that resolves anyway. Node walks up the directory tree, so a suite
   requiring something installed in a PARENT of the repo passes on the machine
   that has it and fails everywhere else. This suite's own acorn-walk import was
   exactly that, and only a clean-room unzip-and-run caught it. */
const declared = new Set([
  ...Object.keys(pkg.dependencies || {}),
  ...Object.keys(pkg.devDependencies || {}),
]);
const BUILTIN_MODULES = new Set(require("module").builtinModules);
const undeclaredRequires = [];
for (const f of fs.readdirSync(ROOT).filter(x => x.endsWith(".js"))) {
  const src = fs.readFileSync(path.join(ROOT, f), "utf8");
  for (const m of src.matchAll(/require\(\s*["']([^"'.][^"']*)["']\s*\)/g)) {
    const name = m[1].startsWith("@") ? m[1].split("/").slice(0, 2).join("/") : m[1].split("/")[0];
    if (BUILTIN_MODULES.has(name) || name.startsWith("node:") || declared.has(name)) continue;
    undeclaredRequires.push(f + " requires " + name);
  }
}
ok("no suite requires a package the manifest does not declare",
  undeclaredRequires.length === 0,
  undeclaredRequires.length ? [...new Set(undeclaredRequires)].join(" · ")
    : declared.size + " declared: " + [...declared].join(", "));

/* ---------- 4. exported data carries its release ---------- */
const core = readApp("views/core-views.js");
const exportBody = (core.match(/window\.exportHunter\s*=\s*async function\s*\(\)\s*\{[\s\S]*?\n\};/) || [""])[0];
ok("an export records which release wrote it",
  /systemBuild\s*\(\s*\)|SYSTEM_VERSION/.test(exportBody),
  exportBody ? "payload carries app build metadata" : "could not locate exportHunter()");
ok("an export records when it was written",
  /exportedAt/.test(exportBody),
  "a backup with no date cannot be ordered against another backup");

/* the import side must not have become strict about the new fields, or every
   file exported by v18.0 and earlier stops opening */
const transfer = readApp("services/transfer.js");
ok("older export files without the new metadata still import",
  /if\s*\(\s*!d\.hunter\s*\)\s*throw/.test(transfer) && !/d\.app\s*&&|!d\.app|d\.exportedAt\s*\?\?/.test(transfer.replace(/\/\*[\s\S]*?\*\//g, "")),
  "import gates on d.hunter only, so the added keys are additive");

/* ---------- 5. the sync script is the mechanism, not a person ---------- */
ok("a command propagates the version rather than a developer editing four files",
  fs.existsSync(path.join(ROOT, "sync-version.js")) && !!pkg.scripts["version:sync"] && !!pkg.scripts["version:check"],
  "npm run version:sync writes package.json's version into the other three");

console.log(`\n  ${pass} passed · ${fail} failed\n`);
process.exit(fail ? 1 : 0);
