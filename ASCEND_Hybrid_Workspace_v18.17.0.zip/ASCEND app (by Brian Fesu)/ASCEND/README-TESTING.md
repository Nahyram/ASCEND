# Running the checks

    npm ci        # deterministic install from package-lock.json
    npm test      # every suite, one exit code

Node 18+. The only dependencies are `jsdom` (boots the app headlessly) and
`acorn` (parses it for the architecture guard); both are devDependencies and
neither ships to a user.

| command | what it does |
|---|---|
| `npm test` | all twelve suites, cheapest first, each in its own process |
| `npm run test:release` | release identity, engine range vs the locked tree, export metadata |
| `npm run test:syntax` | `node --check` on every file; resolves every asset the page loads |
| `npm run test:arch` | global surface and load-order hazards, parsed with acorn |
| `npm run test:offline` | runs the real service worker against a mock Cache API, network off |
| `npm run test:hooks` | the dispatch registry that replaced 22 cross-file reassignments |
| `npm run test:harness` | boots the app and visits every section |
| `npm run test:brain` | the full behavioural suite |
| `npm run test:evidence` | the evidence ledger |
| `npm run test:secrets` | proves the OpenAI key cannot reach a browser |
| `npm run test:backend` | the API over a real socket: auth, isolation, conflicts, limits |
| `npm run test:sync` | the real client against the real server, end to end |
| `npm run test:tz` | all of the above in UTC, New York, Tokyo and Accra |

Every suite exits non-zero on any console error or failed assertion. `ROOT`
defaults to `./system` and can be set to point a suite at another build —
`ROOT=./old-version npm run test:offline` is how a fix is confirmed to fail
without it.

## v18 — offline stopped being an assumption

Every previous offline check in this project asserted on *intent*: the precache
guard compared two lists of strings, and `offlineAudit()` reported readiness
from a cache it located by guessing. Neither ever ran the service worker.

`offline-test.js` runs it. `sw.js` is loaded into a sandbox with a mock Cache
API and a mock `fetch` that can be switched off; the real install and activate
handlers execute against the real file tree; then a navigation is served with
the network down and the result inspected. **All 107 precached files are
verified to serve with no connection**, not just the shell.

Seven of its fifteen checks fail against the v18 that was handed over, which is
the only evidence that they are worth having.

## v18 — three boundaries that are now checked rather than intended

1. **No view reaches the network.** `views/tutor.js` called `fetch()` directly
   for four releases while `services/ai.js` sat beside it holding the timeout,
   the daily cap, the response cache, the privacy filter and the entitlement
   check. A gateway a caller may walk around is not a gateway.
2. **A device-granted licence never reports itself as verified.** Asserted on a
   structured field, not on prose — the previous version of this check tested
   for one phrase in a note, so rewording the sentence broke the check while the
   property it protects got stronger.
3. **Activation is measured in order.** The funnel counted an unordered set and
   granted two of its seven steps for the act of registering.

## Checks written to fail if the app is bluffing

- **The pattern engine, from both directions.** 56 days of seeded history with
  three patterns planted — it must find all three. Then a fixed board with one flat
  probability everywhere — it must report *nothing*.
- **Mastery, from the wrong direction.** A topic marked "studied" twenty times must
  still sit at 25%.
- **Proposals, for what they must not do.** The board is snapshotted, the adaptive
  engine asked for proposals, and the check fails if a byte changed.
- **Sync, against a real second store** with its own revisions — asserting on the
  server's state, not on what `syncNow` claims.
- **XSS, by inspecting the DOM** for injected elements after rendering five probes.
- **Verification, for refusal** — nobody can mark their own achievement verified.
- **The paywall rule, for refusal** — `registerPaidFeature()` must reject anything
  on the never-paid list.

## Four static guards

- **No global function declared in two files.** Classic scripts share one scope, so
  the later file silently replaces the earlier — no error, no log, the older feature
  just stops working. This shipped four times before the guard existed.
- **The precache list must match index.html.** Offline is this product's central
  promise, and a drifted list breaks it only once the connection goes.
- **No load-order hazard.** 87 classic scripts share one scope and load order *is*
  the dependency graph, so a file that uses something at load time which a later
  file declares is a TDZ error that kills the rest of that script silently. Parsed
  with acorn, because the earlier brace-counting version reported 42 hazards of
  which 41 were event handlers it had lost track of — a question about program
  structure needs a parser.
- **No id is used twice in index.html.** `getElementById` returns the first match
  in tree order, so a duplicate means half the code is wiring up an element the
  other half never touches. HTML comments are stripped before counting — a note
  describing a duplicate id is not a duplicate id.

## Why `test:sync` exists

Every other suite tests one side. `test:backend` drives the API over a socket
with no client; `test:brain` drives the sync engine against the in-memory
`loopback` driver with no server. Through v18.6 both were green while the two
halves had never once spoken to each other — `cloud.js` carried a *comment*
describing the REST adapter instead of containing one, and nothing in the suite
could notice, because nothing tested the seam.

`test:sync` is the seam. It boots the real backend on a real socket and the real
frontend in jsdom, then behaves like two students' devices sharing one account.
It found two defects on its first run that had shipped in 18.6: `wifiOnly` was a
switch enforced nowhere, and a dead session replaced its own explanation with the
server's `Authentication required.` while scheduling backoff retries on a token
that could never work.

Its bridge into the page guards every global with `typeof`. A bare object literal
would throw on the first missing name and collapse 21 checks into one unreadable
error; guarded, running it against 18.6 reports *which capability is missing*,
check by check. 18 of the 21 fail there.

## The runtime, pinned

Every suite failure that has ever been reported against this project from a
fresh checkout was the same thing: an older Node than `engines` requires, or
`npm ci` not run. The failures look alarming — architecture, modules, hooks,
brain and evidence all red at once — and none of them were real.

    node --version      # must satisfy package.json "engines"
    npm ci              # not `npm install` — the lockfile is the point
    npm test

`.nvmrc` and `.node-version` pin **22.22.2**, so `nvm use` / `fnm use` picks it
up with no argument. `release-test.js` already fails if the lockfile and
`package.json` disagree about the release; the version files above close the
other half of the same gap.

If a suite fails, check those two things before reading the failure.

## Bugs found because a green suite was hiding untested code

1. A `<script>` that fails to *parse* never runs, so `window.__R` kept the previous
   call's value and `run()` returned it. Each call now stamps a token.
2. Async checks finished before their promises resolved, so three sync tests
   asserted against a client that had never signed in — and returned true.
3. `buildNav()` runs inside `enterSystem()`, which the harness bypasses, so the
   navigation subsystem had never been exercised.
4. `services/perf.js` wrapped `go()` at load, before `app/router.js` declares it —
   every timing read zero. A wrapper that silently measures nothing is worse than no
   measurement. It now lives in `app/wiring.js`, which loads last.
5. Two fixtures had drifted into order-dependence: the rank check leaned on a clear
   count left by thirty preceding tests, and the noise check seeded its history from
   a quest board that earlier checks had been editing. A deterministic seed over a
   non-deterministic board is not deterministic. Both build their own fixtures now.

The principle in every case, and in the precache generator that once reported
success without reading its own output: **assert on the result, never on the
intent.**

## v17 — five defects that shipped while the suite was green

The suite passed 137/137 on a build that **rendered nothing after login.** Each of
these was found by asking a question the tests were not asking.

1. **Two elements carried `id="app"`.** A vestigial v12 topbar sat in its own
   `main` element that was never closed, so the parser let it swallow the whole
   v13 shell — including the real container. `getElementById` returns the first
   match, so `enterSystem()` unhid the empty wrapper and every tabpane stayed
   `display:none`. The old `app visible` check called `getElementById("app")`
   too, so it confirmed the wrapper and reported clean. It now walks up from a
   real pane looking for a hidden ancestor: one answer, however many elements
   share an id.
2. **`sw.js` called `skipWaiting()` at install**, so a worker never *became* a
   waiting worker and `device.js` could never show the update prompt. The check
   was `/SKIP_WAITING/.test(sw)` — the string was present in the message handler
   thirty lines below, so it passed for three releases. It now reads the install
   handler specifically.
3. **A rest day broke the streak.** `rollover()` fell through to `streak = 0`
   when a day had no quests scheduled, and quest days have been user-selectable
   since v2.
4. **A date key was parsed as UTC.** `todayKey()` writes local; `new Date(key)`
   reads UTC midnight, which is the previous day west of Greenwich — so yesterday
   was judged against the wrong weekday's quests for half the world. This
   container runs in UTC, where the bug is invisible, so the check asserts on the
   parsed components and on the call site rather than on the ambient clock.
5. **The Gate's "Export everything" exported nothing** — it called an
   `exportHunter()` that had never existed, behind a `typeof` guard that turned
   the missing function into a silent redirect to Settings.

Three of these (2, 5, and a quadratic shelf rank) were fixed in v15 and returned
in v16, which was rebuilt from a v14 container. **A fix is not durable until a
check fails without it** — every one above now has a check that was confirmed to
fail against the v16 source before it was confirmed to pass against v17.


---

## v18.1 — release identity, and the end of reassignment

**Supported Node.** `^22.22.2 || ^24.15.0 || >=26.0.0`. This is not a
preference; it is what the locked tree requires. `jsdom` declares
`^22.22.2 || ^24.15.0 || >=26`, `undici` `>=22.19.0`, `whatwg-url`
`^22.14.0 || >=24`. Node 18 and Node 20 are excluded by every one of those, so
the previous `>=18` was not a lenient range — it was a false one, and a
developer who trusted it got an install that could not run the suite.
`release-test.js` samples every Node major the declared range admits and fails
if any dependency rejects one.

**One version.** `package.json` is the source. `npm run version:sync` writes it
into `system/app/version.js`, `system/sw.js` and `system/manifest.json`;
`npm run version:check` fails if any of them drifted. The older check in
`offline-test.js` compared the three to *each other*, which they satisfied
throughout v18.0 while all three said `18.0.0` in a build called v18.1.

**The dispatch registry.** `hooks-test.js` covers `core/hooks.js`: composition
order, argument rewriting, short-circuiting, unsubscribe, and error attribution.
It also asserts two things about the source rather than the runtime — that no
file reassigns a function another file declared, and that no global function is
declared in one file and assigned in another.

That second check closes a hole. The v15 collision guard matches
`^(function|const|let|var)\s+NAME` — **declarations**. `views/shelves.js` did
not declare `renderLibrary`, it assigned to it, so `content/library.js`'s
43-line implementation was overwritten on every load and had silently drifted
out of date. `renderScreen` in `views/v9-views.js` was the same, 38 lines. The
guard built to catch exactly this could not see it, because assignment is not
declaration.

**Timezones.** `npm run test:tz` runs every suite under UTC, America/New_York,
Asia/Tokyo and Africa/Accra — 32 runs. Two recommendation defects were found
this way in v18.1 and both were present in the shipped build:
`services/recommend.js` could emit `"Next on the board at 7:00 AM."`, 28
characters against the suite's own 40-character floor, because the explanatory
clause was appended only when the quest fell inside the student's strongest
block — a missing `else`. And the playstyle suggestion asserted a leaning with
no number behind it at all, in a product whose stated promise is explainable
recommendations. Neither is really about timezones; the clock only changed which
recommendation surfaced.
