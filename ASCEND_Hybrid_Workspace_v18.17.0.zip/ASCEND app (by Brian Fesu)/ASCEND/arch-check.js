/* THE SYSTEM v18 — arch-check.js
   The classic-script architecture, measured with a parser rather than a regex.

   ## Why this file exists

   87 classic scripts share one global scope, and load order *is* the dependency
   graph. Nothing declares what it needs, so every dependency is satisfied by
   the accident of sequence in index.html. That has produced the same defect
   five times in this project's history (two files declaring one global; the
   later silently wins) and one subtler one in v18's own audit (a shadow of a
   global inside an IIFE).

   The existing guard in brain-test.js catches duplicate declarations. It cannot
   catch the other half — a file that *calls* something at load time which a
   later file declares. In a browser that is a ReferenceError for `function`
   declarations only if the caller runs first, and a TDZ error for `const`/`let`
   always. Both are silent in the sense that matters: the page keeps loading,
   the rest of the script is skipped, and the first symptom is a feature that
   stopped existing.

   Earlier attempts at this used a brace-depth counter over lines. That is
   wrong, and demonstrably so: braces inside strings, template literals and
   regex literals all move the count, so it reported fourteen hazards of which
   most were function bodies it had lost track of. A question about program
   structure needs a parser. This uses acorn, which is a devDependency and
   ships with nothing.

   ## What it reports

     · the true top-level global surface, split by mutability
     · genuine load-order hazards: identifiers referenced in top-level
       executable code, declared in a file that loads later
     · files that are self-scoped (an IIFE) and therefore add nothing

   It exits non-zero only on a genuine hazard. The global count is reported as a
   measurement, not a threshold — an arbitrary ceiling would either be met by
   gaming it or ignored. */
"use strict";

const fs = require("fs");
const path = require("path");
const acorn = require("acorn");

const ROOT = process.env.ROOT || "./system";
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const files = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]);

/* Identifiers the platform provides. Anything here is not a load-order hazard. */
const AMBIENT = new Set([
  "window","document","navigator","location","console","localStorage","sessionStorage",
  "setTimeout","clearTimeout","setInterval","clearInterval","requestAnimationFrame",
  "fetch","Promise","Math","JSON","Date","Object","Array","String","Number","Boolean",
  "Map","Set","WeakMap","WeakSet","Symbol","Error","TypeError","RangeError","RegExp",
  "crypto","caches","indexedDB","URL","URLSearchParams","Intl","AbortController",
  "TextEncoder","TextDecoder","Blob","File","FileReader","FormData","Headers","Request",
  "Response","MessageChannel","BroadcastChannel","Notification","Audio","Image","Worker",
  "CustomEvent","Event","EventTarget","DOMParser","XMLHttpRequest","performance","screen",
  "history","matchMedia","alert","confirm","prompt","atob","btoa","structuredClone",
  "isNaN","isFinite","parseInt","parseFloat","encodeURIComponent","decodeURIComponent",
  "undefined","NaN","Infinity","globalThis","arguments","Function","Proxy","Reflect","BigInt",
  "queueMicrotask","getComputedStyle","scrollTo","IntersectionObserver","MutationObserver",
  "ResizeObserver","Uint8Array","Uint16Array","Uint32Array","Int8Array","Float32Array",
  "Float64Array","ArrayBuffer","DataView","SharedArrayBuffer","Element","HTMLElement","Node",
]);

const declaredIn = new Map();   /* name -> first file index that declares it */
const kindOf = new Map();       /* name -> const | let | var | function | class */
const selfScoped = [];
const perFile = [];

function declareTopLevel(node, idx, file) {
  const add = (name, kind) => {
    if (!declaredIn.has(name)) { declaredIn.set(name, idx); kindOf.set(name, kind); }
  };
  if (node.type === "FunctionDeclaration" && node.id) add(node.id.name, "function");
  else if (node.type === "ClassDeclaration" && node.id) add(node.id.name, "class");
  else if (node.type === "VariableDeclaration") {
    for (const d of node.declarations) {
      /* Destructuring at top level is rare here but must not be missed. */
      const names = [];
      (function collect(p) {
        if (!p) return;
        if (p.type === "Identifier") names.push(p.name);
        else if (p.type === "ObjectPattern") p.properties.forEach(pr => collect(pr.value || pr.argument));
        else if (p.type === "ArrayPattern") p.elements.forEach(collect);
        else if (p.type === "AssignmentPattern") collect(p.left);
        else if (p.type === "RestElement") collect(p.argument);
      })(d.id);
      names.forEach(n => add(n, node.kind));
    }
  }
}

/* A file whose entire body is one expression statement wrapping a function call
   keeps its own scope and contributes nothing global. */
function isSelfScoped(ast) {
  const real = ast.body.filter(n => n.type !== "EmptyStatement");
  if (real.length !== 1) return false;
  const n = real[0];
  return n.type === "ExpressionStatement" &&
    (n.expression.type === "CallExpression" || (n.expression.type === "UnaryExpression" && n.expression.argument.type === "CallExpression"));
}

/* Identifiers referenced by code that runs *at load*: top-level statements that
   are not declarations. A function declaration's body does not run at load, so
   it is deliberately not walked. */
function loadTimeRefs(ast) {
  const refs = new Set();
  const FN = new Set(["FunctionExpression", "ArrowFunctionExpression", "FunctionDeclaration", "ClassDeclaration", "ClassExpression"]);

  /* The first version of this walker descended into function bodies. That made
     `$("#btn").onclick = () => enterSystem()` — a top-level statement whose
     right-hand side does not run until a click — indistinguishable from a real
     load-time call, and it reported 42 hazards of which 41 were handlers. A
     function body is not load-time code, however it is attached. */
  const walk = n => {
    if (!n || typeof n.type !== "string") return;
    if (FN.has(n.type)) {
      /* Default parameter values and computed keys DO run when the function
         object is created, so they are not skipped. */
      (n.params || []).forEach(p => { if (p.type === "AssignmentPattern") walk(p.right); });
      return;
    }
    if (n.type === "Identifier") { refs.add(n.name); return; }
    if (n.type === "MemberExpression") { walk(n.object); if (n.computed) walk(n.property); return; }
    if (n.type === "Property") { if (n.computed) walk(n.key); walk(n.value); return; }
    if (n.type === "MethodDefinition") { if (n.computed) walk(n.key); return; }
    for (const k of Object.keys(n)) {
      if (k === "type" || k === "start" || k === "end" || k === "loc") continue;
      const v = n[k];
      if (Array.isArray(v)) v.forEach(c => c && typeof c.type === "string" && walk(c));
      else if (v && typeof v.type === "string") walk(v);
    }
  };

  for (const node of ast.body) {
    if (node.type === "FunctionDeclaration" || node.type === "ClassDeclaration") continue;
    if (node.type === "VariableDeclaration") {
      for (const d of node.declarations) if (d.init) walk(d.init);
      continue;
    }
    walk(node);
  }
  return refs;
}

console.log("arch-check — the classic-script architecture, parsed\n");

const asts = [];
files.forEach((f, i) => {
  const src = fs.readFileSync(path.join(ROOT, f), "utf8");
  let ast;
  try { ast = acorn.parse(src, { ecmaVersion: 2022, sourceType: "script" }); }
  catch (e) { console.log(`  FAIL  ${f} does not parse: ${e.message}`); process.exit(1); }
  asts.push(ast);
  if (isSelfScoped(ast)) { selfScoped.push(f); return; }
  ast.body.forEach(n => declareTopLevel(n, i, f));
});

/* Now the hazards, with every declaration known. */
const hazards = [];
files.forEach((f, i) => {
  if (selfScoped.includes(f)) return;
  for (const name of loadTimeRefs(asts[i])) {
    if (AMBIENT.has(name)) continue;
    if (!declaredIn.has(name)) continue;            /* not ours — assume ambient */
    const at = declaredIn.get(name);
    if (at > i) hazards.push({ file: f, name, declaredIn: files[at], kind: kindOf.get(name) });
  }
});

const byKind = { const: 0, let: 0, var: 0, function: 0, class: 0 };
for (const k of kindOf.values()) byKind[k] = (byKind[k] || 0) + 1;
const mutable = byKind.let + byKind.var;

console.log(`  ${files.length} classic scripts · ${selfScoped.length} self-scoped (contribute nothing global)`);
console.log(`  ${declaredIn.size} top-level names: ${byKind.function} functions · ${byKind.const} const · ${mutable} mutable (let/var) · ${byKind.class || 0} class`);
console.log(`  mutable global state is the part that matters for isolation, and it is ${mutable}.`);

if (hazards.length) {
  console.log(`\n  ${hazards.length} LOAD-ORDER HAZARD(S) — used at load, declared later:`);
  for (const h of hazards) console.log(`    ${h.file} uses ${h.name} (${h.kind}) declared later in ${h.declaredIn}`);
  console.log("\n  A `const`/`let` used before its file loads is a TDZ error; the rest of that");
  console.log("  script never runs, and nothing logs a cause. Move the file, or defer the use.");
  console.log("\narch-check FAILED");
  process.exit(1);
}

console.log("\n  no load-order hazards: nothing is used at load time before the file that declares it");
console.log("\narch-check clean");
