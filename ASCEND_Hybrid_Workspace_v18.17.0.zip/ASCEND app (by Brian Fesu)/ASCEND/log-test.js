/* ASCEND — log-test.js
   The event log, deterministic replay, and the claim that client and server
   compute the same answer.

   ## What is actually being proved

   The whole v19 architecture rests on one property: **the same events produce
   the same state everywhere.** If that holds, "offline-first" and
   "server-authoritative" stop contradicting each other — a student levels up on
   a dead connection, and the server recomputes the identical result later and
   can tell a real total from a tampered one. If it does not hold, every layer
   built on top of it inherits a lie.

   So this suite does not check that replay looks right. It runs the reducers in
   two runtimes — the browser bundle inside jsdom and the Node server through
   dynamic import — over the same event list, and compares.

   ## And the one that decides whether it is real

   The last check boots the app, plays a year of simulated usage through the real
   quest-clearing path, and compares what the log replays to what the record
   holds. That is shadow mode. Everything above it is scaffolding; this is the
   evidence that would justify making the log authoritative in a later release. */
"use strict";

const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");
const nodeCrypto = require("node:crypto");
const { JSDOM, VirtualConsole } = require("jsdom");

const ROOT = process.env.ROOT || "./system";
const SHARED = path.resolve("./shared");

const results = [], errors = [];
async function check(label, fn) {
  try { await fn(); results.push("  PASS  " + label); }
  catch (e) { results.push("  FAIL  " + label + " — " + e.message); errors.push(label); }
}

(async () => {

  /* The server's view of the domain: exactly the files the browser bundles. */
  const Ev = await import(path.join(SHARED, "events.js"));
  const Prog = await import(path.join(SHARED, "domain", "progression.js"));

  const dev = (d, n, ts, xp) => Ev.makeEvent({ type: "XP_GRANTED", data: { n: xp }, ts, device: d, seq: n });

  /* ---------- purity ---------- */
  await check("nothing in shared/ reads the clock, randomness or the locale", () => {
    const files = [];
    (function walk(d) {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory()) walk(p); else if (e.name.endsWith(".js")) files.push(p);
      }
    })(SHARED);
    assert.ok(files.length >= 2, "shared/ is empty");
    const banned = [
      [/\bDate\.now\s*\(/, "Date.now()"],
      [/\bnew\s+Date\b/, "new Date"],
      [/\bMath\.random\s*\(/, "Math.random()"],
      [/toLocale[A-Za-z]*\s*\(/, "a toLocale* call"],
      [/\bIntl\./, "Intl"],
      [/\bperformance\.now\b/, "performance.now()"],
    ];
    const bad = [];
    for (const f of files) {
      /* Comments are prose about these rules; only code is judged. */
      const code = fs.readFileSync(f, "utf8")
        .replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
      for (const [re, what] of banned) if (re.test(code)) bad.push(path.relative(SHARED, f) + " uses " + what);
    }
    assert.strictEqual(bad.length, 0,
      "a reducer that reads the environment replays differently than it recorded: " + bad.join("; "));
  });

  /* ---------- ordering ---------- */
  await check("ordering is total and does not depend on arrival order", () => {
    const evs = [dev("bbb", 0, 100, 50), dev("aaa", 0, 100, 30), dev("aaa", 1, 90, 10), dev("bbb", 1, 100, 5)];
    const a = Ev.canonical(evs).map(e => e.id);
    const b = Ev.canonical([...evs].reverse()).map(e => e.id);
    const c = Ev.canonical([evs[2], evs[0], evs[3], evs[1]]).map(e => e.id);
    assert.deepStrictEqual(a, b, "reversing the input changed the order");
    assert.deepStrictEqual(a, c, "shuffling the input changed the order");
    assert.deepStrictEqual(a, ["aaa:1", "aaa:0", "bbb:0", "bbb:1"],
      "equal timestamps must break on device id, then seq");
  });

  await check("replay is independent of the order events arrive in", () => {
    const evs = [];
    for (let i = 0; i < 60; i++) evs.push(dev(i % 2 ? "aaa" : "bbb", i, 1000 + (i % 7), 40 + (i % 13)));
    const straight = Prog.replayProgression(Ev.canonical(evs));
    const shuffled = Prog.replayProgression(Ev.canonical([...evs].sort(() => 0.5 - Math.random())));
    assert.deepStrictEqual(straight, shuffled);
    assert.ok(straight.level > 1 && straight.totalXp > 0, "the fixture produced no progression");
  });

  await check("the same event arriving twice is counted once", () => {
    const evs = [dev("aaa", 0, 10, 100), dev("aaa", 1, 20, 100)];
    const once = Prog.replayProgression(Ev.merge(evs));
    const twice = Prog.replayProgression(Ev.merge(evs, evs, [evs[0]]));
    assert.deepStrictEqual(once, twice, "a retried sync double-counted XP");
    assert.strictEqual(twice.totalXp, 200);
  });

  await check("merging two devices' logs gives both devices the same history", () => {
    const A = [dev("aaa", 0, 10, 50), dev("aaa", 1, 30, 50)];
    const B = [dev("bbb", 0, 20, 70), dev("bbb", 1, 40, 20)];
    const onA = Ev.merge(A, B).map(e => e.id);
    const onB = Ev.merge(B, A).map(e => e.id);
    assert.deepStrictEqual(onA, onB, "the two devices ended up with different histories");
    assert.deepStrictEqual(Prog.replayProgression(Ev.merge(A, B)), Prog.replayProgression(Ev.merge(B, A)));
  });

  /* ---------- compaction ---------- */
  await check("folding old events into a snapshot gives the identical answer", () => {
    const evs = Ev.canonical(Array.from({ length: 300 }, (_, i) => dev("aaa", i, 1000 + i, 25)));
    const whole = Prog.replayProgression(evs);
    const base = Prog.replayProgression(evs.slice(0, 220));
    const compacted = Prog.replayProgression(evs.slice(220), base);
    assert.deepStrictEqual(compacted, whole,
      "compaction changed the result, so the log cannot be safely bounded");
  });

  await check("replaying twice over the same array gives the same state", () => {
    const evs = Ev.canonical([dev("aaa", 0, 10, 900), dev("aaa", 1, 20, 900)]);
    const first = Prog.replayProgression(evs);
    const second = Prog.replayProgression(evs);
    assert.deepStrictEqual(first, second, "a reducer is mutating its input");
  });

  /* ---------- hostile input ---------- */
  await check("a malformed or hostile event cannot corrupt the record", () => {
    const good = dev("aaa", 0, 10, 100);
    const evil = [
      { ...good, id: "aaa:1", seq: 1, data: { n: NaN } },
      { ...good, id: "aaa:2", seq: 2, data: { n: "1e400" } },
      { ...good, id: "aaa:3", seq: 3, data: { n: -5000 } },
      { ...good, id: "aaa:4", seq: 4, type: "SOMETHING_FROM_A_NEWER_CLIENT", data: { n: 5 } },
      { ...good, id: "aaa:5", seq: 5, data: { n: 1e18 } },
    ];
    const out = Prog.replayProgression(Ev.canonical([good, ...evil]));
    assert.ok(Number.isFinite(out.totalXp), "totalXp became non-finite");
    assert.ok(Number.isFinite(out.level) && out.level >= 1, "level became invalid");
    assert.ok(out.totalXp >= 100, "the valid event was lost");
  });

  await check("an unknown event type is skipped, not fatal", () => {
    assert.throws(() => Ev.makeEvent({ type: "NOPE", ts: 1, device: "a", seq: 0 }),
      "makeEvent should refuse to create an unknown type");
    const out = Prog.replayProgression([{ id: "a:0", seq: 0, ts: 1, device: "a", type: "FUTURE", data: {} }]);
    assert.deepStrictEqual(out, { xp: 0, level: 1, totalXp: 0, grants: 0 });
  });

  /* ---------- two runtimes, one answer ---------- */
  await check("the browser bundle and the Node server replay to identical state", async () => {
    const evs = Ev.canonical(Array.from({ length: 400 }, (_, i) =>
      dev(i % 3 === 0 ? "aaa" : "bbb", i, 1_700_000_000_000 + i * 97, 10 + (i % 47))));
    const onServer = Prog.replayProgression(evs);

    /* The same arithmetic, but run out of the compiled bundle inside jsdom —
       a different parser, a different global object, a different code path to
       get there. If those disagree, "the server can recompute what the client
       claims" is not true. */
    const dom = new JSDOM("<!doctype html><html><body></body></html>",
      { runScripts: "dangerously", url: "https://local.test/", virtualConsole: new VirtualConsole() });
    const w = dom.window;
    Object.defineProperty(w, "crypto", { value: { getRandomValues: a => a }, configurable: true });
    w.matchMedia = q => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {} });
    const el = w.document.createElement("script");
    el.textContent = fs.readFileSync(path.join(ROOT, "bundle.js"), "utf8");
    w.document.body.appendChild(el);
    assert.ok(w.ASCEND && typeof w.ASCEND.replayProgression === "function",
      "the bundle does not expose ASCEND.replayProgression");
    const onClient = w.ASCEND.replayProgression(evs);
    dom.window.close();

    /* Field by field, not deepStrictEqual: the two objects come from different
       realms, so their prototypes differ and a structural compare fails on
       values that are in fact identical. That is the check reporting a
       difference between jsdom and Node rather than between client and server. */
    for(const k of ["xp", "level", "totalXp", "grants"]){
      assert.strictEqual(onClient[k], onServer[k],
        `${k}: client ${onClient[k]} vs server ${onServer[k]}`);
    }
    assert.ok(onServer.level > 5, "the fixture was too small to be meaningful");
  });

  await check("the level curve is defined once, not restated in the app", () => {
    const live = fs.readFileSync(path.join(ROOT, "services/progression.js"), "utf8");
    assert.ok(!/const\s+xpNeeded\s*=/.test(live),
      "services/progression.js still declares its own xpNeeded — two level curves is two answers");
    for (let lvl = 1; lvl <= 40; lvl++) {
      assert.strictEqual(Prog.xpNeeded(lvl), Math.round(100 * Math.pow(lvl, 1.35)));
    }
  });

  /* ---------- shadow mode against the real app ---------- */
  await check("a year of real usage replays to exactly what the record holds", async () => {
    const dom = new JSDOM(fs.readFileSync(path.join(ROOT, "index.html"), "utf8"), {
      runScripts: "dangerously", url: "https://local.test/",
      virtualConsole: new VirtualConsole(), pretendToBeVisual: true,
    });
    const w = dom.window, d = w.document;
    Object.defineProperty(w, "crypto", { value: {
      getRandomValues: a => { nodeCrypto.randomFillSync(Buffer.from(a.buffer, a.byteOffset, a.byteLength)); return a; },
      subtle: { importKey: async () => ({}), deriveBits: async () => new Uint8Array(32).buffer,
        digest: async () => new Uint8Array(32).buffer, deriveKey: async () => ({}),
        encrypt: async () => new Uint8Array(16).buffer, decrypt: async () => new Uint8Array(16).buffer },
    }, configurable: true });
    w.matchMedia = q => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
    w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {};
    w.AudioContext = function () { return { createGain: () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} } }), createOscillator: () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0, setValueAtTime() {} }, type: "" }), createBufferSource: () => ({ connect() {}, start() {}, stop() {}, buffer: null, loop: false }), createBuffer: () => ({ getChannelData: () => new Float32Array(1000) }), createBiquadFilter: () => ({ connect() {}, frequency: { value: 0 }, type: "", Q: { value: 0 } }), destination: {}, sampleRate: 44100, currentTime: 0, close() {}, resume() {} }; };
    w.indexedDB = undefined;

    /* A controllable clock. Without it the fixture grants a year of XP inside a
       single simulated day and the anti-farm cap correctly refuses most of it —
       which is the app behaving properly and the test lying about its scope. */
    let FAKE_NOW = Date.parse("2026-01-05T09:00:00Z");
    class FakeDate extends Date {
      constructor(...a) { if (a.length) super(...a); else super(FAKE_NOW); }
      static now() { return FAKE_NOW; }
    }
    w.Date = FakeDate;
    const advanceDay = () => { FAKE_NOW += 86400000; };

    for (const s of [...d.querySelectorAll("script[src]")].map(x => x.getAttribute("src"))) {
      const el = d.createElement("script");
      el.textContent = fs.readFileSync(path.join(ROOT, s), "utf8");
      d.body.appendChild(el);
    }
    await new Promise(r => setTimeout(r, 1600));
    d.getElementById("scr-login").classList.remove("hidden");
    d.getElementById("btnNewHunter").click();
    d.getElementById("regName").value = "Shadow";
    d.getElementById("regTitle").value = "The Audited";
    d.getElementById("regGo").click();
    d.querySelector('#obWorkout .chip[data-w="calisthenics"]').click();
    for (const n of ["2", "3", "4"]) d.querySelectorAll("[data-next]").forEach(b => { if (b.dataset.next === n) b.click(); });
    await new Promise(r => setTimeout(r, 50));
    d.getElementById("obFinish").click();
    await new Promise(r => setTimeout(r, 400));

    const br = d.createElement("script");
    br.textContent = 'window.__L = { grantXp, Log, H, save, DB };';
    d.body.appendChild(br);
    const S = w.__L;
    assert.ok(S && typeof S.grantXp === "function", "grantXp is not reachable");

    /* A year of grants through the app's own funnel — the real function, with
       its real level loop, its real hooks and its real daily cap, not a
       reimplementation. */
    for (let day = 0; day < 365; day++) {
      const perDay = 1 + (day % 4);
      for (let i = 0; i < perDay; i++) S.grantXp(15 + ((day * 7 + i * 13) % 60), "quest cleared");
      advanceDay();
    }
    const audit = S.Log.audit();
    const live = S.H();

    assert.ok(audit, "no audit was produced");
    assert.ok(audit.events >= 365, `only ${audit.events} events were recorded for 365 days of usage`);
    assert.ok(live.level > 10, `the fixture only reached level ${live.level}`);
    /* The emit sits inside grantXpBase, downstream of the anti-farm wrapper, so
       the log records what was actually granted rather than what was asked for.
       A log that recorded requests would over-count every capped day and then
       "prove" a total the student never earned. */
    assert.strictEqual(audit.replayed.totalXp, live.totalXp,
      "the log recorded a different total than the record actually paid");
    /* The record started at level 1 with 0 XP and the log starts empty, so they
       must land on the same number. Any gap is an XP path that bypasses the
       funnel — which is exactly what shadow mode exists to find. */
    assert.ok(audit.agrees,
      "the log and the record disagree: " + JSON.stringify(audit.diffs) +
      ` (record level ${live.level}, replayed level ${audit.replayed.level})`);

    /* Now the case the year-long fixture never reaches, because advancing the
       day resets the anti-farm ledger: hammer one day past the cap. The log must
       follow what was PAID, not what was ASKED FOR.

       This is a separate case because a mutation moving the emit upstream of the
       cap survived the check above unnoticed — the fixture simply never had a
       grant refused. A rule nothing exercises is a rule nothing enforces. */
    const beforeXp = live.totalXp, beforeEvents = audit.events;
    let requested = 0;
    for (let i = 0; i < 400; i++) { S.grantXp(50, "hammering one day"); requested += 50; }
    const capped = S.Log.audit();
    const paid = S.H().totalXp - beforeXp;

    assert.ok(paid < requested,
      `the anti-farm cap did not engage — ${requested} XP requested and all of it paid`);
    assert.ok(capped.agrees,
      "past the daily cap the log and the record diverge: " + JSON.stringify(capped.diffs));
    assert.strictEqual(capped.replayed.totalXp, S.H().totalXp,
      "the log recorded requested XP rather than paid XP, which would prove a total never earned");
    assert.ok(capped.events - beforeEvents < 400,
      "an event was recorded for every request, including the refused ones");
    dom.window.close();
  });

  console.log("\nASCEND — the event log and deterministic replay\n");
  console.log(results.join("\n"));
  if (errors.length) { console.log(`\n${errors.length} of ${results.length} checks failed\n`); process.exit(1); }
  console.log(`\nall ${results.length} checks passed\n`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
