/* THE SYSTEM v18 — evidence-test.js
   Checks for the evidence ledger and the opportunity engine's sight of it.

   Every check here was run against system.v17.orig first and confirmed to fail.
   A check that cannot fail against the broken implementation is not a check —
   that is the lesson this project paid for five times.

   Run:  node evidence-test.js                  (against ./system)
         ROOT=./system.v17.orig node evidence-test.js   (must fail)  */
const { JSDOM, VirtualConsole } = require("jsdom");
const fs = require("fs"), path = require("path");
const ROOT = process.env.ROOT || "./system";

const errors = [];
const vc = new VirtualConsole();
vc.on("jsdomError", e => errors.push("JSDOM: " + (e.message || e)));
vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const dom = new JSDOM(html, { runScripts:"dangerously", url:"https://local.test/", virtualConsole:vc, pretendToBeVisual:true });
const w = dom.window, d = w.document;
w.crypto = w.crypto || {};
const nc = require("crypto");
w.crypto.getRandomValues = a => { nc.randomFillSync(Buffer.from(a.buffer,a.byteOffset,a.byteLength)); return a; };
w.crypto.subtle = w.crypto.subtle || { importKey:async()=>({}), deriveBits:async()=>new Uint8Array(32).buffer, digest:async()=>new Uint8Array(32).buffer, deriveKey:async()=>({}), encrypt:async()=>new Uint8Array(16).buffer, decrypt:async()=>new Uint8Array(16).buffer };
w.matchMedia = w.matchMedia || (q=>({matches:false,media:q,addEventListener(){},removeEventListener(){},addListener(){},removeListener(){}}));
w.scrollTo = ()=>{}; w.HTMLElement.prototype.scrollIntoView = ()=>{};
w.AudioContext = function(){ return { createGain:()=>({connect(){},gain:{value:0,setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}}}), createOscillator:()=>({connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}},type:""}), createBufferSource:()=>({connect(){},start(){},stop(){},buffer:null,loop:false}), createBuffer:()=>({getChannelData:()=>new Float32Array(1000)}), createBiquadFilter:()=>({connect(){},frequency:{value:0},type:"",Q:{value:0}}), destination:{}, sampleRate:44100, currentTime:0, close(){}, resume(){} }; };
w.indexedDB = undefined;
for(const s of [...d.querySelectorAll("script[src]")].map(s=>s.getAttribute("src"))){
  const p = path.join(ROOT, s);
  if(!fs.existsSync(p)){ errors.push("MISSING "+s); continue; }
  const el = d.createElement("script"); el.textContent = fs.readFileSync(p,"utf8"); d.body.appendChild(el);
}
let TOK = 0;
function run(code){
  const tok = ++TOK;
  const el = d.createElement("script");
  el.textContent = `window.__R=${JSON.stringify({__tok:tok})};try{window.__R=Object.assign({__tok:${tok}},(function(){${code}})());}catch(e){window.__R={__tok:${tok},__err:e.message};}`;
  d.body.appendChild(el);
  const r = w.__R;
  if(!r || r.__tok !== tok) throw new Error("script did not run (parse error?)");
  if(r.__err) throw new Error(r.__err);
  return r;
}
let pass = 0, fail = 0;
function check(label, fn){
  let ok = false, note = "";
  try{ const r = fn(); ok = r === true || (r && r.ok === true); note = (r && r.note) || ""; }
  catch(e){ note = "threw: " + e.message; }
  console.log(`  ${ok ? "PASS" : "FAIL"}  ${label}${note ? "\n         " + note : ""}`);
  ok ? pass++ : fail++;
}

(async () => {
  await new Promise(r=>setTimeout(r,1600));
  d.getElementById("scr-login").classList.remove("hidden");
  d.getElementById("btnNewHunter").click();
  d.getElementById("regName").value = "Evidence"; d.getElementById("regTitle").value = "Auditor";
  d.getElementById("regGo").click();
  d.querySelector('#obWorkout .chip[data-w="calisthenics"]').click();
  for(const n of ["2","3","4"]) d.querySelectorAll('[data-next]').forEach(b=>{ if(b.dataset.next===n) b.click(); });
  await new Promise(r=>setTimeout(r,60));
  d.getElementById("obFinish").click();
  await new Promise(r=>setTimeout(r,400));

  console.log("\n  — the evidence ledger —\n");

  check("a named skill with nothing behind it is 'claimed', not demonstrated", () => {
    const r = run(`
      const p = createProject({ title:"Weather station", category:"Technology" });
      p.skills = ["Electronics"]; save();
      const s = skillEvidenceFor("Electronics");
      return { grade:s && s.grade, n: demonstratedSkills().length };
    `);
    return { ok: r.grade === "claimed", note:`grade after naming a skill: ${r.grade}` };
  });

  check("a completed milestone alone does not demonstrate a skill", () => {
    const r = run(`
      const p = projectStore().items[0];
      toggleMilestone(p.id, p.milestones[0].id);
      return { grade: skillEvidenceFor("Electronics").grade, done: p.milestones.filter(m=>m.done).length };
    `);
    return { ok: r.grade === "claimed", note:`${r.done} milestone done, evidence 0 → still ${r.grade}` };
  });

  check("evidence plus a completed milestone demonstrates it", () => {
    const r = run(`
      const p = projectStore().items[0];
      addEvidence(p.id, { name:"Photo of the build", kind:"link", url:"https://example.org/x" });
      return { grade: skillEvidenceFor("Electronics").grade, ledger: evidenceLedger().demonstrated };
    `);
    return { ok: r.grade === "demonstrated" && r.ledger === 1, note:`grade ${r.grade} · ledger demonstrated ${r.ledger}` };
  });

  check("a claim never reaches the opportunity engine", () => {
    const r = run(`
      const p = createProject({ title:"Robotics olympiad entry", category:"STEM" });
      p.skills = ["Robotics"]; save();
      const hits = evidenceMatching("robotics competition for students", "STEM");
      return { skills: hits.skills.map(s=>s.name), projects: hits.projects.map(x=>x.title) };
    `);
    return { ok: !r.skills.includes("Robotics") && !r.projects.includes("Robotics olympiad entry"),
             note:`unevidenced project/skill returned: ${JSON.stringify(r)}` };
  });

  check("a demonstrated project raises an opportunity's match and says why", () => {
    const r = run(`
      const o = addOpportunity({ name:"National Weather Data Challenge", kind:"competition",
        category:"Technology", deadline: todayKey(new Date(Date.now()+86400000*30)), notes:"weather station data" });
      const m = matchOpportunity(o);
      const f = m.factors.find(x => x.k === "Your evidence");
      return { score:m.score, state: f && f.state, text: f && f.text };
    `);
    return { ok: r.state === "pass" && /Weather station/i.test(r.text || ""),
             note:`${Math.round(r.score*100)}% · ${r.text ? r.text.slice(0,90) : "(no evidence factor)"}` };
  });

  check("an opportunity with no matching work says so rather than staying silent", () => {
    const r = run(`
      const o = addOpportunity({ name:"National Poetry Recital", kind:"competition",
        category:"Creative", deadline: todayKey(new Date(Date.now()+86400000*30)), notes:"spoken word" });
      const f = matchOpportunity(o).factors.find(x => x.k === "Your evidence");
      return { state: f && f.state, text: f && f.text };
    `);
    return { ok: r.state === "unknown" && /intention rather than on work/.test(r.text || ""),
             note: r.text ? r.text.slice(0,90) : "(no evidence factor)" };
  });

  check("substring luck does not count as a match", () => {
    const r = run(`
      const hits = evidenceMatching("Startup pitch for artists", "Creative");
      return { skills: hits.skills.map(s=>s.name), projects: hits.projects.map(p=>p.title) };
    `);
    return { ok: r.skills.length === 0 && r.projects.length === 0,
             note:`"art" inside "Startup"/"artists" matched: ${JSON.stringify(r)}` };
  });

  check("the ledger counts verified separately from demonstrated", () => {
    const r = run(`
      const before = evidenceLedger();
      const p = projectStore().items[0];
      const selfPromote = canSetVerification("verified");   /* §15: must be false */
      p.verification = "verified"; save();
      const after = evidenceLedger();
      return { vBefore:before.verified, vAfter:after.verified, grade: skillEvidenceFor("Electronics").grade, selfPromote };
    `);
    return { ok: r.vBefore === 0 && r.vAfter === 1 && r.grade === "verified" && r.selfPromote === false,
             note:`verified ${r.vBefore} → ${r.vAfter}, grade ${r.grade}, self-promotable ${r.selfPromote}` };
  });

  check("evidence.js is precached, or offline loses it", () => {
    const sw = fs.readFileSync(path.join(ROOT, "sw.js"), "utf8");
    const inHtml = /services\/evidence\.js/.test(fs.readFileSync(path.join(ROOT, "index.html"), "utf8"));
    return { ok: inHtml && /services\/evidence\.js/.test(sw),
             note:`index.html ${inHtml} · sw.js ${/services\/evidence\.js/.test(sw)}` };
  });

  console.log(`\n  ${pass} passed · ${fail} failed · ${errors.length} console errors`);
  errors.slice(0,5).forEach(e => console.log("   " + e));
  process.exit(fail || errors.length ? 1 : 0);
})();
