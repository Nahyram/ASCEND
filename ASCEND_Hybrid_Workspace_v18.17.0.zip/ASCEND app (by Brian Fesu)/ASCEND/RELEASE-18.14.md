# ASCEND 18.14 — the progression ledger, and the code that had no way in

Everything in this release already existed. None of it could be reached.

---

## The feature: your XP history is finally visible

ASCEND has kept an append-only event log since 18.10 — every XP grant, its
reason, its device, its timestamp — replayed deterministically on the client and
again on the server since 18.11. **Nothing in any view rendered a single line of
it.** A student had a complete, auditable history of their own year and no screen
showing it.

**Path → Standing → Progression ledger** now shows it: entries grouped by day,
newest first, with what each point was for. Below the totals, two lines that
matter more than the entries:

* **Whether the record and the log agree.** Shadow mode has been comparing them
  since 18.10 and reporting to nobody. If they diverge, the screen says so, says
  it is a fault in ASCEND rather than in the student's work, and **changes
  nothing** — silently correcting a record to match a log turns one bug into a
  lost term.
* **Whether the server agrees too**, when signed in.

---

## The audit that produced the rest

I counted every function the app declares and every place each is referenced:
**554 declared, 33 called by nothing at all.** Not dead branches — whole
capabilities with no way in. §28 of your spec says a button must not be fake;
this is the same defect arriving from the other side, and it is the one this
codebase actually had.

### The protective half of `services/integrity.js` was entirely dead

Five functions, shipped since v18, referenced by nothing outside their own file.

**`guardedSave` — a failed write lost the work.** `save()` wrote directly, showed
a toast, and returned false that almost every one of its 186 call sites ignored.
`guardedSave` exists to stash what could not be written so it can be handed back.
`save()` now routes through it, which wires all 186 at once.

**`recoverUnsaved` — nothing ever offered the stash back.** A recovery copy nobody
is shown is the same as no recovery copy. Boot now retries the held write after
the store hydrates, and tells the student only if it is *still* failing — on the
common path the problem is gone by the next load and they never needed to know.

**`safeUrl` — a real injection vector.** `views/beyond.js` put an opportunity URL
straight into an `href` through `esc()`. `esc()` escapes HTML; it does not touch
`javascript:`, which contains no character it escapes. So `javascript:alert(1)`
survived and became a live link on a button the student clicks — and opportunity
URLs come from what a student types and from imported files. `safeUrl` was
written for exactly this and called nowhere.

### `entitlement()` was enforced nowhere — for the second time

Zero call sites outside `cloud.js`. **v18 found this exact defect** — the rule
declared and enforced nowhere — and the fix then was to write the rule, not to
call it. The AI path now checks it. The server was never the hole here; it
refuses over its own limit regardless. The difference is between a student being
told their plan does not include the tutor and one watching a request fail with
no explanation.

### Both of 18.12's features were unreachable

`plannedRecommendations()` and `scheduleActionAsQuest()` shipped two releases ago
and were reachable **only from their own test suite**. My gap, and the sharpest
illustration of the whole problem: a green suite proved they worked, and no
student could press them.

The brief now has a time control — *as long as it takes · 20 · 45 · 90 min* — and
each recommendation carries its estimate, marks what will not fit, and offers
**+ Quest** to put it on the board.

---

## The ratchet

`reachability-test.js` recounts unreachable functions on every run and fails if
the number goes up. **33 → 28**, five wired rather than deleted. The ceiling is a
literal someone edits, so going backwards requires a decision.

The remaining 28 are listed in the failure message when it trips. They are real
work, not noise — `toggleChecklistItem` means opportunity checklists cannot be
ticked; `renderFrontier` is a view that never renders; `evidenceLedger` has no
viewer. Next release's material.

---

## One found in my own test

Three mutations, two caught immediately. The third — unhooking the ledger from
`renderPath()` entirely — **passed**, because my test called `renderLedger()`
directly instead of going through the real entry point. That is precisely the
"reachable only from its own test" defect this release is about, reproduced in
the test written to catch it. It now renders through `renderPath()`, and the
mutation fails loudly.

---

## Verification

`reachability-test.js` — 10 checks: the four wirings as static fact; `safeUrl`
against eight hostile inputs including case-varied `JaVaScRiPt:`; the ledger
rendering real entries through the real render path; divergence surfaced and
**not** corrected; the stash written on a failed write and retried at boot; and
the ratchet.

**19 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra.

---

## On the School RPG spec

Taken: the XP history screen, which is §22 already built and now visible.

Not taken, and still needing your decision rather than code: teachers, parents,
classes, admins, RBAC and leaderboards. Those need multi-tenancy and the
deliberate removal of the account isolation this server enforces and tests, and
they are built on other people's children's records.

Next from that spec, all single-student and safe: **vacation mode**, **home
quests**, and moving the **achievement engine onto the event log** so achievements
fire from recorded events rather than ad-hoc counters.

Still yours: the **host decision**, **`MAIL_TRANSPORT`** (recovery is built and
off), the **data-protection position**, and the **PIN with no recovery path**.
