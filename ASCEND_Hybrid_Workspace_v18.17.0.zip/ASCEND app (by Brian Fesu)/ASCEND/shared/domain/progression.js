/* ASCEND — shared/domain/progression.js
   XP and level, as a pure function of the event log.

   ## The rule this enforces

   §6 of the v19 notes: rank is not a renamed XP level. This file owns XP and
   level only. Rank stays in services/records.js, where it is gated on quests
   cleared, a streak held, achievements earned and bosses put down — and it moves
   under replay in a later release, once the events those depend on exist. Adding
   a second rank implementation here to make the release look complete is exactly
   how this project shipped five duplicate-rule collisions.

   ## The curve

   xpNeeded lived in services/progression.js as a const and now lives here, with
   that file reading it through the bridge. One definition, because a level curve
   that disagreed between client and server would let a student's phone and their
   account report different levels — and whichever the student saw first is the
   one they would believe.

   ## Purity

   No clock, no randomness, no locale. Given the same events this returns the same
   state on a phone in Accra, on a laptop in New York, and on the server, forever.
   log-test.js parses this file and fails on any impure call. */

import { EVENT_TYPES } from "../events.js";

export const xpNeeded = level => Math.round(100 * Math.pow(level, 1.35));

export const INITIAL = Object.freeze({ xp: 0, level: 1, totalXp: 0, grants: 0 });

/* One event in, one state out. Never mutates its input: replay has to be safe to
   run twice over the same array, and a reducer that mutates makes a second run
   disagree with the first. */
export function reduceProgression(state, ev) {
  switch (ev.type) {
    case EVENT_TYPES.XP_GRANTED: {
      const n = Number(ev.data && ev.data.n);
      /* A malformed amount is dropped rather than turned into NaN. NaN XP
         propagates into level, rank and every stat that reads them, and the
         record never recovers. */
      if (!Number.isFinite(n) || n <= 0) return state;
      let xp = state.xp + n;
      let level = state.level;
      /* Same loop the live code has run since v12, so shadow mode compares like
         with like. A cap because a corrupt event claiming 1e18 XP must not spin
         here forever — it stops at the level the log can actually justify. */
      let guard = 0;
      while (xp >= xpNeeded(level) && guard++ < 10000) { xp -= xpNeeded(level); level += 1; }
      return { xp, level, totalXp: state.totalXp + n, grants: state.grants + 1 };
    }
    default:
      /* An unknown type is a newer client's event, not corruption. Skipping it
         keeps an old client usable instead of failing a student's whole record
         over a field it has never heard of. */
      return state;
  }
}

/* `base` is a snapshot: compaction folds old events into a state and drops them,
   and replaying the remainder on top must give the identical answer. That
   equivalence is the thing that makes the log boundable, so log-test.js checks
   it directly rather than trusting it. */
export function replayProgression(events, base = INITIAL) {
  let state = { xp: base.xp | 0, level: base.level || 1, totalXp: base.totalXp | 0, grants: base.grants | 0 };
  for (const ev of events) state = reduceProgression(state, ev);
  return state;
}

/* Shadow mode. The live record and the replayed log should agree exactly; where
   they do not, that is a defect to surface, never something to quietly correct.
   Silently rewriting a student's level to match a log is how you turn one bug
   into a lost term of work. */
export function compareProgression(live, replayed) {
  const fields = ["xp", "level", "totalXp"];
  const diffs = fields
    .filter(f => Number(live && live[f]) !== Number(replayed[f]))
    .map(f => ({ field: f, live: Number(live && live[f]), replayed: Number(replayed[f]) }));
  return { agrees: diffs.length === 0, diffs };
}
