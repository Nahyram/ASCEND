/* ASCEND — shared/domain/next-action.js
   How long each recommendation takes, and what fits in the time a student has.

   ## Why this file exists

   services/recommend.js already answers "what is the highest-value next action"
   from goals, curriculum, mastery, errors, deadlines and history. It has done so
   since v14, deterministically, with a written reason attached to every item.

   It has never once asked how much time the student has. Every recommendation
   carried `minutes: null` or no minutes at all, which means the list a student
   saw at 21:40 on a school night was the same list they saw on a free Saturday.
   That is the difference between a ranking and a plan, and it is the one input
   on the v19 list that was genuinely missing.

   ## The rule that governs budgeting

   **Time may narrow the list. It may never reorder it, and it may never drop a
   hard constraint.**

   A deadline due tomorrow does not stop being due because the student has twenty
   minutes. The honest response to "this will not fit" is to say so — with what it
   would take and what could be done instead — not to quietly hide it and let the
   student find out at rollover. Hiding an overrunning obligation would be the
   same failure as the level-only rank that congratulated students for a promotion
   the System immediately took back.

   ## Purity

   No clock, no randomness, no locale. Same inputs, same plan, on a phone in Accra
   and on the server. next-action-test.js parses this directory and fails on any
   environment call. */

/* Ordering is the caller's; this file only ever preserves it. */
export const TIER_RANK = Object.freeze({ high: 0, medium: 1, optional: 2 });

/* Estimates by the kind of work, derived from the id prefix recommend.js already
   assigns. These are deliberately coarse. A precise-looking number the System
   cannot actually justify is worse than an honest band — §22 applies to time as
   much as to reasons, and "about 25 minutes" that is sometimes wrong is more
   useful than "24 minutes" that is always wrong. */
const DEFAULTS = Object.freeze({
  recovery: 15,
  deadline: 45,
  overdue:  20,
  next:     20,
  errors:   25,   /* a set of missed questions, revisited */
  exam:     45,
  stale:    20,   /* a topic that has decayed and needs one pass */
  project:  40,
  opp:      20,   /* an application step */
  goal:     30,
  weak:     20,
  style:    20,
});

export const DEFAULT_MINUTES = 20;

/* A quest carries its own scheduled length where the record has one; otherwise
   the kind decides. `hint` wins because it came from the student's own board. */
export function estimateMinutes(rec, hint) {
  if (Number.isFinite(hint) && hint > 0) return Math.round(hint);
  if (rec && Number.isFinite(rec.minutes) && rec.minutes > 0) return Math.round(rec.minutes);
  const kind = String((rec && rec.id) || "").split(":")[0];
  return DEFAULTS[kind] || DEFAULT_MINUTES;
}

/* Fit the ranked list into a budget without changing its order.

   Returns every recommendation, annotated — nothing is removed, because a
   student deciding what to skip needs to see what they are skipping. `fits` says
   whether it lands inside the budget; `overruns` marks a hard constraint that
   does not fit and is shown anyway.

   budget of null or 0 means "not stated", and then this is a pass-through: the
   student never told us, so the System does not invent an answer. */
export function planForBudget(recs, budgetMinutes) {
  const list = Array.isArray(recs) ? recs : [];
  const budget = Number(budgetMinutes);
  const stated = Number.isFinite(budget) && budget > 0;

  let spent = 0;
  let fitted = 0;
  const plan = list.map(r => {
    const minutes = estimateMinutes(r);
    if (!stated) return { ...r, minutes, fits: true, startsAt: null };

    const isHard = (r.tier || "optional") === "high";
    const roomLeft = budget - spent;
    const fits = minutes <= roomLeft;

    if (fits) { const startsAt = spent; spent += minutes; fitted++; return { ...r, minutes, fits: true, startsAt }; }

    /* Does not fit. A hard constraint is still shown and still first — the list
       is not reordered — with an honest note rather than a quiet removal. */
    return {
      ...r, minutes, fits: false, startsAt: null,
      overruns: isHard,
      shortfall: minutes - Math.max(0, roomLeft),
    };
  });

  const overrunning = plan.filter(p => p.overruns);
  return {
    plan,
    budget: stated ? budget : null,
    spent,
    remaining: stated ? Math.max(0, budget - spent) : null,
    fitted,
    overrunning: overrunning.length,
    /* One sentence the UI can print. Written here so the client and any future
       server-side brief say the same thing. */
    note: !stated
      ? "No time stated, so this is the full ranking rather than a plan."
      : overrunning.length
        ? `${fitted} of these fit in ${budget} minutes. ${overrunning.length} cannot be made to fit and ${overrunning.length === 1 ? "is" : "are"} shown anyway, because ${overrunning.length === 1 ? "it is" : "they are"} not optional — a deadline does not move because the evening is short.`
        : fitted === plan.length
          ? `All of this fits in ${budget} minutes, with ${Math.max(0, budget - spent)} to spare.`
          : `${fitted} of these fit in ${budget} minutes. The rest are ranked below and can wait.`,
  };
}

/* The invariant, exported so the suite can assert it against real output rather
   than against a description of it: budgeting never reorders. */
export function preservesOrder(before, after) {
  const a = before.map(r => r.id).join("|");
  const b = after.map(r => r.id).join("|");
  return a === b;
}
