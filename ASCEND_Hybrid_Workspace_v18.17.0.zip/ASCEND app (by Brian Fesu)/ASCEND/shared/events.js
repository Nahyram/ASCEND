/* ASCEND — shared/events.js
   The event vocabulary, and the rules that make a log replayable.

   ## Why this file is in shared/

   ASCEND has to be two contradictory things at once: offline-first, so a student
   on a dead connection keeps levelling up, and server-authoritative, so a student
   cannot hand themselves a rank. Those only reconcile if both sides compute the
   same answer from the same inputs — not similar answers, the same one. That is
   impossible with two implementations, and this project has already shipped the
   consequence of two implementations of one rule five times.

   So the domain lives here, imported by the browser bundle through esbuild and by
   the Node server through dynamic import. One file, two runtimes, byte-identical
   arithmetic. `log-test.js` proves it rather than asserting it.

   ## Why an event log at all

   Sync is currently a whole-record snapshot merge, which is why conflict handling
   needs a hand-written union rule per field, and why two devices editing the same
   day needs special care. Events replace all of that with concatenation: two
   devices produce two lists, the lists are appended, the result is sorted, and
   replay is a pure function. It also means the server can recompute what a client
   claims — an XP total the events do not produce is a tampered client, and that
   check costs nothing because the server was going to replay anyway.

   ## Nothing in this file may be impure

   No Date.now(), no Math.random(), no locale, no timezone. A reducer that reads
   the clock produces a different answer on replay than it did when the event was
   recorded, which silently destroys the one property the whole design rests on.
   log-test.js parses this directory and fails on any of them. */

/* Every type that may appear in a log. A log carrying an unknown type is not
   corrupt — a newer client wrote it — so replay skips it and says so rather than
   throwing away a student's record over a field it does not recognise. */
export const EVENT_TYPES = Object.freeze({
  XP_GRANTED: "XP_GRANTED",
});

export const LOG_VERSION = 1;

/* ---------- construction ----------
   `ts` and `device` are arguments rather than read from the environment, because
   a function that reads the clock cannot be tested for determinism and cannot be
   replayed. The caller owns the impurity; this file has none. */
export function makeEvent({ type, data = {}, ts, device, seq }) {
  if (!EVENT_TYPES[type]) throw new Error("unknown event type: " + type);
  if (!Number.isFinite(ts)) throw new Error("event needs a numeric ts");
  if (!device) throw new Error("event needs a device");
  if (!Number.isInteger(seq) || seq < 0) throw new Error("event needs a non-negative integer seq");
  return Object.freeze({ v: LOG_VERSION, id: device + ":" + seq, seq, ts, device, type, data });
}

export function isEvent(e) {
  return !!e && typeof e === "object"
    && typeof e.id === "string" && typeof e.type === "string"
    && Number.isFinite(e.ts) && typeof e.device === "string" && Number.isInteger(e.seq);
}

/* ---------- ordering ----------

   Two devices offline at the same time will produce events with equal or
   near-equal timestamps, and clocks disagree. So order is total and deterministic
   by construction: timestamp, then device id, then sequence.

   Device id breaks the tie rather than "whichever arrived first", because arrival
   order differs per device and would give two students' phones two different
   histories from identical events — which is precisely the bug this is designed
   to make impossible. Sorting by a value both sides can see gives both sides the
   same answer. */
export function compareEvents(a, b) {
  if (a.ts !== b.ts) return a.ts < b.ts ? -1 : 1;
  if (a.device !== b.device) return a.device < b.device ? -1 : 1;
  if (a.seq !== b.seq) return a.seq < b.seq ? -1 : 1;
  return 0;
}

export function canonical(events) {
  return [...events].filter(isEvent).sort(compareEvents);
}

/* Merging two devices' logs is concatenation plus this. An id is device+seq, so
   the same event arriving twice — a retried sync, a restored backup — collapses
   rather than being counted twice. Double-counted XP is the exact failure a
   student would notice and never forgive. */
export function merge(...lists) {
  const seen = new Map();
  for (const list of lists) for (const e of list || []) if (isEvent(e) && !seen.has(e.id)) seen.set(e.id, e);
  return canonical([...seen.values()]);
}
