# ASCEND 18.16 — the consumers, starting with the keystone

I recorded twice that the module migration could only progress by converting
consumers, and twice did something else. This is that release.

**Classic scripts: 77 → 72. Modules: 16 → 21.**

---

## `core/kernel.js` is now a module

It is the root of the whole app — `DB`, `H()`, `save()`, `load()`, `$`, `$$`,
`todayKey`, `SYSTEM_READY` — and converting it is what unblocked everything else.
`core/seeds.js`, `content/quotes.js`, `views/wall.js` and `armory.js` followed it
in the same pass, because they became convertible the moment it moved.

### `DB` needed a getter, not an assignment

Every other bridged name is stable: the value published at boot is the value
forever. `DB` is not — `kernel.js` reassigns it once the store hydrates, because
the IndexedDB driver cannot answer synchronously at load.

A copy taken at bundle time would therefore have been the **empty record,
permanently**, for all 72 classic scripts that read `DB` as a global. Every one
of them would have seen a hunter with no quests while the modules saw the real
one. It is published through a getter that forwards to the live module binding.

There is deliberately **no setter**. Only `kernel.js` writes `DB` — measured
across all 76 classic scripts before the conversion rather than assumed — so a
stray `DB = ...` from a view now throws instead of quietly forking application
state.

---

## What went wrong, in order

Four failures, all real, all worth writing down.

**1. The converted modules had no imports.** I appended `export {…}` to each file
and moved it. As classic scripts they read `$` and `todayKey` from global scope;
as modules inside the bundle those names are not published *yet* when the bundle
initialises, so `content/quotes.js` threw `ReferenceError: $ is not defined` and
took the whole bundle with it. They import properly now. This is the dependency
inversion I warned about in 18.15, arriving on schedule.

**2. A view module killed the bundle.** `views/wall.js` attached three onclick
handlers at top level. Harmless for eight releases as a classic script — it
loaded after the markup. As a module, a throw during initialisation destroys
**every other module in the bundle**, including the bridge. One view touching a
missing element would have blanked the entire app.

**3. `armory.js` was a second publisher.** It assigned `window.Armory` directly.
Two publishers is how a bridge becomes permanent: one is written down and
shrinking, the other is invisible. It exports now, and `entry.js` remains the
only thing that reaches global scope.

**4. Four suites went red on a path, not on behaviour** — they hard-coded
`system/core/kernel.js`. They resolve through `appFile()` now, which was built
for exactly this in 18.8 and not applied everywhere.

---

## Two of my own checks were wrong

**The bridge extractor was reading comments as names.** A comment line inside the
`BRIDGE` object beginning "ALLD, QUOTES, WALL…" matched the same pattern as a
property, so the check demanded a consumer for a word in a sentence. It strips
comments now.

**And my first fix for problem 2 was a syntactic guess.** I added a rule that no
view module may contain `$(` in a top-level line — and it passed against a
`wall.js` that still touches the DOM at import time, one call deep, through
`wireWall()`. A check that reports a guarantee it does not test is worse than no
check.

It is behavioural now: **load the real bundle into a page with no app markup at
all and assert the bridge survived.** That is the property that actually matters,
and it is the one that broke. Mutation-tested — removing a single null guard in
`wall.js` fails it with the exact TypeError.

---

## A metric I had been reading backwards

I called bridge growth a warning sign twice. It is not, and 18.16 makes that
obvious: the bridge went **37 → 55** because converting a *root* necessarily adds
every name it owns, read by 72 files.

The bridge can only shrink when the **last** classic consumer of a name converts,
which in a leaf-to-root migration is near the end. `MAX_CLASSIC_SCRIPTS` is the
health metric, and it moves monotonically down: **89 → 76 → 77 → 72.** Check 8 —
no name bridged that nothing consumes — is what keeps the list honest meanwhile,
and it earned its keep here by catching `LS`, which no classic script reads.

`brain-test` then broke on `LS`, because it read the storage key from the app.
It asserts the literal `"system.v1"` now: a test that reads the key from the code
can only ever agree with the code, and every existing install is behind that key.

---

## Verification

`module-check.js` — 11 checks, including the new bare-DOM guarantee. Ratchets
reset to their new floors: 72 classic, 21 modules, 55 bridged.

**20 suites, all green**, from a clean `npm ci`, in UTC, America/New_York,
Asia/Tokyo and Africa/Accra.

---

## What is next

The same again. With kernel converted, the next tranche is whatever became free —
and the files that matter most are `services/day.js`, `services/progression.js`,
`services/link.js` and `services/recommend.js`, because those are the consumers
whose conversion starts taking names *off* the bridge rather than adding them.

Still yours: the **host decision**, **`MAIL_TRANSPORT`** (recovery is built and
off), the **data-protection position**, and the **PIN with no recovery path**.
