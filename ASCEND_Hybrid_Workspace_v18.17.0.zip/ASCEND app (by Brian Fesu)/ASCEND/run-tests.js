/* THE SYSTEM v18 — run-tests.js
   Every suite, one command, one exit code.

   `npm test` runs this. Suites are ordered cheapest-first so a parse error is
   reported in a second rather than after the jsdom boot, and each is run in its
   own process because these suites mutate a shared jsdom record and a leaked
   fixture is how two checks in this project's history drifted into
   order-dependence.

   `npm run test:tz` repeats everything in three timezones. A date bug that only
   appears west of Greenwich shipped in v16 and was invisible in this container,
   which runs UTC. */
"use strict";

const { spawnSync } = require("child_process");

const SUITES = [
  ["release",  "release-test.js",  "release identity, engine range and export metadata"],
  ["modules",  "module-check.js",  "the ES module migration: bundle drift, the bridge, the ratchet"],
  ["store",    "store-test.js",    "the IndexedDB driver and the migration onto it"],
  ["log",      "log-test.js",      "the event log, deterministic replay, client/server agreement"],
  ["next",     "next-action-test.js", "time budgeting and turning a recommendation into a quest"],
  ["reach",    "reachability-test.js", "code with no way in: the ledger, the wiring, the ratchet"],
  ["vacation", "vacation-test.js",  "vacation mode, home quests and application checklists"],
  ["syntax",   "syntax-check.js",  "parses every file and resolves every asset the page loads"],
  ["arch",     "arch-check.js",    "global surface and load-order hazards, parsed with acorn"],
  ["modules",  "module-readiness.js", "what still blocks the ES module conversion"],
  ["offline",  "offline-test.js",  "runs the real service worker against a mock cache, network off"],
  ["hooks",    "hooks-test.js",    "the dispatch registry that replaced 22 cross-file reassignments"],
  ["harness",  "harness.js",       "boots the app and visits every section"],
  ["brain",    "brain-test.js",    "the full behavioural suite"],
  ["evidence", "evidence-test.js", "the evidence ledger"],
  ["secrets",  "server/test/secret-scan.js",  "proves the OpenAI key cannot reach a browser"],
  ["backend",  "server/test/server-test.js",   "auth, isolation, sync conflicts, entitlements, AI limits"],
  ["recovery", "recovery-test.js",  "password reset and email verification"],
  ["replay",   "server-replay-test.js", "the server replaying the log: tamper detection, convergence"],
  ["sync",     "sync-test.js",     "the real client against the real server: accounts, sync, AI routing"],
];

const ZONES = process.argv.includes("--timezones")
  ? ["UTC", "America/New_York", "Asia/Tokyo", "Africa/Accra"]
  : [process.env.TZ || "UTC"];

let failed = [];
const t0 = Date.now();

for (const tz of ZONES) {
  if (ZONES.length > 1) console.log(`\n${"=".repeat(64)}\nTZ=${tz}\n${"=".repeat(64)}`);
  for (const [name, file, blurb] of SUITES) {
    process.stdout.write(`\n▸ ${name} — ${blurb}\n`);
    const r = spawnSync(process.execPath, [file], {
      stdio: "inherit",
      env: { ...process.env, TZ: tz },
    });
    if (r.status !== 0) failed.push(`${name}${ZONES.length > 1 ? ` (TZ=${tz})` : ""}`);
  }
}

const secs = ((Date.now() - t0) / 1000).toFixed(1);
console.log("\n" + "=".repeat(64));
if (failed.length) {
  console.log(`FAILED: ${failed.join(", ")}  ·  ${secs}s`);
  process.exit(1);
}
console.log(`all suites passed  ·  ${SUITES.length * ZONES.length} runs  ·  ${secs}s`);
