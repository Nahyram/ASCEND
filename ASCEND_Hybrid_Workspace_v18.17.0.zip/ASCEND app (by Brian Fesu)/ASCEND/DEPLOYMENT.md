# ASCEND — Deployment

Backend: Node 22, zero runtime dependencies, SQLite via `node:sqlite`.
Frontend: static PWA, no build step.

---

## PART 1 — WHAT ONLY YOU CAN DO

Nine items. Everything else is already built and tested. Each one is something
that costs money, requires an account in your name, or is a decision I should
not make for you.

### 1. Revoke the three OpenAI keys already exposed
`platform.openai.com` → API keys → revoke every key pasted into chat.
They are compromised regardless of anything else here. **Do this first.**

A key that has been in a chat log is spent — not "probably fine", spent. The only
place a key belongs is the host's secret manager, set through the host's own UI
or CLI, never typed into a file you edit and never into a message.

### 2. Choose and create a host
The backend needs a Node 22 runtime **and a persistent disk**. The disk matters
more than the runtime: SQLite is a file, and a host with an ephemeral filesystem
silently discards every account on each redeploy.

| Host | Persistent disk | Rough cost |
|---|---|---|
| Render | yes, add a Disk | free tier sleeps; ~$7/mo to stay awake |
| Railway | yes, volume | usage-based, ~$5/mo |
| Fly.io | yes, volume | ~$3–5/mo |
| A VPS (Hetzner/DO) | yes | ~$5/mo |
| Vercel / Netlify functions | **no** | not suitable without swapping to Postgres |

### 3. Generate the session pepper
```
node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"
```
Put the output in the host's secret manager as `SESSION_PEPPER`. Not in a file.
Losing it signs everyone out; leaking it is as bad as leaking the database.

### 4. Create a fresh OpenAI key and add it as a host secret
`OPENAI_API_KEY`, set in the host's environment/secret UI. It must never be
typed into a file in this repository, and never into a chat.

### 5. Set a spending cap on the OpenAI account
`platform.openai.com` → Billing → Limits. `AI_DAILY_LIMIT` protects you
per-student; only a billing cap protects you from a bug or a stolen token.
Set a hard monthly maximum you are willing to lose.

### 5b. Decide how recovery email is sent
`MAIL_TRANSPORT=none` (the default) means a forgotten password is still an
unrecoverable account — the code exists, the delivery does not. Set
`MAIL_TRANSPORT=webhook` and `MAIL_WEBHOOK_URL` to something that will actually
send, and `APP_URL` if you want the message to carry a clickable link rather than
a code to paste. `MAIL_FROM` sets the sender.

This is on the "only you can do it" list because it needs an account with a
provider, a sending domain, and a deliverability reputation — three things that
belong to whoever runs the server.

### 6. Set `CORS_ORIGINS` to your frontend's exact origin
e.g. `https://ascend.yourdomain.com`. The server refuses to start in production
without it, and `*` is never accepted.

### 7. Decide where the frontend is hosted, and point it at the API
The `system/` folder is static — any static host works. As of 18.7 it ships the
`rest` driver, so no code change is needed: a student enters the API address in
**System → Gate → Set server**, the app checks `/health` before accepting it, and
signs in from there.

Two things to get right, and the app enforces the first:

* **https.** The Gate refuses an `http://` address unless it is localhost. Over
  http the session token travels in clear text on the school Wi-Fi and the
  student cannot tell.
* **`CORS_ORIGINS` must be the frontend's exact origin** (step 6). A wrong value
  here looks like "sync silently never works" rather than like an error.

If you want the address pre-filled rather than typed, set `cloudApiBase()` once
at boot from a build-time constant. It is deliberately not hardcoded now, so one
build can serve your server, a school's, and a student's own.

### 8. Decide your data-protection position
This stores accounts for students who may be 13–18. Before real users:
who is the data controller, what is the retention period, how does a parent
request deletion (`DELETE /records/:id` exists; a policy does not), and does
Ghana's Data Protection Act registration apply to you.

### 9. Arrange backups
`DEPLOYMENT.md` cannot do this for you. The database is one file at
`DATABASE_PATH`. A nightly copy off-host is the minimum. There is no "down"
migration by design — recovery from a bad schema change is a restore.

---

## PART 2 — RUNNING IT

```bash
cp server/.env.example server/.env      # fill in SESSION_PEPPER at least
npm ci
npm run server:migrate                  # applies migrations, idempotent
npm run server                          # http://localhost:8787
curl localhost:8787/health
```

Then open `system/index.html`, go to **System → Gate → Set server**, enter
`http://localhost:8787`, and create an account. That is the whole loop, locally.

### Verifying a real deployment

Two things this container cannot check for you, in order:

```bash
# 1. the API is reachable and honest about itself
curl -s https://your-api.example.com/health
#    expect  "ai": "configured"  — "not configured" means OPENAI_API_KEY is unset
#            "sessionsHardened": true  — false means SESSION_PEPPER is unset

# 2. the first live OpenAI call, from a signed-in account
#    Ask the tutor one question in the app. If it answers, the whole chain works:
#    browser → ASCEND → OpenAI → back. If it falls back to a local study card,
#    the note under the answer says which link failed.
```

Then confirm the browser is not the one holding the key — open devtools, Network,
ask the tutor again, and check that the only outbound request is to your API and
that `api.openai.com` never appears. `npm run test:secrets` proves the same thing
against the source; this proves it against what actually ran.

Tests:
```bash
npm test                # all 11 suites, frontend + backend
npm run test:backend    # 18 integration checks
npm run test:secrets    # proves the key cannot reach a browser
```

Migrations run automatically on start, inside a transaction, recorded in
`schema_migrations`. Re-running is a no-op.

---

## PART 3 — API

Identity comes from the bearer token. **The account id in a URL is never
trusted** — a mismatch is 403.

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/health` | — | real status, never a secret |
| POST | `/auth/register` | — | create account |
| POST | `/auth/session` | — | sign in → `{ token, id, entitlements }` |
| DELETE | `/auth/session` | yes | sign out, revokes immediately |
| GET | `/me` | yes | identity, entitlements, AI usage |
| GET | `/records/:id` | yes | pull → `{ rev, payload, updatedAt }` \| `null` |
| PUT | `/records/:id` | yes | push → `{ ok, rev }` or 409 with server copy |
| DELETE | `/records/:id` | yes | wipe |
| POST | `/ai/ask` | yes | tutor; modes: tutor, socratic, diagnose, practice, feedback, plan |
| GET | `/ai/usage` | yes | today's usage against the limit |

This matches the adapter shape already documented at the bottom of
`system/services/cloud.js`.

---

## PART 4 — STATUS

**IMPLEMENTED** — accounts, scrypt passwords, sessions with revocation, account
isolation, record sync with revision-based conflict detection, server-authoritative
entitlements, AI gateway with context minimisation, bounded conversation history,
response cache, server-side daily limits, audit log, rate limiting, migrations.

**IMPLEMENTED IN 18.7** — the client's `rest` driver. The frontend and the backend
now actually talk to each other, and `sync-test.js` proves it: it boots this server
on a real socket and the real app in jsdom, then behaves like two devices sharing
one account. Sign-in, cross-device pull, union merges, a real 409 re-merge, 403
isolation, server entitlements overriding the client, revocation, sign-out, offline
queueing and Wi-Fi-only suppression are each a check, and 18 of the 21 fail against
18.6. The AI tutor also routes browser → ASCEND → OpenAI; the browser holds no key
and never calls a provider, checked mechanically.

**IMPLEMENTED IN 18.11** — the event log, server-side. `POST /records/:id/events`
ingests a client's log, replays it with the *same reducers the browser uses*
(`shared/domain/`, loaded by dynamic import), and reports whether the client's
claim about its own progression matches. `GET /records/:id/events?since=<cursor>`
lets a second device catch up. Ingestion is idempotent by primary key, so a
retried sync cannot double-count XP.

Two properties worth knowing before you deploy it:

* **Nothing revokes XP or lowers a level.** A mismatch is recorded as an
  `events.divergence` audit row and reported in the response. The server cannot
  tell a tampered client from a bug in the reducer, and guessing wrong in the
  punishing direction costs an honest student their year.
* **A client ahead of the server is normal, not suspicious.** On a Ghanaian school
  connection it is the usual state. The comparison is only made after the
  submitted batch has been ingested, so offline work never reads as a lie.

Deleting cloud data now deletes the event log with it. Before 18.11 that button
would have left a complete history behind, which is the wrong answer to give a
parent asking what you hold.

**PARTIALLY IMPLEMENTED** — the AI gateway is complete and tested against a
stubbed provider, but **no live OpenAI call has ever been made**: this build
environment blocks `api.openai.com`. The first real call happens on your host.
Until then treat OpenAI connectivity as unverified. The check to run after
deploying is in PART 2.

**IMPLEMENTED IN 18.13** — password reset and email verification. Tokens are
stored hashed, expire in an hour, work once, and a completed reset revokes every
session on the account. Local data is never touched: the device PIN and the
export passphrase are separate from the account password, so a reset restores
sign-in and nothing else.

**Delivery is a choice you have to make.** `MAIL_TRANSPORT` is `none` by default
and recovery is OFF — the endpoint returns 503 and says so, rather than a
cheerful 200 that sends nothing. Set it to `webhook` with `MAIL_WEBHOOK_URL`
pointing at your provider (or a script of your own), or `log` for local
development. `log` prints the token to the server log on purpose, which is why
`/health` reports which transport is in use and why it must never be the one in
production.

**NOT IMPLEMENTED** — push notifications, curriculum delivery from the server,
multi-instance rate limiting (the limiter is per-process), Postgres.

**KNOWN TRADE-OFF** — the session token is held in `localStorage`, so any script
running on the app's origin can read it. The protection is revocability rather
than secrecy: sign-out revokes server-side, sessions expire on `SESSION_TTL_HOURS`,
and the app ships a CSP. That is an acceptable trade for a progress record. It
would not be for a payment credential, and none is stored.

---

## PART 5 — WHEN SQLITE STOPS BEING ENOUGH

It is fine for one process and, realistically, thousands of students. Swap to
Postgres when you need more than one instance, managed backups, or zero-downtime
deploys. `src/db.js` is the only file that opens a connection; the swap is that
file plus the migration dialect, not a rewrite.
